// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles

(function (modules, entry, mainEntry, parcelRequireName, globalName) {
  /* eslint-disable no-undef */
  var globalObject =
    typeof globalThis !== 'undefined'
      ? globalThis
      : typeof self !== 'undefined'
      ? self
      : typeof window !== 'undefined'
      ? window
      : typeof global !== 'undefined'
      ? global
      : {};
  /* eslint-enable no-undef */

  // Save the require from previous bundle to this closure if any
  var previousRequire =
    typeof globalObject[parcelRequireName] === 'function' &&
    globalObject[parcelRequireName];

  var cache = previousRequire.cache || {};
  // Do not use `require` to prevent Webpack from trying to bundle this call
  var nodeRequire =
    typeof module !== 'undefined' &&
    typeof module.require === 'function' &&
    module.require.bind(module);

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire =
          typeof globalObject[parcelRequireName] === 'function' &&
          globalObject[parcelRequireName];
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error("Cannot find module '" + name + "'");
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = (cache[name] = new newRequire.Module(name));

      modules[name][0].call(
        module.exports,
        localRequire,
        module,
        module.exports,
        this
      );
    }

    return cache[name].exports;

    function localRequire(x) {
      var res = localRequire.resolve(x);
      return res === false ? {} : newRequire(res);
    }

    function resolve(x) {
      var id = modules[name][1][x];
      return id != null ? id : x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [
      function (require, module) {
        module.exports = exports;
      },
      {},
    ];
  };

  Object.defineProperty(newRequire, 'root', {
    get: function () {
      return globalObject[parcelRequireName];
    },
  });

  globalObject[parcelRequireName] = newRequire;

  for (var i = 0; i < entry.length; i++) {
    newRequire(entry[i]);
  }

  if (mainEntry) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(mainEntry);

    // CommonJS
    if (typeof exports === 'object' && typeof module !== 'undefined') {
      module.exports = mainExports;

      // RequireJS
    } else if (typeof define === 'function' && define.amd) {
      define(function () {
        return mainExports;
      });

      // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }
})({"jpdoD":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
var _axios = require("axios");
var _axiosDefault = parcelHelpers.interopDefault(_axios);
let username;
let isChrome = false;
//storage helpers
let browserStorage;
if (typeof browser === "undefined") {
    browserStorage = chrome.storage.local;
    isChrome = true;
} else browserStorage = browser.storage.local;
async function get(key) {
    const userKey = `${username}-${key}`;
    return (await browserStorage.get(userKey))[userKey];
}
async function set(key, val) {
    const data = {};
    const userKey = `${username}-${key}`;
    data[userKey] = val;
    await browserStorage.set(data);
}
function isDescendantOfTag(element, tagName) {
    while(element.parentElement){
        if (element.parentElement.tagName.toLowerCase() === tagName.toLowerCase()) return true;
        element = element.parentElement;
    }
    return false;
}
function getUsername() {
    const links = document.querySelectorAll('a[href^="/users/"]');
    const link = Array.from(links).find((link)=>!isDescendantOfTag(link, "table"));
    if (!link || !link.href) return undefined;
    const parts = link.href.split("/users/");
    if (parts.length > 1) return parts[1]; // Returns everything after "users/"
}
async function timeout(ms) {
    return await new Promise((resolve)=>setTimeout(resolve, ms));
}
async function getSubmissionPages(username, getAllPages) {
    const output = [];
    let page = 0;
    while(true){
        const url = `/users/${username}?tab=submissions&page=${page}&status=AC`;
        page++;
        const { data } = await (0, _axiosDefault.default).get(url);
        const parser = new DOMParser();
        const htmlDoc = parser.parseFromString(data, "text/html");
        const rows = htmlDoc.querySelectorAll("#submissions tbody tr");
        rows.forEach((row)=>{
            const accepted = row.querySelector("div.is-status-accepted");
            if (accepted) {
                let time = row.querySelector('td[data-type="time"]').textContent.trim();
                if (time.length <= 10) {
                    const currentDate = new Date();
                    const year = currentDate.getFullYear();
                    const month = String(currentDate.getMonth() + 1).padStart(2, "0"); // Month starts from 0
                    const day = String(currentDate.getDate()).padStart(2, "0");
                    const formattedDate = `${year}-${month}-${day} `;
                    time = formattedDate + time;
                }
                const submissionId = row.querySelector('td[data-type="actions"] a').href.split("/").pop();
                const problemLinks = row.querySelectorAll('td[data-type="problem"] a');
                const problemId = problemLinks[problemLinks.length - 1].href.split("/").pop();
                output.push({
                    problemId,
                    submissionId,
                    timestamp: new Date(time).getTime()
                });
            }
        });
        await timeout(1000);
        if (!getAllPages || rows.length === 0) break;
    }
    return output;
}
function isOverADayAgo(date) {
    return date < Date.now() - 86400000;
}
async function submit(submissions, isAll) {
    await (0, _axiosDefault.default).post("https://byu-cpc-backend-tqxfeezgfa-uw.a.run.app/kattis_submit", {
        username,
        submissions,
        isAll
    });
}
async function setSubmitting() {
    const badge = document.createElement("div");
    badge.id = "syncingBadge";
    badge.classList.add("shrink");
    badge.innerHTML = `Syncing <div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>`;
    document.body.appendChild(badge);
    const newBadge = document.getElementById("syncingBadge");
    await timeout(10);
    newBadge.classList.remove("shrink");
}
async function unsetSubmitting() {
    const badge = document.getElementById("syncingBadge");
    badge.classList.add("shrink");
    await timeout(500);
    if (badge) document.body.removeChild(badge);
}
async function syncAndSubmit(username) {
    setSubmitting();
    const initialSync = await get("initial-sync");
    const lastFullSync = await get("last-full-sync");
    const getAllPages = !initialSync || !lastFullSync || isOverADayAgo(lastFullSync);
    const submissions = await getSubmissionPages(username, getAllPages);
    await submit(submissions, getAllPages);
    if (getAllPages) {
        await set("initial-sync", true);
        await set("last-full-sync", Date.now());
    }
    unsetSubmitting();
}
async function main() {
    username = getUsername();
    if (!username) return;
    await syncAndSubmit(username);
}
main();

},{"axios":"xn2dJ","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"xn2dJ":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>(0, _axiosJsDefault.default));
parcelHelpers.export(exports, "Axios", ()=>Axios);
parcelHelpers.export(exports, "AxiosError", ()=>AxiosError);
parcelHelpers.export(exports, "CanceledError", ()=>CanceledError);
parcelHelpers.export(exports, "isCancel", ()=>isCancel);
parcelHelpers.export(exports, "CancelToken", ()=>CancelToken);
parcelHelpers.export(exports, "VERSION", ()=>VERSION);
parcelHelpers.export(exports, "all", ()=>all);
parcelHelpers.export(exports, "Cancel", ()=>Cancel);
parcelHelpers.export(exports, "isAxiosError", ()=>isAxiosError);
parcelHelpers.export(exports, "spread", ()=>spread);
parcelHelpers.export(exports, "toFormData", ()=>toFormData);
parcelHelpers.export(exports, "AxiosHeaders", ()=>AxiosHeaders);
parcelHelpers.export(exports, "HttpStatusCode", ()=>HttpStatusCode);
parcelHelpers.export(exports, "formToJSON", ()=>formToJSON);
parcelHelpers.export(exports, "getAdapter", ()=>getAdapter);
parcelHelpers.export(exports, "mergeConfig", ()=>mergeConfig);
var _axiosJs = require("./lib/axios.js");
var _axiosJsDefault = parcelHelpers.interopDefault(_axiosJs);
// This module is intended to unwrap Axios default export as named.
// Keep top-level export same with static properties
// so that it can keep same with es module or cjs
const { Axios, AxiosError, CanceledError, isCancel, CancelToken, VERSION, all, Cancel, isAxiosError, spread, toFormData, AxiosHeaders, HttpStatusCode, formToJSON, getAdapter, mergeConfig } = (0, _axiosJsDefault.default);

},{"./lib/axios.js":"i7Teu","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"i7Teu":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _utilsJs = require("./utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
var _bindJs = require("./helpers/bind.js");
var _bindJsDefault = parcelHelpers.interopDefault(_bindJs);
var _axiosJs = require("./core/Axios.js");
var _axiosJsDefault = parcelHelpers.interopDefault(_axiosJs);
var _mergeConfigJs = require("./core/mergeConfig.js");
var _mergeConfigJsDefault = parcelHelpers.interopDefault(_mergeConfigJs);
var _indexJs = require("./defaults/index.js");
var _indexJsDefault = parcelHelpers.interopDefault(_indexJs);
var _formDataToJSONJs = require("./helpers/formDataToJSON.js");
var _formDataToJSONJsDefault = parcelHelpers.interopDefault(_formDataToJSONJs);
var _canceledErrorJs = require("./cancel/CanceledError.js");
var _canceledErrorJsDefault = parcelHelpers.interopDefault(_canceledErrorJs);
var _cancelTokenJs = require("./cancel/CancelToken.js");
var _cancelTokenJsDefault = parcelHelpers.interopDefault(_cancelTokenJs);
var _isCancelJs = require("./cancel/isCancel.js");
var _isCancelJsDefault = parcelHelpers.interopDefault(_isCancelJs);
var _dataJs = require("./env/data.js");
var _toFormDataJs = require("./helpers/toFormData.js");
var _toFormDataJsDefault = parcelHelpers.interopDefault(_toFormDataJs);
var _axiosErrorJs = require("./core/AxiosError.js");
var _axiosErrorJsDefault = parcelHelpers.interopDefault(_axiosErrorJs);
var _spreadJs = require("./helpers/spread.js");
var _spreadJsDefault = parcelHelpers.interopDefault(_spreadJs);
var _isAxiosErrorJs = require("./helpers/isAxiosError.js");
var _isAxiosErrorJsDefault = parcelHelpers.interopDefault(_isAxiosErrorJs);
var _axiosHeadersJs = require("./core/AxiosHeaders.js");
var _axiosHeadersJsDefault = parcelHelpers.interopDefault(_axiosHeadersJs);
var _adaptersJs = require("./adapters/adapters.js");
var _adaptersJsDefault = parcelHelpers.interopDefault(_adaptersJs);
var _httpStatusCodeJs = require("./helpers/HttpStatusCode.js");
var _httpStatusCodeJsDefault = parcelHelpers.interopDefault(_httpStatusCodeJs);
"use strict";
/**
 * Create an instance of Axios
 *
 * @param {Object} defaultConfig The default config for the instance
 *
 * @returns {Axios} A new instance of Axios
 */ function createInstance(defaultConfig) {
    const context = new (0, _axiosJsDefault.default)(defaultConfig);
    const instance = (0, _bindJsDefault.default)((0, _axiosJsDefault.default).prototype.request, context);
    // Copy axios.prototype to instance
    (0, _utilsJsDefault.default).extend(instance, (0, _axiosJsDefault.default).prototype, context, {
        allOwnKeys: true
    });
    // Copy context to instance
    (0, _utilsJsDefault.default).extend(instance, context, null, {
        allOwnKeys: true
    });
    // Factory for creating new instances
    instance.create = function create(instanceConfig) {
        return createInstance((0, _mergeConfigJsDefault.default)(defaultConfig, instanceConfig));
    };
    return instance;
}
// Create the default instance to be exported
const axios = createInstance((0, _indexJsDefault.default));
// Expose Axios class to allow class inheritance
axios.Axios = (0, _axiosJsDefault.default);
// Expose Cancel & CancelToken
axios.CanceledError = (0, _canceledErrorJsDefault.default);
axios.CancelToken = (0, _cancelTokenJsDefault.default);
axios.isCancel = (0, _isCancelJsDefault.default);
axios.VERSION = (0, _dataJs.VERSION);
axios.toFormData = (0, _toFormDataJsDefault.default);
// Expose AxiosError class
axios.AxiosError = (0, _axiosErrorJsDefault.default);
// alias for CanceledError for backward compatibility
axios.Cancel = axios.CanceledError;
// Expose all/spread
axios.all = function all(promises) {
    return Promise.all(promises);
};
axios.spread = (0, _spreadJsDefault.default);
// Expose isAxiosError
axios.isAxiosError = (0, _isAxiosErrorJsDefault.default);
// Expose mergeConfig
axios.mergeConfig = (0, _mergeConfigJsDefault.default);
axios.AxiosHeaders = (0, _axiosHeadersJsDefault.default);
axios.formToJSON = (thing)=>(0, _formDataToJSONJsDefault.default)((0, _utilsJsDefault.default).isHTMLForm(thing) ? new FormData(thing) : thing);
axios.getAdapter = (0, _adaptersJsDefault.default).getAdapter;
axios.HttpStatusCode = (0, _httpStatusCodeJsDefault.default);
axios.default = axios;
// this module should only have a default export
exports.default = axios;

},{"./utils.js":"dNjua","./helpers/bind.js":"3O9Bk","./core/Axios.js":"aLtF0","./core/mergeConfig.js":"hQkWT","./defaults/index.js":"kStuG","./helpers/formDataToJSON.js":"bKZdy","./cancel/CanceledError.js":"byMZp","./cancel/CancelToken.js":"eY4pT","./cancel/isCancel.js":"i4WpT","./env/data.js":"77oTH","./helpers/toFormData.js":"kEMey","./core/AxiosError.js":"1OwwO","./helpers/spread.js":"8C5in","./helpers/isAxiosError.js":"h3Ewf","./core/AxiosHeaders.js":"gTOgd","./adapters/adapters.js":"fDdzI","./helpers/HttpStatusCode.js":"55iB3","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"dNjua":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _bindJs = require("./helpers/bind.js");
var _bindJsDefault = parcelHelpers.interopDefault(_bindJs);
var global = arguments[3];
"use strict";
// utils is a library of generic helper functions non-specific to axios
const { toString } = Object.prototype;
const { getPrototypeOf } = Object;
const kindOf = ((cache)=>(thing)=>{
        const str = toString.call(thing);
        return cache[str] || (cache[str] = str.slice(8, -1).toLowerCase());
    })(Object.create(null));
const kindOfTest = (type)=>{
    type = type.toLowerCase();
    return (thing)=>kindOf(thing) === type;
};
const typeOfTest = (type)=>(thing)=>typeof thing === type;
/**
 * Determine if a value is an Array
 *
 * @param {Object} val The value to test
 *
 * @returns {boolean} True if value is an Array, otherwise false
 */ const { isArray } = Array;
/**
 * Determine if a value is undefined
 *
 * @param {*} val The value to test
 *
 * @returns {boolean} True if the value is undefined, otherwise false
 */ const isUndefined = typeOfTest("undefined");
/**
 * Determine if a value is a Buffer
 *
 * @param {*} val The value to test
 *
 * @returns {boolean} True if value is a Buffer, otherwise false
 */ function isBuffer(val) {
    return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor) && isFunction(val.constructor.isBuffer) && val.constructor.isBuffer(val);
}
/**
 * Determine if a value is an ArrayBuffer
 *
 * @param {*} val The value to test
 *
 * @returns {boolean} True if value is an ArrayBuffer, otherwise false
 */ const isArrayBuffer = kindOfTest("ArrayBuffer");
/**
 * Determine if a value is a view on an ArrayBuffer
 *
 * @param {*} val The value to test
 *
 * @returns {boolean} True if value is a view on an ArrayBuffer, otherwise false
 */ function isArrayBufferView(val) {
    let result;
    if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) result = ArrayBuffer.isView(val);
    else result = val && val.buffer && isArrayBuffer(val.buffer);
    return result;
}
/**
 * Determine if a value is a String
 *
 * @param {*} val The value to test
 *
 * @returns {boolean} True if value is a String, otherwise false
 */ const isString = typeOfTest("string");
/**
 * Determine if a value is a Function
 *
 * @param {*} val The value to test
 * @returns {boolean} True if value is a Function, otherwise false
 */ const isFunction = typeOfTest("function");
/**
 * Determine if a value is a Number
 *
 * @param {*} val The value to test
 *
 * @returns {boolean} True if value is a Number, otherwise false
 */ const isNumber = typeOfTest("number");
/**
 * Determine if a value is an Object
 *
 * @param {*} thing The value to test
 *
 * @returns {boolean} True if value is an Object, otherwise false
 */ const isObject = (thing)=>thing !== null && typeof thing === "object";
/**
 * Determine if a value is a Boolean
 *
 * @param {*} thing The value to test
 * @returns {boolean} True if value is a Boolean, otherwise false
 */ const isBoolean = (thing)=>thing === true || thing === false;
/**
 * Determine if a value is a plain Object
 *
 * @param {*} val The value to test
 *
 * @returns {boolean} True if value is a plain Object, otherwise false
 */ const isPlainObject = (val)=>{
    if (kindOf(val) !== "object") return false;
    const prototype = getPrototypeOf(val);
    return (prototype === null || prototype === Object.prototype || Object.getPrototypeOf(prototype) === null) && !(Symbol.toStringTag in val) && !(Symbol.iterator in val);
};
/**
 * Determine if a value is a Date
 *
 * @param {*} val The value to test
 *
 * @returns {boolean} True if value is a Date, otherwise false
 */ const isDate = kindOfTest("Date");
/**
 * Determine if a value is a File
 *
 * @param {*} val The value to test
 *
 * @returns {boolean} True if value is a File, otherwise false
 */ const isFile = kindOfTest("File");
/**
 * Determine if a value is a Blob
 *
 * @param {*} val The value to test
 *
 * @returns {boolean} True if value is a Blob, otherwise false
 */ const isBlob = kindOfTest("Blob");
/**
 * Determine if a value is a FileList
 *
 * @param {*} val The value to test
 *
 * @returns {boolean} True if value is a File, otherwise false
 */ const isFileList = kindOfTest("FileList");
/**
 * Determine if a value is a Stream
 *
 * @param {*} val The value to test
 *
 * @returns {boolean} True if value is a Stream, otherwise false
 */ const isStream = (val)=>isObject(val) && isFunction(val.pipe);
/**
 * Determine if a value is a FormData
 *
 * @param {*} thing The value to test
 *
 * @returns {boolean} True if value is an FormData, otherwise false
 */ const isFormData = (thing)=>{
    let kind;
    return thing && (typeof FormData === "function" && thing instanceof FormData || isFunction(thing.append) && ((kind = kindOf(thing)) === "formdata" || // detect form-data instance
    kind === "object" && isFunction(thing.toString) && thing.toString() === "[object FormData]"));
};
/**
 * Determine if a value is a URLSearchParams object
 *
 * @param {*} val The value to test
 *
 * @returns {boolean} True if value is a URLSearchParams object, otherwise false
 */ const isURLSearchParams = kindOfTest("URLSearchParams");
/**
 * Trim excess whitespace off the beginning and end of a string
 *
 * @param {String} str The String to trim
 *
 * @returns {String} The String freed of excess whitespace
 */ const trim = (str)=>str.trim ? str.trim() : str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
/**
 * Iterate over an Array or an Object invoking a function for each item.
 *
 * If `obj` is an Array callback will be called passing
 * the value, index, and complete array for each item.
 *
 * If 'obj' is an Object callback will be called passing
 * the value, key, and complete object for each property.
 *
 * @param {Object|Array} obj The object to iterate
 * @param {Function} fn The callback to invoke for each item
 *
 * @param {Boolean} [allOwnKeys = false]
 * @returns {any}
 */ function forEach(obj, fn, { allOwnKeys = false } = {}) {
    // Don't bother if no value provided
    if (obj === null || typeof obj === "undefined") return;
    let i;
    let l;
    // Force an array if not already something iterable
    if (typeof obj !== "object") /*eslint no-param-reassign:0*/ obj = [
        obj
    ];
    if (isArray(obj)) // Iterate over array values
    for(i = 0, l = obj.length; i < l; i++)fn.call(null, obj[i], i, obj);
    else {
        // Iterate over object keys
        const keys = allOwnKeys ? Object.getOwnPropertyNames(obj) : Object.keys(obj);
        const len = keys.length;
        let key;
        for(i = 0; i < len; i++){
            key = keys[i];
            fn.call(null, obj[key], key, obj);
        }
    }
}
function findKey(obj, key) {
    key = key.toLowerCase();
    const keys = Object.keys(obj);
    let i = keys.length;
    let _key;
    while(i-- > 0){
        _key = keys[i];
        if (key === _key.toLowerCase()) return _key;
    }
    return null;
}
const _global = (()=>{
    /*eslint no-undef:0*/ if (typeof globalThis !== "undefined") return globalThis;
    return typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : global;
})();
const isContextDefined = (context)=>!isUndefined(context) && context !== _global;
/**
 * Accepts varargs expecting each argument to be an object, then
 * immutably merges the properties of each object and returns result.
 *
 * When multiple objects contain the same key the later object in
 * the arguments list will take precedence.
 *
 * Example:
 *
 * ```js
 * var result = merge({foo: 123}, {foo: 456});
 * console.log(result.foo); // outputs 456
 * ```
 *
 * @param {Object} obj1 Object to merge
 *
 * @returns {Object} Result of all merge properties
 */ function merge() {
    const { caseless } = isContextDefined(this) && this || {};
    const result = {};
    const assignValue = (val, key)=>{
        const targetKey = caseless && findKey(result, key) || key;
        if (isPlainObject(result[targetKey]) && isPlainObject(val)) result[targetKey] = merge(result[targetKey], val);
        else if (isPlainObject(val)) result[targetKey] = merge({}, val);
        else if (isArray(val)) result[targetKey] = val.slice();
        else result[targetKey] = val;
    };
    for(let i = 0, l = arguments.length; i < l; i++)arguments[i] && forEach(arguments[i], assignValue);
    return result;
}
/**
 * Extends object a by mutably adding to it the properties of object b.
 *
 * @param {Object} a The object to be extended
 * @param {Object} b The object to copy properties from
 * @param {Object} thisArg The object to bind function to
 *
 * @param {Boolean} [allOwnKeys]
 * @returns {Object} The resulting value of object a
 */ const extend = (a, b, thisArg, { allOwnKeys } = {})=>{
    forEach(b, (val, key)=>{
        if (thisArg && isFunction(val)) a[key] = (0, _bindJsDefault.default)(val, thisArg);
        else a[key] = val;
    }, {
        allOwnKeys
    });
    return a;
};
/**
 * Remove byte order marker. This catches EF BB BF (the UTF-8 BOM)
 *
 * @param {string} content with BOM
 *
 * @returns {string} content value without BOM
 */ const stripBOM = (content)=>{
    if (content.charCodeAt(0) === 0xFEFF) content = content.slice(1);
    return content;
};
/**
 * Inherit the prototype methods from one constructor into another
 * @param {function} constructor
 * @param {function} superConstructor
 * @param {object} [props]
 * @param {object} [descriptors]
 *
 * @returns {void}
 */ const inherits = (constructor, superConstructor, props, descriptors)=>{
    constructor.prototype = Object.create(superConstructor.prototype, descriptors);
    constructor.prototype.constructor = constructor;
    Object.defineProperty(constructor, "super", {
        value: superConstructor.prototype
    });
    props && Object.assign(constructor.prototype, props);
};
/**
 * Resolve object with deep prototype chain to a flat object
 * @param {Object} sourceObj source object
 * @param {Object} [destObj]
 * @param {Function|Boolean} [filter]
 * @param {Function} [propFilter]
 *
 * @returns {Object}
 */ const toFlatObject = (sourceObj, destObj, filter, propFilter)=>{
    let props;
    let i;
    let prop;
    const merged = {};
    destObj = destObj || {};
    // eslint-disable-next-line no-eq-null,eqeqeq
    if (sourceObj == null) return destObj;
    do {
        props = Object.getOwnPropertyNames(sourceObj);
        i = props.length;
        while(i-- > 0){
            prop = props[i];
            if ((!propFilter || propFilter(prop, sourceObj, destObj)) && !merged[prop]) {
                destObj[prop] = sourceObj[prop];
                merged[prop] = true;
            }
        }
        sourceObj = filter !== false && getPrototypeOf(sourceObj);
    }while (sourceObj && (!filter || filter(sourceObj, destObj)) && sourceObj !== Object.prototype);
    return destObj;
};
/**
 * Determines whether a string ends with the characters of a specified string
 *
 * @param {String} str
 * @param {String} searchString
 * @param {Number} [position= 0]
 *
 * @returns {boolean}
 */ const endsWith = (str, searchString, position)=>{
    str = String(str);
    if (position === undefined || position > str.length) position = str.length;
    position -= searchString.length;
    const lastIndex = str.indexOf(searchString, position);
    return lastIndex !== -1 && lastIndex === position;
};
/**
 * Returns new array from array like object or null if failed
 *
 * @param {*} [thing]
 *
 * @returns {?Array}
 */ const toArray = (thing)=>{
    if (!thing) return null;
    if (isArray(thing)) return thing;
    let i = thing.length;
    if (!isNumber(i)) return null;
    const arr = new Array(i);
    while(i-- > 0)arr[i] = thing[i];
    return arr;
};
/**
 * Checking if the Uint8Array exists and if it does, it returns a function that checks if the
 * thing passed in is an instance of Uint8Array
 *
 * @param {TypedArray}
 *
 * @returns {Array}
 */ // eslint-disable-next-line func-names
const isTypedArray = ((TypedArray)=>{
    // eslint-disable-next-line func-names
    return (thing)=>{
        return TypedArray && thing instanceof TypedArray;
    };
})(typeof Uint8Array !== "undefined" && getPrototypeOf(Uint8Array));
/**
 * For each entry in the object, call the function with the key and value.
 *
 * @param {Object<any, any>} obj - The object to iterate over.
 * @param {Function} fn - The function to call for each entry.
 *
 * @returns {void}
 */ const forEachEntry = (obj, fn)=>{
    const generator = obj && obj[Symbol.iterator];
    const iterator = generator.call(obj);
    let result;
    while((result = iterator.next()) && !result.done){
        const pair = result.value;
        fn.call(obj, pair[0], pair[1]);
    }
};
/**
 * It takes a regular expression and a string, and returns an array of all the matches
 *
 * @param {string} regExp - The regular expression to match against.
 * @param {string} str - The string to search.
 *
 * @returns {Array<boolean>}
 */ const matchAll = (regExp, str)=>{
    let matches;
    const arr = [];
    while((matches = regExp.exec(str)) !== null)arr.push(matches);
    return arr;
};
/* Checking if the kindOfTest function returns true when passed an HTMLFormElement. */ const isHTMLForm = kindOfTest("HTMLFormElement");
const toCamelCase = (str)=>{
    return str.toLowerCase().replace(/[-_\s]([a-z\d])(\w*)/g, function replacer(m, p1, p2) {
        return p1.toUpperCase() + p2;
    });
};
/* Creating a function that will check if an object has a property. */ const hasOwnProperty = (({ hasOwnProperty })=>(obj, prop)=>hasOwnProperty.call(obj, prop))(Object.prototype);
/**
 * Determine if a value is a RegExp object
 *
 * @param {*} val The value to test
 *
 * @returns {boolean} True if value is a RegExp object, otherwise false
 */ const isRegExp = kindOfTest("RegExp");
const reduceDescriptors = (obj, reducer)=>{
    const descriptors = Object.getOwnPropertyDescriptors(obj);
    const reducedDescriptors = {};
    forEach(descriptors, (descriptor, name)=>{
        let ret;
        if ((ret = reducer(descriptor, name, obj)) !== false) reducedDescriptors[name] = ret || descriptor;
    });
    Object.defineProperties(obj, reducedDescriptors);
};
/**
 * Makes all methods read-only
 * @param {Object} obj
 */ const freezeMethods = (obj)=>{
    reduceDescriptors(obj, (descriptor, name)=>{
        // skip restricted props in strict mode
        if (isFunction(obj) && [
            "arguments",
            "caller",
            "callee"
        ].indexOf(name) !== -1) return false;
        const value = obj[name];
        if (!isFunction(value)) return;
        descriptor.enumerable = false;
        if ("writable" in descriptor) {
            descriptor.writable = false;
            return;
        }
        if (!descriptor.set) descriptor.set = ()=>{
            throw Error("Can not rewrite read-only method '" + name + "'");
        };
    });
};
const toObjectSet = (arrayOrString, delimiter)=>{
    const obj = {};
    const define = (arr)=>{
        arr.forEach((value)=>{
            obj[value] = true;
        });
    };
    isArray(arrayOrString) ? define(arrayOrString) : define(String(arrayOrString).split(delimiter));
    return obj;
};
const noop = ()=>{};
const toFiniteNumber = (value, defaultValue)=>{
    value = +value;
    return Number.isFinite(value) ? value : defaultValue;
};
const ALPHA = "abcdefghijklmnopqrstuvwxyz";
const DIGIT = "0123456789";
const ALPHABET = {
    DIGIT,
    ALPHA,
    ALPHA_DIGIT: ALPHA + ALPHA.toUpperCase() + DIGIT
};
const generateString = (size = 16, alphabet = ALPHABET.ALPHA_DIGIT)=>{
    let str = "";
    const { length } = alphabet;
    while(size--)str += alphabet[Math.random() * length | 0];
    return str;
};
/**
 * If the thing is a FormData object, return true, otherwise return false.
 *
 * @param {unknown} thing - The thing to check.
 *
 * @returns {boolean}
 */ function isSpecCompliantForm(thing) {
    return !!(thing && isFunction(thing.append) && thing[Symbol.toStringTag] === "FormData" && thing[Symbol.iterator]);
}
const toJSONObject = (obj)=>{
    const stack = new Array(10);
    const visit = (source, i)=>{
        if (isObject(source)) {
            if (stack.indexOf(source) >= 0) return;
            if (!("toJSON" in source)) {
                stack[i] = source;
                const target = isArray(source) ? [] : {};
                forEach(source, (value, key)=>{
                    const reducedValue = visit(value, i + 1);
                    !isUndefined(reducedValue) && (target[key] = reducedValue);
                });
                stack[i] = undefined;
                return target;
            }
        }
        return source;
    };
    return visit(obj, 0);
};
const isAsyncFn = kindOfTest("AsyncFunction");
const isThenable = (thing)=>thing && (isObject(thing) || isFunction(thing)) && isFunction(thing.then) && isFunction(thing.catch);
exports.default = {
    isArray,
    isArrayBuffer,
    isBuffer,
    isFormData,
    isArrayBufferView,
    isString,
    isNumber,
    isBoolean,
    isObject,
    isPlainObject,
    isUndefined,
    isDate,
    isFile,
    isBlob,
    isRegExp,
    isFunction,
    isStream,
    isURLSearchParams,
    isTypedArray,
    isFileList,
    forEach,
    merge,
    extend,
    trim,
    stripBOM,
    inherits,
    toFlatObject,
    kindOf,
    kindOfTest,
    endsWith,
    toArray,
    forEachEntry,
    matchAll,
    isHTMLForm,
    hasOwnProperty,
    hasOwnProp: hasOwnProperty,
    reduceDescriptors,
    freezeMethods,
    toObjectSet,
    toCamelCase,
    noop,
    toFiniteNumber,
    findKey,
    global: _global,
    isContextDefined,
    ALPHABET,
    generateString,
    isSpecCompliantForm,
    toJSONObject,
    isAsyncFn,
    isThenable
};

},{"./helpers/bind.js":"3O9Bk","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"3O9Bk":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>bind);
"use strict";
function bind(fn, thisArg) {
    return function wrap() {
        return fn.apply(thisArg, arguments);
    };
}

},{"@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"8ISrk":[function(require,module,exports) {
exports.interopDefault = function(a) {
    return a && a.__esModule ? a : {
        default: a
    };
};
exports.defineInteropFlag = function(a) {
    Object.defineProperty(a, "__esModule", {
        value: true
    });
};
exports.exportAll = function(source, dest) {
    Object.keys(source).forEach(function(key) {
        if (key === "default" || key === "__esModule" || Object.prototype.hasOwnProperty.call(dest, key)) return;
        Object.defineProperty(dest, key, {
            enumerable: true,
            get: function() {
                return source[key];
            }
        });
    });
    return dest;
};
exports.export = function(dest, destName, get) {
    Object.defineProperty(dest, destName, {
        enumerable: true,
        get: get
    });
};

},{}],"aLtF0":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _utilsJs = require("./../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
var _buildURLJs = require("../helpers/buildURL.js");
var _buildURLJsDefault = parcelHelpers.interopDefault(_buildURLJs);
var _interceptorManagerJs = require("./InterceptorManager.js");
var _interceptorManagerJsDefault = parcelHelpers.interopDefault(_interceptorManagerJs);
var _dispatchRequestJs = require("./dispatchRequest.js");
var _dispatchRequestJsDefault = parcelHelpers.interopDefault(_dispatchRequestJs);
var _mergeConfigJs = require("./mergeConfig.js");
var _mergeConfigJsDefault = parcelHelpers.interopDefault(_mergeConfigJs);
var _buildFullPathJs = require("./buildFullPath.js");
var _buildFullPathJsDefault = parcelHelpers.interopDefault(_buildFullPathJs);
var _validatorJs = require("../helpers/validator.js");
var _validatorJsDefault = parcelHelpers.interopDefault(_validatorJs);
var _axiosHeadersJs = require("./AxiosHeaders.js");
var _axiosHeadersJsDefault = parcelHelpers.interopDefault(_axiosHeadersJs);
"use strict";
const validators = (0, _validatorJsDefault.default).validators;
/**
 * Create a new instance of Axios
 *
 * @param {Object} instanceConfig The default config for the instance
 *
 * @return {Axios} A new instance of Axios
 */ class Axios {
    constructor(instanceConfig){
        this.defaults = instanceConfig;
        this.interceptors = {
            request: new (0, _interceptorManagerJsDefault.default)(),
            response: new (0, _interceptorManagerJsDefault.default)()
        };
    }
    /**
   * Dispatch a request
   *
   * @param {String|Object} configOrUrl The config specific for this request (merged with this.defaults)
   * @param {?Object} config
   *
   * @returns {Promise} The Promise to be fulfilled
   */ async request(configOrUrl, config) {
        try {
            return await this._request(configOrUrl, config);
        } catch (err) {
            if (err instanceof Error) {
                let dummy;
                Error.captureStackTrace ? Error.captureStackTrace(dummy = {}) : dummy = new Error();
                // slice off the Error: ... line
                const stack = dummy.stack ? dummy.stack.replace(/^.+\n/, "") : "";
                if (!err.stack) err.stack = stack;
                else if (stack && !String(err.stack).endsWith(stack.replace(/^.+\n.+\n/, ""))) err.stack += "\n" + stack;
            }
            throw err;
        }
    }
    _request(configOrUrl, config) {
        /*eslint no-param-reassign:0*/ // Allow for axios('example/url'[, config]) a la fetch API
        if (typeof configOrUrl === "string") {
            config = config || {};
            config.url = configOrUrl;
        } else config = configOrUrl || {};
        config = (0, _mergeConfigJsDefault.default)(this.defaults, config);
        const { transitional, paramsSerializer, headers } = config;
        if (transitional !== undefined) (0, _validatorJsDefault.default).assertOptions(transitional, {
            silentJSONParsing: validators.transitional(validators.boolean),
            forcedJSONParsing: validators.transitional(validators.boolean),
            clarifyTimeoutError: validators.transitional(validators.boolean)
        }, false);
        if (paramsSerializer != null) {
            if ((0, _utilsJsDefault.default).isFunction(paramsSerializer)) config.paramsSerializer = {
                serialize: paramsSerializer
            };
            else (0, _validatorJsDefault.default).assertOptions(paramsSerializer, {
                encode: validators.function,
                serialize: validators.function
            }, true);
        }
        // Set config.method
        config.method = (config.method || this.defaults.method || "get").toLowerCase();
        // Flatten headers
        let contextHeaders = headers && (0, _utilsJsDefault.default).merge(headers.common, headers[config.method]);
        headers && (0, _utilsJsDefault.default).forEach([
            "delete",
            "get",
            "head",
            "post",
            "put",
            "patch",
            "common"
        ], (method)=>{
            delete headers[method];
        });
        config.headers = (0, _axiosHeadersJsDefault.default).concat(contextHeaders, headers);
        // filter out skipped interceptors
        const requestInterceptorChain = [];
        let synchronousRequestInterceptors = true;
        this.interceptors.request.forEach(function unshiftRequestInterceptors(interceptor) {
            if (typeof interceptor.runWhen === "function" && interceptor.runWhen(config) === false) return;
            synchronousRequestInterceptors = synchronousRequestInterceptors && interceptor.synchronous;
            requestInterceptorChain.unshift(interceptor.fulfilled, interceptor.rejected);
        });
        const responseInterceptorChain = [];
        this.interceptors.response.forEach(function pushResponseInterceptors(interceptor) {
            responseInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
        });
        let promise;
        let i = 0;
        let len;
        if (!synchronousRequestInterceptors) {
            const chain = [
                (0, _dispatchRequestJsDefault.default).bind(this),
                undefined
            ];
            chain.unshift.apply(chain, requestInterceptorChain);
            chain.push.apply(chain, responseInterceptorChain);
            len = chain.length;
            promise = Promise.resolve(config);
            while(i < len)promise = promise.then(chain[i++], chain[i++]);
            return promise;
        }
        len = requestInterceptorChain.length;
        let newConfig = config;
        i = 0;
        while(i < len){
            const onFulfilled = requestInterceptorChain[i++];
            const onRejected = requestInterceptorChain[i++];
            try {
                newConfig = onFulfilled(newConfig);
            } catch (error) {
                onRejected.call(this, error);
                break;
            }
        }
        try {
            promise = (0, _dispatchRequestJsDefault.default).call(this, newConfig);
        } catch (error) {
            return Promise.reject(error);
        }
        i = 0;
        len = responseInterceptorChain.length;
        while(i < len)promise = promise.then(responseInterceptorChain[i++], responseInterceptorChain[i++]);
        return promise;
    }
    getUri(config) {
        config = (0, _mergeConfigJsDefault.default)(this.defaults, config);
        const fullPath = (0, _buildFullPathJsDefault.default)(config.baseURL, config.url);
        return (0, _buildURLJsDefault.default)(fullPath, config.params, config.paramsSerializer);
    }
}
// Provide aliases for supported request methods
(0, _utilsJsDefault.default).forEach([
    "delete",
    "get",
    "head",
    "options"
], function forEachMethodNoData(method) {
    /*eslint func-names:0*/ Axios.prototype[method] = function(url, config) {
        return this.request((0, _mergeConfigJsDefault.default)(config || {}, {
            method,
            url,
            data: (config || {}).data
        }));
    };
});
(0, _utilsJsDefault.default).forEach([
    "post",
    "put",
    "patch"
], function forEachMethodWithData(method) {
    /*eslint func-names:0*/ function generateHTTPMethod(isForm) {
        return function httpMethod(url, data, config) {
            return this.request((0, _mergeConfigJsDefault.default)(config || {}, {
                method,
                headers: isForm ? {
                    "Content-Type": "multipart/form-data"
                } : {},
                url,
                data
            }));
        };
    }
    Axios.prototype[method] = generateHTTPMethod();
    Axios.prototype[method + "Form"] = generateHTTPMethod(true);
});
exports.default = Axios;

},{"./../utils.js":"dNjua","../helpers/buildURL.js":"gdwll","./InterceptorManager.js":"e61UM","./dispatchRequest.js":"65aou","./mergeConfig.js":"hQkWT","./buildFullPath.js":"ey4Hd","../helpers/validator.js":"71Yni","./AxiosHeaders.js":"gTOgd","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"gdwll":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>buildURL);
var _utilsJs = require("../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
var _axiosURLSearchParamsJs = require("../helpers/AxiosURLSearchParams.js");
var _axiosURLSearchParamsJsDefault = parcelHelpers.interopDefault(_axiosURLSearchParamsJs);
"use strict";
/**
 * It replaces all instances of the characters `:`, `$`, `,`, `+`, `[`, and `]` with their
 * URI encoded counterparts
 *
 * @param {string} val The value to be encoded.
 *
 * @returns {string} The encoded value.
 */ function encode(val) {
    return encodeURIComponent(val).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]");
}
function buildURL(url, params, options) {
    /*eslint no-param-reassign:0*/ if (!params) return url;
    const _encode = options && options.encode || encode;
    const serializeFn = options && options.serialize;
    let serializedParams;
    if (serializeFn) serializedParams = serializeFn(params, options);
    else serializedParams = (0, _utilsJsDefault.default).isURLSearchParams(params) ? params.toString() : new (0, _axiosURLSearchParamsJsDefault.default)(params, options).toString(_encode);
    if (serializedParams) {
        const hashmarkIndex = url.indexOf("#");
        if (hashmarkIndex !== -1) url = url.slice(0, hashmarkIndex);
        url += (url.indexOf("?") === -1 ? "?" : "&") + serializedParams;
    }
    return url;
}

},{"../utils.js":"dNjua","../helpers/AxiosURLSearchParams.js":"h9HvX","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"h9HvX":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _toFormDataJs = require("./toFormData.js");
var _toFormDataJsDefault = parcelHelpers.interopDefault(_toFormDataJs);
"use strict";
/**
 * It encodes a string by replacing all characters that are not in the unreserved set with
 * their percent-encoded equivalents
 *
 * @param {string} str - The string to encode.
 *
 * @returns {string} The encoded string.
 */ function encode(str) {
    const charMap = {
        "!": "%21",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "~": "%7E",
        "%20": "+",
        "%00": "\x00"
    };
    return encodeURIComponent(str).replace(/[!'()~]|%20|%00/g, function replacer(match) {
        return charMap[match];
    });
}
/**
 * It takes a params object and converts it to a FormData object
 *
 * @param {Object<string, any>} params - The parameters to be converted to a FormData object.
 * @param {Object<string, any>} options - The options object passed to the Axios constructor.
 *
 * @returns {void}
 */ function AxiosURLSearchParams(params, options) {
    this._pairs = [];
    params && (0, _toFormDataJsDefault.default)(params, this, options);
}
const prototype = AxiosURLSearchParams.prototype;
prototype.append = function append(name, value) {
    this._pairs.push([
        name,
        value
    ]);
};
prototype.toString = function toString(encoder) {
    const _encode = encoder ? function(value) {
        return encoder.call(this, value, encode);
    } : encode;
    return this._pairs.map(function each(pair) {
        return _encode(pair[0]) + "=" + _encode(pair[1]);
    }, "").join("&");
};
exports.default = AxiosURLSearchParams;

},{"./toFormData.js":"kEMey","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"kEMey":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _utilsJs = require("../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
var _axiosErrorJs = require("../core/AxiosError.js");
var _axiosErrorJsDefault = parcelHelpers.interopDefault(_axiosErrorJs);
// temporary hotfix to avoid circular references until AxiosURLSearchParams is refactored
var _formDataJs = require("../platform/node/classes/FormData.js");
var _formDataJsDefault = parcelHelpers.interopDefault(_formDataJs);
var Buffer = require("adfd9b103875c2dd").Buffer;
"use strict";
/**
 * Determines if the given thing is a array or js object.
 *
 * @param {string} thing - The object or array to be visited.
 *
 * @returns {boolean}
 */ function isVisitable(thing) {
    return (0, _utilsJsDefault.default).isPlainObject(thing) || (0, _utilsJsDefault.default).isArray(thing);
}
/**
 * It removes the brackets from the end of a string
 *
 * @param {string} key - The key of the parameter.
 *
 * @returns {string} the key without the brackets.
 */ function removeBrackets(key) {
    return (0, _utilsJsDefault.default).endsWith(key, "[]") ? key.slice(0, -2) : key;
}
/**
 * It takes a path, a key, and a boolean, and returns a string
 *
 * @param {string} path - The path to the current key.
 * @param {string} key - The key of the current object being iterated over.
 * @param {string} dots - If true, the key will be rendered with dots instead of brackets.
 *
 * @returns {string} The path to the current key.
 */ function renderKey(path, key, dots) {
    if (!path) return key;
    return path.concat(key).map(function each(token, i) {
        // eslint-disable-next-line no-param-reassign
        token = removeBrackets(token);
        return !dots && i ? "[" + token + "]" : token;
    }).join(dots ? "." : "");
}
/**
 * If the array is an array and none of its elements are visitable, then it's a flat array.
 *
 * @param {Array<any>} arr - The array to check
 *
 * @returns {boolean}
 */ function isFlatArray(arr) {
    return (0, _utilsJsDefault.default).isArray(arr) && !arr.some(isVisitable);
}
const predicates = (0, _utilsJsDefault.default).toFlatObject((0, _utilsJsDefault.default), {}, null, function filter(prop) {
    return /^is[A-Z]/.test(prop);
});
/**
 * Convert a data object to FormData
 *
 * @param {Object} obj
 * @param {?Object} [formData]
 * @param {?Object} [options]
 * @param {Function} [options.visitor]
 * @param {Boolean} [options.metaTokens = true]
 * @param {Boolean} [options.dots = false]
 * @param {?Boolean} [options.indexes = false]
 *
 * @returns {Object}
 **/ /**
 * It converts an object into a FormData object
 *
 * @param {Object<any, any>} obj - The object to convert to form data.
 * @param {string} formData - The FormData object to append to.
 * @param {Object<string, any>} options
 *
 * @returns
 */ function toFormData(obj, formData, options) {
    if (!(0, _utilsJsDefault.default).isObject(obj)) throw new TypeError("target must be an object");
    // eslint-disable-next-line no-param-reassign
    formData = formData || new ((0, _formDataJsDefault.default) || FormData)();
    // eslint-disable-next-line no-param-reassign
    options = (0, _utilsJsDefault.default).toFlatObject(options, {
        metaTokens: true,
        dots: false,
        indexes: false
    }, false, function defined(option, source) {
        // eslint-disable-next-line no-eq-null,eqeqeq
        return !(0, _utilsJsDefault.default).isUndefined(source[option]);
    });
    const metaTokens = options.metaTokens;
    // eslint-disable-next-line no-use-before-define
    const visitor = options.visitor || defaultVisitor;
    const dots = options.dots;
    const indexes = options.indexes;
    const _Blob = options.Blob || typeof Blob !== "undefined" && Blob;
    const useBlob = _Blob && (0, _utilsJsDefault.default).isSpecCompliantForm(formData);
    if (!(0, _utilsJsDefault.default).isFunction(visitor)) throw new TypeError("visitor must be a function");
    function convertValue(value) {
        if (value === null) return "";
        if ((0, _utilsJsDefault.default).isDate(value)) return value.toISOString();
        if (!useBlob && (0, _utilsJsDefault.default).isBlob(value)) throw new (0, _axiosErrorJsDefault.default)("Blob is not supported. Use a Buffer instead.");
        if ((0, _utilsJsDefault.default).isArrayBuffer(value) || (0, _utilsJsDefault.default).isTypedArray(value)) return useBlob && typeof Blob === "function" ? new Blob([
            value
        ]) : Buffer.from(value);
        return value;
    }
    /**
   * Default visitor.
   *
   * @param {*} value
   * @param {String|Number} key
   * @param {Array<String|Number>} path
   * @this {FormData}
   *
   * @returns {boolean} return true to visit the each prop of the value recursively
   */ function defaultVisitor(value, key, path) {
        let arr = value;
        if (value && !path && typeof value === "object") {
            if ((0, _utilsJsDefault.default).endsWith(key, "{}")) {
                // eslint-disable-next-line no-param-reassign
                key = metaTokens ? key : key.slice(0, -2);
                // eslint-disable-next-line no-param-reassign
                value = JSON.stringify(value);
            } else if ((0, _utilsJsDefault.default).isArray(value) && isFlatArray(value) || ((0, _utilsJsDefault.default).isFileList(value) || (0, _utilsJsDefault.default).endsWith(key, "[]")) && (arr = (0, _utilsJsDefault.default).toArray(value))) {
                // eslint-disable-next-line no-param-reassign
                key = removeBrackets(key);
                arr.forEach(function each(el, index) {
                    !((0, _utilsJsDefault.default).isUndefined(el) || el === null) && formData.append(// eslint-disable-next-line no-nested-ternary
                    indexes === true ? renderKey([
                        key
                    ], index, dots) : indexes === null ? key : key + "[]", convertValue(el));
                });
                return false;
            }
        }
        if (isVisitable(value)) return true;
        formData.append(renderKey(path, key, dots), convertValue(value));
        return false;
    }
    const stack = [];
    const exposedHelpers = Object.assign(predicates, {
        defaultVisitor,
        convertValue,
        isVisitable
    });
    function build(value, path) {
        if ((0, _utilsJsDefault.default).isUndefined(value)) return;
        if (stack.indexOf(value) !== -1) throw Error("Circular reference detected in " + path.join("."));
        stack.push(value);
        (0, _utilsJsDefault.default).forEach(value, function each(el, key) {
            const result = !((0, _utilsJsDefault.default).isUndefined(el) || el === null) && visitor.call(formData, el, (0, _utilsJsDefault.default).isString(key) ? key.trim() : key, path, exposedHelpers);
            if (result === true) build(el, path ? path.concat(key) : [
                key
            ]);
        });
        stack.pop();
    }
    if (!(0, _utilsJsDefault.default).isObject(obj)) throw new TypeError("data must be an object");
    build(obj);
    return formData;
}
exports.default = toFormData;

},{"adfd9b103875c2dd":"9gszL","../utils.js":"dNjua","../core/AxiosError.js":"1OwwO","../platform/node/classes/FormData.js":"04BpO","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"9gszL":[function(require,module,exports) {
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */ /* eslint-disable no-proto */ "use strict";
const base64 = require("9c62938f1dccc73c");
const ieee754 = require("aceacb6a4531a9d2");
const customInspectSymbol = typeof Symbol === "function" && typeof Symbol["for"] === "function" // eslint-disable-line dot-notation
 ? Symbol["for"]("nodejs.util.inspect.custom") // eslint-disable-line dot-notation
 : null;
exports.Buffer = Buffer;
exports.SlowBuffer = SlowBuffer;
exports.INSPECT_MAX_BYTES = 50;
const K_MAX_LENGTH = 0x7fffffff;
exports.kMaxLength = K_MAX_LENGTH;
/**
 * If `Buffer.TYPED_ARRAY_SUPPORT`:
 *   === true    Use Uint8Array implementation (fastest)
 *   === false   Print warning and recommend using `buffer` v4.x which has an Object
 *               implementation (most compatible, even IE6)
 *
 * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
 * Opera 11.6+, iOS 4.2+.
 *
 * We report that the browser does not support typed arrays if the are not subclassable
 * using __proto__. Firefox 4-29 lacks support for adding new properties to `Uint8Array`
 * (See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438). IE 10 lacks support
 * for __proto__ and has a buggy typed array implementation.
 */ Buffer.TYPED_ARRAY_SUPPORT = typedArraySupport();
if (!Buffer.TYPED_ARRAY_SUPPORT && typeof console !== "undefined" && typeof console.error === "function") console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support.");
function typedArraySupport() {
    // Can typed array instances can be augmented?
    try {
        const arr = new Uint8Array(1);
        const proto = {
            foo: function() {
                return 42;
            }
        };
        Object.setPrototypeOf(proto, Uint8Array.prototype);
        Object.setPrototypeOf(arr, proto);
        return arr.foo() === 42;
    } catch (e) {
        return false;
    }
}
Object.defineProperty(Buffer.prototype, "parent", {
    enumerable: true,
    get: function() {
        if (!Buffer.isBuffer(this)) return undefined;
        return this.buffer;
    }
});
Object.defineProperty(Buffer.prototype, "offset", {
    enumerable: true,
    get: function() {
        if (!Buffer.isBuffer(this)) return undefined;
        return this.byteOffset;
    }
});
function createBuffer(length) {
    if (length > K_MAX_LENGTH) throw new RangeError('The value "' + length + '" is invalid for option "size"');
    // Return an augmented `Uint8Array` instance
    const buf = new Uint8Array(length);
    Object.setPrototypeOf(buf, Buffer.prototype);
    return buf;
}
/**
 * The Buffer constructor returns instances of `Uint8Array` that have their
 * prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
 * `Uint8Array`, so the returned instances will have all the node `Buffer` methods
 * and the `Uint8Array` methods. Square bracket notation works as expected -- it
 * returns a single octet.
 *
 * The `Uint8Array` prototype remains unmodified.
 */ function Buffer(arg, encodingOrOffset, length) {
    // Common case.
    if (typeof arg === "number") {
        if (typeof encodingOrOffset === "string") throw new TypeError('The "string" argument must be of type string. Received type number');
        return allocUnsafe(arg);
    }
    return from(arg, encodingOrOffset, length);
}
Buffer.poolSize = 8192 // not used by this implementation
;
function from(value, encodingOrOffset, length) {
    if (typeof value === "string") return fromString(value, encodingOrOffset);
    if (ArrayBuffer.isView(value)) return fromArrayView(value);
    if (value == null) throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value);
    if (isInstance(value, ArrayBuffer) || value && isInstance(value.buffer, ArrayBuffer)) return fromArrayBuffer(value, encodingOrOffset, length);
    if (typeof SharedArrayBuffer !== "undefined" && (isInstance(value, SharedArrayBuffer) || value && isInstance(value.buffer, SharedArrayBuffer))) return fromArrayBuffer(value, encodingOrOffset, length);
    if (typeof value === "number") throw new TypeError('The "value" argument must not be of type number. Received type number');
    const valueOf = value.valueOf && value.valueOf();
    if (valueOf != null && valueOf !== value) return Buffer.from(valueOf, encodingOrOffset, length);
    const b = fromObject(value);
    if (b) return b;
    if (typeof Symbol !== "undefined" && Symbol.toPrimitive != null && typeof value[Symbol.toPrimitive] === "function") return Buffer.from(value[Symbol.toPrimitive]("string"), encodingOrOffset, length);
    throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof value);
}
/**
 * Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
 * if value is a number.
 * Buffer.from(str[, encoding])
 * Buffer.from(array)
 * Buffer.from(buffer)
 * Buffer.from(arrayBuffer[, byteOffset[, length]])
 **/ Buffer.from = function(value, encodingOrOffset, length) {
    return from(value, encodingOrOffset, length);
};
// Note: Change prototype *after* Buffer.from is defined to workaround Chrome bug:
// https://github.com/feross/buffer/pull/148
Object.setPrototypeOf(Buffer.prototype, Uint8Array.prototype);
Object.setPrototypeOf(Buffer, Uint8Array);
function assertSize(size) {
    if (typeof size !== "number") throw new TypeError('"size" argument must be of type number');
    else if (size < 0) throw new RangeError('The value "' + size + '" is invalid for option "size"');
}
function alloc(size, fill, encoding) {
    assertSize(size);
    if (size <= 0) return createBuffer(size);
    if (fill !== undefined) // Only pay attention to encoding if it's a string. This
    // prevents accidentally sending in a number that would
    // be interpreted as a start offset.
    return typeof encoding === "string" ? createBuffer(size).fill(fill, encoding) : createBuffer(size).fill(fill);
    return createBuffer(size);
}
/**
 * Creates a new filled Buffer instance.
 * alloc(size[, fill[, encoding]])
 **/ Buffer.alloc = function(size, fill, encoding) {
    return alloc(size, fill, encoding);
};
function allocUnsafe(size) {
    assertSize(size);
    return createBuffer(size < 0 ? 0 : checked(size) | 0);
}
/**
 * Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
 * */ Buffer.allocUnsafe = function(size) {
    return allocUnsafe(size);
};
/**
 * Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
 */ Buffer.allocUnsafeSlow = function(size) {
    return allocUnsafe(size);
};
function fromString(string, encoding) {
    if (typeof encoding !== "string" || encoding === "") encoding = "utf8";
    if (!Buffer.isEncoding(encoding)) throw new TypeError("Unknown encoding: " + encoding);
    const length = byteLength(string, encoding) | 0;
    let buf = createBuffer(length);
    const actual = buf.write(string, encoding);
    if (actual !== length) // Writing a hex string, for example, that contains invalid characters will
    // cause everything after the first invalid character to be ignored. (e.g.
    // 'abxxcd' will be treated as 'ab')
    buf = buf.slice(0, actual);
    return buf;
}
function fromArrayLike(array) {
    const length = array.length < 0 ? 0 : checked(array.length) | 0;
    const buf = createBuffer(length);
    for(let i = 0; i < length; i += 1)buf[i] = array[i] & 255;
    return buf;
}
function fromArrayView(arrayView) {
    if (isInstance(arrayView, Uint8Array)) {
        const copy = new Uint8Array(arrayView);
        return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength);
    }
    return fromArrayLike(arrayView);
}
function fromArrayBuffer(array, byteOffset, length) {
    if (byteOffset < 0 || array.byteLength < byteOffset) throw new RangeError('"offset" is outside of buffer bounds');
    if (array.byteLength < byteOffset + (length || 0)) throw new RangeError('"length" is outside of buffer bounds');
    let buf;
    if (byteOffset === undefined && length === undefined) buf = new Uint8Array(array);
    else if (length === undefined) buf = new Uint8Array(array, byteOffset);
    else buf = new Uint8Array(array, byteOffset, length);
    // Return an augmented `Uint8Array` instance
    Object.setPrototypeOf(buf, Buffer.prototype);
    return buf;
}
function fromObject(obj) {
    if (Buffer.isBuffer(obj)) {
        const len = checked(obj.length) | 0;
        const buf = createBuffer(len);
        if (buf.length === 0) return buf;
        obj.copy(buf, 0, 0, len);
        return buf;
    }
    if (obj.length !== undefined) {
        if (typeof obj.length !== "number" || numberIsNaN(obj.length)) return createBuffer(0);
        return fromArrayLike(obj);
    }
    if (obj.type === "Buffer" && Array.isArray(obj.data)) return fromArrayLike(obj.data);
}
function checked(length) {
    // Note: cannot use `length < K_MAX_LENGTH` here because that fails when
    // length is NaN (which is otherwise coerced to zero.)
    if (length >= K_MAX_LENGTH) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + K_MAX_LENGTH.toString(16) + " bytes");
    return length | 0;
}
function SlowBuffer(length) {
    if (+length != length) length = 0;
    return Buffer.alloc(+length);
}
Buffer.isBuffer = function isBuffer(b) {
    return b != null && b._isBuffer === true && b !== Buffer.prototype // so Buffer.isBuffer(Buffer.prototype) will be false
    ;
};
Buffer.compare = function compare(a, b) {
    if (isInstance(a, Uint8Array)) a = Buffer.from(a, a.offset, a.byteLength);
    if (isInstance(b, Uint8Array)) b = Buffer.from(b, b.offset, b.byteLength);
    if (!Buffer.isBuffer(a) || !Buffer.isBuffer(b)) throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
    if (a === b) return 0;
    let x = a.length;
    let y = b.length;
    for(let i = 0, len = Math.min(x, y); i < len; ++i)if (a[i] !== b[i]) {
        x = a[i];
        y = b[i];
        break;
    }
    if (x < y) return -1;
    if (y < x) return 1;
    return 0;
};
Buffer.isEncoding = function isEncoding(encoding) {
    switch(String(encoding).toLowerCase()){
        case "hex":
        case "utf8":
        case "utf-8":
        case "ascii":
        case "latin1":
        case "binary":
        case "base64":
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
            return true;
        default:
            return false;
    }
};
Buffer.concat = function concat(list, length) {
    if (!Array.isArray(list)) throw new TypeError('"list" argument must be an Array of Buffers');
    if (list.length === 0) return Buffer.alloc(0);
    let i;
    if (length === undefined) {
        length = 0;
        for(i = 0; i < list.length; ++i)length += list[i].length;
    }
    const buffer = Buffer.allocUnsafe(length);
    let pos = 0;
    for(i = 0; i < list.length; ++i){
        let buf = list[i];
        if (isInstance(buf, Uint8Array)) {
            if (pos + buf.length > buffer.length) {
                if (!Buffer.isBuffer(buf)) buf = Buffer.from(buf);
                buf.copy(buffer, pos);
            } else Uint8Array.prototype.set.call(buffer, buf, pos);
        } else if (!Buffer.isBuffer(buf)) throw new TypeError('"list" argument must be an Array of Buffers');
        else buf.copy(buffer, pos);
        pos += buf.length;
    }
    return buffer;
};
function byteLength(string, encoding) {
    if (Buffer.isBuffer(string)) return string.length;
    if (ArrayBuffer.isView(string) || isInstance(string, ArrayBuffer)) return string.byteLength;
    if (typeof string !== "string") throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof string);
    const len = string.length;
    const mustMatch = arguments.length > 2 && arguments[2] === true;
    if (!mustMatch && len === 0) return 0;
    // Use a for loop to avoid recursion
    let loweredCase = false;
    for(;;)switch(encoding){
        case "ascii":
        case "latin1":
        case "binary":
            return len;
        case "utf8":
        case "utf-8":
            return utf8ToBytes(string).length;
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
            return len * 2;
        case "hex":
            return len >>> 1;
        case "base64":
            return base64ToBytes(string).length;
        default:
            if (loweredCase) return mustMatch ? -1 : utf8ToBytes(string).length // assume utf8
            ;
            encoding = ("" + encoding).toLowerCase();
            loweredCase = true;
    }
}
Buffer.byteLength = byteLength;
function slowToString(encoding, start, end) {
    let loweredCase = false;
    // No need to verify that "this.length <= MAX_UINT32" since it's a read-only
    // property of a typed array.
    // This behaves neither like String nor Uint8Array in that we set start/end
    // to their upper/lower bounds if the value passed is out of range.
    // undefined is handled specially as per ECMA-262 6th Edition,
    // Section 13.3.3.7 Runtime Semantics: KeyedBindingInitialization.
    if (start === undefined || start < 0) start = 0;
    // Return early if start > this.length. Done here to prevent potential uint32
    // coercion fail below.
    if (start > this.length) return "";
    if (end === undefined || end > this.length) end = this.length;
    if (end <= 0) return "";
    // Force coercion to uint32. This will also coerce falsey/NaN values to 0.
    end >>>= 0;
    start >>>= 0;
    if (end <= start) return "";
    if (!encoding) encoding = "utf8";
    while(true)switch(encoding){
        case "hex":
            return hexSlice(this, start, end);
        case "utf8":
        case "utf-8":
            return utf8Slice(this, start, end);
        case "ascii":
            return asciiSlice(this, start, end);
        case "latin1":
        case "binary":
            return latin1Slice(this, start, end);
        case "base64":
            return base64Slice(this, start, end);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
            return utf16leSlice(this, start, end);
        default:
            if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
            encoding = (encoding + "").toLowerCase();
            loweredCase = true;
    }
}
// This property is used by `Buffer.isBuffer` (and the `is-buffer` npm package)
// to detect a Buffer instance. It's not possible to use `instanceof Buffer`
// reliably in a browserify context because there could be multiple different
// copies of the 'buffer' package in use. This method works even for Buffer
// instances that were created from another copy of the `buffer` package.
// See: https://github.com/feross/buffer/issues/154
Buffer.prototype._isBuffer = true;
function swap(b, n, m) {
    const i = b[n];
    b[n] = b[m];
    b[m] = i;
}
Buffer.prototype.swap16 = function swap16() {
    const len = this.length;
    if (len % 2 !== 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
    for(let i = 0; i < len; i += 2)swap(this, i, i + 1);
    return this;
};
Buffer.prototype.swap32 = function swap32() {
    const len = this.length;
    if (len % 4 !== 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
    for(let i = 0; i < len; i += 4){
        swap(this, i, i + 3);
        swap(this, i + 1, i + 2);
    }
    return this;
};
Buffer.prototype.swap64 = function swap64() {
    const len = this.length;
    if (len % 8 !== 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
    for(let i = 0; i < len; i += 8){
        swap(this, i, i + 7);
        swap(this, i + 1, i + 6);
        swap(this, i + 2, i + 5);
        swap(this, i + 3, i + 4);
    }
    return this;
};
Buffer.prototype.toString = function toString() {
    const length = this.length;
    if (length === 0) return "";
    if (arguments.length === 0) return utf8Slice(this, 0, length);
    return slowToString.apply(this, arguments);
};
Buffer.prototype.toLocaleString = Buffer.prototype.toString;
Buffer.prototype.equals = function equals(b) {
    if (!Buffer.isBuffer(b)) throw new TypeError("Argument must be a Buffer");
    if (this === b) return true;
    return Buffer.compare(this, b) === 0;
};
Buffer.prototype.inspect = function inspect() {
    let str = "";
    const max = exports.INSPECT_MAX_BYTES;
    str = this.toString("hex", 0, max).replace(/(.{2})/g, "$1 ").trim();
    if (this.length > max) str += " ... ";
    return "<Buffer " + str + ">";
};
if (customInspectSymbol) Buffer.prototype[customInspectSymbol] = Buffer.prototype.inspect;
Buffer.prototype.compare = function compare(target, start, end, thisStart, thisEnd) {
    if (isInstance(target, Uint8Array)) target = Buffer.from(target, target.offset, target.byteLength);
    if (!Buffer.isBuffer(target)) throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof target);
    if (start === undefined) start = 0;
    if (end === undefined) end = target ? target.length : 0;
    if (thisStart === undefined) thisStart = 0;
    if (thisEnd === undefined) thisEnd = this.length;
    if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) throw new RangeError("out of range index");
    if (thisStart >= thisEnd && start >= end) return 0;
    if (thisStart >= thisEnd) return -1;
    if (start >= end) return 1;
    start >>>= 0;
    end >>>= 0;
    thisStart >>>= 0;
    thisEnd >>>= 0;
    if (this === target) return 0;
    let x = thisEnd - thisStart;
    let y = end - start;
    const len = Math.min(x, y);
    const thisCopy = this.slice(thisStart, thisEnd);
    const targetCopy = target.slice(start, end);
    for(let i = 0; i < len; ++i)if (thisCopy[i] !== targetCopy[i]) {
        x = thisCopy[i];
        y = targetCopy[i];
        break;
    }
    if (x < y) return -1;
    if (y < x) return 1;
    return 0;
};
// Finds either the first index of `val` in `buffer` at offset >= `byteOffset`,
// OR the last index of `val` in `buffer` at offset <= `byteOffset`.
//
// Arguments:
// - buffer - a Buffer to search
// - val - a string, Buffer, or number
// - byteOffset - an index into `buffer`; will be clamped to an int32
// - encoding - an optional encoding, relevant is val is a string
// - dir - true for indexOf, false for lastIndexOf
function bidirectionalIndexOf(buffer, val, byteOffset, encoding, dir) {
    // Empty buffer means no match
    if (buffer.length === 0) return -1;
    // Normalize byteOffset
    if (typeof byteOffset === "string") {
        encoding = byteOffset;
        byteOffset = 0;
    } else if (byteOffset > 0x7fffffff) byteOffset = 0x7fffffff;
    else if (byteOffset < -2147483648) byteOffset = -2147483648;
    byteOffset = +byteOffset // Coerce to Number.
    ;
    if (numberIsNaN(byteOffset)) // byteOffset: it it's undefined, null, NaN, "foo", etc, search whole buffer
    byteOffset = dir ? 0 : buffer.length - 1;
    // Normalize byteOffset: negative offsets start from the end of the buffer
    if (byteOffset < 0) byteOffset = buffer.length + byteOffset;
    if (byteOffset >= buffer.length) {
        if (dir) return -1;
        else byteOffset = buffer.length - 1;
    } else if (byteOffset < 0) {
        if (dir) byteOffset = 0;
        else return -1;
    }
    // Normalize val
    if (typeof val === "string") val = Buffer.from(val, encoding);
    // Finally, search either indexOf (if dir is true) or lastIndexOf
    if (Buffer.isBuffer(val)) {
        // Special case: looking for empty string/buffer always fails
        if (val.length === 0) return -1;
        return arrayIndexOf(buffer, val, byteOffset, encoding, dir);
    } else if (typeof val === "number") {
        val = val & 0xFF // Search for a byte value [0-255]
        ;
        if (typeof Uint8Array.prototype.indexOf === "function") {
            if (dir) return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset);
            else return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset);
        }
        return arrayIndexOf(buffer, [
            val
        ], byteOffset, encoding, dir);
    }
    throw new TypeError("val must be string, number or Buffer");
}
function arrayIndexOf(arr, val, byteOffset, encoding, dir) {
    let indexSize = 1;
    let arrLength = arr.length;
    let valLength = val.length;
    if (encoding !== undefined) {
        encoding = String(encoding).toLowerCase();
        if (encoding === "ucs2" || encoding === "ucs-2" || encoding === "utf16le" || encoding === "utf-16le") {
            if (arr.length < 2 || val.length < 2) return -1;
            indexSize = 2;
            arrLength /= 2;
            valLength /= 2;
            byteOffset /= 2;
        }
    }
    function read(buf, i) {
        if (indexSize === 1) return buf[i];
        else return buf.readUInt16BE(i * indexSize);
    }
    let i;
    if (dir) {
        let foundIndex = -1;
        for(i = byteOffset; i < arrLength; i++)if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
            if (foundIndex === -1) foundIndex = i;
            if (i - foundIndex + 1 === valLength) return foundIndex * indexSize;
        } else {
            if (foundIndex !== -1) i -= i - foundIndex;
            foundIndex = -1;
        }
    } else {
        if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength;
        for(i = byteOffset; i >= 0; i--){
            let found = true;
            for(let j = 0; j < valLength; j++)if (read(arr, i + j) !== read(val, j)) {
                found = false;
                break;
            }
            if (found) return i;
        }
    }
    return -1;
}
Buffer.prototype.includes = function includes(val, byteOffset, encoding) {
    return this.indexOf(val, byteOffset, encoding) !== -1;
};
Buffer.prototype.indexOf = function indexOf(val, byteOffset, encoding) {
    return bidirectionalIndexOf(this, val, byteOffset, encoding, true);
};
Buffer.prototype.lastIndexOf = function lastIndexOf(val, byteOffset, encoding) {
    return bidirectionalIndexOf(this, val, byteOffset, encoding, false);
};
function hexWrite(buf, string, offset, length) {
    offset = Number(offset) || 0;
    const remaining = buf.length - offset;
    if (!length) length = remaining;
    else {
        length = Number(length);
        if (length > remaining) length = remaining;
    }
    const strLen = string.length;
    if (length > strLen / 2) length = strLen / 2;
    let i;
    for(i = 0; i < length; ++i){
        const parsed = parseInt(string.substr(i * 2, 2), 16);
        if (numberIsNaN(parsed)) return i;
        buf[offset + i] = parsed;
    }
    return i;
}
function utf8Write(buf, string, offset, length) {
    return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length);
}
function asciiWrite(buf, string, offset, length) {
    return blitBuffer(asciiToBytes(string), buf, offset, length);
}
function base64Write(buf, string, offset, length) {
    return blitBuffer(base64ToBytes(string), buf, offset, length);
}
function ucs2Write(buf, string, offset, length) {
    return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length);
}
Buffer.prototype.write = function write(string, offset, length, encoding) {
    // Buffer#write(string)
    if (offset === undefined) {
        encoding = "utf8";
        length = this.length;
        offset = 0;
    // Buffer#write(string, encoding)
    } else if (length === undefined && typeof offset === "string") {
        encoding = offset;
        length = this.length;
        offset = 0;
    // Buffer#write(string, offset[, length][, encoding])
    } else if (isFinite(offset)) {
        offset = offset >>> 0;
        if (isFinite(length)) {
            length = length >>> 0;
            if (encoding === undefined) encoding = "utf8";
        } else {
            encoding = length;
            length = undefined;
        }
    } else throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
    const remaining = this.length - offset;
    if (length === undefined || length > remaining) length = remaining;
    if (string.length > 0 && (length < 0 || offset < 0) || offset > this.length) throw new RangeError("Attempt to write outside buffer bounds");
    if (!encoding) encoding = "utf8";
    let loweredCase = false;
    for(;;)switch(encoding){
        case "hex":
            return hexWrite(this, string, offset, length);
        case "utf8":
        case "utf-8":
            return utf8Write(this, string, offset, length);
        case "ascii":
        case "latin1":
        case "binary":
            return asciiWrite(this, string, offset, length);
        case "base64":
            // Warning: maxLength not taken into account in base64Write
            return base64Write(this, string, offset, length);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
            return ucs2Write(this, string, offset, length);
        default:
            if (loweredCase) throw new TypeError("Unknown encoding: " + encoding);
            encoding = ("" + encoding).toLowerCase();
            loweredCase = true;
    }
};
Buffer.prototype.toJSON = function toJSON() {
    return {
        type: "Buffer",
        data: Array.prototype.slice.call(this._arr || this, 0)
    };
};
function base64Slice(buf, start, end) {
    if (start === 0 && end === buf.length) return base64.fromByteArray(buf);
    else return base64.fromByteArray(buf.slice(start, end));
}
function utf8Slice(buf, start, end) {
    end = Math.min(buf.length, end);
    const res = [];
    let i = start;
    while(i < end){
        const firstByte = buf[i];
        let codePoint = null;
        let bytesPerSequence = firstByte > 0xEF ? 4 : firstByte > 0xDF ? 3 : firstByte > 0xBF ? 2 : 1;
        if (i + bytesPerSequence <= end) {
            let secondByte, thirdByte, fourthByte, tempCodePoint;
            switch(bytesPerSequence){
                case 1:
                    if (firstByte < 0x80) codePoint = firstByte;
                    break;
                case 2:
                    secondByte = buf[i + 1];
                    if ((secondByte & 0xC0) === 0x80) {
                        tempCodePoint = (firstByte & 0x1F) << 0x6 | secondByte & 0x3F;
                        if (tempCodePoint > 0x7F) codePoint = tempCodePoint;
                    }
                    break;
                case 3:
                    secondByte = buf[i + 1];
                    thirdByte = buf[i + 2];
                    if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
                        tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | thirdByte & 0x3F;
                        if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) codePoint = tempCodePoint;
                    }
                    break;
                case 4:
                    secondByte = buf[i + 1];
                    thirdByte = buf[i + 2];
                    fourthByte = buf[i + 3];
                    if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
                        tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | fourthByte & 0x3F;
                        if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) codePoint = tempCodePoint;
                    }
            }
        }
        if (codePoint === null) {
            // we did not generate a valid codePoint so insert a
            // replacement char (U+FFFD) and advance only 1 byte
            codePoint = 0xFFFD;
            bytesPerSequence = 1;
        } else if (codePoint > 0xFFFF) {
            // encode to utf16 (surrogate pair dance)
            codePoint -= 0x10000;
            res.push(codePoint >>> 10 & 0x3FF | 0xD800);
            codePoint = 0xDC00 | codePoint & 0x3FF;
        }
        res.push(codePoint);
        i += bytesPerSequence;
    }
    return decodeCodePointsArray(res);
}
// Based on http://stackoverflow.com/a/22747272/680742, the browser with
// the lowest limit is Chrome, with 0x10000 args.
// We go 1 magnitude less, for safety
const MAX_ARGUMENTS_LENGTH = 0x1000;
function decodeCodePointsArray(codePoints) {
    const len = codePoints.length;
    if (len <= MAX_ARGUMENTS_LENGTH) return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
    ;
    // Decode in chunks to avoid "call stack size exceeded".
    let res = "";
    let i = 0;
    while(i < len)res += String.fromCharCode.apply(String, codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH));
    return res;
}
function asciiSlice(buf, start, end) {
    let ret = "";
    end = Math.min(buf.length, end);
    for(let i = start; i < end; ++i)ret += String.fromCharCode(buf[i] & 0x7F);
    return ret;
}
function latin1Slice(buf, start, end) {
    let ret = "";
    end = Math.min(buf.length, end);
    for(let i = start; i < end; ++i)ret += String.fromCharCode(buf[i]);
    return ret;
}
function hexSlice(buf, start, end) {
    const len = buf.length;
    if (!start || start < 0) start = 0;
    if (!end || end < 0 || end > len) end = len;
    let out = "";
    for(let i = start; i < end; ++i)out += hexSliceLookupTable[buf[i]];
    return out;
}
function utf16leSlice(buf, start, end) {
    const bytes = buf.slice(start, end);
    let res = "";
    // If bytes.length is odd, the last 8 bits must be ignored (same as node.js)
    for(let i = 0; i < bytes.length - 1; i += 2)res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256);
    return res;
}
Buffer.prototype.slice = function slice(start, end) {
    const len = this.length;
    start = ~~start;
    end = end === undefined ? len : ~~end;
    if (start < 0) {
        start += len;
        if (start < 0) start = 0;
    } else if (start > len) start = len;
    if (end < 0) {
        end += len;
        if (end < 0) end = 0;
    } else if (end > len) end = len;
    if (end < start) end = start;
    const newBuf = this.subarray(start, end);
    // Return an augmented `Uint8Array` instance
    Object.setPrototypeOf(newBuf, Buffer.prototype);
    return newBuf;
};
/*
 * Need to make sure that buffer isn't trying to write out of bounds.
 */ function checkOffset(offset, ext, length) {
    if (offset % 1 !== 0 || offset < 0) throw new RangeError("offset is not uint");
    if (offset + ext > length) throw new RangeError("Trying to access beyond buffer length");
}
Buffer.prototype.readUintLE = Buffer.prototype.readUIntLE = function readUIntLE(offset, byteLength, noAssert) {
    offset = offset >>> 0;
    byteLength = byteLength >>> 0;
    if (!noAssert) checkOffset(offset, byteLength, this.length);
    let val = this[offset];
    let mul = 1;
    let i = 0;
    while(++i < byteLength && (mul *= 0x100))val += this[offset + i] * mul;
    return val;
};
Buffer.prototype.readUintBE = Buffer.prototype.readUIntBE = function readUIntBE(offset, byteLength, noAssert) {
    offset = offset >>> 0;
    byteLength = byteLength >>> 0;
    if (!noAssert) checkOffset(offset, byteLength, this.length);
    let val = this[offset + --byteLength];
    let mul = 1;
    while(byteLength > 0 && (mul *= 0x100))val += this[offset + --byteLength] * mul;
    return val;
};
Buffer.prototype.readUint8 = Buffer.prototype.readUInt8 = function readUInt8(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 1, this.length);
    return this[offset];
};
Buffer.prototype.readUint16LE = Buffer.prototype.readUInt16LE = function readUInt16LE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 2, this.length);
    return this[offset] | this[offset + 1] << 8;
};
Buffer.prototype.readUint16BE = Buffer.prototype.readUInt16BE = function readUInt16BE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 2, this.length);
    return this[offset] << 8 | this[offset + 1];
};
Buffer.prototype.readUint32LE = Buffer.prototype.readUInt32LE = function readUInt32LE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 4, this.length);
    return (this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16) + this[offset + 3] * 0x1000000;
};
Buffer.prototype.readUint32BE = Buffer.prototype.readUInt32BE = function readUInt32BE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 4, this.length);
    return this[offset] * 0x1000000 + (this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3]);
};
Buffer.prototype.readBigUInt64LE = defineBigIntMethod(function readBigUInt64LE(offset) {
    offset = offset >>> 0;
    validateNumber(offset, "offset");
    const first = this[offset];
    const last = this[offset + 7];
    if (first === undefined || last === undefined) boundsError(offset, this.length - 8);
    const lo = first + this[++offset] * 256 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24;
    const hi = this[++offset] + this[++offset] * 256 + this[++offset] * 2 ** 16 + last * 2 ** 24;
    return BigInt(lo) + (BigInt(hi) << BigInt(32));
});
Buffer.prototype.readBigUInt64BE = defineBigIntMethod(function readBigUInt64BE(offset) {
    offset = offset >>> 0;
    validateNumber(offset, "offset");
    const first = this[offset];
    const last = this[offset + 7];
    if (first === undefined || last === undefined) boundsError(offset, this.length - 8);
    const hi = first * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 256 + this[++offset];
    const lo = this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 256 + last;
    return (BigInt(hi) << BigInt(32)) + BigInt(lo);
});
Buffer.prototype.readIntLE = function readIntLE(offset, byteLength, noAssert) {
    offset = offset >>> 0;
    byteLength = byteLength >>> 0;
    if (!noAssert) checkOffset(offset, byteLength, this.length);
    let val = this[offset];
    let mul = 1;
    let i = 0;
    while(++i < byteLength && (mul *= 0x100))val += this[offset + i] * mul;
    mul *= 0x80;
    if (val >= mul) val -= Math.pow(2, 8 * byteLength);
    return val;
};
Buffer.prototype.readIntBE = function readIntBE(offset, byteLength, noAssert) {
    offset = offset >>> 0;
    byteLength = byteLength >>> 0;
    if (!noAssert) checkOffset(offset, byteLength, this.length);
    let i = byteLength;
    let mul = 1;
    let val = this[offset + --i];
    while(i > 0 && (mul *= 0x100))val += this[offset + --i] * mul;
    mul *= 0x80;
    if (val >= mul) val -= Math.pow(2, 8 * byteLength);
    return val;
};
Buffer.prototype.readInt8 = function readInt8(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 1, this.length);
    if (!(this[offset] & 0x80)) return this[offset];
    return (0xff - this[offset] + 1) * -1;
};
Buffer.prototype.readInt16LE = function readInt16LE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 2, this.length);
    const val = this[offset] | this[offset + 1] << 8;
    return val & 0x8000 ? val | 0xFFFF0000 : val;
};
Buffer.prototype.readInt16BE = function readInt16BE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 2, this.length);
    const val = this[offset + 1] | this[offset] << 8;
    return val & 0x8000 ? val | 0xFFFF0000 : val;
};
Buffer.prototype.readInt32LE = function readInt32LE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 4, this.length);
    return this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16 | this[offset + 3] << 24;
};
Buffer.prototype.readInt32BE = function readInt32BE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 4, this.length);
    return this[offset] << 24 | this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3];
};
Buffer.prototype.readBigInt64LE = defineBigIntMethod(function readBigInt64LE(offset) {
    offset = offset >>> 0;
    validateNumber(offset, "offset");
    const first = this[offset];
    const last = this[offset + 7];
    if (first === undefined || last === undefined) boundsError(offset, this.length - 8);
    const val = this[offset + 4] + this[offset + 5] * 256 + this[offset + 6] * 2 ** 16 + (last << 24 // Overflow
    );
    return (BigInt(val) << BigInt(32)) + BigInt(first + this[++offset] * 256 + this[++offset] * 2 ** 16 + this[++offset] * 2 ** 24);
});
Buffer.prototype.readBigInt64BE = defineBigIntMethod(function readBigInt64BE(offset) {
    offset = offset >>> 0;
    validateNumber(offset, "offset");
    const first = this[offset];
    const last = this[offset + 7];
    if (first === undefined || last === undefined) boundsError(offset, this.length - 8);
    const val = (first << 24) + // Overflow
    this[++offset] * 2 ** 16 + this[++offset] * 256 + this[++offset];
    return (BigInt(val) << BigInt(32)) + BigInt(this[++offset] * 2 ** 24 + this[++offset] * 2 ** 16 + this[++offset] * 256 + last);
});
Buffer.prototype.readFloatLE = function readFloatLE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 4, this.length);
    return ieee754.read(this, offset, true, 23, 4);
};
Buffer.prototype.readFloatBE = function readFloatBE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 4, this.length);
    return ieee754.read(this, offset, false, 23, 4);
};
Buffer.prototype.readDoubleLE = function readDoubleLE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 8, this.length);
    return ieee754.read(this, offset, true, 52, 8);
};
Buffer.prototype.readDoubleBE = function readDoubleBE(offset, noAssert) {
    offset = offset >>> 0;
    if (!noAssert) checkOffset(offset, 8, this.length);
    return ieee754.read(this, offset, false, 52, 8);
};
function checkInt(buf, value, offset, ext, max, min) {
    if (!Buffer.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance');
    if (value > max || value < min) throw new RangeError('"value" argument is out of bounds');
    if (offset + ext > buf.length) throw new RangeError("Index out of range");
}
Buffer.prototype.writeUintLE = Buffer.prototype.writeUIntLE = function writeUIntLE(value, offset, byteLength, noAssert) {
    value = +value;
    offset = offset >>> 0;
    byteLength = byteLength >>> 0;
    if (!noAssert) {
        const maxBytes = Math.pow(2, 8 * byteLength) - 1;
        checkInt(this, value, offset, byteLength, maxBytes, 0);
    }
    let mul = 1;
    let i = 0;
    this[offset] = value & 0xFF;
    while(++i < byteLength && (mul *= 0x100))this[offset + i] = value / mul & 0xFF;
    return offset + byteLength;
};
Buffer.prototype.writeUintBE = Buffer.prototype.writeUIntBE = function writeUIntBE(value, offset, byteLength, noAssert) {
    value = +value;
    offset = offset >>> 0;
    byteLength = byteLength >>> 0;
    if (!noAssert) {
        const maxBytes = Math.pow(2, 8 * byteLength) - 1;
        checkInt(this, value, offset, byteLength, maxBytes, 0);
    }
    let i = byteLength - 1;
    let mul = 1;
    this[offset + i] = value & 0xFF;
    while(--i >= 0 && (mul *= 0x100))this[offset + i] = value / mul & 0xFF;
    return offset + byteLength;
};
Buffer.prototype.writeUint8 = Buffer.prototype.writeUInt8 = function writeUInt8(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0);
    this[offset] = value & 0xff;
    return offset + 1;
};
Buffer.prototype.writeUint16LE = Buffer.prototype.writeUInt16LE = function writeUInt16LE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0);
    this[offset] = value & 0xff;
    this[offset + 1] = value >>> 8;
    return offset + 2;
};
Buffer.prototype.writeUint16BE = Buffer.prototype.writeUInt16BE = function writeUInt16BE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0);
    this[offset] = value >>> 8;
    this[offset + 1] = value & 0xff;
    return offset + 2;
};
Buffer.prototype.writeUint32LE = Buffer.prototype.writeUInt32LE = function writeUInt32LE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0);
    this[offset + 3] = value >>> 24;
    this[offset + 2] = value >>> 16;
    this[offset + 1] = value >>> 8;
    this[offset] = value & 0xff;
    return offset + 4;
};
Buffer.prototype.writeUint32BE = Buffer.prototype.writeUInt32BE = function writeUInt32BE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0);
    this[offset] = value >>> 24;
    this[offset + 1] = value >>> 16;
    this[offset + 2] = value >>> 8;
    this[offset + 3] = value & 0xff;
    return offset + 4;
};
function wrtBigUInt64LE(buf, value, offset, min, max) {
    checkIntBI(value, min, max, buf, offset, 7);
    let lo = Number(value & BigInt(0xffffffff));
    buf[offset++] = lo;
    lo = lo >> 8;
    buf[offset++] = lo;
    lo = lo >> 8;
    buf[offset++] = lo;
    lo = lo >> 8;
    buf[offset++] = lo;
    let hi = Number(value >> BigInt(32) & BigInt(0xffffffff));
    buf[offset++] = hi;
    hi = hi >> 8;
    buf[offset++] = hi;
    hi = hi >> 8;
    buf[offset++] = hi;
    hi = hi >> 8;
    buf[offset++] = hi;
    return offset;
}
function wrtBigUInt64BE(buf, value, offset, min, max) {
    checkIntBI(value, min, max, buf, offset, 7);
    let lo = Number(value & BigInt(0xffffffff));
    buf[offset + 7] = lo;
    lo = lo >> 8;
    buf[offset + 6] = lo;
    lo = lo >> 8;
    buf[offset + 5] = lo;
    lo = lo >> 8;
    buf[offset + 4] = lo;
    let hi = Number(value >> BigInt(32) & BigInt(0xffffffff));
    buf[offset + 3] = hi;
    hi = hi >> 8;
    buf[offset + 2] = hi;
    hi = hi >> 8;
    buf[offset + 1] = hi;
    hi = hi >> 8;
    buf[offset] = hi;
    return offset + 8;
}
Buffer.prototype.writeBigUInt64LE = defineBigIntMethod(function writeBigUInt64LE(value, offset = 0) {
    return wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
});
Buffer.prototype.writeBigUInt64BE = defineBigIntMethod(function writeBigUInt64BE(value, offset = 0) {
    return wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt("0xffffffffffffffff"));
});
Buffer.prototype.writeIntLE = function writeIntLE(value, offset, byteLength, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) {
        const limit = Math.pow(2, 8 * byteLength - 1);
        checkInt(this, value, offset, byteLength, limit - 1, -limit);
    }
    let i = 0;
    let mul = 1;
    let sub = 0;
    this[offset] = value & 0xFF;
    while(++i < byteLength && (mul *= 0x100)){
        if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) sub = 1;
        this[offset + i] = (value / mul >> 0) - sub & 0xFF;
    }
    return offset + byteLength;
};
Buffer.prototype.writeIntBE = function writeIntBE(value, offset, byteLength, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) {
        const limit = Math.pow(2, 8 * byteLength - 1);
        checkInt(this, value, offset, byteLength, limit - 1, -limit);
    }
    let i = byteLength - 1;
    let mul = 1;
    let sub = 0;
    this[offset + i] = value & 0xFF;
    while(--i >= 0 && (mul *= 0x100)){
        if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) sub = 1;
        this[offset + i] = (value / mul >> 0) - sub & 0xFF;
    }
    return offset + byteLength;
};
Buffer.prototype.writeInt8 = function writeInt8(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -128);
    if (value < 0) value = 0xff + value + 1;
    this[offset] = value & 0xff;
    return offset + 1;
};
Buffer.prototype.writeInt16LE = function writeInt16LE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -32768);
    this[offset] = value & 0xff;
    this[offset + 1] = value >>> 8;
    return offset + 2;
};
Buffer.prototype.writeInt16BE = function writeInt16BE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -32768);
    this[offset] = value >>> 8;
    this[offset + 1] = value & 0xff;
    return offset + 2;
};
Buffer.prototype.writeInt32LE = function writeInt32LE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -2147483648);
    this[offset] = value & 0xff;
    this[offset + 1] = value >>> 8;
    this[offset + 2] = value >>> 16;
    this[offset + 3] = value >>> 24;
    return offset + 4;
};
Buffer.prototype.writeInt32BE = function writeInt32BE(value, offset, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -2147483648);
    if (value < 0) value = 0xffffffff + value + 1;
    this[offset] = value >>> 24;
    this[offset + 1] = value >>> 16;
    this[offset + 2] = value >>> 8;
    this[offset + 3] = value & 0xff;
    return offset + 4;
};
Buffer.prototype.writeBigInt64LE = defineBigIntMethod(function writeBigInt64LE(value, offset = 0) {
    return wrtBigUInt64LE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
});
Buffer.prototype.writeBigInt64BE = defineBigIntMethod(function writeBigInt64BE(value, offset = 0) {
    return wrtBigUInt64BE(this, value, offset, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
});
function checkIEEE754(buf, value, offset, ext, max, min) {
    if (offset + ext > buf.length) throw new RangeError("Index out of range");
    if (offset < 0) throw new RangeError("Index out of range");
}
function writeFloat(buf, value, offset, littleEndian, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkIEEE754(buf, value, offset, 4, 3.4028234663852886e+38, -340282346638528860000000000000000000000);
    ieee754.write(buf, value, offset, littleEndian, 23, 4);
    return offset + 4;
}
Buffer.prototype.writeFloatLE = function writeFloatLE(value, offset, noAssert) {
    return writeFloat(this, value, offset, true, noAssert);
};
Buffer.prototype.writeFloatBE = function writeFloatBE(value, offset, noAssert) {
    return writeFloat(this, value, offset, false, noAssert);
};
function writeDouble(buf, value, offset, littleEndian, noAssert) {
    value = +value;
    offset = offset >>> 0;
    if (!noAssert) checkIEEE754(buf, value, offset, 8, 1.7976931348623157E+308, -179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
    ieee754.write(buf, value, offset, littleEndian, 52, 8);
    return offset + 8;
}
Buffer.prototype.writeDoubleLE = function writeDoubleLE(value, offset, noAssert) {
    return writeDouble(this, value, offset, true, noAssert);
};
Buffer.prototype.writeDoubleBE = function writeDoubleBE(value, offset, noAssert) {
    return writeDouble(this, value, offset, false, noAssert);
};
// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
Buffer.prototype.copy = function copy(target, targetStart, start, end) {
    if (!Buffer.isBuffer(target)) throw new TypeError("argument should be a Buffer");
    if (!start) start = 0;
    if (!end && end !== 0) end = this.length;
    if (targetStart >= target.length) targetStart = target.length;
    if (!targetStart) targetStart = 0;
    if (end > 0 && end < start) end = start;
    // Copy 0 bytes; we're done
    if (end === start) return 0;
    if (target.length === 0 || this.length === 0) return 0;
    // Fatal error conditions
    if (targetStart < 0) throw new RangeError("targetStart out of bounds");
    if (start < 0 || start >= this.length) throw new RangeError("Index out of range");
    if (end < 0) throw new RangeError("sourceEnd out of bounds");
    // Are we oob?
    if (end > this.length) end = this.length;
    if (target.length - targetStart < end - start) end = target.length - targetStart + start;
    const len = end - start;
    if (this === target && typeof Uint8Array.prototype.copyWithin === "function") // Use built-in when available, missing from IE11
    this.copyWithin(targetStart, start, end);
    else Uint8Array.prototype.set.call(target, this.subarray(start, end), targetStart);
    return len;
};
// Usage:
//    buffer.fill(number[, offset[, end]])
//    buffer.fill(buffer[, offset[, end]])
//    buffer.fill(string[, offset[, end]][, encoding])
Buffer.prototype.fill = function fill(val, start, end, encoding) {
    // Handle string cases:
    if (typeof val === "string") {
        if (typeof start === "string") {
            encoding = start;
            start = 0;
            end = this.length;
        } else if (typeof end === "string") {
            encoding = end;
            end = this.length;
        }
        if (encoding !== undefined && typeof encoding !== "string") throw new TypeError("encoding must be a string");
        if (typeof encoding === "string" && !Buffer.isEncoding(encoding)) throw new TypeError("Unknown encoding: " + encoding);
        if (val.length === 1) {
            const code = val.charCodeAt(0);
            if (encoding === "utf8" && code < 128 || encoding === "latin1") // Fast path: If `val` fits into a single byte, use that numeric value.
            val = code;
        }
    } else if (typeof val === "number") val = val & 255;
    else if (typeof val === "boolean") val = Number(val);
    // Invalid ranges are not set to a default, so can range check early.
    if (start < 0 || this.length < start || this.length < end) throw new RangeError("Out of range index");
    if (end <= start) return this;
    start = start >>> 0;
    end = end === undefined ? this.length : end >>> 0;
    if (!val) val = 0;
    let i;
    if (typeof val === "number") for(i = start; i < end; ++i)this[i] = val;
    else {
        const bytes = Buffer.isBuffer(val) ? val : Buffer.from(val, encoding);
        const len = bytes.length;
        if (len === 0) throw new TypeError('The value "' + val + '" is invalid for argument "value"');
        for(i = 0; i < end - start; ++i)this[i + start] = bytes[i % len];
    }
    return this;
};
// CUSTOM ERRORS
// =============
// Simplified versions from Node, changed for Buffer-only usage
const errors = {};
function E(sym, getMessage, Base) {
    errors[sym] = class NodeError extends Base {
        constructor(){
            super();
            Object.defineProperty(this, "message", {
                value: getMessage.apply(this, arguments),
                writable: true,
                configurable: true
            });
            // Add the error code to the name to include it in the stack trace.
            this.name = `${this.name} [${sym}]`;
            // Access the stack to generate the error message including the error code
            // from the name.
            this.stack // eslint-disable-line no-unused-expressions
            ;
            // Reset the name to the actual name.
            delete this.name;
        }
        get code() {
            return sym;
        }
        set code(value) {
            Object.defineProperty(this, "code", {
                configurable: true,
                enumerable: true,
                value,
                writable: true
            });
        }
        toString() {
            return `${this.name} [${sym}]: ${this.message}`;
        }
    };
}
E("ERR_BUFFER_OUT_OF_BOUNDS", function(name) {
    if (name) return `${name} is outside of buffer bounds`;
    return "Attempt to access memory outside buffer bounds";
}, RangeError);
E("ERR_INVALID_ARG_TYPE", function(name, actual) {
    return `The "${name}" argument must be of type number. Received type ${typeof actual}`;
}, TypeError);
E("ERR_OUT_OF_RANGE", function(str, range, input) {
    let msg = `The value of "${str}" is out of range.`;
    let received = input;
    if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) received = addNumericalSeparator(String(input));
    else if (typeof input === "bigint") {
        received = String(input);
        if (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) received = addNumericalSeparator(received);
        received += "n";
    }
    msg += ` It must be ${range}. Received ${received}`;
    return msg;
}, RangeError);
function addNumericalSeparator(val) {
    let res = "";
    let i = val.length;
    const start = val[0] === "-" ? 1 : 0;
    for(; i >= start + 4; i -= 3)res = `_${val.slice(i - 3, i)}${res}`;
    return `${val.slice(0, i)}${res}`;
}
// CHECK FUNCTIONS
// ===============
function checkBounds(buf, offset, byteLength) {
    validateNumber(offset, "offset");
    if (buf[offset] === undefined || buf[offset + byteLength] === undefined) boundsError(offset, buf.length - (byteLength + 1));
}
function checkIntBI(value, min, max, buf, offset, byteLength) {
    if (value > max || value < min) {
        const n = typeof min === "bigint" ? "n" : "";
        let range;
        if (byteLength > 3) {
            if (min === 0 || min === BigInt(0)) range = `>= 0${n} and < 2${n} ** ${(byteLength + 1) * 8}${n}`;
            else range = `>= -(2${n} ** ${(byteLength + 1) * 8 - 1}${n}) and < 2 ** ` + `${(byteLength + 1) * 8 - 1}${n}`;
        } else range = `>= ${min}${n} and <= ${max}${n}`;
        throw new errors.ERR_OUT_OF_RANGE("value", range, value);
    }
    checkBounds(buf, offset, byteLength);
}
function validateNumber(value, name) {
    if (typeof value !== "number") throw new errors.ERR_INVALID_ARG_TYPE(name, "number", value);
}
function boundsError(value, length, type) {
    if (Math.floor(value) !== value) {
        validateNumber(value, type);
        throw new errors.ERR_OUT_OF_RANGE(type || "offset", "an integer", value);
    }
    if (length < 0) throw new errors.ERR_BUFFER_OUT_OF_BOUNDS();
    throw new errors.ERR_OUT_OF_RANGE(type || "offset", `>= ${type ? 1 : 0} and <= ${length}`, value);
}
// HELPER FUNCTIONS
// ================
const INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g;
function base64clean(str) {
    // Node takes equal signs as end of the Base64 encoding
    str = str.split("=")[0];
    // Node strips out invalid characters like \n and \t from the string, base64-js does not
    str = str.trim().replace(INVALID_BASE64_RE, "");
    // Node converts strings with length < 2 to ''
    if (str.length < 2) return "";
    // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
    while(str.length % 4 !== 0)str = str + "=";
    return str;
}
function utf8ToBytes(string, units) {
    units = units || Infinity;
    let codePoint;
    const length = string.length;
    let leadSurrogate = null;
    const bytes = [];
    for(let i = 0; i < length; ++i){
        codePoint = string.charCodeAt(i);
        // is surrogate component
        if (codePoint > 0xD7FF && codePoint < 0xE000) {
            // last char was a lead
            if (!leadSurrogate) {
                // no lead yet
                if (codePoint > 0xDBFF) {
                    // unexpected trail
                    if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
                    continue;
                } else if (i + 1 === length) {
                    // unpaired lead
                    if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
                    continue;
                }
                // valid lead
                leadSurrogate = codePoint;
                continue;
            }
            // 2 leads in a row
            if (codePoint < 0xDC00) {
                if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
                leadSurrogate = codePoint;
                continue;
            }
            // valid surrogate pair
            codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000;
        } else if (leadSurrogate) // valid bmp char, but last char was a lead
        {
            if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
        }
        leadSurrogate = null;
        // encode utf8
        if (codePoint < 0x80) {
            if ((units -= 1) < 0) break;
            bytes.push(codePoint);
        } else if (codePoint < 0x800) {
            if ((units -= 2) < 0) break;
            bytes.push(codePoint >> 0x6 | 0xC0, codePoint & 0x3F | 0x80);
        } else if (codePoint < 0x10000) {
            if ((units -= 3) < 0) break;
            bytes.push(codePoint >> 0xC | 0xE0, codePoint >> 0x6 & 0x3F | 0x80, codePoint & 0x3F | 0x80);
        } else if (codePoint < 0x110000) {
            if ((units -= 4) < 0) break;
            bytes.push(codePoint >> 0x12 | 0xF0, codePoint >> 0xC & 0x3F | 0x80, codePoint >> 0x6 & 0x3F | 0x80, codePoint & 0x3F | 0x80);
        } else throw new Error("Invalid code point");
    }
    return bytes;
}
function asciiToBytes(str) {
    const byteArray = [];
    for(let i = 0; i < str.length; ++i)// Node's code seems to be doing this and not & 0x7F..
    byteArray.push(str.charCodeAt(i) & 0xFF);
    return byteArray;
}
function utf16leToBytes(str, units) {
    let c, hi, lo;
    const byteArray = [];
    for(let i = 0; i < str.length; ++i){
        if ((units -= 2) < 0) break;
        c = str.charCodeAt(i);
        hi = c >> 8;
        lo = c % 256;
        byteArray.push(lo);
        byteArray.push(hi);
    }
    return byteArray;
}
function base64ToBytes(str) {
    return base64.toByteArray(base64clean(str));
}
function blitBuffer(src, dst, offset, length) {
    let i;
    for(i = 0; i < length; ++i){
        if (i + offset >= dst.length || i >= src.length) break;
        dst[i + offset] = src[i];
    }
    return i;
}
// ArrayBuffer or Uint8Array objects from other contexts (i.e. iframes) do not pass
// the `instanceof` check but they should be treated as of that type.
// See: https://github.com/feross/buffer/issues/166
function isInstance(obj, type) {
    return obj instanceof type || obj != null && obj.constructor != null && obj.constructor.name != null && obj.constructor.name === type.name;
}
function numberIsNaN(obj) {
    // For IE11 support
    return obj !== obj // eslint-disable-line no-self-compare
    ;
}
// Create lookup table for `toString('hex')`
// See: https://github.com/feross/buffer/issues/219
const hexSliceLookupTable = function() {
    const alphabet = "0123456789abcdef";
    const table = new Array(256);
    for(let i = 0; i < 16; ++i){
        const i16 = i * 16;
        for(let j = 0; j < 16; ++j)table[i16 + j] = alphabet[i] + alphabet[j];
    }
    return table;
}();
// Return not function with Error if BigInt not supported
function defineBigIntMethod(fn) {
    return typeof BigInt === "undefined" ? BufferBigIntNotDefined : fn;
}
function BufferBigIntNotDefined() {
    throw new Error("BigInt not supported");
}

},{"9c62938f1dccc73c":"8lw4j","aceacb6a4531a9d2":"ckKOw"}],"8lw4j":[function(require,module,exports) {
"use strict";
exports.byteLength = byteLength;
exports.toByteArray = toByteArray;
exports.fromByteArray = fromByteArray;
var lookup = [];
var revLookup = [];
var Arr = typeof Uint8Array !== "undefined" ? Uint8Array : Array;
var code = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for(var i = 0, len = code.length; i < len; ++i){
    lookup[i] = code[i];
    revLookup[code.charCodeAt(i)] = i;
}
// Support decoding URL-safe base64 strings, as Node.js does.
// See: https://en.wikipedia.org/wiki/Base64#URL_applications
revLookup["-".charCodeAt(0)] = 62;
revLookup["_".charCodeAt(0)] = 63;
function getLens(b64) {
    var len = b64.length;
    if (len % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
    // Trim off extra bytes after placeholder bytes are found
    // See: https://github.com/beatgammit/base64-js/issues/42
    var validLen = b64.indexOf("=");
    if (validLen === -1) validLen = len;
    var placeHoldersLen = validLen === len ? 0 : 4 - validLen % 4;
    return [
        validLen,
        placeHoldersLen
    ];
}
// base64 is 4/3 + up to two characters of the original data
function byteLength(b64) {
    var lens = getLens(b64);
    var validLen = lens[0];
    var placeHoldersLen = lens[1];
    return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
}
function _byteLength(b64, validLen, placeHoldersLen) {
    return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
}
function toByteArray(b64) {
    var tmp;
    var lens = getLens(b64);
    var validLen = lens[0];
    var placeHoldersLen = lens[1];
    var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));
    var curByte = 0;
    // if there are placeholders, only get up to the last complete 4 chars
    var len = placeHoldersLen > 0 ? validLen - 4 : validLen;
    var i;
    for(i = 0; i < len; i += 4){
        tmp = revLookup[b64.charCodeAt(i)] << 18 | revLookup[b64.charCodeAt(i + 1)] << 12 | revLookup[b64.charCodeAt(i + 2)] << 6 | revLookup[b64.charCodeAt(i + 3)];
        arr[curByte++] = tmp >> 16 & 0xFF;
        arr[curByte++] = tmp >> 8 & 0xFF;
        arr[curByte++] = tmp & 0xFF;
    }
    if (placeHoldersLen === 2) {
        tmp = revLookup[b64.charCodeAt(i)] << 2 | revLookup[b64.charCodeAt(i + 1)] >> 4;
        arr[curByte++] = tmp & 0xFF;
    }
    if (placeHoldersLen === 1) {
        tmp = revLookup[b64.charCodeAt(i)] << 10 | revLookup[b64.charCodeAt(i + 1)] << 4 | revLookup[b64.charCodeAt(i + 2)] >> 2;
        arr[curByte++] = tmp >> 8 & 0xFF;
        arr[curByte++] = tmp & 0xFF;
    }
    return arr;
}
function tripletToBase64(num) {
    return lookup[num >> 18 & 0x3F] + lookup[num >> 12 & 0x3F] + lookup[num >> 6 & 0x3F] + lookup[num & 0x3F];
}
function encodeChunk(uint8, start, end) {
    var tmp;
    var output = [];
    for(var i = start; i < end; i += 3){
        tmp = (uint8[i] << 16 & 0xFF0000) + (uint8[i + 1] << 8 & 0xFF00) + (uint8[i + 2] & 0xFF);
        output.push(tripletToBase64(tmp));
    }
    return output.join("");
}
function fromByteArray(uint8) {
    var tmp;
    var len = uint8.length;
    var extraBytes = len % 3 // if we have 1 byte left, pad 2 bytes
    ;
    var parts = [];
    var maxChunkLength = 16383 // must be multiple of 3
    ;
    // go through the array every three bytes, we'll deal with trailing stuff later
    for(var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength)parts.push(encodeChunk(uint8, i, i + maxChunkLength > len2 ? len2 : i + maxChunkLength));
    // pad the end with zeros, but make sure to not forget the extra bytes
    if (extraBytes === 1) {
        tmp = uint8[len - 1];
        parts.push(lookup[tmp >> 2] + lookup[tmp << 4 & 0x3F] + "==");
    } else if (extraBytes === 2) {
        tmp = (uint8[len - 2] << 8) + uint8[len - 1];
        parts.push(lookup[tmp >> 10] + lookup[tmp >> 4 & 0x3F] + lookup[tmp << 2 & 0x3F] + "=");
    }
    return parts.join("");
}

},{}],"ckKOw":[function(require,module,exports) {
/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */ exports.read = function(buffer, offset, isLE, mLen, nBytes) {
    var e, m;
    var eLen = nBytes * 8 - mLen - 1;
    var eMax = (1 << eLen) - 1;
    var eBias = eMax >> 1;
    var nBits = -7;
    var i = isLE ? nBytes - 1 : 0;
    var d = isLE ? -1 : 1;
    var s = buffer[offset + i];
    i += d;
    e = s & (1 << -nBits) - 1;
    s >>= -nBits;
    nBits += eLen;
    for(; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8);
    m = e & (1 << -nBits) - 1;
    e >>= -nBits;
    nBits += mLen;
    for(; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8);
    if (e === 0) e = 1 - eBias;
    else if (e === eMax) return m ? NaN : (s ? -1 : 1) * Infinity;
    else {
        m = m + Math.pow(2, mLen);
        e = e - eBias;
    }
    return (s ? -1 : 1) * m * Math.pow(2, e - mLen);
};
exports.write = function(buffer, value, offset, isLE, mLen, nBytes) {
    var e, m, c;
    var eLen = nBytes * 8 - mLen - 1;
    var eMax = (1 << eLen) - 1;
    var eBias = eMax >> 1;
    var rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
    var i = isLE ? 0 : nBytes - 1;
    var d = isLE ? 1 : -1;
    var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
    value = Math.abs(value);
    if (isNaN(value) || value === Infinity) {
        m = isNaN(value) ? 1 : 0;
        e = eMax;
    } else {
        e = Math.floor(Math.log(value) / Math.LN2);
        if (value * (c = Math.pow(2, -e)) < 1) {
            e--;
            c *= 2;
        }
        if (e + eBias >= 1) value += rt / c;
        else value += rt * Math.pow(2, 1 - eBias);
        if (value * c >= 2) {
            e++;
            c /= 2;
        }
        if (e + eBias >= eMax) {
            m = 0;
            e = eMax;
        } else if (e + eBias >= 1) {
            m = (value * c - 1) * Math.pow(2, mLen);
            e = e + eBias;
        } else {
            m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
            e = 0;
        }
    }
    for(; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8);
    e = e << mLen | m;
    eLen += mLen;
    for(; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8);
    buffer[offset + i - d] |= s * 128;
};

},{}],"1OwwO":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _utilsJs = require("../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
"use strict";
/**
 * Create an Error with the specified message, config, error code, request and response.
 *
 * @param {string} message The error message.
 * @param {string} [code] The error code (for example, 'ECONNABORTED').
 * @param {Object} [config] The config.
 * @param {Object} [request] The request.
 * @param {Object} [response] The response.
 *
 * @returns {Error} The created error.
 */ function AxiosError(message, code, config, request, response) {
    Error.call(this);
    if (Error.captureStackTrace) Error.captureStackTrace(this, this.constructor);
    else this.stack = new Error().stack;
    this.message = message;
    this.name = "AxiosError";
    code && (this.code = code);
    config && (this.config = config);
    request && (this.request = request);
    response && (this.response = response);
}
(0, _utilsJsDefault.default).inherits(AxiosError, Error, {
    toJSON: function toJSON() {
        return {
            // Standard
            message: this.message,
            name: this.name,
            // Microsoft
            description: this.description,
            number: this.number,
            // Mozilla
            fileName: this.fileName,
            lineNumber: this.lineNumber,
            columnNumber: this.columnNumber,
            stack: this.stack,
            // Axios
            config: (0, _utilsJsDefault.default).toJSONObject(this.config),
            code: this.code,
            status: this.response && this.response.status ? this.response.status : null
        };
    }
});
const prototype = AxiosError.prototype;
const descriptors = {};
[
    "ERR_BAD_OPTION_VALUE",
    "ERR_BAD_OPTION",
    "ECONNABORTED",
    "ETIMEDOUT",
    "ERR_NETWORK",
    "ERR_FR_TOO_MANY_REDIRECTS",
    "ERR_DEPRECATED",
    "ERR_BAD_RESPONSE",
    "ERR_BAD_REQUEST",
    "ERR_CANCELED",
    "ERR_NOT_SUPPORT",
    "ERR_INVALID_URL"
].forEach((code)=>{
    descriptors[code] = {
        value: code
    };
});
Object.defineProperties(AxiosError, descriptors);
Object.defineProperty(prototype, "isAxiosError", {
    value: true
});
// eslint-disable-next-line func-names
AxiosError.from = (error, code, config, request, response, customProps)=>{
    const axiosError = Object.create(prototype);
    (0, _utilsJsDefault.default).toFlatObject(error, axiosError, function filter(obj) {
        return obj !== Error.prototype;
    }, (prop)=>{
        return prop !== "isAxiosError";
    });
    AxiosError.call(axiosError, error.message, code, config, request, response);
    axiosError.cause = error;
    axiosError.name = error.name;
    customProps && Object.assign(axiosError, customProps);
    return axiosError;
};
exports.default = AxiosError;

},{"../utils.js":"dNjua","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"04BpO":[function(require,module,exports) {
// eslint-disable-next-line strict
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
exports.default = null;

},{"@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"e61UM":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _utilsJs = require("./../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
"use strict";
class InterceptorManager {
    constructor(){
        this.handlers = [];
    }
    /**
   * Add a new interceptor to the stack
   *
   * @param {Function} fulfilled The function to handle `then` for a `Promise`
   * @param {Function} rejected The function to handle `reject` for a `Promise`
   *
   * @return {Number} An ID used to remove interceptor later
   */ use(fulfilled, rejected, options) {
        this.handlers.push({
            fulfilled,
            rejected,
            synchronous: options ? options.synchronous : false,
            runWhen: options ? options.runWhen : null
        });
        return this.handlers.length - 1;
    }
    /**
   * Remove an interceptor from the stack
   *
   * @param {Number} id The ID that was returned by `use`
   *
   * @returns {Boolean} `true` if the interceptor was removed, `false` otherwise
   */ eject(id) {
        if (this.handlers[id]) this.handlers[id] = null;
    }
    /**
   * Clear all interceptors from the stack
   *
   * @returns {void}
   */ clear() {
        if (this.handlers) this.handlers = [];
    }
    /**
   * Iterate over all the registered interceptors
   *
   * This method is particularly useful for skipping over any
   * interceptors that may have become `null` calling `eject`.
   *
   * @param {Function} fn The function to call for each interceptor
   *
   * @returns {void}
   */ forEach(fn) {
        (0, _utilsJsDefault.default).forEach(this.handlers, function forEachHandler(h) {
            if (h !== null) fn(h);
        });
    }
}
exports.default = InterceptorManager;

},{"./../utils.js":"dNjua","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"65aou":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>dispatchRequest);
var _transformDataJs = require("./transformData.js");
var _transformDataJsDefault = parcelHelpers.interopDefault(_transformDataJs);
var _isCancelJs = require("../cancel/isCancel.js");
var _isCancelJsDefault = parcelHelpers.interopDefault(_isCancelJs);
var _indexJs = require("../defaults/index.js");
var _indexJsDefault = parcelHelpers.interopDefault(_indexJs);
var _canceledErrorJs = require("../cancel/CanceledError.js");
var _canceledErrorJsDefault = parcelHelpers.interopDefault(_canceledErrorJs);
var _axiosHeadersJs = require("../core/AxiosHeaders.js");
var _axiosHeadersJsDefault = parcelHelpers.interopDefault(_axiosHeadersJs);
var _adaptersJs = require("../adapters/adapters.js");
var _adaptersJsDefault = parcelHelpers.interopDefault(_adaptersJs);
"use strict";
/**
 * Throws a `CanceledError` if cancellation has been requested.
 *
 * @param {Object} config The config that is to be used for the request
 *
 * @returns {void}
 */ function throwIfCancellationRequested(config) {
    if (config.cancelToken) config.cancelToken.throwIfRequested();
    if (config.signal && config.signal.aborted) throw new (0, _canceledErrorJsDefault.default)(null, config);
}
function dispatchRequest(config) {
    throwIfCancellationRequested(config);
    config.headers = (0, _axiosHeadersJsDefault.default).from(config.headers);
    // Transform request data
    config.data = (0, _transformDataJsDefault.default).call(config, config.transformRequest);
    if ([
        "post",
        "put",
        "patch"
    ].indexOf(config.method) !== -1) config.headers.setContentType("application/x-www-form-urlencoded", false);
    const adapter = (0, _adaptersJsDefault.default).getAdapter(config.adapter || (0, _indexJsDefault.default).adapter);
    return adapter(config).then(function onAdapterResolution(response) {
        throwIfCancellationRequested(config);
        // Transform response data
        response.data = (0, _transformDataJsDefault.default).call(config, config.transformResponse, response);
        response.headers = (0, _axiosHeadersJsDefault.default).from(response.headers);
        return response;
    }, function onAdapterRejection(reason) {
        if (!(0, _isCancelJsDefault.default)(reason)) {
            throwIfCancellationRequested(config);
            // Transform response data
            if (reason && reason.response) {
                reason.response.data = (0, _transformDataJsDefault.default).call(config, config.transformResponse, reason.response);
                reason.response.headers = (0, _axiosHeadersJsDefault.default).from(reason.response.headers);
            }
        }
        return Promise.reject(reason);
    });
}

},{"./transformData.js":"i7XK5","../cancel/isCancel.js":"i4WpT","../defaults/index.js":"kStuG","../cancel/CanceledError.js":"byMZp","../core/AxiosHeaders.js":"gTOgd","../adapters/adapters.js":"fDdzI","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"i7XK5":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>transformData);
var _utilsJs = require("./../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
var _indexJs = require("../defaults/index.js");
var _indexJsDefault = parcelHelpers.interopDefault(_indexJs);
var _axiosHeadersJs = require("../core/AxiosHeaders.js");
var _axiosHeadersJsDefault = parcelHelpers.interopDefault(_axiosHeadersJs);
"use strict";
function transformData(fns, response) {
    const config = this || (0, _indexJsDefault.default);
    const context = response || config;
    const headers = (0, _axiosHeadersJsDefault.default).from(context.headers);
    let data = context.data;
    (0, _utilsJsDefault.default).forEach(fns, function transform(fn) {
        data = fn.call(config, data, headers.normalize(), response ? response.status : undefined);
    });
    headers.normalize();
    return data;
}

},{"./../utils.js":"dNjua","../defaults/index.js":"kStuG","../core/AxiosHeaders.js":"gTOgd","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"kStuG":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _utilsJs = require("../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
var _axiosErrorJs = require("../core/AxiosError.js");
var _axiosErrorJsDefault = parcelHelpers.interopDefault(_axiosErrorJs);
var _transitionalJs = require("./transitional.js");
var _transitionalJsDefault = parcelHelpers.interopDefault(_transitionalJs);
var _toFormDataJs = require("../helpers/toFormData.js");
var _toFormDataJsDefault = parcelHelpers.interopDefault(_toFormDataJs);
var _toURLEncodedFormJs = require("../helpers/toURLEncodedForm.js");
var _toURLEncodedFormJsDefault = parcelHelpers.interopDefault(_toURLEncodedFormJs);
var _indexJs = require("../platform/index.js");
var _indexJsDefault = parcelHelpers.interopDefault(_indexJs);
var _formDataToJSONJs = require("../helpers/formDataToJSON.js");
var _formDataToJSONJsDefault = parcelHelpers.interopDefault(_formDataToJSONJs);
"use strict";
/**
 * It takes a string, tries to parse it, and if it fails, it returns the stringified version
 * of the input
 *
 * @param {any} rawValue - The value to be stringified.
 * @param {Function} parser - A function that parses a string into a JavaScript object.
 * @param {Function} encoder - A function that takes a value and returns a string.
 *
 * @returns {string} A stringified version of the rawValue.
 */ function stringifySafely(rawValue, parser, encoder) {
    if ((0, _utilsJsDefault.default).isString(rawValue)) try {
        (parser || JSON.parse)(rawValue);
        return (0, _utilsJsDefault.default).trim(rawValue);
    } catch (e) {
        if (e.name !== "SyntaxError") throw e;
    }
    return (encoder || JSON.stringify)(rawValue);
}
const defaults = {
    transitional: (0, _transitionalJsDefault.default),
    adapter: [
        "xhr",
        "http"
    ],
    transformRequest: [
        function transformRequest(data, headers) {
            const contentType = headers.getContentType() || "";
            const hasJSONContentType = contentType.indexOf("application/json") > -1;
            const isObjectPayload = (0, _utilsJsDefault.default).isObject(data);
            if (isObjectPayload && (0, _utilsJsDefault.default).isHTMLForm(data)) data = new FormData(data);
            const isFormData = (0, _utilsJsDefault.default).isFormData(data);
            if (isFormData) return hasJSONContentType ? JSON.stringify((0, _formDataToJSONJsDefault.default)(data)) : data;
            if ((0, _utilsJsDefault.default).isArrayBuffer(data) || (0, _utilsJsDefault.default).isBuffer(data) || (0, _utilsJsDefault.default).isStream(data) || (0, _utilsJsDefault.default).isFile(data) || (0, _utilsJsDefault.default).isBlob(data)) return data;
            if ((0, _utilsJsDefault.default).isArrayBufferView(data)) return data.buffer;
            if ((0, _utilsJsDefault.default).isURLSearchParams(data)) {
                headers.setContentType("application/x-www-form-urlencoded;charset=utf-8", false);
                return data.toString();
            }
            let isFileList;
            if (isObjectPayload) {
                if (contentType.indexOf("application/x-www-form-urlencoded") > -1) return (0, _toURLEncodedFormJsDefault.default)(data, this.formSerializer).toString();
                if ((isFileList = (0, _utilsJsDefault.default).isFileList(data)) || contentType.indexOf("multipart/form-data") > -1) {
                    const _FormData = this.env && this.env.FormData;
                    return (0, _toFormDataJsDefault.default)(isFileList ? {
                        "files[]": data
                    } : data, _FormData && new _FormData(), this.formSerializer);
                }
            }
            if (isObjectPayload || hasJSONContentType) {
                headers.setContentType("application/json", false);
                return stringifySafely(data);
            }
            return data;
        }
    ],
    transformResponse: [
        function transformResponse(data) {
            const transitional = this.transitional || defaults.transitional;
            const forcedJSONParsing = transitional && transitional.forcedJSONParsing;
            const JSONRequested = this.responseType === "json";
            if (data && (0, _utilsJsDefault.default).isString(data) && (forcedJSONParsing && !this.responseType || JSONRequested)) {
                const silentJSONParsing = transitional && transitional.silentJSONParsing;
                const strictJSONParsing = !silentJSONParsing && JSONRequested;
                try {
                    return JSON.parse(data);
                } catch (e) {
                    if (strictJSONParsing) {
                        if (e.name === "SyntaxError") throw (0, _axiosErrorJsDefault.default).from(e, (0, _axiosErrorJsDefault.default).ERR_BAD_RESPONSE, this, null, this.response);
                        throw e;
                    }
                }
            }
            return data;
        }
    ],
    /**
   * A timeout in milliseconds to abort a request. If set to 0 (default) a
   * timeout is not created.
   */ timeout: 0,
    xsrfCookieName: "XSRF-TOKEN",
    xsrfHeaderName: "X-XSRF-TOKEN",
    maxContentLength: -1,
    maxBodyLength: -1,
    env: {
        FormData: (0, _indexJsDefault.default).classes.FormData,
        Blob: (0, _indexJsDefault.default).classes.Blob
    },
    validateStatus: function validateStatus(status) {
        return status >= 200 && status < 300;
    },
    headers: {
        common: {
            "Accept": "application/json, text/plain, */*",
            "Content-Type": undefined
        }
    }
};
(0, _utilsJsDefault.default).forEach([
    "delete",
    "get",
    "head",
    "post",
    "put",
    "patch"
], (method)=>{
    defaults.headers[method] = {};
});
exports.default = defaults;

},{"../utils.js":"dNjua","../core/AxiosError.js":"1OwwO","./transitional.js":"aqR16","../helpers/toFormData.js":"kEMey","../helpers/toURLEncodedForm.js":"beT5a","../platform/index.js":"2mULr","../helpers/formDataToJSON.js":"bKZdy","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"aqR16":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
"use strict";
exports.default = {
    silentJSONParsing: true,
    forcedJSONParsing: true,
    clarifyTimeoutError: false
};

},{"@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"beT5a":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>toURLEncodedForm);
var _utilsJs = require("../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
var _toFormDataJs = require("./toFormData.js");
var _toFormDataJsDefault = parcelHelpers.interopDefault(_toFormDataJs);
var _indexJs = require("../platform/index.js");
var _indexJsDefault = parcelHelpers.interopDefault(_indexJs);
"use strict";
function toURLEncodedForm(data, options) {
    return (0, _toFormDataJsDefault.default)(data, new (0, _indexJsDefault.default).classes.URLSearchParams(), Object.assign({
        visitor: function(value, key, path, helpers) {
            if ((0, _indexJsDefault.default).isNode && (0, _utilsJsDefault.default).isBuffer(value)) {
                this.append(key, value.toString("base64"));
                return false;
            }
            return helpers.defaultVisitor.apply(this, arguments);
        }
    }, options));
}

},{"../utils.js":"dNjua","./toFormData.js":"kEMey","../platform/index.js":"2mULr","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"2mULr":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _indexJs = require("./node/index.js");
var _indexJsDefault = parcelHelpers.interopDefault(_indexJs);
var _utilsJs = require("./common/utils.js");
exports.default = {
    ..._utilsJs,
    ...(0, _indexJsDefault.default)
};

},{"./node/index.js":"6mHDd","./common/utils.js":"bc9H6","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"6mHDd":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _urlsearchParamsJs = require("./classes/URLSearchParams.js");
var _urlsearchParamsJsDefault = parcelHelpers.interopDefault(_urlsearchParamsJs);
var _formDataJs = require("./classes/FormData.js");
var _formDataJsDefault = parcelHelpers.interopDefault(_formDataJs);
var _blobJs = require("./classes/Blob.js");
var _blobJsDefault = parcelHelpers.interopDefault(_blobJs);
exports.default = {
    isBrowser: true,
    classes: {
        URLSearchParams: (0, _urlsearchParamsJsDefault.default),
        FormData: (0, _formDataJsDefault.default),
        Blob: (0, _blobJsDefault.default)
    },
    protocols: [
        "http",
        "https",
        "file",
        "blob",
        "url",
        "data"
    ]
};

},{"./classes/URLSearchParams.js":"8Znds","./classes/FormData.js":"axzu5","./classes/Blob.js":"izlE1","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"8Znds":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _axiosURLSearchParamsJs = require("../../../helpers/AxiosURLSearchParams.js");
var _axiosURLSearchParamsJsDefault = parcelHelpers.interopDefault(_axiosURLSearchParamsJs);
"use strict";
exports.default = typeof URLSearchParams !== "undefined" ? URLSearchParams : (0, _axiosURLSearchParamsJsDefault.default);

},{"../../../helpers/AxiosURLSearchParams.js":"h9HvX","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"axzu5":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
"use strict";
exports.default = typeof FormData !== "undefined" ? FormData : null;

},{"@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"izlE1":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
"use strict";
exports.default = typeof Blob !== "undefined" ? Blob : null;

},{"@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"bc9H6":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "hasBrowserEnv", ()=>hasBrowserEnv);
parcelHelpers.export(exports, "hasStandardBrowserWebWorkerEnv", ()=>hasStandardBrowserWebWorkerEnv);
parcelHelpers.export(exports, "hasStandardBrowserEnv", ()=>hasStandardBrowserEnv);
const hasBrowserEnv = typeof window !== "undefined" && typeof document !== "undefined";
/**
 * Determine if we're running in a standard browser environment
 *
 * This allows axios to run in a web worker, and react-native.
 * Both environments support XMLHttpRequest, but not fully standard globals.
 *
 * web workers:
 *  typeof window -> undefined
 *  typeof document -> undefined
 *
 * react-native:
 *  navigator.product -> 'ReactNative'
 * nativescript
 *  navigator.product -> 'NativeScript' or 'NS'
 *
 * @returns {boolean}
 */ const hasStandardBrowserEnv = ((product)=>{
    return hasBrowserEnv && [
        "ReactNative",
        "NativeScript",
        "NS"
    ].indexOf(product) < 0;
})(typeof navigator !== "undefined" && navigator.product);
/**
 * Determine if we're running in a standard browser webWorker environment
 *
 * Although the `isStandardBrowserEnv` method indicates that
 * `allows axios to run in a web worker`, the WebWorker will still be
 * filtered out due to its judgment standard
 * `typeof window !== 'undefined' && typeof document !== 'undefined'`.
 * This leads to a problem when axios post `FormData` in webWorker
 */ const hasStandardBrowserWebWorkerEnv = (()=>{
    return typeof WorkerGlobalScope !== "undefined" && // eslint-disable-next-line no-undef
    self instanceof WorkerGlobalScope && typeof self.importScripts === "function";
})();

},{"@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"bKZdy":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _utilsJs = require("../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
"use strict";
/**
 * It takes a string like `foo[x][y][z]` and returns an array like `['foo', 'x', 'y', 'z']
 *
 * @param {string} name - The name of the property to get.
 *
 * @returns An array of strings.
 */ function parsePropPath(name) {
    // foo[x][y][z]
    // foo.x.y.z
    // foo-x-y-z
    // foo x y z
    return (0, _utilsJsDefault.default).matchAll(/\w+|\[(\w*)]/g, name).map((match)=>{
        return match[0] === "[]" ? "" : match[1] || match[0];
    });
}
/**
 * Convert an array to an object.
 *
 * @param {Array<any>} arr - The array to convert to an object.
 *
 * @returns An object with the same keys and values as the array.
 */ function arrayToObject(arr) {
    const obj = {};
    const keys = Object.keys(arr);
    let i;
    const len = keys.length;
    let key;
    for(i = 0; i < len; i++){
        key = keys[i];
        obj[key] = arr[key];
    }
    return obj;
}
/**
 * It takes a FormData object and returns a JavaScript object
 *
 * @param {string} formData The FormData object to convert to JSON.
 *
 * @returns {Object<string, any> | null} The converted object.
 */ function formDataToJSON(formData) {
    function buildPath(path, value, target, index) {
        let name = path[index++];
        if (name === "__proto__") return true;
        const isNumericKey = Number.isFinite(+name);
        const isLast = index >= path.length;
        name = !name && (0, _utilsJsDefault.default).isArray(target) ? target.length : name;
        if (isLast) {
            if ((0, _utilsJsDefault.default).hasOwnProp(target, name)) target[name] = [
                target[name],
                value
            ];
            else target[name] = value;
            return !isNumericKey;
        }
        if (!target[name] || !(0, _utilsJsDefault.default).isObject(target[name])) target[name] = [];
        const result = buildPath(path, value, target[name], index);
        if (result && (0, _utilsJsDefault.default).isArray(target[name])) target[name] = arrayToObject(target[name]);
        return !isNumericKey;
    }
    if ((0, _utilsJsDefault.default).isFormData(formData) && (0, _utilsJsDefault.default).isFunction(formData.entries)) {
        const obj = {};
        (0, _utilsJsDefault.default).forEachEntry(formData, (name, value)=>{
            buildPath(parsePropPath(name), value, obj, 0);
        });
        return obj;
    }
    return null;
}
exports.default = formDataToJSON;

},{"../utils.js":"dNjua","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"gTOgd":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _utilsJs = require("../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
var _parseHeadersJs = require("../helpers/parseHeaders.js");
var _parseHeadersJsDefault = parcelHelpers.interopDefault(_parseHeadersJs);
"use strict";
const $internals = Symbol("internals");
function normalizeHeader(header) {
    return header && String(header).trim().toLowerCase();
}
function normalizeValue(value) {
    if (value === false || value == null) return value;
    return (0, _utilsJsDefault.default).isArray(value) ? value.map(normalizeValue) : String(value);
}
function parseTokens(str) {
    const tokens = Object.create(null);
    const tokensRE = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
    let match;
    while(match = tokensRE.exec(str))tokens[match[1]] = match[2];
    return tokens;
}
const isValidHeaderName = (str)=>/^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(str.trim());
function matchHeaderValue(context, value, header, filter, isHeaderNameFilter) {
    if ((0, _utilsJsDefault.default).isFunction(filter)) return filter.call(this, value, header);
    if (isHeaderNameFilter) value = header;
    if (!(0, _utilsJsDefault.default).isString(value)) return;
    if ((0, _utilsJsDefault.default).isString(filter)) return value.indexOf(filter) !== -1;
    if ((0, _utilsJsDefault.default).isRegExp(filter)) return filter.test(value);
}
function formatHeader(header) {
    return header.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (w, char, str)=>{
        return char.toUpperCase() + str;
    });
}
function buildAccessors(obj, header) {
    const accessorName = (0, _utilsJsDefault.default).toCamelCase(" " + header);
    [
        "get",
        "set",
        "has"
    ].forEach((methodName)=>{
        Object.defineProperty(obj, methodName + accessorName, {
            value: function(arg1, arg2, arg3) {
                return this[methodName].call(this, header, arg1, arg2, arg3);
            },
            configurable: true
        });
    });
}
class AxiosHeaders {
    constructor(headers){
        headers && this.set(headers);
    }
    set(header, valueOrRewrite, rewrite) {
        const self = this;
        function setHeader(_value, _header, _rewrite) {
            const lHeader = normalizeHeader(_header);
            if (!lHeader) throw new Error("header name must be a non-empty string");
            const key = (0, _utilsJsDefault.default).findKey(self, lHeader);
            if (!key || self[key] === undefined || _rewrite === true || _rewrite === undefined && self[key] !== false) self[key || _header] = normalizeValue(_value);
        }
        const setHeaders = (headers, _rewrite)=>(0, _utilsJsDefault.default).forEach(headers, (_value, _header)=>setHeader(_value, _header, _rewrite));
        if ((0, _utilsJsDefault.default).isPlainObject(header) || header instanceof this.constructor) setHeaders(header, valueOrRewrite);
        else if ((0, _utilsJsDefault.default).isString(header) && (header = header.trim()) && !isValidHeaderName(header)) setHeaders((0, _parseHeadersJsDefault.default)(header), valueOrRewrite);
        else header != null && setHeader(valueOrRewrite, header, rewrite);
        return this;
    }
    get(header, parser) {
        header = normalizeHeader(header);
        if (header) {
            const key = (0, _utilsJsDefault.default).findKey(this, header);
            if (key) {
                const value = this[key];
                if (!parser) return value;
                if (parser === true) return parseTokens(value);
                if ((0, _utilsJsDefault.default).isFunction(parser)) return parser.call(this, value, key);
                if ((0, _utilsJsDefault.default).isRegExp(parser)) return parser.exec(value);
                throw new TypeError("parser must be boolean|regexp|function");
            }
        }
    }
    has(header, matcher) {
        header = normalizeHeader(header);
        if (header) {
            const key = (0, _utilsJsDefault.default).findKey(this, header);
            return !!(key && this[key] !== undefined && (!matcher || matchHeaderValue(this, this[key], key, matcher)));
        }
        return false;
    }
    delete(header, matcher) {
        const self = this;
        let deleted = false;
        function deleteHeader(_header) {
            _header = normalizeHeader(_header);
            if (_header) {
                const key = (0, _utilsJsDefault.default).findKey(self, _header);
                if (key && (!matcher || matchHeaderValue(self, self[key], key, matcher))) {
                    delete self[key];
                    deleted = true;
                }
            }
        }
        if ((0, _utilsJsDefault.default).isArray(header)) header.forEach(deleteHeader);
        else deleteHeader(header);
        return deleted;
    }
    clear(matcher) {
        const keys = Object.keys(this);
        let i = keys.length;
        let deleted = false;
        while(i--){
            const key = keys[i];
            if (!matcher || matchHeaderValue(this, this[key], key, matcher, true)) {
                delete this[key];
                deleted = true;
            }
        }
        return deleted;
    }
    normalize(format) {
        const self = this;
        const headers = {};
        (0, _utilsJsDefault.default).forEach(this, (value, header)=>{
            const key = (0, _utilsJsDefault.default).findKey(headers, header);
            if (key) {
                self[key] = normalizeValue(value);
                delete self[header];
                return;
            }
            const normalized = format ? formatHeader(header) : String(header).trim();
            if (normalized !== header) delete self[header];
            self[normalized] = normalizeValue(value);
            headers[normalized] = true;
        });
        return this;
    }
    concat(...targets) {
        return this.constructor.concat(this, ...targets);
    }
    toJSON(asStrings) {
        const obj = Object.create(null);
        (0, _utilsJsDefault.default).forEach(this, (value, header)=>{
            value != null && value !== false && (obj[header] = asStrings && (0, _utilsJsDefault.default).isArray(value) ? value.join(", ") : value);
        });
        return obj;
    }
    [Symbol.iterator]() {
        return Object.entries(this.toJSON())[Symbol.iterator]();
    }
    toString() {
        return Object.entries(this.toJSON()).map(([header, value])=>header + ": " + value).join("\n");
    }
    get [Symbol.toStringTag]() {
        return "AxiosHeaders";
    }
    static from(thing) {
        return thing instanceof this ? thing : new this(thing);
    }
    static concat(first, ...targets) {
        const computed = new this(first);
        targets.forEach((target)=>computed.set(target));
        return computed;
    }
    static accessor(header) {
        const internals = this[$internals] = this[$internals] = {
            accessors: {}
        };
        const accessors = internals.accessors;
        const prototype = this.prototype;
        function defineAccessor(_header) {
            const lHeader = normalizeHeader(_header);
            if (!accessors[lHeader]) {
                buildAccessors(prototype, _header);
                accessors[lHeader] = true;
            }
        }
        (0, _utilsJsDefault.default).isArray(header) ? header.forEach(defineAccessor) : defineAccessor(header);
        return this;
    }
}
AxiosHeaders.accessor([
    "Content-Type",
    "Content-Length",
    "Accept",
    "Accept-Encoding",
    "User-Agent",
    "Authorization"
]);
// reserved names hotfix
(0, _utilsJsDefault.default).reduceDescriptors(AxiosHeaders.prototype, ({ value }, key)=>{
    let mapped = key[0].toUpperCase() + key.slice(1); // map `set` => `Set`
    return {
        get: ()=>value,
        set (headerValue) {
            this[mapped] = headerValue;
        }
    };
});
(0, _utilsJsDefault.default).freezeMethods(AxiosHeaders);
exports.default = AxiosHeaders;

},{"../utils.js":"dNjua","../helpers/parseHeaders.js":"bJpZN","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"bJpZN":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _utilsJs = require("./../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
"use strict";
// RawAxiosHeaders whose duplicates are ignored by node
// c.f. https://nodejs.org/api/http.html#http_message_headers
const ignoreDuplicateOf = (0, _utilsJsDefault.default).toObjectSet([
    "age",
    "authorization",
    "content-length",
    "content-type",
    "etag",
    "expires",
    "from",
    "host",
    "if-modified-since",
    "if-unmodified-since",
    "last-modified",
    "location",
    "max-forwards",
    "proxy-authorization",
    "referer",
    "retry-after",
    "user-agent"
]);
/**
 * Parse headers into an object
 *
 * ```
 * Date: Wed, 27 Aug 2014 08:58:49 GMT
 * Content-Type: application/json
 * Connection: keep-alive
 * Transfer-Encoding: chunked
 * ```
 *
 * @param {String} rawHeaders Headers needing to be parsed
 *
 * @returns {Object} Headers parsed into an object
 */ exports.default = (rawHeaders)=>{
    const parsed = {};
    let key;
    let val;
    let i;
    rawHeaders && rawHeaders.split("\n").forEach(function parser(line) {
        i = line.indexOf(":");
        key = line.substring(0, i).trim().toLowerCase();
        val = line.substring(i + 1).trim();
        if (!key || parsed[key] && ignoreDuplicateOf[key]) return;
        if (key === "set-cookie") {
            if (parsed[key]) parsed[key].push(val);
            else parsed[key] = [
                val
            ];
        } else parsed[key] = parsed[key] ? parsed[key] + ", " + val : val;
    });
    return parsed;
};

},{"./../utils.js":"dNjua","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"i4WpT":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>isCancel);
"use strict";
function isCancel(value) {
    return !!(value && value.__CANCEL__);
}

},{"@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"byMZp":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _axiosErrorJs = require("../core/AxiosError.js");
var _axiosErrorJsDefault = parcelHelpers.interopDefault(_axiosErrorJs);
var _utilsJs = require("../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
"use strict";
/**
 * A `CanceledError` is an object that is thrown when an operation is canceled.
 *
 * @param {string=} message The message.
 * @param {Object=} config The config.
 * @param {Object=} request The request.
 *
 * @returns {CanceledError} The created error.
 */ function CanceledError(message, config, request) {
    // eslint-disable-next-line no-eq-null,eqeqeq
    (0, _axiosErrorJsDefault.default).call(this, message == null ? "canceled" : message, (0, _axiosErrorJsDefault.default).ERR_CANCELED, config, request);
    this.name = "CanceledError";
}
(0, _utilsJsDefault.default).inherits(CanceledError, (0, _axiosErrorJsDefault.default), {
    __CANCEL__: true
});
exports.default = CanceledError;

},{"../core/AxiosError.js":"1OwwO","../utils.js":"dNjua","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"fDdzI":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _utilsJs = require("../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
var _httpJs = require("./http.js");
var _httpJsDefault = parcelHelpers.interopDefault(_httpJs);
var _xhrJs = require("./xhr.js");
var _xhrJsDefault = parcelHelpers.interopDefault(_xhrJs);
var _axiosErrorJs = require("../core/AxiosError.js");
var _axiosErrorJsDefault = parcelHelpers.interopDefault(_axiosErrorJs);
const knownAdapters = {
    http: (0, _httpJsDefault.default),
    xhr: (0, _xhrJsDefault.default)
};
(0, _utilsJsDefault.default).forEach(knownAdapters, (fn, value)=>{
    if (fn) {
        try {
            Object.defineProperty(fn, "name", {
                value
            });
        } catch (e) {
        // eslint-disable-next-line no-empty
        }
        Object.defineProperty(fn, "adapterName", {
            value
        });
    }
});
const renderReason = (reason)=>`- ${reason}`;
const isResolvedHandle = (adapter)=>(0, _utilsJsDefault.default).isFunction(adapter) || adapter === null || adapter === false;
exports.default = {
    getAdapter: (adapters)=>{
        adapters = (0, _utilsJsDefault.default).isArray(adapters) ? adapters : [
            adapters
        ];
        const { length } = adapters;
        let nameOrAdapter;
        let adapter;
        const rejectedReasons = {};
        for(let i = 0; i < length; i++){
            nameOrAdapter = adapters[i];
            let id;
            adapter = nameOrAdapter;
            if (!isResolvedHandle(nameOrAdapter)) {
                adapter = knownAdapters[(id = String(nameOrAdapter)).toLowerCase()];
                if (adapter === undefined) throw new (0, _axiosErrorJsDefault.default)(`Unknown adapter '${id}'`);
            }
            if (adapter) break;
            rejectedReasons[id || "#" + i] = adapter;
        }
        if (!adapter) {
            const reasons = Object.entries(rejectedReasons).map(([id, state])=>`adapter ${id} ` + (state === false ? "is not supported by the environment" : "is not available in the build"));
            let s = length ? reasons.length > 1 ? "since :\n" + reasons.map(renderReason).join("\n") : " " + renderReason(reasons[0]) : "as no adapter specified";
            throw new (0, _axiosErrorJsDefault.default)(`There is no suitable adapter to dispatch the request ` + s, "ERR_NOT_SUPPORT");
        }
        return adapter;
    },
    adapters: knownAdapters
};

},{"../utils.js":"dNjua","./http.js":"04BpO","./xhr.js":"iNKBT","../core/AxiosError.js":"1OwwO","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"iNKBT":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _utilsJs = require("./../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
var _settleJs = require("./../core/settle.js");
var _settleJsDefault = parcelHelpers.interopDefault(_settleJs);
var _cookiesJs = require("./../helpers/cookies.js");
var _cookiesJsDefault = parcelHelpers.interopDefault(_cookiesJs);
var _buildURLJs = require("./../helpers/buildURL.js");
var _buildURLJsDefault = parcelHelpers.interopDefault(_buildURLJs);
var _buildFullPathJs = require("../core/buildFullPath.js");
var _buildFullPathJsDefault = parcelHelpers.interopDefault(_buildFullPathJs);
var _isURLSameOriginJs = require("./../helpers/isURLSameOrigin.js");
var _isURLSameOriginJsDefault = parcelHelpers.interopDefault(_isURLSameOriginJs);
var _transitionalJs = require("../defaults/transitional.js");
var _transitionalJsDefault = parcelHelpers.interopDefault(_transitionalJs);
var _axiosErrorJs = require("../core/AxiosError.js");
var _axiosErrorJsDefault = parcelHelpers.interopDefault(_axiosErrorJs);
var _canceledErrorJs = require("../cancel/CanceledError.js");
var _canceledErrorJsDefault = parcelHelpers.interopDefault(_canceledErrorJs);
var _parseProtocolJs = require("../helpers/parseProtocol.js");
var _parseProtocolJsDefault = parcelHelpers.interopDefault(_parseProtocolJs);
var _indexJs = require("../platform/index.js");
var _indexJsDefault = parcelHelpers.interopDefault(_indexJs);
var _axiosHeadersJs = require("../core/AxiosHeaders.js");
var _axiosHeadersJsDefault = parcelHelpers.interopDefault(_axiosHeadersJs);
var _speedometerJs = require("../helpers/speedometer.js");
var _speedometerJsDefault = parcelHelpers.interopDefault(_speedometerJs);
"use strict";
function progressEventReducer(listener, isDownloadStream) {
    let bytesNotified = 0;
    const _speedometer = (0, _speedometerJsDefault.default)(50, 250);
    return (e)=>{
        const loaded = e.loaded;
        const total = e.lengthComputable ? e.total : undefined;
        const progressBytes = loaded - bytesNotified;
        const rate = _speedometer(progressBytes);
        const inRange = loaded <= total;
        bytesNotified = loaded;
        const data = {
            loaded,
            total,
            progress: total ? loaded / total : undefined,
            bytes: progressBytes,
            rate: rate ? rate : undefined,
            estimated: rate && total && inRange ? (total - loaded) / rate : undefined,
            event: e
        };
        data[isDownloadStream ? "download" : "upload"] = true;
        listener(data);
    };
}
const isXHRAdapterSupported = typeof XMLHttpRequest !== "undefined";
exports.default = isXHRAdapterSupported && function(config) {
    return new Promise(function dispatchXhrRequest(resolve, reject) {
        let requestData = config.data;
        const requestHeaders = (0, _axiosHeadersJsDefault.default).from(config.headers).normalize();
        let { responseType, withXSRFToken } = config;
        let onCanceled;
        function done() {
            if (config.cancelToken) config.cancelToken.unsubscribe(onCanceled);
            if (config.signal) config.signal.removeEventListener("abort", onCanceled);
        }
        let contentType;
        if ((0, _utilsJsDefault.default).isFormData(requestData)) {
            if ((0, _indexJsDefault.default).hasStandardBrowserEnv || (0, _indexJsDefault.default).hasStandardBrowserWebWorkerEnv) requestHeaders.setContentType(false); // Let the browser set it
            else if ((contentType = requestHeaders.getContentType()) !== false) {
                // fix semicolon duplication issue for ReactNative FormData implementation
                const [type, ...tokens] = contentType ? contentType.split(";").map((token)=>token.trim()).filter(Boolean) : [];
                requestHeaders.setContentType([
                    type || "multipart/form-data",
                    ...tokens
                ].join("; "));
            }
        }
        let request = new XMLHttpRequest();
        // HTTP basic authentication
        if (config.auth) {
            const username = config.auth.username || "";
            const password = config.auth.password ? unescape(encodeURIComponent(config.auth.password)) : "";
            requestHeaders.set("Authorization", "Basic " + btoa(username + ":" + password));
        }
        const fullPath = (0, _buildFullPathJsDefault.default)(config.baseURL, config.url);
        request.open(config.method.toUpperCase(), (0, _buildURLJsDefault.default)(fullPath, config.params, config.paramsSerializer), true);
        // Set the request timeout in MS
        request.timeout = config.timeout;
        function onloadend() {
            if (!request) return;
            // Prepare the response
            const responseHeaders = (0, _axiosHeadersJsDefault.default).from("getAllResponseHeaders" in request && request.getAllResponseHeaders());
            const responseData = !responseType || responseType === "text" || responseType === "json" ? request.responseText : request.response;
            const response = {
                data: responseData,
                status: request.status,
                statusText: request.statusText,
                headers: responseHeaders,
                config,
                request
            };
            (0, _settleJsDefault.default)(function _resolve(value) {
                resolve(value);
                done();
            }, function _reject(err) {
                reject(err);
                done();
            }, response);
            // Clean up request
            request = null;
        }
        if ("onloadend" in request) // Use onloadend if available
        request.onloadend = onloadend;
        else // Listen for ready state to emulate onloadend
        request.onreadystatechange = function handleLoad() {
            if (!request || request.readyState !== 4) return;
            // The request errored out and we didn't get a response, this will be
            // handled by onerror instead
            // With one exception: request that using file: protocol, most browsers
            // will return status as 0 even though it's a successful request
            if (request.status === 0 && !(request.responseURL && request.responseURL.indexOf("file:") === 0)) return;
            // readystate handler is calling before onerror or ontimeout handlers,
            // so we should call onloadend on the next 'tick'
            setTimeout(onloadend);
        };
        // Handle browser request cancellation (as opposed to a manual cancellation)
        request.onabort = function handleAbort() {
            if (!request) return;
            reject(new (0, _axiosErrorJsDefault.default)("Request aborted", (0, _axiosErrorJsDefault.default).ECONNABORTED, config, request));
            // Clean up request
            request = null;
        };
        // Handle low level network errors
        request.onerror = function handleError() {
            // Real errors are hidden from us by the browser
            // onerror should only fire if it's a network error
            reject(new (0, _axiosErrorJsDefault.default)("Network Error", (0, _axiosErrorJsDefault.default).ERR_NETWORK, config, request));
            // Clean up request
            request = null;
        };
        // Handle timeout
        request.ontimeout = function handleTimeout() {
            let timeoutErrorMessage = config.timeout ? "timeout of " + config.timeout + "ms exceeded" : "timeout exceeded";
            const transitional = config.transitional || (0, _transitionalJsDefault.default);
            if (config.timeoutErrorMessage) timeoutErrorMessage = config.timeoutErrorMessage;
            reject(new (0, _axiosErrorJsDefault.default)(timeoutErrorMessage, transitional.clarifyTimeoutError ? (0, _axiosErrorJsDefault.default).ETIMEDOUT : (0, _axiosErrorJsDefault.default).ECONNABORTED, config, request));
            // Clean up request
            request = null;
        };
        // Add xsrf header
        // This is only done if running in a standard browser environment.
        // Specifically not if we're in a web worker, or react-native.
        if ((0, _indexJsDefault.default).hasStandardBrowserEnv) {
            withXSRFToken && (0, _utilsJsDefault.default).isFunction(withXSRFToken) && (withXSRFToken = withXSRFToken(config));
            if (withXSRFToken || withXSRFToken !== false && (0, _isURLSameOriginJsDefault.default)(fullPath)) {
                // Add xsrf header
                const xsrfValue = config.xsrfHeaderName && config.xsrfCookieName && (0, _cookiesJsDefault.default).read(config.xsrfCookieName);
                if (xsrfValue) requestHeaders.set(config.xsrfHeaderName, xsrfValue);
            }
        }
        // Remove Content-Type if data is undefined
        requestData === undefined && requestHeaders.setContentType(null);
        // Add headers to the request
        if ("setRequestHeader" in request) (0, _utilsJsDefault.default).forEach(requestHeaders.toJSON(), function setRequestHeader(val, key) {
            request.setRequestHeader(key, val);
        });
        // Add withCredentials to request if needed
        if (!(0, _utilsJsDefault.default).isUndefined(config.withCredentials)) request.withCredentials = !!config.withCredentials;
        // Add responseType to request if needed
        if (responseType && responseType !== "json") request.responseType = config.responseType;
        // Handle progress if needed
        if (typeof config.onDownloadProgress === "function") request.addEventListener("progress", progressEventReducer(config.onDownloadProgress, true));
        // Not all browsers support upload events
        if (typeof config.onUploadProgress === "function" && request.upload) request.upload.addEventListener("progress", progressEventReducer(config.onUploadProgress));
        if (config.cancelToken || config.signal) {
            // Handle cancellation
            // eslint-disable-next-line func-names
            onCanceled = (cancel)=>{
                if (!request) return;
                reject(!cancel || cancel.type ? new (0, _canceledErrorJsDefault.default)(null, config, request) : cancel);
                request.abort();
                request = null;
            };
            config.cancelToken && config.cancelToken.subscribe(onCanceled);
            if (config.signal) config.signal.aborted ? onCanceled() : config.signal.addEventListener("abort", onCanceled);
        }
        const protocol = (0, _parseProtocolJsDefault.default)(fullPath);
        if (protocol && (0, _indexJsDefault.default).protocols.indexOf(protocol) === -1) {
            reject(new (0, _axiosErrorJsDefault.default)("Unsupported protocol " + protocol + ":", (0, _axiosErrorJsDefault.default).ERR_BAD_REQUEST, config));
            return;
        }
        // Send the request
        request.send(requestData || null);
    });
};

},{"./../utils.js":"dNjua","./../core/settle.js":"i19BL","./../helpers/cookies.js":"8mZkm","./../helpers/buildURL.js":"gdwll","../core/buildFullPath.js":"ey4Hd","./../helpers/isURLSameOrigin.js":"b6507","../defaults/transitional.js":"aqR16","../core/AxiosError.js":"1OwwO","../cancel/CanceledError.js":"byMZp","../helpers/parseProtocol.js":"7PoPk","../platform/index.js":"2mULr","../core/AxiosHeaders.js":"gTOgd","../helpers/speedometer.js":"elFm1","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"i19BL":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>settle);
var _axiosErrorJs = require("./AxiosError.js");
var _axiosErrorJsDefault = parcelHelpers.interopDefault(_axiosErrorJs);
"use strict";
function settle(resolve, reject, response) {
    const validateStatus = response.config.validateStatus;
    if (!response.status || !validateStatus || validateStatus(response.status)) resolve(response);
    else reject(new (0, _axiosErrorJsDefault.default)("Request failed with status code " + response.status, [
        (0, _axiosErrorJsDefault.default).ERR_BAD_REQUEST,
        (0, _axiosErrorJsDefault.default).ERR_BAD_RESPONSE
    ][Math.floor(response.status / 100) - 4], response.config, response.request, response));
}

},{"./AxiosError.js":"1OwwO","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"8mZkm":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _utilsJs = require("./../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
var _indexJs = require("../platform/index.js");
var _indexJsDefault = parcelHelpers.interopDefault(_indexJs);
exports.default = (0, _indexJsDefault.default).hasStandardBrowserEnv ? // Standard browser envs support document.cookie
{
    write (name, value, expires, path, domain, secure) {
        const cookie = [
            name + "=" + encodeURIComponent(value)
        ];
        (0, _utilsJsDefault.default).isNumber(expires) && cookie.push("expires=" + new Date(expires).toGMTString());
        (0, _utilsJsDefault.default).isString(path) && cookie.push("path=" + path);
        (0, _utilsJsDefault.default).isString(domain) && cookie.push("domain=" + domain);
        secure === true && cookie.push("secure");
        document.cookie = cookie.join("; ");
    },
    read (name) {
        const match = document.cookie.match(new RegExp("(^|;\\s*)(" + name + ")=([^;]*)"));
        return match ? decodeURIComponent(match[3]) : null;
    },
    remove (name) {
        this.write(name, "", Date.now() - 86400000);
    }
} : // Non-standard browser env (web workers, react-native) lack needed support.
{
    write () {},
    read () {
        return null;
    },
    remove () {}
};

},{"./../utils.js":"dNjua","../platform/index.js":"2mULr","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"ey4Hd":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>buildFullPath);
var _isAbsoluteURLJs = require("../helpers/isAbsoluteURL.js");
var _isAbsoluteURLJsDefault = parcelHelpers.interopDefault(_isAbsoluteURLJs);
var _combineURLsJs = require("../helpers/combineURLs.js");
var _combineURLsJsDefault = parcelHelpers.interopDefault(_combineURLsJs);
"use strict";
function buildFullPath(baseURL, requestedURL) {
    if (baseURL && !(0, _isAbsoluteURLJsDefault.default)(requestedURL)) return (0, _combineURLsJsDefault.default)(baseURL, requestedURL);
    return requestedURL;
}

},{"../helpers/isAbsoluteURL.js":"bEzbp","../helpers/combineURLs.js":"dNnGv","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"bEzbp":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>isAbsoluteURL);
"use strict";
function isAbsoluteURL(url) {
    // A URL is considered absolute if it begins with "<scheme>://" or "//" (protocol-relative URL).
    // RFC 3986 defines scheme name as a sequence of characters beginning with a letter and followed
    // by any combination of letters, digits, plus, period, or hyphen.
    return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(url);
}

},{"@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"dNnGv":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>combineURLs);
"use strict";
function combineURLs(baseURL, relativeURL) {
    return relativeURL ? baseURL.replace(/\/?\/$/, "") + "/" + relativeURL.replace(/^\/+/, "") : baseURL;
}

},{"@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"b6507":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _utilsJs = require("./../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
var _indexJs = require("../platform/index.js");
var _indexJsDefault = parcelHelpers.interopDefault(_indexJs);
"use strict";
exports.default = (0, _indexJsDefault.default).hasStandardBrowserEnv ? // Standard browser envs have full support of the APIs needed to test
// whether the request URL is of the same origin as current location.
function standardBrowserEnv() {
    const msie = /(msie|trident)/i.test(navigator.userAgent);
    const urlParsingNode = document.createElement("a");
    let originURL;
    /**
    * Parse a URL to discover its components
    *
    * @param {String} url The URL to be parsed
    * @returns {Object}
    */ function resolveURL(url) {
        let href = url;
        if (msie) {
            // IE needs attribute set twice to normalize properties
            urlParsingNode.setAttribute("href", href);
            href = urlParsingNode.href;
        }
        urlParsingNode.setAttribute("href", href);
        // urlParsingNode provides the UrlUtils interface - http://url.spec.whatwg.org/#urlutils
        return {
            href: urlParsingNode.href,
            protocol: urlParsingNode.protocol ? urlParsingNode.protocol.replace(/:$/, "") : "",
            host: urlParsingNode.host,
            search: urlParsingNode.search ? urlParsingNode.search.replace(/^\?/, "") : "",
            hash: urlParsingNode.hash ? urlParsingNode.hash.replace(/^#/, "") : "",
            hostname: urlParsingNode.hostname,
            port: urlParsingNode.port,
            pathname: urlParsingNode.pathname.charAt(0) === "/" ? urlParsingNode.pathname : "/" + urlParsingNode.pathname
        };
    }
    originURL = resolveURL(window.location.href);
    /**
    * Determine if a URL shares the same origin as the current location
    *
    * @param {String} requestURL The URL to test
    * @returns {boolean} True if URL shares the same origin, otherwise false
    */ return function isURLSameOrigin(requestURL) {
        const parsed = (0, _utilsJsDefault.default).isString(requestURL) ? resolveURL(requestURL) : requestURL;
        return parsed.protocol === originURL.protocol && parsed.host === originURL.host;
    };
}() : // Non standard browser envs (web workers, react-native) lack needed support.
function nonStandardBrowserEnv() {
    return function isURLSameOrigin() {
        return true;
    };
}();

},{"./../utils.js":"dNjua","../platform/index.js":"2mULr","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"7PoPk":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>parseProtocol);
"use strict";
function parseProtocol(url) {
    const match = /^([-+\w]{1,25})(:?\/\/|:)/.exec(url);
    return match && match[1] || "";
}

},{"@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"elFm1":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
"use strict";
/**
 * Calculate data maxRate
 * @param {Number} [samplesCount= 10]
 * @param {Number} [min= 1000]
 * @returns {Function}
 */ function speedometer(samplesCount, min) {
    samplesCount = samplesCount || 10;
    const bytes = new Array(samplesCount);
    const timestamps = new Array(samplesCount);
    let head = 0;
    let tail = 0;
    let firstSampleTS;
    min = min !== undefined ? min : 1000;
    return function push(chunkLength) {
        const now = Date.now();
        const startedAt = timestamps[tail];
        if (!firstSampleTS) firstSampleTS = now;
        bytes[head] = chunkLength;
        timestamps[head] = now;
        let i = tail;
        let bytesCount = 0;
        while(i !== head){
            bytesCount += bytes[i++];
            i = i % samplesCount;
        }
        head = (head + 1) % samplesCount;
        if (head === tail) tail = (tail + 1) % samplesCount;
        if (now - firstSampleTS < min) return;
        const passed = startedAt && now - startedAt;
        return passed ? Math.round(bytesCount * 1000 / passed) : undefined;
    };
}
exports.default = speedometer;

},{"@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"hQkWT":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>mergeConfig);
var _utilsJs = require("../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
var _axiosHeadersJs = require("./AxiosHeaders.js");
var _axiosHeadersJsDefault = parcelHelpers.interopDefault(_axiosHeadersJs);
"use strict";
const headersToObject = (thing)=>thing instanceof (0, _axiosHeadersJsDefault.default) ? {
        ...thing
    } : thing;
function mergeConfig(config1, config2) {
    // eslint-disable-next-line no-param-reassign
    config2 = config2 || {};
    const config = {};
    function getMergedValue(target, source, caseless) {
        if ((0, _utilsJsDefault.default).isPlainObject(target) && (0, _utilsJsDefault.default).isPlainObject(source)) return (0, _utilsJsDefault.default).merge.call({
            caseless
        }, target, source);
        else if ((0, _utilsJsDefault.default).isPlainObject(source)) return (0, _utilsJsDefault.default).merge({}, source);
        else if ((0, _utilsJsDefault.default).isArray(source)) return source.slice();
        return source;
    }
    // eslint-disable-next-line consistent-return
    function mergeDeepProperties(a, b, caseless) {
        if (!(0, _utilsJsDefault.default).isUndefined(b)) return getMergedValue(a, b, caseless);
        else if (!(0, _utilsJsDefault.default).isUndefined(a)) return getMergedValue(undefined, a, caseless);
    }
    // eslint-disable-next-line consistent-return
    function valueFromConfig2(a, b) {
        if (!(0, _utilsJsDefault.default).isUndefined(b)) return getMergedValue(undefined, b);
    }
    // eslint-disable-next-line consistent-return
    function defaultToConfig2(a, b) {
        if (!(0, _utilsJsDefault.default).isUndefined(b)) return getMergedValue(undefined, b);
        else if (!(0, _utilsJsDefault.default).isUndefined(a)) return getMergedValue(undefined, a);
    }
    // eslint-disable-next-line consistent-return
    function mergeDirectKeys(a, b, prop) {
        if (prop in config2) return getMergedValue(a, b);
        else if (prop in config1) return getMergedValue(undefined, a);
    }
    const mergeMap = {
        url: valueFromConfig2,
        method: valueFromConfig2,
        data: valueFromConfig2,
        baseURL: defaultToConfig2,
        transformRequest: defaultToConfig2,
        transformResponse: defaultToConfig2,
        paramsSerializer: defaultToConfig2,
        timeout: defaultToConfig2,
        timeoutMessage: defaultToConfig2,
        withCredentials: defaultToConfig2,
        withXSRFToken: defaultToConfig2,
        adapter: defaultToConfig2,
        responseType: defaultToConfig2,
        xsrfCookieName: defaultToConfig2,
        xsrfHeaderName: defaultToConfig2,
        onUploadProgress: defaultToConfig2,
        onDownloadProgress: defaultToConfig2,
        decompress: defaultToConfig2,
        maxContentLength: defaultToConfig2,
        maxBodyLength: defaultToConfig2,
        beforeRedirect: defaultToConfig2,
        transport: defaultToConfig2,
        httpAgent: defaultToConfig2,
        httpsAgent: defaultToConfig2,
        cancelToken: defaultToConfig2,
        socketPath: defaultToConfig2,
        responseEncoding: defaultToConfig2,
        validateStatus: mergeDirectKeys,
        headers: (a, b)=>mergeDeepProperties(headersToObject(a), headersToObject(b), true)
    };
    (0, _utilsJsDefault.default).forEach(Object.keys(Object.assign({}, config1, config2)), function computeConfigValue(prop) {
        const merge = mergeMap[prop] || mergeDeepProperties;
        const configValue = merge(config1[prop], config2[prop], prop);
        (0, _utilsJsDefault.default).isUndefined(configValue) && merge !== mergeDirectKeys || (config[prop] = configValue);
    });
    return config;
}

},{"../utils.js":"dNjua","./AxiosHeaders.js":"gTOgd","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"71Yni":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _dataJs = require("../env/data.js");
var _axiosErrorJs = require("../core/AxiosError.js");
var _axiosErrorJsDefault = parcelHelpers.interopDefault(_axiosErrorJs);
"use strict";
const validators = {};
// eslint-disable-next-line func-names
[
    "object",
    "boolean",
    "number",
    "function",
    "string",
    "symbol"
].forEach((type, i)=>{
    validators[type] = function validator(thing) {
        return typeof thing === type || "a" + (i < 1 ? "n " : " ") + type;
    };
});
const deprecatedWarnings = {};
/**
 * Transitional option validator
 *
 * @param {function|boolean?} validator - set to false if the transitional option has been removed
 * @param {string?} version - deprecated version / removed since version
 * @param {string?} message - some message with additional info
 *
 * @returns {function}
 */ validators.transitional = function transitional(validator, version, message) {
    function formatMessage(opt, desc) {
        return "[Axios v" + (0, _dataJs.VERSION) + "] Transitional option '" + opt + "'" + desc + (message ? ". " + message : "");
    }
    // eslint-disable-next-line func-names
    return (value, opt, opts)=>{
        if (validator === false) throw new (0, _axiosErrorJsDefault.default)(formatMessage(opt, " has been removed" + (version ? " in " + version : "")), (0, _axiosErrorJsDefault.default).ERR_DEPRECATED);
        if (version && !deprecatedWarnings[opt]) {
            deprecatedWarnings[opt] = true;
            // eslint-disable-next-line no-console
            console.warn(formatMessage(opt, " has been deprecated since v" + version + " and will be removed in the near future"));
        }
        return validator ? validator(value, opt, opts) : true;
    };
};
/**
 * Assert object's properties type
 *
 * @param {object} options
 * @param {object} schema
 * @param {boolean?} allowUnknown
 *
 * @returns {object}
 */ function assertOptions(options, schema, allowUnknown) {
    if (typeof options !== "object") throw new (0, _axiosErrorJsDefault.default)("options must be an object", (0, _axiosErrorJsDefault.default).ERR_BAD_OPTION_VALUE);
    const keys = Object.keys(options);
    let i = keys.length;
    while(i-- > 0){
        const opt = keys[i];
        const validator = schema[opt];
        if (validator) {
            const value = options[opt];
            const result = value === undefined || validator(value, opt, options);
            if (result !== true) throw new (0, _axiosErrorJsDefault.default)("option " + opt + " must be " + result, (0, _axiosErrorJsDefault.default).ERR_BAD_OPTION_VALUE);
            continue;
        }
        if (allowUnknown !== true) throw new (0, _axiosErrorJsDefault.default)("Unknown option " + opt, (0, _axiosErrorJsDefault.default).ERR_BAD_OPTION);
    }
}
exports.default = {
    assertOptions,
    validators
};

},{"../env/data.js":"77oTH","../core/AxiosError.js":"1OwwO","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"77oTH":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "VERSION", ()=>VERSION);
const VERSION = "1.6.8";

},{"@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"eY4pT":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
var _canceledErrorJs = require("./CanceledError.js");
var _canceledErrorJsDefault = parcelHelpers.interopDefault(_canceledErrorJs);
"use strict";
/**
 * A `CancelToken` is an object that can be used to request cancellation of an operation.
 *
 * @param {Function} executor The executor function.
 *
 * @returns {CancelToken}
 */ class CancelToken {
    constructor(executor){
        if (typeof executor !== "function") throw new TypeError("executor must be a function.");
        let resolvePromise;
        this.promise = new Promise(function promiseExecutor(resolve) {
            resolvePromise = resolve;
        });
        const token = this;
        // eslint-disable-next-line func-names
        this.promise.then((cancel)=>{
            if (!token._listeners) return;
            let i = token._listeners.length;
            while(i-- > 0)token._listeners[i](cancel);
            token._listeners = null;
        });
        // eslint-disable-next-line func-names
        this.promise.then = (onfulfilled)=>{
            let _resolve;
            // eslint-disable-next-line func-names
            const promise = new Promise((resolve)=>{
                token.subscribe(resolve);
                _resolve = resolve;
            }).then(onfulfilled);
            promise.cancel = function reject() {
                token.unsubscribe(_resolve);
            };
            return promise;
        };
        executor(function cancel(message, config, request) {
            if (token.reason) // Cancellation has already been requested
            return;
            token.reason = new (0, _canceledErrorJsDefault.default)(message, config, request);
            resolvePromise(token.reason);
        });
    }
    /**
   * Throws a `CanceledError` if cancellation has been requested.
   */ throwIfRequested() {
        if (this.reason) throw this.reason;
    }
    /**
   * Subscribe to the cancel signal
   */ subscribe(listener) {
        if (this.reason) {
            listener(this.reason);
            return;
        }
        if (this._listeners) this._listeners.push(listener);
        else this._listeners = [
            listener
        ];
    }
    /**
   * Unsubscribe from the cancel signal
   */ unsubscribe(listener) {
        if (!this._listeners) return;
        const index = this._listeners.indexOf(listener);
        if (index !== -1) this._listeners.splice(index, 1);
    }
    /**
   * Returns an object that contains a new `CancelToken` and a function that, when called,
   * cancels the `CancelToken`.
   */ static source() {
        let cancel;
        const token = new CancelToken(function executor(c) {
            cancel = c;
        });
        return {
            token,
            cancel
        };
    }
}
exports.default = CancelToken;

},{"./CanceledError.js":"byMZp","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"8C5in":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>spread);
"use strict";
function spread(callback) {
    return function wrap(arr) {
        return callback.apply(null, arr);
    };
}

},{"@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"h3Ewf":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
parcelHelpers.export(exports, "default", ()=>isAxiosError);
var _utilsJs = require("./../utils.js");
var _utilsJsDefault = parcelHelpers.interopDefault(_utilsJs);
"use strict";
function isAxiosError(payload) {
    return (0, _utilsJsDefault.default).isObject(payload) && payload.isAxiosError === true;
}

},{"./../utils.js":"dNjua","@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}],"55iB3":[function(require,module,exports) {
var parcelHelpers = require("@parcel/transformer-js/src/esmodule-helpers.js");
parcelHelpers.defineInteropFlag(exports);
const HttpStatusCode = {
    Continue: 100,
    SwitchingProtocols: 101,
    Processing: 102,
    EarlyHints: 103,
    Ok: 200,
    Created: 201,
    Accepted: 202,
    NonAuthoritativeInformation: 203,
    NoContent: 204,
    ResetContent: 205,
    PartialContent: 206,
    MultiStatus: 207,
    AlreadyReported: 208,
    ImUsed: 226,
    MultipleChoices: 300,
    MovedPermanently: 301,
    Found: 302,
    SeeOther: 303,
    NotModified: 304,
    UseProxy: 305,
    Unused: 306,
    TemporaryRedirect: 307,
    PermanentRedirect: 308,
    BadRequest: 400,
    Unauthorized: 401,
    PaymentRequired: 402,
    Forbidden: 403,
    NotFound: 404,
    MethodNotAllowed: 405,
    NotAcceptable: 406,
    ProxyAuthenticationRequired: 407,
    RequestTimeout: 408,
    Conflict: 409,
    Gone: 410,
    LengthRequired: 411,
    PreconditionFailed: 412,
    PayloadTooLarge: 413,
    UriTooLong: 414,
    UnsupportedMediaType: 415,
    RangeNotSatisfiable: 416,
    ExpectationFailed: 417,
    ImATeapot: 418,
    MisdirectedRequest: 421,
    UnprocessableEntity: 422,
    Locked: 423,
    FailedDependency: 424,
    TooEarly: 425,
    UpgradeRequired: 426,
    PreconditionRequired: 428,
    TooManyRequests: 429,
    RequestHeaderFieldsTooLarge: 431,
    UnavailableForLegalReasons: 451,
    InternalServerError: 500,
    NotImplemented: 501,
    BadGateway: 502,
    ServiceUnavailable: 503,
    GatewayTimeout: 504,
    HttpVersionNotSupported: 505,
    VariantAlsoNegotiates: 506,
    InsufficientStorage: 507,
    LoopDetected: 508,
    NotExtended: 510,
    NetworkAuthenticationRequired: 511
};
Object.entries(HttpStatusCode).forEach(([key, value])=>{
    HttpStatusCode[value] = key;
});
exports.default = HttpStatusCode;

},{"@parcel/transformer-js/src/esmodule-helpers.js":"8ISrk"}]},["jpdoD"], "jpdoD", "parcelRequire94c2")

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTs7QUFDQSxJQUFJO0FBQ0osSUFBSSxXQUFXO0FBRWYsaUJBQWlCO0FBQ2pCLElBQUk7QUFDSixJQUFJLE9BQU8sWUFBWSxhQUFhO0lBQ25DLGlCQUFpQixPQUFPLE9BQU8sQ0FBQyxLQUFLO0lBQ3JDLFdBQVc7QUFDWixPQUNDLGlCQUFpQixRQUFRLE9BQU8sQ0FBQyxLQUFLO0FBRXZDLGVBQWUsSUFBSSxHQUFHO0lBQ3JCLE1BQU0sVUFBVSxDQUFDLEVBQUUsU0FBUyxDQUFDLEVBQUUsSUFBSSxDQUFDO0lBQ3BDLE9BQU8sQUFBQyxDQUFBLE1BQU0sZUFBZSxHQUFHLENBQUMsUUFBTyxDQUFFLENBQUMsUUFBUTtBQUNwRDtBQUNBLGVBQWUsSUFBSSxHQUFHLEVBQUUsR0FBRztJQUMxQixNQUFNLE9BQU8sQ0FBQztJQUNkLE1BQU0sVUFBVSxDQUFDLEVBQUUsU0FBUyxDQUFDLEVBQUUsSUFBSSxDQUFDO0lBQ3BDLElBQUksQ0FBQyxRQUFRLEdBQUc7SUFDaEIsTUFBTSxlQUFlLEdBQUcsQ0FBQztBQUMxQjtBQUVBLFNBQVMsa0JBQWtCLE9BQU8sRUFBRSxPQUFPO0lBQzFDLE1BQU8sUUFBUSxhQUFhLENBQUU7UUFDN0IsSUFBSSxRQUFRLGFBQWEsQ0FBQyxPQUFPLENBQUMsV0FBVyxPQUFPLFFBQVEsV0FBVyxJQUN0RSxPQUFPO1FBRVIsVUFBVSxRQUFRLGFBQWE7SUFDaEM7SUFDQSxPQUFPO0FBQ1I7QUFFQSxTQUFTO0lBQ1IsTUFBTSxRQUFRLFNBQVMsZ0JBQWdCLENBQUM7SUFDeEMsTUFBTSxPQUFPLE1BQU0sSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUNsQyxDQUFDLE9BQVMsQ0FBQyxrQkFBa0IsTUFBTTtJQUVwQyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssSUFBSSxFQUFFLE9BQU87SUFDaEMsTUFBTSxRQUFRLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQztJQUM5QixJQUFJLE1BQU0sTUFBTSxHQUFHLEdBQ2xCLE9BQU8sS0FBSyxDQUFDLEVBQUUsRUFBRSxvQ0FBb0M7QUFFdkQ7QUFDQSxlQUFlLFFBQVEsRUFBRTtJQUN4QixPQUFPLE1BQU0sSUFBSSxRQUFRLENBQUMsVUFBWSxXQUFXLFNBQVM7QUFDM0Q7QUFFQSxlQUFlLG1CQUFtQixRQUFRLEVBQUUsV0FBVztJQUN0RCxNQUFNLFNBQVMsRUFBRTtJQUNqQixJQUFJLE9BQU87SUFDWCxNQUFPLEtBQU07UUFDWixNQUFNLE1BQU0sQ0FBQyxPQUFPLEVBQUUsU0FBUyxzQkFBc0IsRUFBRSxLQUFLLFVBQVUsQ0FBQztRQUN2RTtRQUNBLE1BQU0sRUFBRSxJQUFJLEVBQUUsR0FBRyxNQUFNLENBQUEsR0FBQSxxQkFBSyxBQUFELEVBQUUsR0FBRyxDQUFDO1FBQ2pDLE1BQU0sU0FBUyxJQUFJO1FBQ25CLE1BQU0sVUFBVSxPQUFPLGVBQWUsQ0FBQyxNQUFNO1FBQzdDLE1BQU0sT0FBTyxRQUFRLGdCQUFnQixDQUFDO1FBQ3RDLEtBQUssT0FBTyxDQUFDLENBQUM7WUFDYixNQUFNLFdBQVcsSUFBSSxhQUFhLENBQUM7WUFDbkMsSUFBSSxVQUFVO2dCQUNiLElBQUksT0FBTyxJQUFJLGFBQWEsQ0FBQyx3QkFBd0IsV0FBVyxDQUFDLElBQUk7Z0JBQ3JFLElBQUksS0FBSyxNQUFNLElBQUksSUFBSTtvQkFDdEIsTUFBTSxjQUFjLElBQUk7b0JBQ3hCLE1BQU0sT0FBTyxZQUFZLFdBQVc7b0JBQ3BDLE1BQU0sUUFBUSxPQUFPLFlBQVksUUFBUSxLQUFLLEdBQUcsUUFBUSxDQUFDLEdBQUcsTUFBTSxzQkFBc0I7b0JBQ3pGLE1BQU0sTUFBTSxPQUFPLFlBQVksT0FBTyxJQUFJLFFBQVEsQ0FBQyxHQUFHO29CQUN0RCxNQUFNLGdCQUFnQixDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUUsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7b0JBQ2hELE9BQU8sZ0JBQWdCO2dCQUN4QjtnQkFDQSxNQUFNLGVBQWUsSUFDbkIsYUFBYSxDQUFDLDZCQUNkLElBQUksQ0FBQyxLQUFLLENBQUMsS0FDWCxHQUFHO2dCQUNMLE1BQU0sZUFBZSxJQUFJLGdCQUFnQixDQUFDO2dCQUMxQyxNQUFNLFlBQVksWUFBWSxDQUFDLGFBQWEsTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQzFELEtBQUssQ0FBQyxLQUNOLEdBQUc7Z0JBQ0wsT0FBTyxJQUFJLENBQUM7b0JBQ1g7b0JBQ0E7b0JBQ0EsV0FBVyxJQUFJLEtBQUssTUFBTSxPQUFPO2dCQUNsQztZQUNEO1FBQ0Q7UUFDQSxNQUFNLFFBQVE7UUFDZCxJQUFJLENBQUMsZUFBZSxLQUFLLE1BQU0sS0FBSyxHQUNuQztJQUVGO0lBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxjQUFjLElBQUk7SUFDMUIsT0FBTyxPQUFPLEtBQUssR0FBRyxLQUFLO0FBQzVCO0FBRUEsZUFBZSxPQUFPLFdBQVcsRUFBRSxLQUFLO0lBQ3ZDLE1BQU0sQ0FBQSxHQUFBLHFCQUFLLEFBQUQsRUFBRSxJQUFJLENBQ2YsaUVBQ0E7UUFDQztRQUNBO1FBQ0E7SUFDRDtBQUVGO0FBQ0EsZUFBZTtJQUNkLE1BQU0sUUFBUSxTQUFTLGFBQWEsQ0FBQztJQUNyQyxNQUFNLEVBQUUsR0FBRztJQUNYLE1BQU0sU0FBUyxDQUFDLEdBQUcsQ0FBQztJQUNwQixNQUFNLFNBQVMsR0FBRyxDQUFDLDhIQUE4SCxDQUFDO0lBQ2xKLFNBQVMsSUFBSSxDQUFDLFdBQVcsQ0FBQztJQUMxQixNQUFNLFdBQVcsU0FBUyxjQUFjLENBQUM7SUFDekMsTUFBTSxRQUFRO0lBQ2QsU0FBUyxTQUFTLENBQUMsTUFBTSxDQUFDO0FBQzNCO0FBRUEsZUFBZTtJQUNkLE1BQU0sUUFBUSxTQUFTLGNBQWMsQ0FBQztJQUN0QyxNQUFNLFNBQVMsQ0FBQyxHQUFHLENBQUM7SUFDcEIsTUFBTSxRQUFRO0lBQ2QsSUFBSSxPQUNILFNBQVMsSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUU1QjtBQUVBLGVBQWUsY0FBYyxRQUFRO0lBQ3BDO0lBQ0EsTUFBTSxjQUFjLE1BQU0sSUFBSTtJQUM5QixNQUFNLGVBQWUsTUFBTSxJQUFJO0lBQy9CLE1BQU0sY0FDTCxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsY0FBYztJQUNoRCxNQUFNLGNBQWMsTUFBTSxtQkFBbUIsVUFBVTtJQUN2RCxNQUFNLE9BQU8sYUFBYTtJQUMxQixJQUFJLGFBQWE7UUFDaEIsTUFBTSxJQUFJLGdCQUFnQjtRQUMxQixNQUFNLElBQUksa0JBQWtCLEtBQUssR0FBRztJQUNyQztJQUNBO0FBQ0Q7QUFFQSxlQUFlO0lBQ2QsV0FBVztJQUNYLElBQUksQ0FBQyxVQUNKO0lBRUQsTUFBTSxjQUFjO0FBQ3JCO0FBRUE7Ozs7O0FDN0hBLDZDQUNFLENBQUEsR0FBQSx1QkFBSyxBQUFEO0FBRE4sMkNBRUU7QUFGRixnREFHRTtBQUhGLG1EQUlFO0FBSkYsOENBS0U7QUFMRixpREFNRTtBQU5GLDZDQU9FO0FBUEYseUNBUUU7QUFSRiw0Q0FTRTtBQVRGLGtEQVVFO0FBVkYsNENBV0U7QUFYRixnREFZRTtBQVpGLGtEQWFFO0FBYkYsb0RBY0U7QUFkRixnREFlRTtBQWZGLGdEQWdCRTtBQWhCRixpREFpQkU7QUF6Q0Y7O0FBRUEsbUVBQW1FO0FBQ25FLG9EQUFvRDtBQUNwRCxpREFBaUQ7QUFDakQsTUFBTSxFQUNKLEtBQUssRUFDTCxVQUFVLEVBQ1YsYUFBYSxFQUNiLFFBQVEsRUFDUixXQUFXLEVBQ1gsT0FBTyxFQUNQLEdBQUcsRUFDSCxNQUFNLEVBQ04sWUFBWSxFQUNaLE1BQU0sRUFDTixVQUFVLEVBQ1YsWUFBWSxFQUNaLGNBQWMsRUFDZCxVQUFVLEVBQ1YsVUFBVSxFQUNWLFdBQVcsRUFDWixHQUFHLENBQUEsR0FBQSx1QkFBSyxBQUFEOzs7OztBQ3BCUjs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTtBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQWxCQTtBQW9CQTs7Ozs7O0NBTUMsR0FDRCxTQUFTLGVBQWUsYUFBYTtJQUNuQyxNQUFNLFVBQVUsSUFBSSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFO0lBQzFCLE1BQU0sV0FBVyxDQUFBLEdBQUEsc0JBQUksQUFBRCxFQUFFLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsU0FBUyxDQUFDLE9BQU8sRUFBRTtJQUUvQyxtQ0FBbUM7SUFDbkMsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxNQUFNLENBQUMsVUFBVSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFNBQVMsRUFBRSxTQUFTO1FBQUMsWUFBWTtJQUFJO0lBRWxFLDJCQUEyQjtJQUMzQixDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLE1BQU0sQ0FBQyxVQUFVLFNBQVMsTUFBTTtRQUFDLFlBQVk7SUFBSTtJQUV2RCxxQ0FBcUM7SUFDckMsU0FBUyxNQUFNLEdBQUcsU0FBUyxPQUFPLGNBQWM7UUFDOUMsT0FBTyxlQUFlLENBQUEsR0FBQSw2QkFBVyxBQUFELEVBQUUsZUFBZTtJQUNuRDtJQUVBLE9BQU87QUFDVDtBQUVBLDZDQUE2QztBQUM3QyxNQUFNLFFBQVEsZUFBZSxDQUFBLEdBQUEsdUJBQVEsQUFBRDtBQUVwQyxnREFBZ0Q7QUFDaEQsTUFBTSxLQUFLLEdBQUcsQ0FBQSxHQUFBLHVCQUFLLEFBQUQ7QUFFbEIsOEJBQThCO0FBQzlCLE1BQU0sYUFBYSxHQUFHLENBQUEsR0FBQSwrQkFBYSxBQUFEO0FBQ2xDLE1BQU0sV0FBVyxHQUFHLENBQUEsR0FBQSw2QkFBVyxBQUFEO0FBQzlCLE1BQU0sUUFBUSxHQUFHLENBQUEsR0FBQSwwQkFBUSxBQUFEO0FBQ3hCLE1BQU0sT0FBTyxHQUFHLENBQUEsR0FBQSxlQUFPLEFBQUQ7QUFDdEIsTUFBTSxVQUFVLEdBQUcsQ0FBQSxHQUFBLDRCQUFVLEFBQUQ7QUFFNUIsMEJBQTBCO0FBQzFCLE1BQU0sVUFBVSxHQUFHLENBQUEsR0FBQSw0QkFBVSxBQUFEO0FBRTVCLHFEQUFxRDtBQUNyRCxNQUFNLE1BQU0sR0FBRyxNQUFNLGFBQWE7QUFFbEMsb0JBQW9CO0FBQ3BCLE1BQU0sR0FBRyxHQUFHLFNBQVMsSUFBSSxRQUFRO0lBQy9CLE9BQU8sUUFBUSxHQUFHLENBQUM7QUFDckI7QUFFQSxNQUFNLE1BQU0sR0FBRyxDQUFBLEdBQUEsd0JBQU0sQUFBRDtBQUVwQixzQkFBc0I7QUFDdEIsTUFBTSxZQUFZLEdBQUcsQ0FBQSxHQUFBLDhCQUFZLEFBQUQ7QUFFaEMscUJBQXFCO0FBQ3JCLE1BQU0sV0FBVyxHQUFHLENBQUEsR0FBQSw2QkFBVyxBQUFEO0FBRTlCLE1BQU0sWUFBWSxHQUFHLENBQUEsR0FBQSw4QkFBWSxBQUFEO0FBRWhDLE1BQU0sVUFBVSxHQUFHLENBQUEsUUFBUyxDQUFBLEdBQUEsZ0NBQWMsQUFBRCxFQUFFLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsVUFBVSxDQUFDLFNBQVMsSUFBSSxTQUFTLFNBQVM7QUFFM0YsTUFBTSxVQUFVLEdBQUcsQ0FBQSxHQUFBLDBCQUFRLEFBQUQsRUFBRSxVQUFVO0FBRXRDLE1BQU0sY0FBYyxHQUFHLENBQUEsR0FBQSxnQ0FBYyxBQUFEO0FBRXBDLE1BQU0sT0FBTyxHQUFHO0FBRWhCLGdEQUFnRDtrQkFDakM7Ozs7O0FDdEZmOzs7QUFGQTtBQUlBLHVFQUF1RTtBQUV2RSxNQUFNLEVBQUMsUUFBUSxFQUFDLEdBQUcsT0FBTyxTQUFTO0FBQ25DLE1BQU0sRUFBQyxjQUFjLEVBQUMsR0FBRztBQUV6QixNQUFNLFNBQVMsQUFBQyxDQUFBLENBQUEsUUFBUyxDQUFBO1FBQ3JCLE1BQU0sTUFBTSxTQUFTLElBQUksQ0FBQztRQUMxQixPQUFPLEtBQUssQ0FBQyxJQUFJLElBQUssQ0FBQSxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxXQUFXLEVBQUM7SUFDcEUsQ0FBQSxFQUFHLE9BQU8sTUFBTSxDQUFDO0FBRWpCLE1BQU0sYUFBYSxDQUFDO0lBQ2xCLE9BQU8sS0FBSyxXQUFXO0lBQ3ZCLE9BQU8sQ0FBQyxRQUFVLE9BQU8sV0FBVztBQUN0QztBQUVBLE1BQU0sYUFBYSxDQUFBLE9BQVEsQ0FBQSxRQUFTLE9BQU8sVUFBVTtBQUVyRDs7Ozs7O0NBTUMsR0FDRCxNQUFNLEVBQUMsT0FBTyxFQUFDLEdBQUc7QUFFbEI7Ozs7OztDQU1DLEdBQ0QsTUFBTSxjQUFjLFdBQVc7QUFFL0I7Ozs7OztDQU1DLEdBQ0QsU0FBUyxTQUFTLEdBQUc7SUFDbkIsT0FBTyxRQUFRLFFBQVEsQ0FBQyxZQUFZLFFBQVEsSUFBSSxXQUFXLEtBQUssUUFBUSxDQUFDLFlBQVksSUFBSSxXQUFXLEtBQy9GLFdBQVcsSUFBSSxXQUFXLENBQUMsUUFBUSxLQUFLLElBQUksV0FBVyxDQUFDLFFBQVEsQ0FBQztBQUN4RTtBQUVBOzs7Ozs7Q0FNQyxHQUNELE1BQU0sZ0JBQWdCLFdBQVc7QUFHakM7Ozs7OztDQU1DLEdBQ0QsU0FBUyxrQkFBa0IsR0FBRztJQUM1QixJQUFJO0lBQ0osSUFBSSxBQUFDLE9BQU8sZ0JBQWdCLGVBQWlCLFlBQVksTUFBTSxFQUM3RCxTQUFTLFlBQVksTUFBTSxDQUFDO1NBRTVCLFNBQVMsQUFBQyxPQUFTLElBQUksTUFBTSxJQUFNLGNBQWMsSUFBSSxNQUFNO0lBRTdELE9BQU87QUFDVDtBQUVBOzs7Ozs7Q0FNQyxHQUNELE1BQU0sV0FBVyxXQUFXO0FBRTVCOzs7OztDQUtDLEdBQ0QsTUFBTSxhQUFhLFdBQVc7QUFFOUI7Ozs7OztDQU1DLEdBQ0QsTUFBTSxXQUFXLFdBQVc7QUFFNUI7Ozs7OztDQU1DLEdBQ0QsTUFBTSxXQUFXLENBQUMsUUFBVSxVQUFVLFFBQVEsT0FBTyxVQUFVO0FBRS9EOzs7OztDQUtDLEdBQ0QsTUFBTSxZQUFZLENBQUEsUUFBUyxVQUFVLFFBQVEsVUFBVTtBQUV2RDs7Ozs7O0NBTUMsR0FDRCxNQUFNLGdCQUFnQixDQUFDO0lBQ3JCLElBQUksT0FBTyxTQUFTLFVBQ2xCLE9BQU87SUFHVCxNQUFNLFlBQVksZUFBZTtJQUNqQyxPQUFPLEFBQUMsQ0FBQSxjQUFjLFFBQVEsY0FBYyxPQUFPLFNBQVMsSUFBSSxPQUFPLGNBQWMsQ0FBQyxlQUFlLElBQUcsS0FBTSxDQUFFLENBQUEsT0FBTyxXQUFXLElBQUksR0FBRSxLQUFNLENBQUUsQ0FBQSxPQUFPLFFBQVEsSUFBSSxHQUFFO0FBQ3ZLO0FBRUE7Ozs7OztDQU1DLEdBQ0QsTUFBTSxTQUFTLFdBQVc7QUFFMUI7Ozs7OztDQU1DLEdBQ0QsTUFBTSxTQUFTLFdBQVc7QUFFMUI7Ozs7OztDQU1DLEdBQ0QsTUFBTSxTQUFTLFdBQVc7QUFFMUI7Ozs7OztDQU1DLEdBQ0QsTUFBTSxhQUFhLFdBQVc7QUFFOUI7Ozs7OztDQU1DLEdBQ0QsTUFBTSxXQUFXLENBQUMsTUFBUSxTQUFTLFFBQVEsV0FBVyxJQUFJLElBQUk7QUFFOUQ7Ozs7OztDQU1DLEdBQ0QsTUFBTSxhQUFhLENBQUM7SUFDbEIsSUFBSTtJQUNKLE9BQU8sU0FDTCxDQUFBLEFBQUMsT0FBTyxhQUFhLGNBQWMsaUJBQWlCLFlBQ2xELFdBQVcsTUFBTSxNQUFNLEtBQ3JCLENBQUEsQUFBQyxDQUFBLE9BQU8sT0FBTyxNQUFLLE1BQU8sY0FDM0IsNEJBQTRCO0lBQzNCLFNBQVMsWUFBWSxXQUFXLE1BQU0sUUFBUSxLQUFLLE1BQU0sUUFBUSxPQUFPLG1CQUFtQixDQUVoRztBQUVKO0FBRUE7Ozs7OztDQU1DLEdBQ0QsTUFBTSxvQkFBb0IsV0FBVztBQUVyQzs7Ozs7O0NBTUMsR0FDRCxNQUFNLE9BQU8sQ0FBQyxNQUFRLElBQUksSUFBSSxHQUM1QixJQUFJLElBQUksS0FBSyxJQUFJLE9BQU8sQ0FBQyxzQ0FBc0M7QUFFakU7Ozs7Ozs7Ozs7Ozs7O0NBY0MsR0FDRCxTQUFTLFFBQVEsR0FBRyxFQUFFLEVBQUUsRUFBRSxFQUFDLGFBQWEsS0FBSyxFQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ2pELG9DQUFvQztJQUNwQyxJQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsYUFDakM7SUFHRixJQUFJO0lBQ0osSUFBSTtJQUVKLG1EQUFtRDtJQUNuRCxJQUFJLE9BQU8sUUFBUSxVQUNqQiw0QkFBNEIsR0FDNUIsTUFBTTtRQUFDO0tBQUk7SUFHYixJQUFJLFFBQVEsTUFDViw0QkFBNEI7SUFDNUIsSUFBSyxJQUFJLEdBQUcsSUFBSSxJQUFJLE1BQU0sRUFBRSxJQUFJLEdBQUcsSUFDakMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxFQUFFLEdBQUc7U0FFdEI7UUFDTCwyQkFBMkI7UUFDM0IsTUFBTSxPQUFPLGFBQWEsT0FBTyxtQkFBbUIsQ0FBQyxPQUFPLE9BQU8sSUFBSSxDQUFDO1FBQ3hFLE1BQU0sTUFBTSxLQUFLLE1BQU07UUFDdkIsSUFBSTtRQUVKLElBQUssSUFBSSxHQUFHLElBQUksS0FBSyxJQUFLO1lBQ3hCLE1BQU0sSUFBSSxDQUFDLEVBQUU7WUFDYixHQUFHLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLEVBQUUsS0FBSztRQUMvQjtJQUNGO0FBQ0Y7QUFFQSxTQUFTLFFBQVEsR0FBRyxFQUFFLEdBQUc7SUFDdkIsTUFBTSxJQUFJLFdBQVc7SUFDckIsTUFBTSxPQUFPLE9BQU8sSUFBSSxDQUFDO0lBQ3pCLElBQUksSUFBSSxLQUFLLE1BQU07SUFDbkIsSUFBSTtJQUNKLE1BQU8sTUFBTSxFQUFHO1FBQ2QsT0FBTyxJQUFJLENBQUMsRUFBRTtRQUNkLElBQUksUUFBUSxLQUFLLFdBQVcsSUFDMUIsT0FBTztJQUVYO0lBQ0EsT0FBTztBQUNUO0FBRUEsTUFBTSxVQUFVLEFBQUMsQ0FBQTtJQUNmLG1CQUFtQixHQUNuQixJQUFJLE9BQU8sZUFBZSxhQUFhLE9BQU87SUFDOUMsT0FBTyxPQUFPLFNBQVMsY0FBYyxPQUFRLE9BQU8sV0FBVyxjQUFjLFNBQVM7QUFDeEYsQ0FBQTtBQUVBLE1BQU0sbUJBQW1CLENBQUMsVUFBWSxDQUFDLFlBQVksWUFBWSxZQUFZO0FBRTNFOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQyxHQUNELFNBQVM7SUFDUCxNQUFNLEVBQUMsUUFBUSxFQUFDLEdBQUcsaUJBQWlCLElBQUksS0FBSyxJQUFJLElBQUksQ0FBQztJQUN0RCxNQUFNLFNBQVMsQ0FBQztJQUNoQixNQUFNLGNBQWMsQ0FBQyxLQUFLO1FBQ3hCLE1BQU0sWUFBWSxZQUFZLFFBQVEsUUFBUSxRQUFRO1FBQ3RELElBQUksY0FBYyxNQUFNLENBQUMsVUFBVSxLQUFLLGNBQWMsTUFDcEQsTUFBTSxDQUFDLFVBQVUsR0FBRyxNQUFNLE1BQU0sQ0FBQyxVQUFVLEVBQUU7YUFDeEMsSUFBSSxjQUFjLE1BQ3ZCLE1BQU0sQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLEdBQUc7YUFDekIsSUFBSSxRQUFRLE1BQ2pCLE1BQU0sQ0FBQyxVQUFVLEdBQUcsSUFBSSxLQUFLO2FBRTdCLE1BQU0sQ0FBQyxVQUFVLEdBQUc7SUFFeEI7SUFFQSxJQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxNQUFNLEVBQUUsSUFBSSxHQUFHLElBQzNDLFNBQVMsQ0FBQyxFQUFFLElBQUksUUFBUSxTQUFTLENBQUMsRUFBRSxFQUFFO0lBRXhDLE9BQU87QUFDVDtBQUVBOzs7Ozs7Ozs7Q0FTQyxHQUNELE1BQU0sU0FBUyxDQUFDLEdBQUcsR0FBRyxTQUFTLEVBQUMsVUFBVSxFQUFDLEdBQUUsQ0FBQyxDQUFDO0lBQzdDLFFBQVEsR0FBRyxDQUFDLEtBQUs7UUFDZixJQUFJLFdBQVcsV0FBVyxNQUN4QixDQUFDLENBQUMsSUFBSSxHQUFHLENBQUEsR0FBQSxzQkFBSSxBQUFELEVBQUUsS0FBSzthQUVuQixDQUFDLENBQUMsSUFBSSxHQUFHO0lBRWIsR0FBRztRQUFDO0lBQVU7SUFDZCxPQUFPO0FBQ1Q7QUFFQTs7Ozs7O0NBTUMsR0FDRCxNQUFNLFdBQVcsQ0FBQztJQUNoQixJQUFJLFFBQVEsVUFBVSxDQUFDLE9BQU8sUUFDNUIsVUFBVSxRQUFRLEtBQUssQ0FBQztJQUUxQixPQUFPO0FBQ1Q7QUFFQTs7Ozs7Ozs7Q0FRQyxHQUNELE1BQU0sV0FBVyxDQUFDLGFBQWEsa0JBQWtCLE9BQU87SUFDdEQsWUFBWSxTQUFTLEdBQUcsT0FBTyxNQUFNLENBQUMsaUJBQWlCLFNBQVMsRUFBRTtJQUNsRSxZQUFZLFNBQVMsQ0FBQyxXQUFXLEdBQUc7SUFDcEMsT0FBTyxjQUFjLENBQUMsYUFBYSxTQUFTO1FBQzFDLE9BQU8saUJBQWlCLFNBQVM7SUFDbkM7SUFDQSxTQUFTLE9BQU8sTUFBTSxDQUFDLFlBQVksU0FBUyxFQUFFO0FBQ2hEO0FBRUE7Ozs7Ozs7O0NBUUMsR0FDRCxNQUFNLGVBQWUsQ0FBQyxXQUFXLFNBQVMsUUFBUTtJQUNoRCxJQUFJO0lBQ0osSUFBSTtJQUNKLElBQUk7SUFDSixNQUFNLFNBQVMsQ0FBQztJQUVoQixVQUFVLFdBQVcsQ0FBQztJQUN0Qiw2Q0FBNkM7SUFDN0MsSUFBSSxhQUFhLE1BQU0sT0FBTztJQUU5QixHQUFHO1FBQ0QsUUFBUSxPQUFPLG1CQUFtQixDQUFDO1FBQ25DLElBQUksTUFBTSxNQUFNO1FBQ2hCLE1BQU8sTUFBTSxFQUFHO1lBQ2QsT0FBTyxLQUFLLENBQUMsRUFBRTtZQUNmLElBQUksQUFBQyxDQUFBLENBQUMsY0FBYyxXQUFXLE1BQU0sV0FBVyxRQUFPLEtBQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO2dCQUMxRSxPQUFPLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxLQUFLO2dCQUMvQixNQUFNLENBQUMsS0FBSyxHQUFHO1lBQ2pCO1FBQ0Y7UUFDQSxZQUFZLFdBQVcsU0FBUyxlQUFlO0lBQ2pELFFBQVMsYUFBYyxDQUFBLENBQUMsVUFBVSxPQUFPLFdBQVcsUUFBTyxLQUFNLGNBQWMsT0FBTyxTQUFTLEVBQUU7SUFFakcsT0FBTztBQUNUO0FBRUE7Ozs7Ozs7O0NBUUMsR0FDRCxNQUFNLFdBQVcsQ0FBQyxLQUFLLGNBQWM7SUFDbkMsTUFBTSxPQUFPO0lBQ2IsSUFBSSxhQUFhLGFBQWEsV0FBVyxJQUFJLE1BQU0sRUFDakQsV0FBVyxJQUFJLE1BQU07SUFFdkIsWUFBWSxhQUFhLE1BQU07SUFDL0IsTUFBTSxZQUFZLElBQUksT0FBTyxDQUFDLGNBQWM7SUFDNUMsT0FBTyxjQUFjLE1BQU0sY0FBYztBQUMzQztBQUdBOzs7Ozs7Q0FNQyxHQUNELE1BQU0sVUFBVSxDQUFDO0lBQ2YsSUFBSSxDQUFDLE9BQU8sT0FBTztJQUNuQixJQUFJLFFBQVEsUUFBUSxPQUFPO0lBQzNCLElBQUksSUFBSSxNQUFNLE1BQU07SUFDcEIsSUFBSSxDQUFDLFNBQVMsSUFBSSxPQUFPO0lBQ3pCLE1BQU0sTUFBTSxJQUFJLE1BQU07SUFDdEIsTUFBTyxNQUFNLEVBQ1gsR0FBRyxDQUFDLEVBQUUsR0FBRyxLQUFLLENBQUMsRUFBRTtJQUVuQixPQUFPO0FBQ1Q7QUFFQTs7Ozs7OztDQU9DLEdBQ0Qsc0NBQXNDO0FBQ3RDLE1BQU0sZUFBZSxBQUFDLENBQUEsQ0FBQTtJQUNwQixzQ0FBc0M7SUFDdEMsT0FBTyxDQUFBO1FBQ0wsT0FBTyxjQUFjLGlCQUFpQjtJQUN4QztBQUNGLENBQUEsRUFBRyxPQUFPLGVBQWUsZUFBZSxlQUFlO0FBRXZEOzs7Ozs7O0NBT0MsR0FDRCxNQUFNLGVBQWUsQ0FBQyxLQUFLO0lBQ3pCLE1BQU0sWUFBWSxPQUFPLEdBQUcsQ0FBQyxPQUFPLFFBQVEsQ0FBQztJQUU3QyxNQUFNLFdBQVcsVUFBVSxJQUFJLENBQUM7SUFFaEMsSUFBSTtJQUVKLE1BQU8sQUFBQyxDQUFBLFNBQVMsU0FBUyxJQUFJLEVBQUMsS0FBTSxDQUFDLE9BQU8sSUFBSSxDQUFFO1FBQ2pELE1BQU0sT0FBTyxPQUFPLEtBQUs7UUFDekIsR0FBRyxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFO0lBQy9CO0FBQ0Y7QUFFQTs7Ozs7OztDQU9DLEdBQ0QsTUFBTSxXQUFXLENBQUMsUUFBUTtJQUN4QixJQUFJO0lBQ0osTUFBTSxNQUFNLEVBQUU7SUFFZCxNQUFPLEFBQUMsQ0FBQSxVQUFVLE9BQU8sSUFBSSxDQUFDLElBQUcsTUFBTyxLQUN0QyxJQUFJLElBQUksQ0FBQztJQUdYLE9BQU87QUFDVDtBQUVBLG9GQUFvRixHQUNwRixNQUFNLGFBQWEsV0FBVztBQUU5QixNQUFNLGNBQWMsQ0FBQTtJQUNsQixPQUFPLElBQUksV0FBVyxHQUFHLE9BQU8sQ0FBQyx5QkFDL0IsU0FBUyxTQUFTLENBQUMsRUFBRSxFQUFFLEVBQUUsRUFBRTtRQUN6QixPQUFPLEdBQUcsV0FBVyxLQUFLO0lBQzVCO0FBRUo7QUFFQSxvRUFBb0UsR0FDcEUsTUFBTSxpQkFBaUIsQUFBQyxDQUFBLENBQUMsRUFBQyxjQUFjLEVBQUMsR0FBSyxDQUFDLEtBQUssT0FBUyxlQUFlLElBQUksQ0FBQyxLQUFLLEtBQUksRUFBRyxPQUFPLFNBQVM7QUFFN0c7Ozs7OztDQU1DLEdBQ0QsTUFBTSxXQUFXLFdBQVc7QUFFNUIsTUFBTSxvQkFBb0IsQ0FBQyxLQUFLO0lBQzlCLE1BQU0sY0FBYyxPQUFPLHlCQUF5QixDQUFDO0lBQ3JELE1BQU0scUJBQXFCLENBQUM7SUFFNUIsUUFBUSxhQUFhLENBQUMsWUFBWTtRQUNoQyxJQUFJO1FBQ0osSUFBSSxBQUFDLENBQUEsTUFBTSxRQUFRLFlBQVksTUFBTSxJQUFHLE1BQU8sT0FDN0Msa0JBQWtCLENBQUMsS0FBSyxHQUFHLE9BQU87SUFFdEM7SUFFQSxPQUFPLGdCQUFnQixDQUFDLEtBQUs7QUFDL0I7QUFFQTs7O0NBR0MsR0FFRCxNQUFNLGdCQUFnQixDQUFDO0lBQ3JCLGtCQUFrQixLQUFLLENBQUMsWUFBWTtRQUNsQyx1Q0FBdUM7UUFDdkMsSUFBSSxXQUFXLFFBQVE7WUFBQztZQUFhO1lBQVU7U0FBUyxDQUFDLE9BQU8sQ0FBQyxVQUFVLElBQ3pFLE9BQU87UUFHVCxNQUFNLFFBQVEsR0FBRyxDQUFDLEtBQUs7UUFFdkIsSUFBSSxDQUFDLFdBQVcsUUFBUTtRQUV4QixXQUFXLFVBQVUsR0FBRztRQUV4QixJQUFJLGNBQWMsWUFBWTtZQUM1QixXQUFXLFFBQVEsR0FBRztZQUN0QjtRQUNGO1FBRUEsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUNqQixXQUFXLEdBQUcsR0FBRztZQUNmLE1BQU0sTUFBTSx1Q0FBd0MsT0FBTztRQUM3RDtJQUVKO0FBQ0Y7QUFFQSxNQUFNLGNBQWMsQ0FBQyxlQUFlO0lBQ2xDLE1BQU0sTUFBTSxDQUFDO0lBRWIsTUFBTSxTQUFTLENBQUM7UUFDZCxJQUFJLE9BQU8sQ0FBQyxDQUFBO1lBQ1YsR0FBRyxDQUFDLE1BQU0sR0FBRztRQUNmO0lBQ0Y7SUFFQSxRQUFRLGlCQUFpQixPQUFPLGlCQUFpQixPQUFPLE9BQU8sZUFBZSxLQUFLLENBQUM7SUFFcEYsT0FBTztBQUNUO0FBRUEsTUFBTSxPQUFPLEtBQU87QUFFcEIsTUFBTSxpQkFBaUIsQ0FBQyxPQUFPO0lBQzdCLFFBQVEsQ0FBQztJQUNULE9BQU8sT0FBTyxRQUFRLENBQUMsU0FBUyxRQUFRO0FBQzFDO0FBRUEsTUFBTSxRQUFRO0FBRWQsTUFBTSxRQUFRO0FBRWQsTUFBTSxXQUFXO0lBQ2Y7SUFDQTtJQUNBLGFBQWEsUUFBUSxNQUFNLFdBQVcsS0FBSztBQUM3QztBQUVBLE1BQU0saUJBQWlCLENBQUMsT0FBTyxFQUFFLEVBQUUsV0FBVyxTQUFTLFdBQVc7SUFDaEUsSUFBSSxNQUFNO0lBQ1YsTUFBTSxFQUFDLE1BQU0sRUFBQyxHQUFHO0lBQ2pCLE1BQU8sT0FDTCxPQUFPLFFBQVEsQ0FBQyxLQUFLLE1BQU0sS0FBSyxTQUFPLEVBQUU7SUFHM0MsT0FBTztBQUNUO0FBRUE7Ozs7OztDQU1DLEdBQ0QsU0FBUyxvQkFBb0IsS0FBSztJQUNoQyxPQUFPLENBQUMsQ0FBRSxDQUFBLFNBQVMsV0FBVyxNQUFNLE1BQU0sS0FBSyxLQUFLLENBQUMsT0FBTyxXQUFXLENBQUMsS0FBSyxjQUFjLEtBQUssQ0FBQyxPQUFPLFFBQVEsQ0FBQyxBQUFEO0FBQ2xIO0FBRUEsTUFBTSxlQUFlLENBQUM7SUFDcEIsTUFBTSxRQUFRLElBQUksTUFBTTtJQUV4QixNQUFNLFFBQVEsQ0FBQyxRQUFRO1FBRXJCLElBQUksU0FBUyxTQUFTO1lBQ3BCLElBQUksTUFBTSxPQUFPLENBQUMsV0FBVyxHQUMzQjtZQUdGLElBQUcsQ0FBRSxDQUFBLFlBQVksTUFBSyxHQUFJO2dCQUN4QixLQUFLLENBQUMsRUFBRSxHQUFHO2dCQUNYLE1BQU0sU0FBUyxRQUFRLFVBQVUsRUFBRSxHQUFHLENBQUM7Z0JBRXZDLFFBQVEsUUFBUSxDQUFDLE9BQU87b0JBQ3RCLE1BQU0sZUFBZSxNQUFNLE9BQU8sSUFBSTtvQkFDdEMsQ0FBQyxZQUFZLGlCQUFrQixDQUFBLE1BQU0sQ0FBQyxJQUFJLEdBQUcsWUFBVztnQkFDMUQ7Z0JBRUEsS0FBSyxDQUFDLEVBQUUsR0FBRztnQkFFWCxPQUFPO1lBQ1Q7UUFDRjtRQUVBLE9BQU87SUFDVDtJQUVBLE9BQU8sTUFBTSxLQUFLO0FBQ3BCO0FBRUEsTUFBTSxZQUFZLFdBQVc7QUFFN0IsTUFBTSxhQUFhLENBQUMsUUFDbEIsU0FBVSxDQUFBLFNBQVMsVUFBVSxXQUFXLE1BQUssS0FBTSxXQUFXLE1BQU0sSUFBSSxLQUFLLFdBQVcsTUFBTSxLQUFLO2tCQUV0RjtJQUNiO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQSxZQUFZO0lBQ1o7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQSxRQUFRO0lBQ1I7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7QUFDRjs7Ozs7NkNDaHRCd0I7QUFGeEI7QUFFZSxTQUFTLEtBQUssRUFBRSxFQUFFLE9BQU87SUFDdEMsT0FBTyxTQUFTO1FBQ2QsT0FBTyxHQUFHLEtBQUssQ0FBQyxTQUFTO0lBQzNCO0FBQ0Y7OztBQ05BLFFBQVEsY0FBYyxHQUFHLFNBQVUsQ0FBQztJQUNsQyxPQUFPLEtBQUssRUFBRSxVQUFVLEdBQUcsSUFBSTtRQUFDLFNBQVM7SUFBQztBQUM1QztBQUVBLFFBQVEsaUJBQWlCLEdBQUcsU0FBVSxDQUFDO0lBQ3JDLE9BQU8sY0FBYyxDQUFDLEdBQUcsY0FBYztRQUFDLE9BQU87SUFBSTtBQUNyRDtBQUVBLFFBQVEsU0FBUyxHQUFHLFNBQVUsTUFBTSxFQUFFLElBQUk7SUFDeEMsT0FBTyxJQUFJLENBQUMsUUFBUSxPQUFPLENBQUMsU0FBVSxHQUFHO1FBQ3ZDLElBQ0UsUUFBUSxhQUNSLFFBQVEsZ0JBQ1IsT0FBTyxTQUFTLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLE1BRTNDO1FBR0YsT0FBTyxjQUFjLENBQUMsTUFBTSxLQUFLO1lBQy9CLFlBQVk7WUFDWixLQUFLO2dCQUNILE9BQU8sTUFBTSxDQUFDLElBQUk7WUFDcEI7UUFDRjtJQUNGO0lBRUEsT0FBTztBQUNUO0FBRUEsUUFBUSxNQUFNLEdBQUcsU0FBVSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUc7SUFDNUMsT0FBTyxjQUFjLENBQUMsTUFBTSxVQUFVO1FBQ3BDLFlBQVk7UUFDWixLQUFLO0lBQ1A7QUFDRjs7Ozs7QUNoQ0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBVEE7QUFXQSxNQUFNLGFBQWEsQ0FBQSxHQUFBLDJCQUFTLEFBQUQsRUFBRSxVQUFVO0FBRXZDOzs7Ozs7Q0FNQyxHQUNELE1BQU07SUFDSixZQUFZLGNBQWMsQ0FBRTtRQUMxQixJQUFJLENBQUMsUUFBUSxHQUFHO1FBQ2hCLElBQUksQ0FBQyxZQUFZLEdBQUc7WUFDbEIsU0FBUyxJQUFJLENBQUEsR0FBQSxvQ0FBa0IsQUFBRDtZQUM5QixVQUFVLElBQUksQ0FBQSxHQUFBLG9DQUFrQixBQUFEO1FBQ2pDO0lBQ0Y7SUFFQTs7Ozs7OztHQU9DLEdBQ0QsTUFBTSxRQUFRLFdBQVcsRUFBRSxNQUFNLEVBQUU7UUFDakMsSUFBSTtZQUNGLE9BQU8sTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWE7UUFDMUMsRUFBRSxPQUFPLEtBQUs7WUFDWixJQUFJLGVBQWUsT0FBTztnQkFDeEIsSUFBSTtnQkFFSixNQUFNLGlCQUFpQixHQUFHLE1BQU0saUJBQWlCLENBQUMsUUFBUSxDQUFDLEtBQU0sUUFBUSxJQUFJO2dCQUU3RSxnQ0FBZ0M7Z0JBQ2hDLE1BQU0sUUFBUSxNQUFNLEtBQUssR0FBRyxNQUFNLEtBQUssQ0FBQyxPQUFPLENBQUMsU0FBUyxNQUFNO2dCQUUvRCxJQUFJLENBQUMsSUFBSSxLQUFLLEVBQ1osSUFBSSxLQUFLLEdBQUc7cUJBRVAsSUFBSSxTQUFTLENBQUMsT0FBTyxJQUFJLEtBQUssRUFBRSxRQUFRLENBQUMsTUFBTSxPQUFPLENBQUMsYUFBYSxNQUN6RSxJQUFJLEtBQUssSUFBSSxPQUFPO1lBRXhCO1lBRUEsTUFBTTtRQUNSO0lBQ0Y7SUFFQSxTQUFTLFdBQVcsRUFBRSxNQUFNLEVBQUU7UUFDNUIsNEJBQTRCLEdBQzVCLDBEQUEwRDtRQUMxRCxJQUFJLE9BQU8sZ0JBQWdCLFVBQVU7WUFDbkMsU0FBUyxVQUFVLENBQUM7WUFDcEIsT0FBTyxHQUFHLEdBQUc7UUFDZixPQUNFLFNBQVMsZUFBZSxDQUFDO1FBRzNCLFNBQVMsQ0FBQSxHQUFBLDZCQUFXLEFBQUQsRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFO1FBRXBDLE1BQU0sRUFBQyxZQUFZLEVBQUUsZ0JBQWdCLEVBQUUsT0FBTyxFQUFDLEdBQUc7UUFFbEQsSUFBSSxpQkFBaUIsV0FDbkIsQ0FBQSxHQUFBLDJCQUFTLEFBQUQsRUFBRSxhQUFhLENBQUMsY0FBYztZQUNwQyxtQkFBbUIsV0FBVyxZQUFZLENBQUMsV0FBVyxPQUFPO1lBQzdELG1CQUFtQixXQUFXLFlBQVksQ0FBQyxXQUFXLE9BQU87WUFDN0QscUJBQXFCLFdBQVcsWUFBWSxDQUFDLFdBQVcsT0FBTztRQUNqRSxHQUFHO1FBR0wsSUFBSSxvQkFBb0I7WUFDdEIsSUFBSSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFVBQVUsQ0FBQyxtQkFDbkIsT0FBTyxnQkFBZ0IsR0FBRztnQkFDeEIsV0FBVztZQUNiO2lCQUVBLENBQUEsR0FBQSwyQkFBUyxBQUFELEVBQUUsYUFBYSxDQUFDLGtCQUFrQjtnQkFDeEMsUUFBUSxXQUFXLFFBQVE7Z0JBQzNCLFdBQVcsV0FBVyxRQUFRO1lBQ2hDLEdBQUc7O1FBSVAsb0JBQW9CO1FBQ3BCLE9BQU8sTUFBTSxHQUFHLEFBQUMsQ0FBQSxPQUFPLE1BQU0sSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sSUFBSSxLQUFJLEVBQUcsV0FBVztRQUU1RSxrQkFBa0I7UUFDbEIsSUFBSSxpQkFBaUIsV0FBVyxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLEtBQUssQ0FDekMsUUFBUSxNQUFNLEVBQ2QsT0FBTyxDQUFDLE9BQU8sTUFBTSxDQUFDO1FBR3hCLFdBQVcsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxPQUFPLENBQ3RCO1lBQUM7WUFBVTtZQUFPO1lBQVE7WUFBUTtZQUFPO1lBQVM7U0FBUyxFQUMzRCxDQUFDO1lBQ0MsT0FBTyxPQUFPLENBQUMsT0FBTztRQUN4QjtRQUdGLE9BQU8sT0FBTyxHQUFHLENBQUEsR0FBQSw4QkFBWSxBQUFELEVBQUUsTUFBTSxDQUFDLGdCQUFnQjtRQUVyRCxrQ0FBa0M7UUFDbEMsTUFBTSwwQkFBMEIsRUFBRTtRQUNsQyxJQUFJLGlDQUFpQztRQUNyQyxJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUywyQkFBMkIsV0FBVztZQUMvRSxJQUFJLE9BQU8sWUFBWSxPQUFPLEtBQUssY0FBYyxZQUFZLE9BQU8sQ0FBQyxZQUFZLE9BQy9FO1lBR0YsaUNBQWlDLGtDQUFrQyxZQUFZLFdBQVc7WUFFMUYsd0JBQXdCLE9BQU8sQ0FBQyxZQUFZLFNBQVMsRUFBRSxZQUFZLFFBQVE7UUFDN0U7UUFFQSxNQUFNLDJCQUEyQixFQUFFO1FBQ25DLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLHlCQUF5QixXQUFXO1lBQzlFLHlCQUF5QixJQUFJLENBQUMsWUFBWSxTQUFTLEVBQUUsWUFBWSxRQUFRO1FBQzNFO1FBRUEsSUFBSTtRQUNKLElBQUksSUFBSTtRQUNSLElBQUk7UUFFSixJQUFJLENBQUMsZ0NBQWdDO1lBQ25DLE1BQU0sUUFBUTtnQkFBQyxDQUFBLEdBQUEsaUNBQWUsQUFBRCxFQUFFLElBQUksQ0FBQyxJQUFJO2dCQUFHO2FBQVU7WUFDckQsTUFBTSxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQU87WUFDM0IsTUFBTSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU87WUFDeEIsTUFBTSxNQUFNLE1BQU07WUFFbEIsVUFBVSxRQUFRLE9BQU8sQ0FBQztZQUUxQixNQUFPLElBQUksSUFDVCxVQUFVLFFBQVEsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7WUFHL0MsT0FBTztRQUNUO1FBRUEsTUFBTSx3QkFBd0IsTUFBTTtRQUVwQyxJQUFJLFlBQVk7UUFFaEIsSUFBSTtRQUVKLE1BQU8sSUFBSSxJQUFLO1lBQ2QsTUFBTSxjQUFjLHVCQUF1QixDQUFDLElBQUk7WUFDaEQsTUFBTSxhQUFhLHVCQUF1QixDQUFDLElBQUk7WUFDL0MsSUFBSTtnQkFDRixZQUFZLFlBQVk7WUFDMUIsRUFBRSxPQUFPLE9BQU87Z0JBQ2QsV0FBVyxJQUFJLENBQUMsSUFBSSxFQUFFO2dCQUN0QjtZQUNGO1FBQ0Y7UUFFQSxJQUFJO1lBQ0YsVUFBVSxDQUFBLEdBQUEsaUNBQWUsQUFBRCxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUU7UUFDdkMsRUFBRSxPQUFPLE9BQU87WUFDZCxPQUFPLFFBQVEsTUFBTSxDQUFDO1FBQ3hCO1FBRUEsSUFBSTtRQUNKLE1BQU0seUJBQXlCLE1BQU07UUFFckMsTUFBTyxJQUFJLElBQ1QsVUFBVSxRQUFRLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLEVBQUUsd0JBQXdCLENBQUMsSUFBSTtRQUdyRixPQUFPO0lBQ1Q7SUFFQSxPQUFPLE1BQU0sRUFBRTtRQUNiLFNBQVMsQ0FBQSxHQUFBLDZCQUFXLEFBQUQsRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFO1FBQ3BDLE1BQU0sV0FBVyxDQUFBLEdBQUEsK0JBQWEsQUFBRCxFQUFFLE9BQU8sT0FBTyxFQUFFLE9BQU8sR0FBRztRQUN6RCxPQUFPLENBQUEsR0FBQSwwQkFBUSxBQUFELEVBQUUsVUFBVSxPQUFPLE1BQU0sRUFBRSxPQUFPLGdCQUFnQjtJQUNsRTtBQUNGO0FBRUEsZ0RBQWdEO0FBQ2hELENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsT0FBTyxDQUFDO0lBQUM7SUFBVTtJQUFPO0lBQVE7Q0FBVSxFQUFFLFNBQVMsb0JBQW9CLE1BQU07SUFDckYscUJBQXFCLEdBQ3JCLE1BQU0sU0FBUyxDQUFDLE9BQU8sR0FBRyxTQUFTLEdBQUcsRUFBRSxNQUFNO1FBQzVDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBLEdBQUEsNkJBQVcsQUFBRCxFQUFFLFVBQVUsQ0FBQyxHQUFHO1lBQzVDO1lBQ0E7WUFDQSxNQUFNLEFBQUMsQ0FBQSxVQUFVLENBQUMsQ0FBQSxFQUFHLElBQUk7UUFDM0I7SUFDRjtBQUNGO0FBRUEsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxPQUFPLENBQUM7SUFBQztJQUFRO0lBQU87Q0FBUSxFQUFFLFNBQVMsc0JBQXNCLE1BQU07SUFDM0UscUJBQXFCLEdBRXJCLFNBQVMsbUJBQW1CLE1BQU07UUFDaEMsT0FBTyxTQUFTLFdBQVcsR0FBRyxFQUFFLElBQUksRUFBRSxNQUFNO1lBQzFDLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBLEdBQUEsNkJBQVcsQUFBRCxFQUFFLFVBQVUsQ0FBQyxHQUFHO2dCQUM1QztnQkFDQSxTQUFTLFNBQVM7b0JBQ2hCLGdCQUFnQjtnQkFDbEIsSUFBSSxDQUFDO2dCQUNMO2dCQUNBO1lBQ0Y7UUFDRjtJQUNGO0lBRUEsTUFBTSxTQUFTLENBQUMsT0FBTyxHQUFHO0lBRTFCLE1BQU0sU0FBUyxDQUFDLFNBQVMsT0FBTyxHQUFHLG1CQUFtQjtBQUN4RDtrQkFFZTs7Ozs7NkNDaE1TO0FBOUJ4Qjs7QUFDQTs7QUFIQTtBQUtBOzs7Ozs7O0NBT0MsR0FDRCxTQUFTLE9BQU8sR0FBRztJQUNqQixPQUFPLG1CQUFtQixLQUN4QixPQUFPLENBQUMsU0FBUyxLQUNqQixPQUFPLENBQUMsUUFBUSxLQUNoQixPQUFPLENBQUMsU0FBUyxLQUNqQixPQUFPLENBQUMsUUFBUSxLQUNoQixPQUFPLENBQUMsU0FBUyxLQUNqQixPQUFPLENBQUMsU0FBUztBQUNyQjtBQVdlLFNBQVMsU0FBUyxHQUFHLEVBQUUsTUFBTSxFQUFFLE9BQU87SUFDbkQsNEJBQTRCLEdBQzVCLElBQUksQ0FBQyxRQUNILE9BQU87SUFHVCxNQUFNLFVBQVUsV0FBVyxRQUFRLE1BQU0sSUFBSTtJQUU3QyxNQUFNLGNBQWMsV0FBVyxRQUFRLFNBQVM7SUFFaEQsSUFBSTtJQUVKLElBQUksYUFDRixtQkFBbUIsWUFBWSxRQUFRO1NBRXZDLG1CQUFtQixDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLGlCQUFpQixDQUFDLFVBQ3pDLE9BQU8sUUFBUSxLQUNmLElBQUksQ0FBQSxHQUFBLHNDQUFvQixBQUFELEVBQUUsUUFBUSxTQUFTLFFBQVEsQ0FBQztJQUd2RCxJQUFJLGtCQUFrQjtRQUNwQixNQUFNLGdCQUFnQixJQUFJLE9BQU8sQ0FBQztRQUVsQyxJQUFJLGtCQUFrQixJQUNwQixNQUFNLElBQUksS0FBSyxDQUFDLEdBQUc7UUFFckIsT0FBTyxBQUFDLENBQUEsSUFBSSxPQUFPLENBQUMsU0FBUyxLQUFLLE1BQU0sR0FBRSxJQUFLO0lBQ2pEO0lBRUEsT0FBTztBQUNUOzs7OztBQzVEQTs7QUFGQTtBQUlBOzs7Ozs7O0NBT0MsR0FDRCxTQUFTLE9BQU8sR0FBRztJQUNqQixNQUFNLFVBQVU7UUFDZCxLQUFLO1FBQ0wsS0FBSztRQUNMLEtBQUs7UUFDTCxLQUFLO1FBQ0wsS0FBSztRQUNMLE9BQU87UUFDUCxPQUFPO0lBQ1Q7SUFDQSxPQUFPLG1CQUFtQixLQUFLLE9BQU8sQ0FBQyxvQkFBb0IsU0FBUyxTQUFTLEtBQUs7UUFDaEYsT0FBTyxPQUFPLENBQUMsTUFBTTtJQUN2QjtBQUNGO0FBRUE7Ozs7Ozs7Q0FPQyxHQUNELFNBQVMscUJBQXFCLE1BQU0sRUFBRSxPQUFPO0lBQzNDLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRTtJQUVoQixVQUFVLENBQUEsR0FBQSw0QkFBVSxBQUFELEVBQUUsUUFBUSxJQUFJLEVBQUU7QUFDckM7QUFFQSxNQUFNLFlBQVkscUJBQXFCLFNBQVM7QUFFaEQsVUFBVSxNQUFNLEdBQUcsU0FBUyxPQUFPLElBQUksRUFBRSxLQUFLO0lBQzVDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQUM7UUFBTTtLQUFNO0FBQ2hDO0FBRUEsVUFBVSxRQUFRLEdBQUcsU0FBUyxTQUFTLE9BQU87SUFDNUMsTUFBTSxVQUFVLFVBQVUsU0FBUyxLQUFLO1FBQ3RDLE9BQU8sUUFBUSxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU87SUFDbkMsSUFBSTtJQUVKLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxLQUFLLElBQUk7UUFDdkMsT0FBTyxRQUFRLElBQUksQ0FBQyxFQUFFLElBQUksTUFBTSxRQUFRLElBQUksQ0FBQyxFQUFFO0lBQ2pELEdBQUcsSUFBSSxJQUFJLENBQUM7QUFDZDtrQkFFZTs7Ozs7QUN2RGY7O0FBQ0E7O0FBQ0EseUZBQXlGO0FBQ3pGOzs7QUFMQTtBQU9BOzs7Ozs7Q0FNQyxHQUNELFNBQVMsWUFBWSxLQUFLO0lBQ3hCLE9BQU8sQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxhQUFhLENBQUMsVUFBVSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLE9BQU8sQ0FBQztBQUNyRDtBQUVBOzs7Ozs7Q0FNQyxHQUNELFNBQVMsZUFBZSxHQUFHO0lBQ3pCLE9BQU8sQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxRQUFRLENBQUMsS0FBSyxRQUFRLElBQUksS0FBSyxDQUFDLEdBQUcsTUFBTTtBQUN4RDtBQUVBOzs7Ozs7OztDQVFDLEdBQ0QsU0FBUyxVQUFVLElBQUksRUFBRSxHQUFHLEVBQUUsSUFBSTtJQUNoQyxJQUFJLENBQUMsTUFBTSxPQUFPO0lBQ2xCLE9BQU8sS0FBSyxNQUFNLENBQUMsS0FBSyxHQUFHLENBQUMsU0FBUyxLQUFLLEtBQUssRUFBRSxDQUFDO1FBQ2hELDZDQUE2QztRQUM3QyxRQUFRLGVBQWU7UUFDdkIsT0FBTyxDQUFDLFFBQVEsSUFBSSxNQUFNLFFBQVEsTUFBTTtJQUMxQyxHQUFHLElBQUksQ0FBQyxPQUFPLE1BQU07QUFDdkI7QUFFQTs7Ozs7O0NBTUMsR0FDRCxTQUFTLFlBQVksR0FBRztJQUN0QixPQUFPLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksQ0FBQztBQUN6QztBQUVBLE1BQU0sYUFBYSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFlBQVksQ0FBQyxDQUFBLEdBQUEsdUJBQUssQUFBRCxHQUFHLENBQUMsR0FBRyxNQUFNLFNBQVMsT0FBTyxJQUFJO0lBQ3pFLE9BQU8sV0FBVyxJQUFJLENBQUM7QUFDekI7QUFFQTs7Ozs7Ozs7Ozs7O0VBWUUsR0FFRjs7Ozs7Ozs7Q0FRQyxHQUNELFNBQVMsV0FBVyxHQUFHLEVBQUUsUUFBUSxFQUFFLE9BQU87SUFDeEMsSUFBSSxDQUFDLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsUUFBUSxDQUFDLE1BQ2xCLE1BQU0sSUFBSSxVQUFVO0lBR3RCLDZDQUE2QztJQUM3QyxXQUFXLFlBQVksSUFBSyxDQUFBLENBQUEsR0FBQSwwQkFBZ0IsQUFBRCxLQUFLLFFBQU87SUFFdkQsNkNBQTZDO0lBQzdDLFVBQVUsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxZQUFZLENBQUMsU0FBUztRQUNwQyxZQUFZO1FBQ1osTUFBTTtRQUNOLFNBQVM7SUFDWCxHQUFHLE9BQU8sU0FBUyxRQUFRLE1BQU0sRUFBRSxNQUFNO1FBQ3ZDLDZDQUE2QztRQUM3QyxPQUFPLENBQUMsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxXQUFXLENBQUMsTUFBTSxDQUFDLE9BQU87SUFDMUM7SUFFQSxNQUFNLGFBQWEsUUFBUSxVQUFVO0lBQ3JDLGdEQUFnRDtJQUNoRCxNQUFNLFVBQVUsUUFBUSxPQUFPLElBQUk7SUFDbkMsTUFBTSxPQUFPLFFBQVEsSUFBSTtJQUN6QixNQUFNLFVBQVUsUUFBUSxPQUFPO0lBQy9CLE1BQU0sUUFBUSxRQUFRLElBQUksSUFBSSxPQUFPLFNBQVMsZUFBZTtJQUM3RCxNQUFNLFVBQVUsU0FBUyxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLG1CQUFtQixDQUFDO0lBRW5ELElBQUksQ0FBQyxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFVBQVUsQ0FBQyxVQUNwQixNQUFNLElBQUksVUFBVTtJQUd0QixTQUFTLGFBQWEsS0FBSztRQUN6QixJQUFJLFVBQVUsTUFBTSxPQUFPO1FBRTNCLElBQUksQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxNQUFNLENBQUMsUUFDZixPQUFPLE1BQU0sV0FBVztRQUcxQixJQUFJLENBQUMsV0FBVyxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLE1BQU0sQ0FBQyxRQUMzQixNQUFNLElBQUksQ0FBQSxHQUFBLDRCQUFVLEFBQUQsRUFBRTtRQUd2QixJQUFJLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsYUFBYSxDQUFDLFVBQVUsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxZQUFZLENBQUMsUUFDbkQsT0FBTyxXQUFXLE9BQU8sU0FBUyxhQUFhLElBQUksS0FBSztZQUFDO1NBQU0sSUFBSSxPQUFPLElBQUksQ0FBQztRQUdqRixPQUFPO0lBQ1Q7SUFFQTs7Ozs7Ozs7O0dBU0MsR0FDRCxTQUFTLGVBQWUsS0FBSyxFQUFFLEdBQUcsRUFBRSxJQUFJO1FBQ3RDLElBQUksTUFBTTtRQUVWLElBQUksU0FBUyxDQUFDLFFBQVEsT0FBTyxVQUFVLFVBQVU7WUFDL0MsSUFBSSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFFBQVEsQ0FBQyxLQUFLLE9BQU87Z0JBQzdCLDZDQUE2QztnQkFDN0MsTUFBTSxhQUFhLE1BQU0sSUFBSSxLQUFLLENBQUMsR0FBRztnQkFDdEMsNkNBQTZDO2dCQUM3QyxRQUFRLEtBQUssU0FBUyxDQUFDO1lBQ3pCLE9BQU8sSUFDTCxBQUFDLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsT0FBTyxDQUFDLFVBQVUsWUFBWSxVQUNwQyxBQUFDLENBQUEsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxVQUFVLENBQUMsVUFBVSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFFBQVEsQ0FBQyxLQUFLLEtBQUksS0FBTyxDQUFBLE1BQU0sQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxPQUFPLENBQUMsTUFBSyxHQUNsRjtnQkFDSCw2Q0FBNkM7Z0JBQzdDLE1BQU0sZUFBZTtnQkFFckIsSUFBSSxPQUFPLENBQUMsU0FBUyxLQUFLLEVBQUUsRUFBRSxLQUFLO29CQUNqQyxDQUFFLENBQUEsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxXQUFXLENBQUMsT0FBTyxPQUFPLElBQUcsS0FBTSxTQUFTLE1BQU0sQ0FDeEQsNkNBQTZDO29CQUM3QyxZQUFZLE9BQU8sVUFBVTt3QkFBQztxQkFBSSxFQUFFLE9BQU8sUUFBUyxZQUFZLE9BQU8sTUFBTSxNQUFNLE1BQ25GLGFBQWE7Z0JBRWpCO2dCQUNBLE9BQU87WUFDVDtRQUNGO1FBRUEsSUFBSSxZQUFZLFFBQ2QsT0FBTztRQUdULFNBQVMsTUFBTSxDQUFDLFVBQVUsTUFBTSxLQUFLLE9BQU8sYUFBYTtRQUV6RCxPQUFPO0lBQ1Q7SUFFQSxNQUFNLFFBQVEsRUFBRTtJQUVoQixNQUFNLGlCQUFpQixPQUFPLE1BQU0sQ0FBQyxZQUFZO1FBQy9DO1FBQ0E7UUFDQTtJQUNGO0lBRUEsU0FBUyxNQUFNLEtBQUssRUFBRSxJQUFJO1FBQ3hCLElBQUksQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxXQUFXLENBQUMsUUFBUTtRQUU5QixJQUFJLE1BQU0sT0FBTyxDQUFDLFdBQVcsSUFDM0IsTUFBTSxNQUFNLG9DQUFvQyxLQUFLLElBQUksQ0FBQztRQUc1RCxNQUFNLElBQUksQ0FBQztRQUVYLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsT0FBTyxDQUFDLE9BQU8sU0FBUyxLQUFLLEVBQUUsRUFBRSxHQUFHO1lBQ3hDLE1BQU0sU0FBUyxDQUFFLENBQUEsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxXQUFXLENBQUMsT0FBTyxPQUFPLElBQUcsS0FBTSxRQUFRLElBQUksQ0FDcEUsVUFBVSxJQUFJLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsUUFBUSxDQUFDLE9BQU8sSUFBSSxJQUFJLEtBQUssS0FBSyxNQUFNO1lBRzlELElBQUksV0FBVyxNQUNiLE1BQU0sSUFBSSxPQUFPLEtBQUssTUFBTSxDQUFDLE9BQU87Z0JBQUM7YUFBSTtRQUU3QztRQUVBLE1BQU0sR0FBRztJQUNYO0lBRUEsSUFBSSxDQUFDLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsUUFBUSxDQUFDLE1BQ2xCLE1BQU0sSUFBSSxVQUFVO0lBR3RCLE1BQU07SUFFTixPQUFPO0FBQ1Q7a0JBRWU7OztBQzFOZjs7Ozs7Q0FLQyxHQUNELDJCQUEyQixHQUUzQjtBQUVBLE1BQU0sU0FBUyxRQUFRO0FBQ3ZCLE1BQU0sVUFBVSxRQUFRO0FBQ3hCLE1BQU0sc0JBQ0osQUFBQyxPQUFPLFdBQVcsY0FBYyxPQUFPLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBWSxtQ0FBbUM7R0FDckcsTUFBTSxDQUFDLE1BQU0sQ0FBQyw4QkFBOEIsbUNBQW1DO0dBQy9FO0FBRU4sUUFBUSxNQUFNLEdBQUc7QUFDakIsUUFBUSxVQUFVLEdBQUc7QUFDckIsUUFBUSxpQkFBaUIsR0FBRztBQUU1QixNQUFNLGVBQWU7QUFDckIsUUFBUSxVQUFVLEdBQUc7QUFFckI7Ozs7Ozs7Ozs7Ozs7Q0FhQyxHQUNELE9BQU8sbUJBQW1CLEdBQUc7QUFFN0IsSUFBSSxDQUFDLE9BQU8sbUJBQW1CLElBQUksT0FBTyxZQUFZLGVBQ2xELE9BQU8sUUFBUSxLQUFLLEtBQUssWUFDM0IsUUFBUSxLQUFLLENBQ1g7QUFLSixTQUFTO0lBQ1AsOENBQThDO0lBQzlDLElBQUk7UUFDRixNQUFNLE1BQU0sSUFBSSxXQUFXO1FBQzNCLE1BQU0sUUFBUTtZQUFFLEtBQUs7Z0JBQWMsT0FBTztZQUFHO1FBQUU7UUFDL0MsT0FBTyxjQUFjLENBQUMsT0FBTyxXQUFXLFNBQVM7UUFDakQsT0FBTyxjQUFjLENBQUMsS0FBSztRQUMzQixPQUFPLElBQUksR0FBRyxPQUFPO0lBQ3ZCLEVBQUUsT0FBTyxHQUFHO1FBQ1YsT0FBTztJQUNUO0FBQ0Y7QUFFQSxPQUFPLGNBQWMsQ0FBQyxPQUFPLFNBQVMsRUFBRSxVQUFVO0lBQ2hELFlBQVk7SUFDWixLQUFLO1FBQ0gsSUFBSSxDQUFDLE9BQU8sUUFBUSxDQUFDLElBQUksR0FBRyxPQUFPO1FBQ25DLE9BQU8sSUFBSSxDQUFDLE1BQU07SUFDcEI7QUFDRjtBQUVBLE9BQU8sY0FBYyxDQUFDLE9BQU8sU0FBUyxFQUFFLFVBQVU7SUFDaEQsWUFBWTtJQUNaLEtBQUs7UUFDSCxJQUFJLENBQUMsT0FBTyxRQUFRLENBQUMsSUFBSSxHQUFHLE9BQU87UUFDbkMsT0FBTyxJQUFJLENBQUMsVUFBVTtJQUN4QjtBQUNGO0FBRUEsU0FBUyxhQUFjLE1BQU07SUFDM0IsSUFBSSxTQUFTLGNBQ1gsTUFBTSxJQUFJLFdBQVcsZ0JBQWdCLFNBQVM7SUFFaEQsNENBQTRDO0lBQzVDLE1BQU0sTUFBTSxJQUFJLFdBQVc7SUFDM0IsT0FBTyxjQUFjLENBQUMsS0FBSyxPQUFPLFNBQVM7SUFDM0MsT0FBTztBQUNUO0FBRUE7Ozs7Ozs7O0NBUUMsR0FFRCxTQUFTLE9BQVEsR0FBRyxFQUFFLGdCQUFnQixFQUFFLE1BQU07SUFDNUMsZUFBZTtJQUNmLElBQUksT0FBTyxRQUFRLFVBQVU7UUFDM0IsSUFBSSxPQUFPLHFCQUFxQixVQUM5QixNQUFNLElBQUksVUFDUjtRQUdKLE9BQU8sWUFBWTtJQUNyQjtJQUNBLE9BQU8sS0FBSyxLQUFLLGtCQUFrQjtBQUNyQztBQUVBLE9BQU8sUUFBUSxHQUFHLEtBQUssa0NBQWtDOztBQUV6RCxTQUFTLEtBQU0sS0FBSyxFQUFFLGdCQUFnQixFQUFFLE1BQU07SUFDNUMsSUFBSSxPQUFPLFVBQVUsVUFDbkIsT0FBTyxXQUFXLE9BQU87SUFHM0IsSUFBSSxZQUFZLE1BQU0sQ0FBQyxRQUNyQixPQUFPLGNBQWM7SUFHdkIsSUFBSSxTQUFTLE1BQ1gsTUFBTSxJQUFJLFVBQ1Isb0hBQzBDLE9BQU87SUFJckQsSUFBSSxXQUFXLE9BQU8sZ0JBQ2pCLFNBQVMsV0FBVyxNQUFNLE1BQU0sRUFBRSxjQUNyQyxPQUFPLGdCQUFnQixPQUFPLGtCQUFrQjtJQUdsRCxJQUFJLE9BQU8sc0JBQXNCLGVBQzVCLENBQUEsV0FBVyxPQUFPLHNCQUNsQixTQUFTLFdBQVcsTUFBTSxNQUFNLEVBQUUsa0JBQWtCLEdBQ3ZELE9BQU8sZ0JBQWdCLE9BQU8sa0JBQWtCO0lBR2xELElBQUksT0FBTyxVQUFVLFVBQ25CLE1BQU0sSUFBSSxVQUNSO0lBSUosTUFBTSxVQUFVLE1BQU0sT0FBTyxJQUFJLE1BQU0sT0FBTztJQUM5QyxJQUFJLFdBQVcsUUFBUSxZQUFZLE9BQ2pDLE9BQU8sT0FBTyxJQUFJLENBQUMsU0FBUyxrQkFBa0I7SUFHaEQsTUFBTSxJQUFJLFdBQVc7SUFDckIsSUFBSSxHQUFHLE9BQU87SUFFZCxJQUFJLE9BQU8sV0FBVyxlQUFlLE9BQU8sV0FBVyxJQUFJLFFBQ3ZELE9BQU8sS0FBSyxDQUFDLE9BQU8sV0FBVyxDQUFDLEtBQUssWUFDdkMsT0FBTyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxXQUFXLENBQUMsQ0FBQyxXQUFXLGtCQUFrQjtJQUc1RSxNQUFNLElBQUksVUFDUixvSEFDMEMsT0FBTztBQUVyRDtBQUVBOzs7Ozs7O0VBT0UsR0FDRixPQUFPLElBQUksR0FBRyxTQUFVLEtBQUssRUFBRSxnQkFBZ0IsRUFBRSxNQUFNO0lBQ3JELE9BQU8sS0FBSyxPQUFPLGtCQUFrQjtBQUN2QztBQUVBLGtGQUFrRjtBQUNsRiw0Q0FBNEM7QUFDNUMsT0FBTyxjQUFjLENBQUMsT0FBTyxTQUFTLEVBQUUsV0FBVyxTQUFTO0FBQzVELE9BQU8sY0FBYyxDQUFDLFFBQVE7QUFFOUIsU0FBUyxXQUFZLElBQUk7SUFDdkIsSUFBSSxPQUFPLFNBQVMsVUFDbEIsTUFBTSxJQUFJLFVBQVU7U0FDZixJQUFJLE9BQU8sR0FDaEIsTUFBTSxJQUFJLFdBQVcsZ0JBQWdCLE9BQU87QUFFaEQ7QUFFQSxTQUFTLE1BQU8sSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRO0lBQ2xDLFdBQVc7SUFDWCxJQUFJLFFBQVEsR0FDVixPQUFPLGFBQWE7SUFFdEIsSUFBSSxTQUFTLFdBQ1gsd0RBQXdEO0lBQ3hELHVEQUF1RDtJQUN2RCxvQ0FBb0M7SUFDcEMsT0FBTyxPQUFPLGFBQWEsV0FDdkIsYUFBYSxNQUFNLElBQUksQ0FBQyxNQUFNLFlBQzlCLGFBQWEsTUFBTSxJQUFJLENBQUM7SUFFOUIsT0FBTyxhQUFhO0FBQ3RCO0FBRUE7OztFQUdFLEdBQ0YsT0FBTyxLQUFLLEdBQUcsU0FBVSxJQUFJLEVBQUUsSUFBSSxFQUFFLFFBQVE7SUFDM0MsT0FBTyxNQUFNLE1BQU0sTUFBTTtBQUMzQjtBQUVBLFNBQVMsWUFBYSxJQUFJO0lBQ3hCLFdBQVc7SUFDWCxPQUFPLGFBQWEsT0FBTyxJQUFJLElBQUksUUFBUSxRQUFRO0FBQ3JEO0FBRUE7O0dBRUcsR0FDSCxPQUFPLFdBQVcsR0FBRyxTQUFVLElBQUk7SUFDakMsT0FBTyxZQUFZO0FBQ3JCO0FBQ0E7O0NBRUMsR0FDRCxPQUFPLGVBQWUsR0FBRyxTQUFVLElBQUk7SUFDckMsT0FBTyxZQUFZO0FBQ3JCO0FBRUEsU0FBUyxXQUFZLE1BQU0sRUFBRSxRQUFRO0lBQ25DLElBQUksT0FBTyxhQUFhLFlBQVksYUFBYSxJQUMvQyxXQUFXO0lBR2IsSUFBSSxDQUFDLE9BQU8sVUFBVSxDQUFDLFdBQ3JCLE1BQU0sSUFBSSxVQUFVLHVCQUF1QjtJQUc3QyxNQUFNLFNBQVMsV0FBVyxRQUFRLFlBQVk7SUFDOUMsSUFBSSxNQUFNLGFBQWE7SUFFdkIsTUFBTSxTQUFTLElBQUksS0FBSyxDQUFDLFFBQVE7SUFFakMsSUFBSSxXQUFXLFFBQ2IsMkVBQTJFO0lBQzNFLDBFQUEwRTtJQUMxRSxvQ0FBb0M7SUFDcEMsTUFBTSxJQUFJLEtBQUssQ0FBQyxHQUFHO0lBR3JCLE9BQU87QUFDVDtBQUVBLFNBQVMsY0FBZSxLQUFLO0lBQzNCLE1BQU0sU0FBUyxNQUFNLE1BQU0sR0FBRyxJQUFJLElBQUksUUFBUSxNQUFNLE1BQU0sSUFBSTtJQUM5RCxNQUFNLE1BQU0sYUFBYTtJQUN6QixJQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLLEVBQy9CLEdBQUcsQ0FBQyxFQUFFLEdBQUcsS0FBSyxDQUFDLEVBQUUsR0FBRztJQUV0QixPQUFPO0FBQ1Q7QUFFQSxTQUFTLGNBQWUsU0FBUztJQUMvQixJQUFJLFdBQVcsV0FBVyxhQUFhO1FBQ3JDLE1BQU0sT0FBTyxJQUFJLFdBQVc7UUFDNUIsT0FBTyxnQkFBZ0IsS0FBSyxNQUFNLEVBQUUsS0FBSyxVQUFVLEVBQUUsS0FBSyxVQUFVO0lBQ3RFO0lBQ0EsT0FBTyxjQUFjO0FBQ3ZCO0FBRUEsU0FBUyxnQkFBaUIsS0FBSyxFQUFFLFVBQVUsRUFBRSxNQUFNO0lBQ2pELElBQUksYUFBYSxLQUFLLE1BQU0sVUFBVSxHQUFHLFlBQ3ZDLE1BQU0sSUFBSSxXQUFXO0lBR3ZCLElBQUksTUFBTSxVQUFVLEdBQUcsYUFBYyxDQUFBLFVBQVUsQ0FBQSxHQUM3QyxNQUFNLElBQUksV0FBVztJQUd2QixJQUFJO0lBQ0osSUFBSSxlQUFlLGFBQWEsV0FBVyxXQUN6QyxNQUFNLElBQUksV0FBVztTQUNoQixJQUFJLFdBQVcsV0FDcEIsTUFBTSxJQUFJLFdBQVcsT0FBTztTQUU1QixNQUFNLElBQUksV0FBVyxPQUFPLFlBQVk7SUFHMUMsNENBQTRDO0lBQzVDLE9BQU8sY0FBYyxDQUFDLEtBQUssT0FBTyxTQUFTO0lBRTNDLE9BQU87QUFDVDtBQUVBLFNBQVMsV0FBWSxHQUFHO0lBQ3RCLElBQUksT0FBTyxRQUFRLENBQUMsTUFBTTtRQUN4QixNQUFNLE1BQU0sUUFBUSxJQUFJLE1BQU0sSUFBSTtRQUNsQyxNQUFNLE1BQU0sYUFBYTtRQUV6QixJQUFJLElBQUksTUFBTSxLQUFLLEdBQ2pCLE9BQU87UUFHVCxJQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsR0FBRztRQUNwQixPQUFPO0lBQ1Q7SUFFQSxJQUFJLElBQUksTUFBTSxLQUFLLFdBQVc7UUFDNUIsSUFBSSxPQUFPLElBQUksTUFBTSxLQUFLLFlBQVksWUFBWSxJQUFJLE1BQU0sR0FDMUQsT0FBTyxhQUFhO1FBRXRCLE9BQU8sY0FBYztJQUN2QjtJQUVBLElBQUksSUFBSSxJQUFJLEtBQUssWUFBWSxNQUFNLE9BQU8sQ0FBQyxJQUFJLElBQUksR0FDakQsT0FBTyxjQUFjLElBQUksSUFBSTtBQUVqQztBQUVBLFNBQVMsUUFBUyxNQUFNO0lBQ3RCLHdFQUF3RTtJQUN4RSxzREFBc0Q7SUFDdEQsSUFBSSxVQUFVLGNBQ1osTUFBTSxJQUFJLFdBQVcsNERBQ2EsYUFBYSxRQUFRLENBQUMsTUFBTTtJQUVoRSxPQUFPLFNBQVM7QUFDbEI7QUFFQSxTQUFTLFdBQVksTUFBTTtJQUN6QixJQUFJLENBQUMsVUFBVSxRQUNiLFNBQVM7SUFFWCxPQUFPLE9BQU8sS0FBSyxDQUFDLENBQUM7QUFDdkI7QUFFQSxPQUFPLFFBQVEsR0FBRyxTQUFTLFNBQVUsQ0FBQztJQUNwQyxPQUFPLEtBQUssUUFBUSxFQUFFLFNBQVMsS0FBSyxRQUNsQyxNQUFNLE9BQU8sU0FBUyxDQUFDLHFEQUFxRDs7QUFDaEY7QUFFQSxPQUFPLE9BQU8sR0FBRyxTQUFTLFFBQVMsQ0FBQyxFQUFFLENBQUM7SUFDckMsSUFBSSxXQUFXLEdBQUcsYUFBYSxJQUFJLE9BQU8sSUFBSSxDQUFDLEdBQUcsRUFBRSxNQUFNLEVBQUUsRUFBRSxVQUFVO0lBQ3hFLElBQUksV0FBVyxHQUFHLGFBQWEsSUFBSSxPQUFPLElBQUksQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLEVBQUUsVUFBVTtJQUN4RSxJQUFJLENBQUMsT0FBTyxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sUUFBUSxDQUFDLElBQzFDLE1BQU0sSUFBSSxVQUNSO0lBSUosSUFBSSxNQUFNLEdBQUcsT0FBTztJQUVwQixJQUFJLElBQUksRUFBRSxNQUFNO0lBQ2hCLElBQUksSUFBSSxFQUFFLE1BQU07SUFFaEIsSUFBSyxJQUFJLElBQUksR0FBRyxNQUFNLEtBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxJQUFJLEtBQUssRUFBRSxFQUMvQyxJQUFJLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRTtRQUNqQixJQUFJLENBQUMsQ0FBQyxFQUFFO1FBQ1IsSUFBSSxDQUFDLENBQUMsRUFBRTtRQUNSO0lBQ0Y7SUFHRixJQUFJLElBQUksR0FBRyxPQUFPO0lBQ2xCLElBQUksSUFBSSxHQUFHLE9BQU87SUFDbEIsT0FBTztBQUNUO0FBRUEsT0FBTyxVQUFVLEdBQUcsU0FBUyxXQUFZLFFBQVE7SUFDL0MsT0FBUSxPQUFPLFVBQVUsV0FBVztRQUNsQyxLQUFLO1FBQ0wsS0FBSztRQUNMLEtBQUs7UUFDTCxLQUFLO1FBQ0wsS0FBSztRQUNMLEtBQUs7UUFDTCxLQUFLO1FBQ0wsS0FBSztRQUNMLEtBQUs7UUFDTCxLQUFLO1FBQ0wsS0FBSztZQUNILE9BQU87UUFDVDtZQUNFLE9BQU87SUFDWDtBQUNGO0FBRUEsT0FBTyxNQUFNLEdBQUcsU0FBUyxPQUFRLElBQUksRUFBRSxNQUFNO0lBQzNDLElBQUksQ0FBQyxNQUFNLE9BQU8sQ0FBQyxPQUNqQixNQUFNLElBQUksVUFBVTtJQUd0QixJQUFJLEtBQUssTUFBTSxLQUFLLEdBQ2xCLE9BQU8sT0FBTyxLQUFLLENBQUM7SUFHdEIsSUFBSTtJQUNKLElBQUksV0FBVyxXQUFXO1FBQ3hCLFNBQVM7UUFDVCxJQUFLLElBQUksR0FBRyxJQUFJLEtBQUssTUFBTSxFQUFFLEVBQUUsRUFDN0IsVUFBVSxJQUFJLENBQUMsRUFBRSxDQUFDLE1BQU07SUFFNUI7SUFFQSxNQUFNLFNBQVMsT0FBTyxXQUFXLENBQUM7SUFDbEMsSUFBSSxNQUFNO0lBQ1YsSUFBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLE1BQU0sRUFBRSxFQUFFLEVBQUc7UUFDaEMsSUFBSSxNQUFNLElBQUksQ0FBQyxFQUFFO1FBQ2pCLElBQUksV0FBVyxLQUFLO1lBQ2xCLElBQUksTUFBTSxJQUFJLE1BQU0sR0FBRyxPQUFPLE1BQU0sRUFBRTtnQkFDcEMsSUFBSSxDQUFDLE9BQU8sUUFBUSxDQUFDLE1BQU0sTUFBTSxPQUFPLElBQUksQ0FBQztnQkFDN0MsSUFBSSxJQUFJLENBQUMsUUFBUTtZQUNuQixPQUNFLFdBQVcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQzNCLFFBQ0EsS0FDQTtlQUdDLElBQUksQ0FBQyxPQUFPLFFBQVEsQ0FBQyxNQUMxQixNQUFNLElBQUksVUFBVTthQUVwQixJQUFJLElBQUksQ0FBQyxRQUFRO1FBRW5CLE9BQU8sSUFBSSxNQUFNO0lBQ25CO0lBQ0EsT0FBTztBQUNUO0FBRUEsU0FBUyxXQUFZLE1BQU0sRUFBRSxRQUFRO0lBQ25DLElBQUksT0FBTyxRQUFRLENBQUMsU0FDbEIsT0FBTyxPQUFPLE1BQU07SUFFdEIsSUFBSSxZQUFZLE1BQU0sQ0FBQyxXQUFXLFdBQVcsUUFBUSxjQUNuRCxPQUFPLE9BQU8sVUFBVTtJQUUxQixJQUFJLE9BQU8sV0FBVyxVQUNwQixNQUFNLElBQUksVUFDUiw2RkFDbUIsT0FBTztJQUk5QixNQUFNLE1BQU0sT0FBTyxNQUFNO0lBQ3pCLE1BQU0sWUFBYSxVQUFVLE1BQU0sR0FBRyxLQUFLLFNBQVMsQ0FBQyxFQUFFLEtBQUs7SUFDNUQsSUFBSSxDQUFDLGFBQWEsUUFBUSxHQUFHLE9BQU87SUFFcEMsb0NBQW9DO0lBQ3BDLElBQUksY0FBYztJQUNsQixPQUNFLE9BQVE7UUFDTixLQUFLO1FBQ0wsS0FBSztRQUNMLEtBQUs7WUFDSCxPQUFPO1FBQ1QsS0FBSztRQUNMLEtBQUs7WUFDSCxPQUFPLFlBQVksUUFBUSxNQUFNO1FBQ25DLEtBQUs7UUFDTCxLQUFLO1FBQ0wsS0FBSztRQUNMLEtBQUs7WUFDSCxPQUFPLE1BQU07UUFDZixLQUFLO1lBQ0gsT0FBTyxRQUFRO1FBQ2pCLEtBQUs7WUFDSCxPQUFPLGNBQWMsUUFBUSxNQUFNO1FBQ3JDO1lBQ0UsSUFBSSxhQUNGLE9BQU8sWUFBWSxLQUFLLFlBQVksUUFBUSxNQUFNLENBQUMsY0FBYzs7WUFFbkUsV0FBVyxBQUFDLENBQUEsS0FBSyxRQUFPLEVBQUcsV0FBVztZQUN0QyxjQUFjO0lBQ2xCO0FBRUo7QUFDQSxPQUFPLFVBQVUsR0FBRztBQUVwQixTQUFTLGFBQWMsUUFBUSxFQUFFLEtBQUssRUFBRSxHQUFHO0lBQ3pDLElBQUksY0FBYztJQUVsQiw0RUFBNEU7SUFDNUUsNkJBQTZCO0lBRTdCLDJFQUEyRTtJQUMzRSxtRUFBbUU7SUFDbkUsOERBQThEO0lBQzlELGtFQUFrRTtJQUNsRSxJQUFJLFVBQVUsYUFBYSxRQUFRLEdBQ2pDLFFBQVE7SUFFViw2RUFBNkU7SUFDN0UsdUJBQXVCO0lBQ3ZCLElBQUksUUFBUSxJQUFJLENBQUMsTUFBTSxFQUNyQixPQUFPO0lBR1QsSUFBSSxRQUFRLGFBQWEsTUFBTSxJQUFJLENBQUMsTUFBTSxFQUN4QyxNQUFNLElBQUksQ0FBQyxNQUFNO0lBR25CLElBQUksT0FBTyxHQUNULE9BQU87SUFHVCwwRUFBMEU7SUFDMUUsU0FBUztJQUNULFdBQVc7SUFFWCxJQUFJLE9BQU8sT0FDVCxPQUFPO0lBR1QsSUFBSSxDQUFDLFVBQVUsV0FBVztJQUUxQixNQUFPLEtBQ0wsT0FBUTtRQUNOLEtBQUs7WUFDSCxPQUFPLFNBQVMsSUFBSSxFQUFFLE9BQU87UUFFL0IsS0FBSztRQUNMLEtBQUs7WUFDSCxPQUFPLFVBQVUsSUFBSSxFQUFFLE9BQU87UUFFaEMsS0FBSztZQUNILE9BQU8sV0FBVyxJQUFJLEVBQUUsT0FBTztRQUVqQyxLQUFLO1FBQ0wsS0FBSztZQUNILE9BQU8sWUFBWSxJQUFJLEVBQUUsT0FBTztRQUVsQyxLQUFLO1lBQ0gsT0FBTyxZQUFZLElBQUksRUFBRSxPQUFPO1FBRWxDLEtBQUs7UUFDTCxLQUFLO1FBQ0wsS0FBSztRQUNMLEtBQUs7WUFDSCxPQUFPLGFBQWEsSUFBSSxFQUFFLE9BQU87UUFFbkM7WUFDRSxJQUFJLGFBQWEsTUFBTSxJQUFJLFVBQVUsdUJBQXVCO1lBQzVELFdBQVcsQUFBQyxDQUFBLFdBQVcsRUFBQyxFQUFHLFdBQVc7WUFDdEMsY0FBYztJQUNsQjtBQUVKO0FBRUEsK0VBQStFO0FBQy9FLDRFQUE0RTtBQUM1RSw2RUFBNkU7QUFDN0UsMkVBQTJFO0FBQzNFLHlFQUF5RTtBQUN6RSxtREFBbUQ7QUFDbkQsT0FBTyxTQUFTLENBQUMsU0FBUyxHQUFHO0FBRTdCLFNBQVMsS0FBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7SUFDcEIsTUFBTSxJQUFJLENBQUMsQ0FBQyxFQUFFO0lBQ2QsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRTtJQUNYLENBQUMsQ0FBQyxFQUFFLEdBQUc7QUFDVDtBQUVBLE9BQU8sU0FBUyxDQUFDLE1BQU0sR0FBRyxTQUFTO0lBQ2pDLE1BQU0sTUFBTSxJQUFJLENBQUMsTUFBTTtJQUN2QixJQUFJLE1BQU0sTUFBTSxHQUNkLE1BQU0sSUFBSSxXQUFXO0lBRXZCLElBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUssRUFDNUIsS0FBSyxJQUFJLEVBQUUsR0FBRyxJQUFJO0lBRXBCLE9BQU8sSUFBSTtBQUNiO0FBRUEsT0FBTyxTQUFTLENBQUMsTUFBTSxHQUFHLFNBQVM7SUFDakMsTUFBTSxNQUFNLElBQUksQ0FBQyxNQUFNO0lBQ3ZCLElBQUksTUFBTSxNQUFNLEdBQ2QsTUFBTSxJQUFJLFdBQVc7SUFFdkIsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSyxFQUFHO1FBQy9CLEtBQUssSUFBSSxFQUFFLEdBQUcsSUFBSTtRQUNsQixLQUFLLElBQUksRUFBRSxJQUFJLEdBQUcsSUFBSTtJQUN4QjtJQUNBLE9BQU8sSUFBSTtBQUNiO0FBRUEsT0FBTyxTQUFTLENBQUMsTUFBTSxHQUFHLFNBQVM7SUFDakMsTUFBTSxNQUFNLElBQUksQ0FBQyxNQUFNO0lBQ3ZCLElBQUksTUFBTSxNQUFNLEdBQ2QsTUFBTSxJQUFJLFdBQVc7SUFFdkIsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSyxFQUFHO1FBQy9CLEtBQUssSUFBSSxFQUFFLEdBQUcsSUFBSTtRQUNsQixLQUFLLElBQUksRUFBRSxJQUFJLEdBQUcsSUFBSTtRQUN0QixLQUFLLElBQUksRUFBRSxJQUFJLEdBQUcsSUFBSTtRQUN0QixLQUFLLElBQUksRUFBRSxJQUFJLEdBQUcsSUFBSTtJQUN4QjtJQUNBLE9BQU8sSUFBSTtBQUNiO0FBRUEsT0FBTyxTQUFTLENBQUMsUUFBUSxHQUFHLFNBQVM7SUFDbkMsTUFBTSxTQUFTLElBQUksQ0FBQyxNQUFNO0lBQzFCLElBQUksV0FBVyxHQUFHLE9BQU87SUFDekIsSUFBSSxVQUFVLE1BQU0sS0FBSyxHQUFHLE9BQU8sVUFBVSxJQUFJLEVBQUUsR0FBRztJQUN0RCxPQUFPLGFBQWEsS0FBSyxDQUFDLElBQUksRUFBRTtBQUNsQztBQUVBLE9BQU8sU0FBUyxDQUFDLGNBQWMsR0FBRyxPQUFPLFNBQVMsQ0FBQyxRQUFRO0FBRTNELE9BQU8sU0FBUyxDQUFDLE1BQU0sR0FBRyxTQUFTLE9BQVEsQ0FBQztJQUMxQyxJQUFJLENBQUMsT0FBTyxRQUFRLENBQUMsSUFBSSxNQUFNLElBQUksVUFBVTtJQUM3QyxJQUFJLElBQUksS0FBSyxHQUFHLE9BQU87SUFDdkIsT0FBTyxPQUFPLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTztBQUNyQztBQUVBLE9BQU8sU0FBUyxDQUFDLE9BQU8sR0FBRyxTQUFTO0lBQ2xDLElBQUksTUFBTTtJQUNWLE1BQU0sTUFBTSxRQUFRLGlCQUFpQjtJQUNyQyxNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxHQUFHLEtBQUssT0FBTyxDQUFDLFdBQVcsT0FBTyxJQUFJO0lBQ2pFLElBQUksSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLE9BQU87SUFDOUIsT0FBTyxhQUFhLE1BQU07QUFDNUI7QUFDQSxJQUFJLHFCQUNGLE9BQU8sU0FBUyxDQUFDLG9CQUFvQixHQUFHLE9BQU8sU0FBUyxDQUFDLE9BQU87QUFHbEUsT0FBTyxTQUFTLENBQUMsT0FBTyxHQUFHLFNBQVMsUUFBUyxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsT0FBTztJQUNqRixJQUFJLFdBQVcsUUFBUSxhQUNyQixTQUFTLE9BQU8sSUFBSSxDQUFDLFFBQVEsT0FBTyxNQUFNLEVBQUUsT0FBTyxVQUFVO0lBRS9ELElBQUksQ0FBQyxPQUFPLFFBQVEsQ0FBQyxTQUNuQixNQUFNLElBQUksVUFDUixtRkFDb0IsT0FBTztJQUkvQixJQUFJLFVBQVUsV0FDWixRQUFRO0lBRVYsSUFBSSxRQUFRLFdBQ1YsTUFBTSxTQUFTLE9BQU8sTUFBTSxHQUFHO0lBRWpDLElBQUksY0FBYyxXQUNoQixZQUFZO0lBRWQsSUFBSSxZQUFZLFdBQ2QsVUFBVSxJQUFJLENBQUMsTUFBTTtJQUd2QixJQUFJLFFBQVEsS0FBSyxNQUFNLE9BQU8sTUFBTSxJQUFJLFlBQVksS0FBSyxVQUFVLElBQUksQ0FBQyxNQUFNLEVBQzVFLE1BQU0sSUFBSSxXQUFXO0lBR3ZCLElBQUksYUFBYSxXQUFXLFNBQVMsS0FDbkMsT0FBTztJQUVULElBQUksYUFBYSxTQUNmLE9BQU87SUFFVCxJQUFJLFNBQVMsS0FDWCxPQUFPO0lBR1QsV0FBVztJQUNYLFNBQVM7SUFDVCxlQUFlO0lBQ2YsYUFBYTtJQUViLElBQUksSUFBSSxLQUFLLFFBQVEsT0FBTztJQUU1QixJQUFJLElBQUksVUFBVTtJQUNsQixJQUFJLElBQUksTUFBTTtJQUNkLE1BQU0sTUFBTSxLQUFLLEdBQUcsQ0FBQyxHQUFHO0lBRXhCLE1BQU0sV0FBVyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVc7SUFDdkMsTUFBTSxhQUFhLE9BQU8sS0FBSyxDQUFDLE9BQU87SUFFdkMsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssRUFBRSxFQUN6QixJQUFJLFFBQVEsQ0FBQyxFQUFFLEtBQUssVUFBVSxDQUFDLEVBQUUsRUFBRTtRQUNqQyxJQUFJLFFBQVEsQ0FBQyxFQUFFO1FBQ2YsSUFBSSxVQUFVLENBQUMsRUFBRTtRQUNqQjtJQUNGO0lBR0YsSUFBSSxJQUFJLEdBQUcsT0FBTztJQUNsQixJQUFJLElBQUksR0FBRyxPQUFPO0lBQ2xCLE9BQU87QUFDVDtBQUVBLCtFQUErRTtBQUMvRSxvRUFBb0U7QUFDcEUsRUFBRTtBQUNGLGFBQWE7QUFDYixnQ0FBZ0M7QUFDaEMsc0NBQXNDO0FBQ3RDLHFFQUFxRTtBQUNyRSxpRUFBaUU7QUFDakUsa0RBQWtEO0FBQ2xELFNBQVMscUJBQXNCLE1BQU0sRUFBRSxHQUFHLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxHQUFHO0lBQ25FLDhCQUE4QjtJQUM5QixJQUFJLE9BQU8sTUFBTSxLQUFLLEdBQUcsT0FBTztJQUVoQyx1QkFBdUI7SUFDdkIsSUFBSSxPQUFPLGVBQWUsVUFBVTtRQUNsQyxXQUFXO1FBQ1gsYUFBYTtJQUNmLE9BQU8sSUFBSSxhQUFhLFlBQ3RCLGFBQWE7U0FDUixJQUFJLGFBQWEsYUFDdEIsYUFBYTtJQUVmLGFBQWEsQ0FBQyxXQUFXLG9CQUFvQjs7SUFDN0MsSUFBSSxZQUFZLGFBQ2QsNEVBQTRFO0lBQzVFLGFBQWEsTUFBTSxJQUFLLE9BQU8sTUFBTSxHQUFHO0lBRzFDLDBFQUEwRTtJQUMxRSxJQUFJLGFBQWEsR0FBRyxhQUFhLE9BQU8sTUFBTSxHQUFHO0lBQ2pELElBQUksY0FBYyxPQUFPLE1BQU0sRUFBRTtRQUMvQixJQUFJLEtBQUssT0FBTzthQUNYLGFBQWEsT0FBTyxNQUFNLEdBQUc7SUFDcEMsT0FBTyxJQUFJLGFBQWEsR0FBRztRQUN6QixJQUFJLEtBQUssYUFBYTthQUNqQixPQUFPO0lBQ2Q7SUFFQSxnQkFBZ0I7SUFDaEIsSUFBSSxPQUFPLFFBQVEsVUFDakIsTUFBTSxPQUFPLElBQUksQ0FBQyxLQUFLO0lBR3pCLGlFQUFpRTtJQUNqRSxJQUFJLE9BQU8sUUFBUSxDQUFDLE1BQU07UUFDeEIsNkRBQTZEO1FBQzdELElBQUksSUFBSSxNQUFNLEtBQUssR0FDakIsT0FBTztRQUVULE9BQU8sYUFBYSxRQUFRLEtBQUssWUFBWSxVQUFVO0lBQ3pELE9BQU8sSUFBSSxPQUFPLFFBQVEsVUFBVTtRQUNsQyxNQUFNLE1BQU0sS0FBSyxrQ0FBa0M7O1FBQ25ELElBQUksT0FBTyxXQUFXLFNBQVMsQ0FBQyxPQUFPLEtBQUssWUFBWTtZQUN0RCxJQUFJLEtBQ0YsT0FBTyxXQUFXLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsS0FBSztpQkFFdEQsT0FBTyxXQUFXLFNBQVMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsS0FBSztRQUU5RDtRQUNBLE9BQU8sYUFBYSxRQUFRO1lBQUM7U0FBSSxFQUFFLFlBQVksVUFBVTtJQUMzRDtJQUVBLE1BQU0sSUFBSSxVQUFVO0FBQ3RCO0FBRUEsU0FBUyxhQUFjLEdBQUcsRUFBRSxHQUFHLEVBQUUsVUFBVSxFQUFFLFFBQVEsRUFBRSxHQUFHO0lBQ3hELElBQUksWUFBWTtJQUNoQixJQUFJLFlBQVksSUFBSSxNQUFNO0lBQzFCLElBQUksWUFBWSxJQUFJLE1BQU07SUFFMUIsSUFBSSxhQUFhLFdBQVc7UUFDMUIsV0FBVyxPQUFPLFVBQVUsV0FBVztRQUN2QyxJQUFJLGFBQWEsVUFBVSxhQUFhLFdBQ3BDLGFBQWEsYUFBYSxhQUFhLFlBQVk7WUFDckQsSUFBSSxJQUFJLE1BQU0sR0FBRyxLQUFLLElBQUksTUFBTSxHQUFHLEdBQ2pDLE9BQU87WUFFVCxZQUFZO1lBQ1osYUFBYTtZQUNiLGFBQWE7WUFDYixjQUFjO1FBQ2hCO0lBQ0Y7SUFFQSxTQUFTLEtBQU0sR0FBRyxFQUFFLENBQUM7UUFDbkIsSUFBSSxjQUFjLEdBQ2hCLE9BQU8sR0FBRyxDQUFDLEVBQUU7YUFFYixPQUFPLElBQUksWUFBWSxDQUFDLElBQUk7SUFFaEM7SUFFQSxJQUFJO0lBQ0osSUFBSSxLQUFLO1FBQ1AsSUFBSSxhQUFhO1FBQ2pCLElBQUssSUFBSSxZQUFZLElBQUksV0FBVyxJQUNsQyxJQUFJLEtBQUssS0FBSyxPQUFPLEtBQUssS0FBSyxlQUFlLEtBQUssSUFBSSxJQUFJLGFBQWE7WUFDdEUsSUFBSSxlQUFlLElBQUksYUFBYTtZQUNwQyxJQUFJLElBQUksYUFBYSxNQUFNLFdBQVcsT0FBTyxhQUFhO1FBQzVELE9BQU87WUFDTCxJQUFJLGVBQWUsSUFBSSxLQUFLLElBQUk7WUFDaEMsYUFBYTtRQUNmO0lBRUosT0FBTztRQUNMLElBQUksYUFBYSxZQUFZLFdBQVcsYUFBYSxZQUFZO1FBQ2pFLElBQUssSUFBSSxZQUFZLEtBQUssR0FBRyxJQUFLO1lBQ2hDLElBQUksUUFBUTtZQUNaLElBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxXQUFXLElBQzdCLElBQUksS0FBSyxLQUFLLElBQUksT0FBTyxLQUFLLEtBQUssSUFBSTtnQkFDckMsUUFBUTtnQkFDUjtZQUNGO1lBRUYsSUFBSSxPQUFPLE9BQU87UUFDcEI7SUFDRjtJQUVBLE9BQU87QUFDVDtBQUVBLE9BQU8sU0FBUyxDQUFDLFFBQVEsR0FBRyxTQUFTLFNBQVUsR0FBRyxFQUFFLFVBQVUsRUFBRSxRQUFRO0lBQ3RFLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLFlBQVksY0FBYztBQUNyRDtBQUVBLE9BQU8sU0FBUyxDQUFDLE9BQU8sR0FBRyxTQUFTLFFBQVMsR0FBRyxFQUFFLFVBQVUsRUFBRSxRQUFRO0lBQ3BFLE9BQU8scUJBQXFCLElBQUksRUFBRSxLQUFLLFlBQVksVUFBVTtBQUMvRDtBQUVBLE9BQU8sU0FBUyxDQUFDLFdBQVcsR0FBRyxTQUFTLFlBQWEsR0FBRyxFQUFFLFVBQVUsRUFBRSxRQUFRO0lBQzVFLE9BQU8scUJBQXFCLElBQUksRUFBRSxLQUFLLFlBQVksVUFBVTtBQUMvRDtBQUVBLFNBQVMsU0FBVSxHQUFHLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNO0lBQzVDLFNBQVMsT0FBTyxXQUFXO0lBQzNCLE1BQU0sWUFBWSxJQUFJLE1BQU0sR0FBRztJQUMvQixJQUFJLENBQUMsUUFDSCxTQUFTO1NBQ0o7UUFDTCxTQUFTLE9BQU87UUFDaEIsSUFBSSxTQUFTLFdBQ1gsU0FBUztJQUViO0lBRUEsTUFBTSxTQUFTLE9BQU8sTUFBTTtJQUU1QixJQUFJLFNBQVMsU0FBUyxHQUNwQixTQUFTLFNBQVM7SUFFcEIsSUFBSTtJQUNKLElBQUssSUFBSSxHQUFHLElBQUksUUFBUSxFQUFFLEVBQUc7UUFDM0IsTUFBTSxTQUFTLFNBQVMsT0FBTyxNQUFNLENBQUMsSUFBSSxHQUFHLElBQUk7UUFDakQsSUFBSSxZQUFZLFNBQVMsT0FBTztRQUNoQyxHQUFHLENBQUMsU0FBUyxFQUFFLEdBQUc7SUFDcEI7SUFDQSxPQUFPO0FBQ1Q7QUFFQSxTQUFTLFVBQVcsR0FBRyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTTtJQUM3QyxPQUFPLFdBQVcsWUFBWSxRQUFRLElBQUksTUFBTSxHQUFHLFNBQVMsS0FBSyxRQUFRO0FBQzNFO0FBRUEsU0FBUyxXQUFZLEdBQUcsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU07SUFDOUMsT0FBTyxXQUFXLGFBQWEsU0FBUyxLQUFLLFFBQVE7QUFDdkQ7QUFFQSxTQUFTLFlBQWEsR0FBRyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTTtJQUMvQyxPQUFPLFdBQVcsY0FBYyxTQUFTLEtBQUssUUFBUTtBQUN4RDtBQUVBLFNBQVMsVUFBVyxHQUFHLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNO0lBQzdDLE9BQU8sV0FBVyxlQUFlLFFBQVEsSUFBSSxNQUFNLEdBQUcsU0FBUyxLQUFLLFFBQVE7QUFDOUU7QUFFQSxPQUFPLFNBQVMsQ0FBQyxLQUFLLEdBQUcsU0FBUyxNQUFPLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLFFBQVE7SUFDdkUsdUJBQXVCO0lBQ3ZCLElBQUksV0FBVyxXQUFXO1FBQ3hCLFdBQVc7UUFDWCxTQUFTLElBQUksQ0FBQyxNQUFNO1FBQ3BCLFNBQVM7SUFDWCxpQ0FBaUM7SUFDakMsT0FBTyxJQUFJLFdBQVcsYUFBYSxPQUFPLFdBQVcsVUFBVTtRQUM3RCxXQUFXO1FBQ1gsU0FBUyxJQUFJLENBQUMsTUFBTTtRQUNwQixTQUFTO0lBQ1gscURBQXFEO0lBQ3JELE9BQU8sSUFBSSxTQUFTLFNBQVM7UUFDM0IsU0FBUyxXQUFXO1FBQ3BCLElBQUksU0FBUyxTQUFTO1lBQ3BCLFNBQVMsV0FBVztZQUNwQixJQUFJLGFBQWEsV0FBVyxXQUFXO1FBQ3pDLE9BQU87WUFDTCxXQUFXO1lBQ1gsU0FBUztRQUNYO0lBQ0YsT0FDRSxNQUFNLElBQUksTUFDUjtJQUlKLE1BQU0sWUFBWSxJQUFJLENBQUMsTUFBTSxHQUFHO0lBQ2hDLElBQUksV0FBVyxhQUFhLFNBQVMsV0FBVyxTQUFTO0lBRXpELElBQUksQUFBQyxPQUFPLE1BQU0sR0FBRyxLQUFNLENBQUEsU0FBUyxLQUFLLFNBQVMsQ0FBQSxLQUFPLFNBQVMsSUFBSSxDQUFDLE1BQU0sRUFDM0UsTUFBTSxJQUFJLFdBQVc7SUFHdkIsSUFBSSxDQUFDLFVBQVUsV0FBVztJQUUxQixJQUFJLGNBQWM7SUFDbEIsT0FDRSxPQUFRO1FBQ04sS0FBSztZQUNILE9BQU8sU0FBUyxJQUFJLEVBQUUsUUFBUSxRQUFRO1FBRXhDLEtBQUs7UUFDTCxLQUFLO1lBQ0gsT0FBTyxVQUFVLElBQUksRUFBRSxRQUFRLFFBQVE7UUFFekMsS0FBSztRQUNMLEtBQUs7UUFDTCxLQUFLO1lBQ0gsT0FBTyxXQUFXLElBQUksRUFBRSxRQUFRLFFBQVE7UUFFMUMsS0FBSztZQUNILDJEQUEyRDtZQUMzRCxPQUFPLFlBQVksSUFBSSxFQUFFLFFBQVEsUUFBUTtRQUUzQyxLQUFLO1FBQ0wsS0FBSztRQUNMLEtBQUs7UUFDTCxLQUFLO1lBQ0gsT0FBTyxVQUFVLElBQUksRUFBRSxRQUFRLFFBQVE7UUFFekM7WUFDRSxJQUFJLGFBQWEsTUFBTSxJQUFJLFVBQVUsdUJBQXVCO1lBQzVELFdBQVcsQUFBQyxDQUFBLEtBQUssUUFBTyxFQUFHLFdBQVc7WUFDdEMsY0FBYztJQUNsQjtBQUVKO0FBRUEsT0FBTyxTQUFTLENBQUMsTUFBTSxHQUFHLFNBQVM7SUFDakMsT0FBTztRQUNMLE1BQU07UUFDTixNQUFNLE1BQU0sU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLEVBQUU7SUFDdEQ7QUFDRjtBQUVBLFNBQVMsWUFBYSxHQUFHLEVBQUUsS0FBSyxFQUFFLEdBQUc7SUFDbkMsSUFBSSxVQUFVLEtBQUssUUFBUSxJQUFJLE1BQU0sRUFDbkMsT0FBTyxPQUFPLGFBQWEsQ0FBQztTQUU1QixPQUFPLE9BQU8sYUFBYSxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU87QUFFakQ7QUFFQSxTQUFTLFVBQVcsR0FBRyxFQUFFLEtBQUssRUFBRSxHQUFHO0lBQ2pDLE1BQU0sS0FBSyxHQUFHLENBQUMsSUFBSSxNQUFNLEVBQUU7SUFDM0IsTUFBTSxNQUFNLEVBQUU7SUFFZCxJQUFJLElBQUk7SUFDUixNQUFPLElBQUksSUFBSztRQUNkLE1BQU0sWUFBWSxHQUFHLENBQUMsRUFBRTtRQUN4QixJQUFJLFlBQVk7UUFDaEIsSUFBSSxtQkFBbUIsQUFBQyxZQUFZLE9BQ2hDLElBQ0EsQUFBQyxZQUFZLE9BQ1QsSUFDQSxBQUFDLFlBQVksT0FDVCxJQUNBO1FBRVosSUFBSSxJQUFJLG9CQUFvQixLQUFLO1lBQy9CLElBQUksWUFBWSxXQUFXLFlBQVk7WUFFdkMsT0FBUTtnQkFDTixLQUFLO29CQUNILElBQUksWUFBWSxNQUNkLFlBQVk7b0JBRWQ7Z0JBQ0YsS0FBSztvQkFDSCxhQUFhLEdBQUcsQ0FBQyxJQUFJLEVBQUU7b0JBQ3ZCLElBQUksQUFBQyxDQUFBLGFBQWEsSUFBRyxNQUFPLE1BQU07d0JBQ2hDLGdCQUFnQixBQUFDLENBQUEsWUFBWSxJQUFHLEtBQU0sTUFBTyxhQUFhO3dCQUMxRCxJQUFJLGdCQUFnQixNQUNsQixZQUFZO29CQUVoQjtvQkFDQTtnQkFDRixLQUFLO29CQUNILGFBQWEsR0FBRyxDQUFDLElBQUksRUFBRTtvQkFDdkIsWUFBWSxHQUFHLENBQUMsSUFBSSxFQUFFO29CQUN0QixJQUFJLEFBQUMsQ0FBQSxhQUFhLElBQUcsTUFBTyxRQUFRLEFBQUMsQ0FBQSxZQUFZLElBQUcsTUFBTyxNQUFNO3dCQUMvRCxnQkFBZ0IsQUFBQyxDQUFBLFlBQVksR0FBRSxLQUFNLE1BQU0sQUFBQyxDQUFBLGFBQWEsSUFBRyxLQUFNLE1BQU8sWUFBWTt3QkFDckYsSUFBSSxnQkFBZ0IsU0FBVSxDQUFBLGdCQUFnQixVQUFVLGdCQUFnQixNQUFLLEdBQzNFLFlBQVk7b0JBRWhCO29CQUNBO2dCQUNGLEtBQUs7b0JBQ0gsYUFBYSxHQUFHLENBQUMsSUFBSSxFQUFFO29CQUN2QixZQUFZLEdBQUcsQ0FBQyxJQUFJLEVBQUU7b0JBQ3RCLGFBQWEsR0FBRyxDQUFDLElBQUksRUFBRTtvQkFDdkIsSUFBSSxBQUFDLENBQUEsYUFBYSxJQUFHLE1BQU8sUUFBUSxBQUFDLENBQUEsWUFBWSxJQUFHLE1BQU8sUUFBUSxBQUFDLENBQUEsYUFBYSxJQUFHLE1BQU8sTUFBTTt3QkFDL0YsZ0JBQWdCLEFBQUMsQ0FBQSxZQUFZLEdBQUUsS0FBTSxPQUFPLEFBQUMsQ0FBQSxhQUFhLElBQUcsS0FBTSxNQUFNLEFBQUMsQ0FBQSxZQUFZLElBQUcsS0FBTSxNQUFPLGFBQWE7d0JBQ25ILElBQUksZ0JBQWdCLFVBQVUsZ0JBQWdCLFVBQzVDLFlBQVk7b0JBRWhCO1lBQ0o7UUFDRjtRQUVBLElBQUksY0FBYyxNQUFNO1lBQ3RCLG9EQUFvRDtZQUNwRCxvREFBb0Q7WUFDcEQsWUFBWTtZQUNaLG1CQUFtQjtRQUNyQixPQUFPLElBQUksWUFBWSxRQUFRO1lBQzdCLHlDQUF5QztZQUN6QyxhQUFhO1lBQ2IsSUFBSSxJQUFJLENBQUMsY0FBYyxLQUFLLFFBQVE7WUFDcEMsWUFBWSxTQUFTLFlBQVk7UUFDbkM7UUFFQSxJQUFJLElBQUksQ0FBQztRQUNULEtBQUs7SUFDUDtJQUVBLE9BQU8sc0JBQXNCO0FBQy9CO0FBRUEsd0VBQXdFO0FBQ3hFLGlEQUFpRDtBQUNqRCxxQ0FBcUM7QUFDckMsTUFBTSx1QkFBdUI7QUFFN0IsU0FBUyxzQkFBdUIsVUFBVTtJQUN4QyxNQUFNLE1BQU0sV0FBVyxNQUFNO0lBQzdCLElBQUksT0FBTyxzQkFDVCxPQUFPLE9BQU8sWUFBWSxDQUFDLEtBQUssQ0FBQyxRQUFRLFlBQVksc0JBQXNCOztJQUc3RSx3REFBd0Q7SUFDeEQsSUFBSSxNQUFNO0lBQ1YsSUFBSSxJQUFJO0lBQ1IsTUFBTyxJQUFJLElBQ1QsT0FBTyxPQUFPLFlBQVksQ0FBQyxLQUFLLENBQzlCLFFBQ0EsV0FBVyxLQUFLLENBQUMsR0FBRyxLQUFLO0lBRzdCLE9BQU87QUFDVDtBQUVBLFNBQVMsV0FBWSxHQUFHLEVBQUUsS0FBSyxFQUFFLEdBQUc7SUFDbEMsSUFBSSxNQUFNO0lBQ1YsTUFBTSxLQUFLLEdBQUcsQ0FBQyxJQUFJLE1BQU0sRUFBRTtJQUUzQixJQUFLLElBQUksSUFBSSxPQUFPLElBQUksS0FBSyxFQUFFLEVBQzdCLE9BQU8sT0FBTyxZQUFZLENBQUMsR0FBRyxDQUFDLEVBQUUsR0FBRztJQUV0QyxPQUFPO0FBQ1Q7QUFFQSxTQUFTLFlBQWEsR0FBRyxFQUFFLEtBQUssRUFBRSxHQUFHO0lBQ25DLElBQUksTUFBTTtJQUNWLE1BQU0sS0FBSyxHQUFHLENBQUMsSUFBSSxNQUFNLEVBQUU7SUFFM0IsSUFBSyxJQUFJLElBQUksT0FBTyxJQUFJLEtBQUssRUFBRSxFQUM3QixPQUFPLE9BQU8sWUFBWSxDQUFDLEdBQUcsQ0FBQyxFQUFFO0lBRW5DLE9BQU87QUFDVDtBQUVBLFNBQVMsU0FBVSxHQUFHLEVBQUUsS0FBSyxFQUFFLEdBQUc7SUFDaEMsTUFBTSxNQUFNLElBQUksTUFBTTtJQUV0QixJQUFJLENBQUMsU0FBUyxRQUFRLEdBQUcsUUFBUTtJQUNqQyxJQUFJLENBQUMsT0FBTyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU07SUFFeEMsSUFBSSxNQUFNO0lBQ1YsSUFBSyxJQUFJLElBQUksT0FBTyxJQUFJLEtBQUssRUFBRSxFQUM3QixPQUFPLG1CQUFtQixDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7SUFFcEMsT0FBTztBQUNUO0FBRUEsU0FBUyxhQUFjLEdBQUcsRUFBRSxLQUFLLEVBQUUsR0FBRztJQUNwQyxNQUFNLFFBQVEsSUFBSSxLQUFLLENBQUMsT0FBTztJQUMvQixJQUFJLE1BQU07SUFDViw0RUFBNEU7SUFDNUUsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sTUFBTSxHQUFHLEdBQUcsS0FBSyxFQUN6QyxPQUFPLE9BQU8sWUFBWSxDQUFDLEtBQUssQ0FBQyxFQUFFLEdBQUksS0FBSyxDQUFDLElBQUksRUFBRSxHQUFHO0lBRXhELE9BQU87QUFDVDtBQUVBLE9BQU8sU0FBUyxDQUFDLEtBQUssR0FBRyxTQUFTLE1BQU8sS0FBSyxFQUFFLEdBQUc7SUFDakQsTUFBTSxNQUFNLElBQUksQ0FBQyxNQUFNO0lBQ3ZCLFFBQVEsQ0FBQyxDQUFDO0lBQ1YsTUFBTSxRQUFRLFlBQVksTUFBTSxDQUFDLENBQUM7SUFFbEMsSUFBSSxRQUFRLEdBQUc7UUFDYixTQUFTO1FBQ1QsSUFBSSxRQUFRLEdBQUcsUUFBUTtJQUN6QixPQUFPLElBQUksUUFBUSxLQUNqQixRQUFRO0lBR1YsSUFBSSxNQUFNLEdBQUc7UUFDWCxPQUFPO1FBQ1AsSUFBSSxNQUFNLEdBQUcsTUFBTTtJQUNyQixPQUFPLElBQUksTUFBTSxLQUNmLE1BQU07SUFHUixJQUFJLE1BQU0sT0FBTyxNQUFNO0lBRXZCLE1BQU0sU0FBUyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU87SUFDcEMsNENBQTRDO0lBQzVDLE9BQU8sY0FBYyxDQUFDLFFBQVEsT0FBTyxTQUFTO0lBRTlDLE9BQU87QUFDVDtBQUVBOztDQUVDLEdBQ0QsU0FBUyxZQUFhLE1BQU0sRUFBRSxHQUFHLEVBQUUsTUFBTTtJQUN2QyxJQUFJLEFBQUMsU0FBUyxNQUFPLEtBQUssU0FBUyxHQUFHLE1BQU0sSUFBSSxXQUFXO0lBQzNELElBQUksU0FBUyxNQUFNLFFBQVEsTUFBTSxJQUFJLFdBQVc7QUFDbEQ7QUFFQSxPQUFPLFNBQVMsQ0FBQyxVQUFVLEdBQzNCLE9BQU8sU0FBUyxDQUFDLFVBQVUsR0FBRyxTQUFTLFdBQVksTUFBTSxFQUFFLFVBQVUsRUFBRSxRQUFRO0lBQzdFLFNBQVMsV0FBVztJQUNwQixhQUFhLGVBQWU7SUFDNUIsSUFBSSxDQUFDLFVBQVUsWUFBWSxRQUFRLFlBQVksSUFBSSxDQUFDLE1BQU07SUFFMUQsSUFBSSxNQUFNLElBQUksQ0FBQyxPQUFPO0lBQ3RCLElBQUksTUFBTTtJQUNWLElBQUksSUFBSTtJQUNSLE1BQU8sRUFBRSxJQUFJLGNBQWUsQ0FBQSxPQUFPLEtBQUksRUFDckMsT0FBTyxJQUFJLENBQUMsU0FBUyxFQUFFLEdBQUc7SUFHNUIsT0FBTztBQUNUO0FBRUEsT0FBTyxTQUFTLENBQUMsVUFBVSxHQUMzQixPQUFPLFNBQVMsQ0FBQyxVQUFVLEdBQUcsU0FBUyxXQUFZLE1BQU0sRUFBRSxVQUFVLEVBQUUsUUFBUTtJQUM3RSxTQUFTLFdBQVc7SUFDcEIsYUFBYSxlQUFlO0lBQzVCLElBQUksQ0FBQyxVQUNILFlBQVksUUFBUSxZQUFZLElBQUksQ0FBQyxNQUFNO0lBRzdDLElBQUksTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFLFdBQVc7SUFDckMsSUFBSSxNQUFNO0lBQ1YsTUFBTyxhQUFhLEtBQU0sQ0FBQSxPQUFPLEtBQUksRUFDbkMsT0FBTyxJQUFJLENBQUMsU0FBUyxFQUFFLFdBQVcsR0FBRztJQUd2QyxPQUFPO0FBQ1Q7QUFFQSxPQUFPLFNBQVMsQ0FBQyxTQUFTLEdBQzFCLE9BQU8sU0FBUyxDQUFDLFNBQVMsR0FBRyxTQUFTLFVBQVcsTUFBTSxFQUFFLFFBQVE7SUFDL0QsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxVQUFVLFlBQVksUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNO0lBQ2pELE9BQU8sSUFBSSxDQUFDLE9BQU87QUFDckI7QUFFQSxPQUFPLFNBQVMsQ0FBQyxZQUFZLEdBQzdCLE9BQU8sU0FBUyxDQUFDLFlBQVksR0FBRyxTQUFTLGFBQWMsTUFBTSxFQUFFLFFBQVE7SUFDckUsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxVQUFVLFlBQVksUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNO0lBQ2pELE9BQU8sSUFBSSxDQUFDLE9BQU8sR0FBSSxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUk7QUFDN0M7QUFFQSxPQUFPLFNBQVMsQ0FBQyxZQUFZLEdBQzdCLE9BQU8sU0FBUyxDQUFDLFlBQVksR0FBRyxTQUFTLGFBQWMsTUFBTSxFQUFFLFFBQVE7SUFDckUsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxVQUFVLFlBQVksUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNO0lBQ2pELE9BQU8sQUFBQyxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUssSUFBSSxDQUFDLFNBQVMsRUFBRTtBQUMvQztBQUVBLE9BQU8sU0FBUyxDQUFDLFlBQVksR0FDN0IsT0FBTyxTQUFTLENBQUMsWUFBWSxHQUFHLFNBQVMsYUFBYyxNQUFNLEVBQUUsUUFBUTtJQUNyRSxTQUFTLFdBQVc7SUFDcEIsSUFBSSxDQUFDLFVBQVUsWUFBWSxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU07SUFFakQsT0FBTyxBQUFDLENBQUEsQUFBQyxJQUFJLENBQUMsT0FBTyxHQUNoQixJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksSUFDcEIsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLEVBQUUsSUFDdEIsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFHO0FBQzFCO0FBRUEsT0FBTyxTQUFTLENBQUMsWUFBWSxHQUM3QixPQUFPLFNBQVMsQ0FBQyxZQUFZLEdBQUcsU0FBUyxhQUFjLE1BQU0sRUFBRSxRQUFRO0lBQ3JFLFNBQVMsV0FBVztJQUNwQixJQUFJLENBQUMsVUFBVSxZQUFZLFFBQVEsR0FBRyxJQUFJLENBQUMsTUFBTTtJQUVqRCxPQUFPLEFBQUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxZQUNwQixDQUFBLEFBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLEtBQ3JCLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxJQUNyQixJQUFJLENBQUMsU0FBUyxFQUFFLEFBQUQ7QUFDbkI7QUFFQSxPQUFPLFNBQVMsQ0FBQyxlQUFlLEdBQUcsbUJBQW1CLFNBQVMsZ0JBQWlCLE1BQU07SUFDcEYsU0FBUyxXQUFXO0lBQ3BCLGVBQWUsUUFBUTtJQUN2QixNQUFNLFFBQVEsSUFBSSxDQUFDLE9BQU87SUFDMUIsTUFBTSxPQUFPLElBQUksQ0FBQyxTQUFTLEVBQUU7SUFDN0IsSUFBSSxVQUFVLGFBQWEsU0FBUyxXQUNsQyxZQUFZLFFBQVEsSUFBSSxDQUFDLE1BQU0sR0FBRztJQUdwQyxNQUFNLEtBQUssUUFDVCxJQUFJLENBQUMsRUFBRSxPQUFPLEdBQUcsTUFDakIsSUFBSSxDQUFDLEVBQUUsT0FBTyxHQUFHLEtBQUssS0FDdEIsSUFBSSxDQUFDLEVBQUUsT0FBTyxHQUFHLEtBQUs7SUFFeEIsTUFBTSxLQUFLLElBQUksQ0FBQyxFQUFFLE9BQU8sR0FDdkIsSUFBSSxDQUFDLEVBQUUsT0FBTyxHQUFHLE1BQ2pCLElBQUksQ0FBQyxFQUFFLE9BQU8sR0FBRyxLQUFLLEtBQ3RCLE9BQU8sS0FBSztJQUVkLE9BQU8sT0FBTyxNQUFPLENBQUEsT0FBTyxPQUFPLE9BQU8sR0FBRTtBQUM5QztBQUVBLE9BQU8sU0FBUyxDQUFDLGVBQWUsR0FBRyxtQkFBbUIsU0FBUyxnQkFBaUIsTUFBTTtJQUNwRixTQUFTLFdBQVc7SUFDcEIsZUFBZSxRQUFRO0lBQ3ZCLE1BQU0sUUFBUSxJQUFJLENBQUMsT0FBTztJQUMxQixNQUFNLE9BQU8sSUFBSSxDQUFDLFNBQVMsRUFBRTtJQUM3QixJQUFJLFVBQVUsYUFBYSxTQUFTLFdBQ2xDLFlBQVksUUFBUSxJQUFJLENBQUMsTUFBTSxHQUFHO0lBR3BDLE1BQU0sS0FBSyxRQUFRLEtBQUssS0FDdEIsSUFBSSxDQUFDLEVBQUUsT0FBTyxHQUFHLEtBQUssS0FDdEIsSUFBSSxDQUFDLEVBQUUsT0FBTyxHQUFHLE1BQ2pCLElBQUksQ0FBQyxFQUFFLE9BQU87SUFFaEIsTUFBTSxLQUFLLElBQUksQ0FBQyxFQUFFLE9BQU8sR0FBRyxLQUFLLEtBQy9CLElBQUksQ0FBQyxFQUFFLE9BQU8sR0FBRyxLQUFLLEtBQ3RCLElBQUksQ0FBQyxFQUFFLE9BQU8sR0FBRyxNQUNqQjtJQUVGLE9BQU8sQUFBQyxDQUFBLE9BQU8sT0FBTyxPQUFPLEdBQUUsSUFBSyxPQUFPO0FBQzdDO0FBRUEsT0FBTyxTQUFTLENBQUMsU0FBUyxHQUFHLFNBQVMsVUFBVyxNQUFNLEVBQUUsVUFBVSxFQUFFLFFBQVE7SUFDM0UsU0FBUyxXQUFXO0lBQ3BCLGFBQWEsZUFBZTtJQUM1QixJQUFJLENBQUMsVUFBVSxZQUFZLFFBQVEsWUFBWSxJQUFJLENBQUMsTUFBTTtJQUUxRCxJQUFJLE1BQU0sSUFBSSxDQUFDLE9BQU87SUFDdEIsSUFBSSxNQUFNO0lBQ1YsSUFBSSxJQUFJO0lBQ1IsTUFBTyxFQUFFLElBQUksY0FBZSxDQUFBLE9BQU8sS0FBSSxFQUNyQyxPQUFPLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FBRztJQUU1QixPQUFPO0lBRVAsSUFBSSxPQUFPLEtBQUssT0FBTyxLQUFLLEdBQUcsQ0FBQyxHQUFHLElBQUk7SUFFdkMsT0FBTztBQUNUO0FBRUEsT0FBTyxTQUFTLENBQUMsU0FBUyxHQUFHLFNBQVMsVUFBVyxNQUFNLEVBQUUsVUFBVSxFQUFFLFFBQVE7SUFDM0UsU0FBUyxXQUFXO0lBQ3BCLGFBQWEsZUFBZTtJQUM1QixJQUFJLENBQUMsVUFBVSxZQUFZLFFBQVEsWUFBWSxJQUFJLENBQUMsTUFBTTtJQUUxRCxJQUFJLElBQUk7SUFDUixJQUFJLE1BQU07SUFDVixJQUFJLE1BQU0sSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFO0lBQzVCLE1BQU8sSUFBSSxLQUFNLENBQUEsT0FBTyxLQUFJLEVBQzFCLE9BQU8sSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLEdBQUc7SUFFOUIsT0FBTztJQUVQLElBQUksT0FBTyxLQUFLLE9BQU8sS0FBSyxHQUFHLENBQUMsR0FBRyxJQUFJO0lBRXZDLE9BQU87QUFDVDtBQUVBLE9BQU8sU0FBUyxDQUFDLFFBQVEsR0FBRyxTQUFTLFNBQVUsTUFBTSxFQUFFLFFBQVE7SUFDN0QsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxVQUFVLFlBQVksUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNO0lBQ2pELElBQUksQ0FBRSxDQUFBLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBRyxHQUFJLE9BQVEsSUFBSSxDQUFDLE9BQU87SUFDaEQsT0FBUSxBQUFDLENBQUEsT0FBTyxJQUFJLENBQUMsT0FBTyxHQUFHLENBQUEsSUFBSztBQUN0QztBQUVBLE9BQU8sU0FBUyxDQUFDLFdBQVcsR0FBRyxTQUFTLFlBQWEsTUFBTSxFQUFFLFFBQVE7SUFDbkUsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxVQUFVLFlBQVksUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNO0lBQ2pELE1BQU0sTUFBTSxJQUFJLENBQUMsT0FBTyxHQUFJLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSTtJQUNoRCxPQUFPLEFBQUMsTUFBTSxTQUFVLE1BQU0sYUFBYTtBQUM3QztBQUVBLE9BQU8sU0FBUyxDQUFDLFdBQVcsR0FBRyxTQUFTLFlBQWEsTUFBTSxFQUFFLFFBQVE7SUFDbkUsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxVQUFVLFlBQVksUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNO0lBQ2pELE1BQU0sTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFLEdBQUksSUFBSSxDQUFDLE9BQU8sSUFBSTtJQUNoRCxPQUFPLEFBQUMsTUFBTSxTQUFVLE1BQU0sYUFBYTtBQUM3QztBQUVBLE9BQU8sU0FBUyxDQUFDLFdBQVcsR0FBRyxTQUFTLFlBQWEsTUFBTSxFQUFFLFFBQVE7SUFDbkUsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxVQUFVLFlBQVksUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNO0lBRWpELE9BQU8sQUFBQyxJQUFJLENBQUMsT0FBTyxHQUNqQixJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksSUFDcEIsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLEtBQ3BCLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSTtBQUN6QjtBQUVBLE9BQU8sU0FBUyxDQUFDLFdBQVcsR0FBRyxTQUFTLFlBQWEsTUFBTSxFQUFFLFFBQVE7SUFDbkUsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxVQUFVLFlBQVksUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNO0lBRWpELE9BQU8sQUFBQyxJQUFJLENBQUMsT0FBTyxJQUFJLEtBQ3JCLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxLQUNwQixJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksSUFDcEIsSUFBSSxDQUFDLFNBQVMsRUFBRTtBQUNyQjtBQUVBLE9BQU8sU0FBUyxDQUFDLGNBQWMsR0FBRyxtQkFBbUIsU0FBUyxlQUFnQixNQUFNO0lBQ2xGLFNBQVMsV0FBVztJQUNwQixlQUFlLFFBQVE7SUFDdkIsTUFBTSxRQUFRLElBQUksQ0FBQyxPQUFPO0lBQzFCLE1BQU0sT0FBTyxJQUFJLENBQUMsU0FBUyxFQUFFO0lBQzdCLElBQUksVUFBVSxhQUFhLFNBQVMsV0FDbEMsWUFBWSxRQUFRLElBQUksQ0FBQyxNQUFNLEdBQUc7SUFHcEMsTUFBTSxNQUFNLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FDMUIsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFHLE1BQ25CLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FBRyxLQUFLLEtBQ3ZCLENBQUEsUUFBUSxHQUFJLFdBQVc7SUFBZDtJQUVaLE9BQU8sQUFBQyxDQUFBLE9BQU8sUUFBUSxPQUFPLEdBQUUsSUFDOUIsT0FBTyxRQUNQLElBQUksQ0FBQyxFQUFFLE9BQU8sR0FBRyxNQUNqQixJQUFJLENBQUMsRUFBRSxPQUFPLEdBQUcsS0FBSyxLQUN0QixJQUFJLENBQUMsRUFBRSxPQUFPLEdBQUcsS0FBSztBQUMxQjtBQUVBLE9BQU8sU0FBUyxDQUFDLGNBQWMsR0FBRyxtQkFBbUIsU0FBUyxlQUFnQixNQUFNO0lBQ2xGLFNBQVMsV0FBVztJQUNwQixlQUFlLFFBQVE7SUFDdkIsTUFBTSxRQUFRLElBQUksQ0FBQyxPQUFPO0lBQzFCLE1BQU0sT0FBTyxJQUFJLENBQUMsU0FBUyxFQUFFO0lBQzdCLElBQUksVUFBVSxhQUFhLFNBQVMsV0FDbEMsWUFBWSxRQUFRLElBQUksQ0FBQyxNQUFNLEdBQUc7SUFHcEMsTUFBTSxNQUFNLEFBQUMsQ0FBQSxTQUFTLEVBQUMsSUFBSyxXQUFXO0lBQ3JDLElBQUksQ0FBQyxFQUFFLE9BQU8sR0FBRyxLQUFLLEtBQ3RCLElBQUksQ0FBQyxFQUFFLE9BQU8sR0FBRyxNQUNqQixJQUFJLENBQUMsRUFBRSxPQUFPO0lBRWhCLE9BQU8sQUFBQyxDQUFBLE9BQU8sUUFBUSxPQUFPLEdBQUUsSUFDOUIsT0FBTyxJQUFJLENBQUMsRUFBRSxPQUFPLEdBQUcsS0FBSyxLQUM3QixJQUFJLENBQUMsRUFBRSxPQUFPLEdBQUcsS0FBSyxLQUN0QixJQUFJLENBQUMsRUFBRSxPQUFPLEdBQUcsTUFDakI7QUFDSjtBQUVBLE9BQU8sU0FBUyxDQUFDLFdBQVcsR0FBRyxTQUFTLFlBQWEsTUFBTSxFQUFFLFFBQVE7SUFDbkUsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxVQUFVLFlBQVksUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNO0lBQ2pELE9BQU8sUUFBUSxJQUFJLENBQUMsSUFBSSxFQUFFLFFBQVEsTUFBTSxJQUFJO0FBQzlDO0FBRUEsT0FBTyxTQUFTLENBQUMsV0FBVyxHQUFHLFNBQVMsWUFBYSxNQUFNLEVBQUUsUUFBUTtJQUNuRSxTQUFTLFdBQVc7SUFDcEIsSUFBSSxDQUFDLFVBQVUsWUFBWSxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU07SUFDakQsT0FBTyxRQUFRLElBQUksQ0FBQyxJQUFJLEVBQUUsUUFBUSxPQUFPLElBQUk7QUFDL0M7QUFFQSxPQUFPLFNBQVMsQ0FBQyxZQUFZLEdBQUcsU0FBUyxhQUFjLE1BQU0sRUFBRSxRQUFRO0lBQ3JFLFNBQVMsV0FBVztJQUNwQixJQUFJLENBQUMsVUFBVSxZQUFZLFFBQVEsR0FBRyxJQUFJLENBQUMsTUFBTTtJQUNqRCxPQUFPLFFBQVEsSUFBSSxDQUFDLElBQUksRUFBRSxRQUFRLE1BQU0sSUFBSTtBQUM5QztBQUVBLE9BQU8sU0FBUyxDQUFDLFlBQVksR0FBRyxTQUFTLGFBQWMsTUFBTSxFQUFFLFFBQVE7SUFDckUsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxVQUFVLFlBQVksUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNO0lBQ2pELE9BQU8sUUFBUSxJQUFJLENBQUMsSUFBSSxFQUFFLFFBQVEsT0FBTyxJQUFJO0FBQy9DO0FBRUEsU0FBUyxTQUFVLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRztJQUNsRCxJQUFJLENBQUMsT0FBTyxRQUFRLENBQUMsTUFBTSxNQUFNLElBQUksVUFBVTtJQUMvQyxJQUFJLFFBQVEsT0FBTyxRQUFRLEtBQUssTUFBTSxJQUFJLFdBQVc7SUFDckQsSUFBSSxTQUFTLE1BQU0sSUFBSSxNQUFNLEVBQUUsTUFBTSxJQUFJLFdBQVc7QUFDdEQ7QUFFQSxPQUFPLFNBQVMsQ0FBQyxXQUFXLEdBQzVCLE9BQU8sU0FBUyxDQUFDLFdBQVcsR0FBRyxTQUFTLFlBQWEsS0FBSyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsUUFBUTtJQUN0RixRQUFRLENBQUM7SUFDVCxTQUFTLFdBQVc7SUFDcEIsYUFBYSxlQUFlO0lBQzVCLElBQUksQ0FBQyxVQUFVO1FBQ2IsTUFBTSxXQUFXLEtBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxjQUFjO1FBQy9DLFNBQVMsSUFBSSxFQUFFLE9BQU8sUUFBUSxZQUFZLFVBQVU7SUFDdEQ7SUFFQSxJQUFJLE1BQU07SUFDVixJQUFJLElBQUk7SUFDUixJQUFJLENBQUMsT0FBTyxHQUFHLFFBQVE7SUFDdkIsTUFBTyxFQUFFLElBQUksY0FBZSxDQUFBLE9BQU8sS0FBSSxFQUNyQyxJQUFJLENBQUMsU0FBUyxFQUFFLEdBQUcsQUFBQyxRQUFRLE1BQU87SUFHckMsT0FBTyxTQUFTO0FBQ2xCO0FBRUEsT0FBTyxTQUFTLENBQUMsV0FBVyxHQUM1QixPQUFPLFNBQVMsQ0FBQyxXQUFXLEdBQUcsU0FBUyxZQUFhLEtBQUssRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLFFBQVE7SUFDdEYsUUFBUSxDQUFDO0lBQ1QsU0FBUyxXQUFXO0lBQ3BCLGFBQWEsZUFBZTtJQUM1QixJQUFJLENBQUMsVUFBVTtRQUNiLE1BQU0sV0FBVyxLQUFLLEdBQUcsQ0FBQyxHQUFHLElBQUksY0FBYztRQUMvQyxTQUFTLElBQUksRUFBRSxPQUFPLFFBQVEsWUFBWSxVQUFVO0lBQ3REO0lBRUEsSUFBSSxJQUFJLGFBQWE7SUFDckIsSUFBSSxNQUFNO0lBQ1YsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFHLFFBQVE7SUFDM0IsTUFBTyxFQUFFLEtBQUssS0FBTSxDQUFBLE9BQU8sS0FBSSxFQUM3QixJQUFJLENBQUMsU0FBUyxFQUFFLEdBQUcsQUFBQyxRQUFRLE1BQU87SUFHckMsT0FBTyxTQUFTO0FBQ2xCO0FBRUEsT0FBTyxTQUFTLENBQUMsVUFBVSxHQUMzQixPQUFPLFNBQVMsQ0FBQyxVQUFVLEdBQUcsU0FBUyxXQUFZLEtBQUssRUFBRSxNQUFNLEVBQUUsUUFBUTtJQUN4RSxRQUFRLENBQUM7SUFDVCxTQUFTLFdBQVc7SUFDcEIsSUFBSSxDQUFDLFVBQVUsU0FBUyxJQUFJLEVBQUUsT0FBTyxRQUFRLEdBQUcsTUFBTTtJQUN0RCxJQUFJLENBQUMsT0FBTyxHQUFJLFFBQVE7SUFDeEIsT0FBTyxTQUFTO0FBQ2xCO0FBRUEsT0FBTyxTQUFTLENBQUMsYUFBYSxHQUM5QixPQUFPLFNBQVMsQ0FBQyxhQUFhLEdBQUcsU0FBUyxjQUFlLEtBQUssRUFBRSxNQUFNLEVBQUUsUUFBUTtJQUM5RSxRQUFRLENBQUM7SUFDVCxTQUFTLFdBQVc7SUFDcEIsSUFBSSxDQUFDLFVBQVUsU0FBUyxJQUFJLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtJQUN4RCxJQUFJLENBQUMsT0FBTyxHQUFJLFFBQVE7SUFDeEIsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFJLFVBQVU7SUFDOUIsT0FBTyxTQUFTO0FBQ2xCO0FBRUEsT0FBTyxTQUFTLENBQUMsYUFBYSxHQUM5QixPQUFPLFNBQVMsQ0FBQyxhQUFhLEdBQUcsU0FBUyxjQUFlLEtBQUssRUFBRSxNQUFNLEVBQUUsUUFBUTtJQUM5RSxRQUFRLENBQUM7SUFDVCxTQUFTLFdBQVc7SUFDcEIsSUFBSSxDQUFDLFVBQVUsU0FBUyxJQUFJLEVBQUUsT0FBTyxRQUFRLEdBQUcsUUFBUTtJQUN4RCxJQUFJLENBQUMsT0FBTyxHQUFJLFVBQVU7SUFDMUIsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFJLFFBQVE7SUFDNUIsT0FBTyxTQUFTO0FBQ2xCO0FBRUEsT0FBTyxTQUFTLENBQUMsYUFBYSxHQUM5QixPQUFPLFNBQVMsQ0FBQyxhQUFhLEdBQUcsU0FBUyxjQUFlLEtBQUssRUFBRSxNQUFNLEVBQUUsUUFBUTtJQUM5RSxRQUFRLENBQUM7SUFDVCxTQUFTLFdBQVc7SUFDcEIsSUFBSSxDQUFDLFVBQVUsU0FBUyxJQUFJLEVBQUUsT0FBTyxRQUFRLEdBQUcsWUFBWTtJQUM1RCxJQUFJLENBQUMsU0FBUyxFQUFFLEdBQUksVUFBVTtJQUM5QixJQUFJLENBQUMsU0FBUyxFQUFFLEdBQUksVUFBVTtJQUM5QixJQUFJLENBQUMsU0FBUyxFQUFFLEdBQUksVUFBVTtJQUM5QixJQUFJLENBQUMsT0FBTyxHQUFJLFFBQVE7SUFDeEIsT0FBTyxTQUFTO0FBQ2xCO0FBRUEsT0FBTyxTQUFTLENBQUMsYUFBYSxHQUM5QixPQUFPLFNBQVMsQ0FBQyxhQUFhLEdBQUcsU0FBUyxjQUFlLEtBQUssRUFBRSxNQUFNLEVBQUUsUUFBUTtJQUM5RSxRQUFRLENBQUM7SUFDVCxTQUFTLFdBQVc7SUFDcEIsSUFBSSxDQUFDLFVBQVUsU0FBUyxJQUFJLEVBQUUsT0FBTyxRQUFRLEdBQUcsWUFBWTtJQUM1RCxJQUFJLENBQUMsT0FBTyxHQUFJLFVBQVU7SUFDMUIsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFJLFVBQVU7SUFDOUIsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFJLFVBQVU7SUFDOUIsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFJLFFBQVE7SUFDNUIsT0FBTyxTQUFTO0FBQ2xCO0FBRUEsU0FBUyxlQUFnQixHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRztJQUNuRCxXQUFXLE9BQU8sS0FBSyxLQUFLLEtBQUssUUFBUTtJQUV6QyxJQUFJLEtBQUssT0FBTyxRQUFRLE9BQU87SUFDL0IsR0FBRyxDQUFDLFNBQVMsR0FBRztJQUNoQixLQUFLLE1BQU07SUFDWCxHQUFHLENBQUMsU0FBUyxHQUFHO0lBQ2hCLEtBQUssTUFBTTtJQUNYLEdBQUcsQ0FBQyxTQUFTLEdBQUc7SUFDaEIsS0FBSyxNQUFNO0lBQ1gsR0FBRyxDQUFDLFNBQVMsR0FBRztJQUNoQixJQUFJLEtBQUssT0FBTyxTQUFTLE9BQU8sTUFBTSxPQUFPO0lBQzdDLEdBQUcsQ0FBQyxTQUFTLEdBQUc7SUFDaEIsS0FBSyxNQUFNO0lBQ1gsR0FBRyxDQUFDLFNBQVMsR0FBRztJQUNoQixLQUFLLE1BQU07SUFDWCxHQUFHLENBQUMsU0FBUyxHQUFHO0lBQ2hCLEtBQUssTUFBTTtJQUNYLEdBQUcsQ0FBQyxTQUFTLEdBQUc7SUFDaEIsT0FBTztBQUNUO0FBRUEsU0FBUyxlQUFnQixHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRztJQUNuRCxXQUFXLE9BQU8sS0FBSyxLQUFLLEtBQUssUUFBUTtJQUV6QyxJQUFJLEtBQUssT0FBTyxRQUFRLE9BQU87SUFDL0IsR0FBRyxDQUFDLFNBQVMsRUFBRSxHQUFHO0lBQ2xCLEtBQUssTUFBTTtJQUNYLEdBQUcsQ0FBQyxTQUFTLEVBQUUsR0FBRztJQUNsQixLQUFLLE1BQU07SUFDWCxHQUFHLENBQUMsU0FBUyxFQUFFLEdBQUc7SUFDbEIsS0FBSyxNQUFNO0lBQ1gsR0FBRyxDQUFDLFNBQVMsRUFBRSxHQUFHO0lBQ2xCLElBQUksS0FBSyxPQUFPLFNBQVMsT0FBTyxNQUFNLE9BQU87SUFDN0MsR0FBRyxDQUFDLFNBQVMsRUFBRSxHQUFHO0lBQ2xCLEtBQUssTUFBTTtJQUNYLEdBQUcsQ0FBQyxTQUFTLEVBQUUsR0FBRztJQUNsQixLQUFLLE1BQU07SUFDWCxHQUFHLENBQUMsU0FBUyxFQUFFLEdBQUc7SUFDbEIsS0FBSyxNQUFNO0lBQ1gsR0FBRyxDQUFDLE9BQU8sR0FBRztJQUNkLE9BQU8sU0FBUztBQUNsQjtBQUVBLE9BQU8sU0FBUyxDQUFDLGdCQUFnQixHQUFHLG1CQUFtQixTQUFTLGlCQUFrQixLQUFLLEVBQUUsU0FBUyxDQUFDO0lBQ2pHLE9BQU8sZUFBZSxJQUFJLEVBQUUsT0FBTyxRQUFRLE9BQU8sSUFBSSxPQUFPO0FBQy9EO0FBRUEsT0FBTyxTQUFTLENBQUMsZ0JBQWdCLEdBQUcsbUJBQW1CLFNBQVMsaUJBQWtCLEtBQUssRUFBRSxTQUFTLENBQUM7SUFDakcsT0FBTyxlQUFlLElBQUksRUFBRSxPQUFPLFFBQVEsT0FBTyxJQUFJLE9BQU87QUFDL0Q7QUFFQSxPQUFPLFNBQVMsQ0FBQyxVQUFVLEdBQUcsU0FBUyxXQUFZLEtBQUssRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLFFBQVE7SUFDcEYsUUFBUSxDQUFDO0lBQ1QsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxVQUFVO1FBQ2IsTUFBTSxRQUFRLEtBQUssR0FBRyxDQUFDLEdBQUcsQUFBQyxJQUFJLGFBQWM7UUFFN0MsU0FBUyxJQUFJLEVBQUUsT0FBTyxRQUFRLFlBQVksUUFBUSxHQUFHLENBQUM7SUFDeEQ7SUFFQSxJQUFJLElBQUk7SUFDUixJQUFJLE1BQU07SUFDVixJQUFJLE1BQU07SUFDVixJQUFJLENBQUMsT0FBTyxHQUFHLFFBQVE7SUFDdkIsTUFBTyxFQUFFLElBQUksY0FBZSxDQUFBLE9BQU8sS0FBSSxFQUFJO1FBQ3pDLElBQUksUUFBUSxLQUFLLFFBQVEsS0FBSyxJQUFJLENBQUMsU0FBUyxJQUFJLEVBQUUsS0FBSyxHQUNyRCxNQUFNO1FBRVIsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFHLEFBQUMsQ0FBQSxBQUFDLFFBQVEsT0FBUSxDQUFBLElBQUssTUFBTTtJQUNsRDtJQUVBLE9BQU8sU0FBUztBQUNsQjtBQUVBLE9BQU8sU0FBUyxDQUFDLFVBQVUsR0FBRyxTQUFTLFdBQVksS0FBSyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsUUFBUTtJQUNwRixRQUFRLENBQUM7SUFDVCxTQUFTLFdBQVc7SUFDcEIsSUFBSSxDQUFDLFVBQVU7UUFDYixNQUFNLFFBQVEsS0FBSyxHQUFHLENBQUMsR0FBRyxBQUFDLElBQUksYUFBYztRQUU3QyxTQUFTLElBQUksRUFBRSxPQUFPLFFBQVEsWUFBWSxRQUFRLEdBQUcsQ0FBQztJQUN4RDtJQUVBLElBQUksSUFBSSxhQUFhO0lBQ3JCLElBQUksTUFBTTtJQUNWLElBQUksTUFBTTtJQUNWLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FBRyxRQUFRO0lBQzNCLE1BQU8sRUFBRSxLQUFLLEtBQU0sQ0FBQSxPQUFPLEtBQUksRUFBSTtRQUNqQyxJQUFJLFFBQVEsS0FBSyxRQUFRLEtBQUssSUFBSSxDQUFDLFNBQVMsSUFBSSxFQUFFLEtBQUssR0FDckQsTUFBTTtRQUVSLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FBRyxBQUFDLENBQUEsQUFBQyxRQUFRLE9BQVEsQ0FBQSxJQUFLLE1BQU07SUFDbEQ7SUFFQSxPQUFPLFNBQVM7QUFDbEI7QUFFQSxPQUFPLFNBQVMsQ0FBQyxTQUFTLEdBQUcsU0FBUyxVQUFXLEtBQUssRUFBRSxNQUFNLEVBQUUsUUFBUTtJQUN0RSxRQUFRLENBQUM7SUFDVCxTQUFTLFdBQVc7SUFDcEIsSUFBSSxDQUFDLFVBQVUsU0FBUyxJQUFJLEVBQUUsT0FBTyxRQUFRLEdBQUcsTUFBTTtJQUN0RCxJQUFJLFFBQVEsR0FBRyxRQUFRLE9BQU8sUUFBUTtJQUN0QyxJQUFJLENBQUMsT0FBTyxHQUFJLFFBQVE7SUFDeEIsT0FBTyxTQUFTO0FBQ2xCO0FBRUEsT0FBTyxTQUFTLENBQUMsWUFBWSxHQUFHLFNBQVMsYUFBYyxLQUFLLEVBQUUsTUFBTSxFQUFFLFFBQVE7SUFDNUUsUUFBUSxDQUFDO0lBQ1QsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxVQUFVLFNBQVMsSUFBSSxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVE7SUFDeEQsSUFBSSxDQUFDLE9BQU8sR0FBSSxRQUFRO0lBQ3hCLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FBSSxVQUFVO0lBQzlCLE9BQU8sU0FBUztBQUNsQjtBQUVBLE9BQU8sU0FBUyxDQUFDLFlBQVksR0FBRyxTQUFTLGFBQWMsS0FBSyxFQUFFLE1BQU0sRUFBRSxRQUFRO0lBQzVFLFFBQVEsQ0FBQztJQUNULFNBQVMsV0FBVztJQUNwQixJQUFJLENBQUMsVUFBVSxTQUFTLElBQUksRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRO0lBQ3hELElBQUksQ0FBQyxPQUFPLEdBQUksVUFBVTtJQUMxQixJQUFJLENBQUMsU0FBUyxFQUFFLEdBQUksUUFBUTtJQUM1QixPQUFPLFNBQVM7QUFDbEI7QUFFQSxPQUFPLFNBQVMsQ0FBQyxZQUFZLEdBQUcsU0FBUyxhQUFjLEtBQUssRUFBRSxNQUFNLEVBQUUsUUFBUTtJQUM1RSxRQUFRLENBQUM7SUFDVCxTQUFTLFdBQVc7SUFDcEIsSUFBSSxDQUFDLFVBQVUsU0FBUyxJQUFJLEVBQUUsT0FBTyxRQUFRLEdBQUcsWUFBWTtJQUM1RCxJQUFJLENBQUMsT0FBTyxHQUFJLFFBQVE7SUFDeEIsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFJLFVBQVU7SUFDOUIsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFJLFVBQVU7SUFDOUIsSUFBSSxDQUFDLFNBQVMsRUFBRSxHQUFJLFVBQVU7SUFDOUIsT0FBTyxTQUFTO0FBQ2xCO0FBRUEsT0FBTyxTQUFTLENBQUMsWUFBWSxHQUFHLFNBQVMsYUFBYyxLQUFLLEVBQUUsTUFBTSxFQUFFLFFBQVE7SUFDNUUsUUFBUSxDQUFDO0lBQ1QsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxVQUFVLFNBQVMsSUFBSSxFQUFFLE9BQU8sUUFBUSxHQUFHLFlBQVk7SUFDNUQsSUFBSSxRQUFRLEdBQUcsUUFBUSxhQUFhLFFBQVE7SUFDNUMsSUFBSSxDQUFDLE9BQU8sR0FBSSxVQUFVO0lBQzFCLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FBSSxVQUFVO0lBQzlCLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FBSSxVQUFVO0lBQzlCLElBQUksQ0FBQyxTQUFTLEVBQUUsR0FBSSxRQUFRO0lBQzVCLE9BQU8sU0FBUztBQUNsQjtBQUVBLE9BQU8sU0FBUyxDQUFDLGVBQWUsR0FBRyxtQkFBbUIsU0FBUyxnQkFBaUIsS0FBSyxFQUFFLFNBQVMsQ0FBQztJQUMvRixPQUFPLGVBQWUsSUFBSSxFQUFFLE9BQU8sUUFBUSxDQUFDLE9BQU8sdUJBQXVCLE9BQU87QUFDbkY7QUFFQSxPQUFPLFNBQVMsQ0FBQyxlQUFlLEdBQUcsbUJBQW1CLFNBQVMsZ0JBQWlCLEtBQUssRUFBRSxTQUFTLENBQUM7SUFDL0YsT0FBTyxlQUFlLElBQUksRUFBRSxPQUFPLFFBQVEsQ0FBQyxPQUFPLHVCQUF1QixPQUFPO0FBQ25GO0FBRUEsU0FBUyxhQUFjLEdBQUcsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRztJQUN0RCxJQUFJLFNBQVMsTUFBTSxJQUFJLE1BQU0sRUFBRSxNQUFNLElBQUksV0FBVztJQUNwRCxJQUFJLFNBQVMsR0FBRyxNQUFNLElBQUksV0FBVztBQUN2QztBQUVBLFNBQVMsV0FBWSxHQUFHLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsUUFBUTtJQUM3RCxRQUFRLENBQUM7SUFDVCxTQUFTLFdBQVc7SUFDcEIsSUFBSSxDQUFDLFVBQ0gsYUFBYSxLQUFLLE9BQU8sUUFBUSxHQUFHLHdCQUF3QjtJQUU5RCxRQUFRLEtBQUssQ0FBQyxLQUFLLE9BQU8sUUFBUSxjQUFjLElBQUk7SUFDcEQsT0FBTyxTQUFTO0FBQ2xCO0FBRUEsT0FBTyxTQUFTLENBQUMsWUFBWSxHQUFHLFNBQVMsYUFBYyxLQUFLLEVBQUUsTUFBTSxFQUFFLFFBQVE7SUFDNUUsT0FBTyxXQUFXLElBQUksRUFBRSxPQUFPLFFBQVEsTUFBTTtBQUMvQztBQUVBLE9BQU8sU0FBUyxDQUFDLFlBQVksR0FBRyxTQUFTLGFBQWMsS0FBSyxFQUFFLE1BQU0sRUFBRSxRQUFRO0lBQzVFLE9BQU8sV0FBVyxJQUFJLEVBQUUsT0FBTyxRQUFRLE9BQU87QUFDaEQ7QUFFQSxTQUFTLFlBQWEsR0FBRyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLFFBQVE7SUFDOUQsUUFBUSxDQUFDO0lBQ1QsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxVQUNILGFBQWEsS0FBSyxPQUFPLFFBQVEsR0FBRyx5QkFBeUI7SUFFL0QsUUFBUSxLQUFLLENBQUMsS0FBSyxPQUFPLFFBQVEsY0FBYyxJQUFJO0lBQ3BELE9BQU8sU0FBUztBQUNsQjtBQUVBLE9BQU8sU0FBUyxDQUFDLGFBQWEsR0FBRyxTQUFTLGNBQWUsS0FBSyxFQUFFLE1BQU0sRUFBRSxRQUFRO0lBQzlFLE9BQU8sWUFBWSxJQUFJLEVBQUUsT0FBTyxRQUFRLE1BQU07QUFDaEQ7QUFFQSxPQUFPLFNBQVMsQ0FBQyxhQUFhLEdBQUcsU0FBUyxjQUFlLEtBQUssRUFBRSxNQUFNLEVBQUUsUUFBUTtJQUM5RSxPQUFPLFlBQVksSUFBSSxFQUFFLE9BQU8sUUFBUSxPQUFPO0FBQ2pEO0FBRUEsNEVBQTRFO0FBQzVFLE9BQU8sU0FBUyxDQUFDLElBQUksR0FBRyxTQUFTLEtBQU0sTUFBTSxFQUFFLFdBQVcsRUFBRSxLQUFLLEVBQUUsR0FBRztJQUNwRSxJQUFJLENBQUMsT0FBTyxRQUFRLENBQUMsU0FBUyxNQUFNLElBQUksVUFBVTtJQUNsRCxJQUFJLENBQUMsT0FBTyxRQUFRO0lBQ3BCLElBQUksQ0FBQyxPQUFPLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxNQUFNO0lBQ3hDLElBQUksZUFBZSxPQUFPLE1BQU0sRUFBRSxjQUFjLE9BQU8sTUFBTTtJQUM3RCxJQUFJLENBQUMsYUFBYSxjQUFjO0lBQ2hDLElBQUksTUFBTSxLQUFLLE1BQU0sT0FBTyxNQUFNO0lBRWxDLDJCQUEyQjtJQUMzQixJQUFJLFFBQVEsT0FBTyxPQUFPO0lBQzFCLElBQUksT0FBTyxNQUFNLEtBQUssS0FBSyxJQUFJLENBQUMsTUFBTSxLQUFLLEdBQUcsT0FBTztJQUVyRCx5QkFBeUI7SUFDekIsSUFBSSxjQUFjLEdBQ2hCLE1BQU0sSUFBSSxXQUFXO0lBRXZCLElBQUksUUFBUSxLQUFLLFNBQVMsSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLElBQUksV0FBVztJQUM1RCxJQUFJLE1BQU0sR0FBRyxNQUFNLElBQUksV0FBVztJQUVsQyxjQUFjO0lBQ2QsSUFBSSxNQUFNLElBQUksQ0FBQyxNQUFNLEVBQUUsTUFBTSxJQUFJLENBQUMsTUFBTTtJQUN4QyxJQUFJLE9BQU8sTUFBTSxHQUFHLGNBQWMsTUFBTSxPQUN0QyxNQUFNLE9BQU8sTUFBTSxHQUFHLGNBQWM7SUFHdEMsTUFBTSxNQUFNLE1BQU07SUFFbEIsSUFBSSxJQUFJLEtBQUssVUFBVSxPQUFPLFdBQVcsU0FBUyxDQUFDLFVBQVUsS0FBSyxZQUNoRSxpREFBaUQ7SUFDakQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLE9BQU87U0FFcEMsV0FBVyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FDM0IsUUFDQSxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sTUFDckI7SUFJSixPQUFPO0FBQ1Q7QUFFQSxTQUFTO0FBQ1QsMENBQTBDO0FBQzFDLDBDQUEwQztBQUMxQyxzREFBc0Q7QUFDdEQsT0FBTyxTQUFTLENBQUMsSUFBSSxHQUFHLFNBQVMsS0FBTSxHQUFHLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxRQUFRO0lBQzlELHVCQUF1QjtJQUN2QixJQUFJLE9BQU8sUUFBUSxVQUFVO1FBQzNCLElBQUksT0FBTyxVQUFVLFVBQVU7WUFDN0IsV0FBVztZQUNYLFFBQVE7WUFDUixNQUFNLElBQUksQ0FBQyxNQUFNO1FBQ25CLE9BQU8sSUFBSSxPQUFPLFFBQVEsVUFBVTtZQUNsQyxXQUFXO1lBQ1gsTUFBTSxJQUFJLENBQUMsTUFBTTtRQUNuQjtRQUNBLElBQUksYUFBYSxhQUFhLE9BQU8sYUFBYSxVQUNoRCxNQUFNLElBQUksVUFBVTtRQUV0QixJQUFJLE9BQU8sYUFBYSxZQUFZLENBQUMsT0FBTyxVQUFVLENBQUMsV0FDckQsTUFBTSxJQUFJLFVBQVUsdUJBQXVCO1FBRTdDLElBQUksSUFBSSxNQUFNLEtBQUssR0FBRztZQUNwQixNQUFNLE9BQU8sSUFBSSxVQUFVLENBQUM7WUFDNUIsSUFBSSxBQUFDLGFBQWEsVUFBVSxPQUFPLE9BQy9CLGFBQWEsVUFDZix1RUFBdUU7WUFDdkUsTUFBTTtRQUVWO0lBQ0YsT0FBTyxJQUFJLE9BQU8sUUFBUSxVQUN4QixNQUFNLE1BQU07U0FDUCxJQUFJLE9BQU8sUUFBUSxXQUN4QixNQUFNLE9BQU87SUFHZixxRUFBcUU7SUFDckUsSUFBSSxRQUFRLEtBQUssSUFBSSxDQUFDLE1BQU0sR0FBRyxTQUFTLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FDcEQsTUFBTSxJQUFJLFdBQVc7SUFHdkIsSUFBSSxPQUFPLE9BQ1QsT0FBTyxJQUFJO0lBR2IsUUFBUSxVQUFVO0lBQ2xCLE1BQU0sUUFBUSxZQUFZLElBQUksQ0FBQyxNQUFNLEdBQUcsUUFBUTtJQUVoRCxJQUFJLENBQUMsS0FBSyxNQUFNO0lBRWhCLElBQUk7SUFDSixJQUFJLE9BQU8sUUFBUSxVQUNqQixJQUFLLElBQUksT0FBTyxJQUFJLEtBQUssRUFBRSxFQUN6QixJQUFJLENBQUMsRUFBRSxHQUFHO1NBRVA7UUFDTCxNQUFNLFFBQVEsT0FBTyxRQUFRLENBQUMsT0FDMUIsTUFDQSxPQUFPLElBQUksQ0FBQyxLQUFLO1FBQ3JCLE1BQU0sTUFBTSxNQUFNLE1BQU07UUFDeEIsSUFBSSxRQUFRLEdBQ1YsTUFBTSxJQUFJLFVBQVUsZ0JBQWdCLE1BQ2xDO1FBRUosSUFBSyxJQUFJLEdBQUcsSUFBSSxNQUFNLE9BQU8sRUFBRSxFQUM3QixJQUFJLENBQUMsSUFBSSxNQUFNLEdBQUcsS0FBSyxDQUFDLElBQUksSUFBSTtJQUVwQztJQUVBLE9BQU8sSUFBSTtBQUNiO0FBRUEsZ0JBQWdCO0FBQ2hCLGdCQUFnQjtBQUVoQiwrREFBK0Q7QUFDL0QsTUFBTSxTQUFTLENBQUM7QUFDaEIsU0FBUyxFQUFHLEdBQUcsRUFBRSxVQUFVLEVBQUUsSUFBSTtJQUMvQixNQUFNLENBQUMsSUFBSSxHQUFHLE1BQU0sa0JBQWtCO1FBQ3BDLGFBQWU7WUFDYixLQUFLO1lBRUwsT0FBTyxjQUFjLENBQUMsSUFBSSxFQUFFLFdBQVc7Z0JBQ3JDLE9BQU8sV0FBVyxLQUFLLENBQUMsSUFBSSxFQUFFO2dCQUM5QixVQUFVO2dCQUNWLGNBQWM7WUFDaEI7WUFFQSxtRUFBbUU7WUFDbkUsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDbkMsMEVBQTBFO1lBQzFFLGlCQUFpQjtZQUNqQixJQUFJLENBQUMsS0FBSyxDQUFDLDRDQUE0Qzs7WUFDdkQscUNBQXFDO1lBQ3JDLE9BQU8sSUFBSSxDQUFDLElBQUk7UUFDbEI7UUFFQSxJQUFJLE9BQVE7WUFDVixPQUFPO1FBQ1Q7UUFFQSxJQUFJLEtBQU0sS0FBSyxFQUFFO1lBQ2YsT0FBTyxjQUFjLENBQUMsSUFBSSxFQUFFLFFBQVE7Z0JBQ2xDLGNBQWM7Z0JBQ2QsWUFBWTtnQkFDWjtnQkFDQSxVQUFVO1lBQ1o7UUFDRjtRQUVBLFdBQVk7WUFDVixPQUFPLENBQUMsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxJQUFJLEdBQUcsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDakQ7SUFDRjtBQUNGO0FBRUEsRUFBRSw0QkFDQSxTQUFVLElBQUk7SUFDWixJQUFJLE1BQ0YsT0FBTyxDQUFDLEVBQUUsS0FBSyw0QkFBNEIsQ0FBQztJQUc5QyxPQUFPO0FBQ1QsR0FBRztBQUNMLEVBQUUsd0JBQ0EsU0FBVSxJQUFJLEVBQUUsTUFBTTtJQUNwQixPQUFPLENBQUMsS0FBSyxFQUFFLEtBQUssaURBQWlELEVBQUUsT0FBTyxPQUFPLENBQUM7QUFDeEYsR0FBRztBQUNMLEVBQUUsb0JBQ0EsU0FBVSxHQUFHLEVBQUUsS0FBSyxFQUFFLEtBQUs7SUFDekIsSUFBSSxNQUFNLENBQUMsY0FBYyxFQUFFLElBQUksa0JBQWtCLENBQUM7SUFDbEQsSUFBSSxXQUFXO0lBQ2YsSUFBSSxPQUFPLFNBQVMsQ0FBQyxVQUFVLEtBQUssR0FBRyxDQUFDLFNBQVMsS0FBSyxJQUNwRCxXQUFXLHNCQUFzQixPQUFPO1NBQ25DLElBQUksT0FBTyxVQUFVLFVBQVU7UUFDcEMsV0FBVyxPQUFPO1FBQ2xCLElBQUksUUFBUSxPQUFPLE1BQU0sT0FBTyxPQUFPLFFBQVEsQ0FBRSxDQUFBLE9BQU8sTUFBTSxPQUFPLEdBQUUsR0FDckUsV0FBVyxzQkFBc0I7UUFFbkMsWUFBWTtJQUNkO0lBQ0EsT0FBTyxDQUFDLFlBQVksRUFBRSxNQUFNLFdBQVcsRUFBRSxTQUFTLENBQUM7SUFDbkQsT0FBTztBQUNULEdBQUc7QUFFTCxTQUFTLHNCQUF1QixHQUFHO0lBQ2pDLElBQUksTUFBTTtJQUNWLElBQUksSUFBSSxJQUFJLE1BQU07SUFDbEIsTUFBTSxRQUFRLEdBQUcsQ0FBQyxFQUFFLEtBQUssTUFBTSxJQUFJO0lBQ25DLE1BQU8sS0FBSyxRQUFRLEdBQUcsS0FBSyxFQUMxQixNQUFNLENBQUMsQ0FBQyxFQUFFLElBQUksS0FBSyxDQUFDLElBQUksR0FBRyxHQUFHLEVBQUUsSUFBSSxDQUFDO0lBRXZDLE9BQU8sQ0FBQyxFQUFFLElBQUksS0FBSyxDQUFDLEdBQUcsR0FBRyxFQUFFLElBQUksQ0FBQztBQUNuQztBQUVBLGtCQUFrQjtBQUNsQixrQkFBa0I7QUFFbEIsU0FBUyxZQUFhLEdBQUcsRUFBRSxNQUFNLEVBQUUsVUFBVTtJQUMzQyxlQUFlLFFBQVE7SUFDdkIsSUFBSSxHQUFHLENBQUMsT0FBTyxLQUFLLGFBQWEsR0FBRyxDQUFDLFNBQVMsV0FBVyxLQUFLLFdBQzVELFlBQVksUUFBUSxJQUFJLE1BQU0sR0FBSSxDQUFBLGFBQWEsQ0FBQTtBQUVuRDtBQUVBLFNBQVMsV0FBWSxLQUFLLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLFVBQVU7SUFDM0QsSUFBSSxRQUFRLE9BQU8sUUFBUSxLQUFLO1FBQzlCLE1BQU0sSUFBSSxPQUFPLFFBQVEsV0FBVyxNQUFNO1FBQzFDLElBQUk7UUFDSixJQUFJLGFBQWE7WUFDZixJQUFJLFFBQVEsS0FBSyxRQUFRLE9BQU8sSUFDOUIsUUFBUSxDQUFDLElBQUksRUFBRSxFQUFFLFFBQVEsRUFBRSxFQUFFLElBQUksRUFBRSxBQUFDLENBQUEsYUFBYSxDQUFBLElBQUssRUFBRSxFQUFFLEVBQUUsQ0FBQztpQkFFN0QsUUFBUSxDQUFDLE1BQU0sRUFBRSxFQUFFLElBQUksRUFBRSxBQUFDLENBQUEsYUFBYSxDQUFBLElBQUssSUFBSSxFQUFFLEVBQUUsRUFBRSxhQUFhLENBQUMsR0FDNUQsQ0FBQyxFQUFFLEFBQUMsQ0FBQSxhQUFhLENBQUEsSUFBSyxJQUFJLEVBQUUsRUFBRSxFQUFFLENBQUM7ZUFHM0MsUUFBUSxDQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUUsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLEVBQUUsQ0FBQztRQUUzQyxNQUFNLElBQUksT0FBTyxnQkFBZ0IsQ0FBQyxTQUFTLE9BQU87SUFDcEQ7SUFDQSxZQUFZLEtBQUssUUFBUTtBQUMzQjtBQUVBLFNBQVMsZUFBZ0IsS0FBSyxFQUFFLElBQUk7SUFDbEMsSUFBSSxPQUFPLFVBQVUsVUFDbkIsTUFBTSxJQUFJLE9BQU8sb0JBQW9CLENBQUMsTUFBTSxVQUFVO0FBRTFEO0FBRUEsU0FBUyxZQUFhLEtBQUssRUFBRSxNQUFNLEVBQUUsSUFBSTtJQUN2QyxJQUFJLEtBQUssS0FBSyxDQUFDLFdBQVcsT0FBTztRQUMvQixlQUFlLE9BQU87UUFDdEIsTUFBTSxJQUFJLE9BQU8sZ0JBQWdCLENBQUMsUUFBUSxVQUFVLGNBQWM7SUFDcEU7SUFFQSxJQUFJLFNBQVMsR0FDWCxNQUFNLElBQUksT0FBTyx3QkFBd0I7SUFHM0MsTUFBTSxJQUFJLE9BQU8sZ0JBQWdCLENBQUMsUUFBUSxVQUNSLENBQUMsR0FBRyxFQUFFLE9BQU8sSUFBSSxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsRUFDckM7QUFDcEM7QUFFQSxtQkFBbUI7QUFDbkIsbUJBQW1CO0FBRW5CLE1BQU0sb0JBQW9CO0FBRTFCLFNBQVMsWUFBYSxHQUFHO0lBQ3ZCLHVEQUF1RDtJQUN2RCxNQUFNLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQ3ZCLHdGQUF3RjtJQUN4RixNQUFNLElBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQyxtQkFBbUI7SUFDNUMsOENBQThDO0lBQzlDLElBQUksSUFBSSxNQUFNLEdBQUcsR0FBRyxPQUFPO0lBQzNCLHVGQUF1RjtJQUN2RixNQUFPLElBQUksTUFBTSxHQUFHLE1BQU0sRUFDeEIsTUFBTSxNQUFNO0lBRWQsT0FBTztBQUNUO0FBRUEsU0FBUyxZQUFhLE1BQU0sRUFBRSxLQUFLO0lBQ2pDLFFBQVEsU0FBUztJQUNqQixJQUFJO0lBQ0osTUFBTSxTQUFTLE9BQU8sTUFBTTtJQUM1QixJQUFJLGdCQUFnQjtJQUNwQixNQUFNLFFBQVEsRUFBRTtJQUVoQixJQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxFQUFFLEVBQUc7UUFDL0IsWUFBWSxPQUFPLFVBQVUsQ0FBQztRQUU5Qix5QkFBeUI7UUFDekIsSUFBSSxZQUFZLFVBQVUsWUFBWSxRQUFRO1lBQzVDLHVCQUF1QjtZQUN2QixJQUFJLENBQUMsZUFBZTtnQkFDbEIsY0FBYztnQkFDZCxJQUFJLFlBQVksUUFBUTtvQkFDdEIsbUJBQW1CO29CQUNuQixJQUFJLEFBQUMsQ0FBQSxTQUFTLENBQUEsSUFBSyxJQUFJLE1BQU0sSUFBSSxDQUFDLE1BQU0sTUFBTTtvQkFDOUM7Z0JBQ0YsT0FBTyxJQUFJLElBQUksTUFBTSxRQUFRO29CQUMzQixnQkFBZ0I7b0JBQ2hCLElBQUksQUFBQyxDQUFBLFNBQVMsQ0FBQSxJQUFLLElBQUksTUFBTSxJQUFJLENBQUMsTUFBTSxNQUFNO29CQUM5QztnQkFDRjtnQkFFQSxhQUFhO2dCQUNiLGdCQUFnQjtnQkFFaEI7WUFDRjtZQUVBLG1CQUFtQjtZQUNuQixJQUFJLFlBQVksUUFBUTtnQkFDdEIsSUFBSSxBQUFDLENBQUEsU0FBUyxDQUFBLElBQUssSUFBSSxNQUFNLElBQUksQ0FBQyxNQUFNLE1BQU07Z0JBQzlDLGdCQUFnQjtnQkFDaEI7WUFDRjtZQUVBLHVCQUF1QjtZQUN2QixZQUFZLEFBQUMsQ0FBQSxnQkFBZ0IsVUFBVSxLQUFLLFlBQVksTUFBSyxJQUFLO1FBQ3BFLE9BQU8sSUFBSSxlQUNULDJDQUEyQztRQUMzQztZQUFBLElBQUksQUFBQyxDQUFBLFNBQVMsQ0FBQSxJQUFLLElBQUksTUFBTSxJQUFJLENBQUMsTUFBTSxNQUFNO1FBQUk7UUFHcEQsZ0JBQWdCO1FBRWhCLGNBQWM7UUFDZCxJQUFJLFlBQVksTUFBTTtZQUNwQixJQUFJLEFBQUMsQ0FBQSxTQUFTLENBQUEsSUFBSyxHQUFHO1lBQ3RCLE1BQU0sSUFBSSxDQUFDO1FBQ2IsT0FBTyxJQUFJLFlBQVksT0FBTztZQUM1QixJQUFJLEFBQUMsQ0FBQSxTQUFTLENBQUEsSUFBSyxHQUFHO1lBQ3RCLE1BQU0sSUFBSSxDQUNSLGFBQWEsTUFBTSxNQUNuQixZQUFZLE9BQU87UUFFdkIsT0FBTyxJQUFJLFlBQVksU0FBUztZQUM5QixJQUFJLEFBQUMsQ0FBQSxTQUFTLENBQUEsSUFBSyxHQUFHO1lBQ3RCLE1BQU0sSUFBSSxDQUNSLGFBQWEsTUFBTSxNQUNuQixhQUFhLE1BQU0sT0FBTyxNQUMxQixZQUFZLE9BQU87UUFFdkIsT0FBTyxJQUFJLFlBQVksVUFBVTtZQUMvQixJQUFJLEFBQUMsQ0FBQSxTQUFTLENBQUEsSUFBSyxHQUFHO1lBQ3RCLE1BQU0sSUFBSSxDQUNSLGFBQWEsT0FBTyxNQUNwQixhQUFhLE1BQU0sT0FBTyxNQUMxQixhQUFhLE1BQU0sT0FBTyxNQUMxQixZQUFZLE9BQU87UUFFdkIsT0FDRSxNQUFNLElBQUksTUFBTTtJQUVwQjtJQUVBLE9BQU87QUFDVDtBQUVBLFNBQVMsYUFBYyxHQUFHO0lBQ3hCLE1BQU0sWUFBWSxFQUFFO0lBQ3BCLElBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLE1BQU0sRUFBRSxFQUFFLEVBQ2hDLHNEQUFzRDtJQUN0RCxVQUFVLElBQUksQ0FBQyxJQUFJLFVBQVUsQ0FBQyxLQUFLO0lBRXJDLE9BQU87QUFDVDtBQUVBLFNBQVMsZUFBZ0IsR0FBRyxFQUFFLEtBQUs7SUFDakMsSUFBSSxHQUFHLElBQUk7SUFDWCxNQUFNLFlBQVksRUFBRTtJQUNwQixJQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxNQUFNLEVBQUUsRUFBRSxFQUFHO1FBQ25DLElBQUksQUFBQyxDQUFBLFNBQVMsQ0FBQSxJQUFLLEdBQUc7UUFFdEIsSUFBSSxJQUFJLFVBQVUsQ0FBQztRQUNuQixLQUFLLEtBQUs7UUFDVixLQUFLLElBQUk7UUFDVCxVQUFVLElBQUksQ0FBQztRQUNmLFVBQVUsSUFBSSxDQUFDO0lBQ2pCO0lBRUEsT0FBTztBQUNUO0FBRUEsU0FBUyxjQUFlLEdBQUc7SUFDekIsT0FBTyxPQUFPLFdBQVcsQ0FBQyxZQUFZO0FBQ3hDO0FBRUEsU0FBUyxXQUFZLEdBQUcsRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLE1BQU07SUFDM0MsSUFBSTtJQUNKLElBQUssSUFBSSxHQUFHLElBQUksUUFBUSxFQUFFLEVBQUc7UUFDM0IsSUFBSSxBQUFDLElBQUksVUFBVSxJQUFJLE1BQU0sSUFBTSxLQUFLLElBQUksTUFBTSxFQUFHO1FBQ3JELEdBQUcsQ0FBQyxJQUFJLE9BQU8sR0FBRyxHQUFHLENBQUMsRUFBRTtJQUMxQjtJQUNBLE9BQU87QUFDVDtBQUVBLG1GQUFtRjtBQUNuRixxRUFBcUU7QUFDckUsbURBQW1EO0FBQ25ELFNBQVMsV0FBWSxHQUFHLEVBQUUsSUFBSTtJQUM1QixPQUFPLGVBQWUsUUFDbkIsT0FBTyxRQUFRLElBQUksV0FBVyxJQUFJLFFBQVEsSUFBSSxXQUFXLENBQUMsSUFBSSxJQUFJLFFBQ2pFLElBQUksV0FBVyxDQUFDLElBQUksS0FBSyxLQUFLLElBQUk7QUFDeEM7QUFDQSxTQUFTLFlBQWEsR0FBRztJQUN2QixtQkFBbUI7SUFDbkIsT0FBTyxRQUFRLElBQUksc0NBQXNDOztBQUMzRDtBQUVBLDRDQUE0QztBQUM1QyxtREFBbUQ7QUFDbkQsTUFBTSxzQkFBc0IsQUFBQztJQUMzQixNQUFNLFdBQVc7SUFDakIsTUFBTSxRQUFRLElBQUksTUFBTTtJQUN4QixJQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLEVBQUc7UUFDM0IsTUFBTSxNQUFNLElBQUk7UUFDaEIsSUFBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksRUFBRSxFQUN4QixLQUFLLENBQUMsTUFBTSxFQUFFLEdBQUcsUUFBUSxDQUFDLEVBQUUsR0FBRyxRQUFRLENBQUMsRUFBRTtJQUU5QztJQUNBLE9BQU87QUFDVDtBQUVBLHlEQUF5RDtBQUN6RCxTQUFTLG1CQUFvQixFQUFFO0lBQzdCLE9BQU8sT0FBTyxXQUFXLGNBQWMseUJBQXlCO0FBQ2xFO0FBRUEsU0FBUztJQUNQLE1BQU0sSUFBSSxNQUFNO0FBQ2xCOzs7QUN6akVBO0FBRUEsUUFBUSxVQUFVLEdBQUc7QUFDckIsUUFBUSxXQUFXLEdBQUc7QUFDdEIsUUFBUSxhQUFhLEdBQUc7QUFFeEIsSUFBSSxTQUFTLEVBQUU7QUFDZixJQUFJLFlBQVksRUFBRTtBQUNsQixJQUFJLE1BQU0sT0FBTyxlQUFlLGNBQWMsYUFBYTtBQUUzRCxJQUFJLE9BQU87QUFDWCxJQUFLLElBQUksSUFBSSxHQUFHLE1BQU0sS0FBSyxNQUFNLEVBQUUsSUFBSSxLQUFLLEVBQUUsRUFBRztJQUMvQyxNQUFNLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxFQUFFO0lBQ25CLFNBQVMsQ0FBQyxLQUFLLFVBQVUsQ0FBQyxHQUFHLEdBQUc7QUFDbEM7QUFFQSw2REFBNkQ7QUFDN0QsNkRBQTZEO0FBQzdELFNBQVMsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxHQUFHLEdBQUc7QUFDL0IsU0FBUyxDQUFDLElBQUksVUFBVSxDQUFDLEdBQUcsR0FBRztBQUUvQixTQUFTLFFBQVMsR0FBRztJQUNuQixJQUFJLE1BQU0sSUFBSSxNQUFNO0lBRXBCLElBQUksTUFBTSxJQUFJLEdBQ1osTUFBTSxJQUFJLE1BQU07SUFHbEIseURBQXlEO0lBQ3pELHlEQUF5RDtJQUN6RCxJQUFJLFdBQVcsSUFBSSxPQUFPLENBQUM7SUFDM0IsSUFBSSxhQUFhLElBQUksV0FBVztJQUVoQyxJQUFJLGtCQUFrQixhQUFhLE1BQy9CLElBQ0EsSUFBSyxXQUFXO0lBRXBCLE9BQU87UUFBQztRQUFVO0tBQWdCO0FBQ3BDO0FBRUEsNERBQTREO0FBQzVELFNBQVMsV0FBWSxHQUFHO0lBQ3RCLElBQUksT0FBTyxRQUFRO0lBQ25CLElBQUksV0FBVyxJQUFJLENBQUMsRUFBRTtJQUN0QixJQUFJLGtCQUFrQixJQUFJLENBQUMsRUFBRTtJQUM3QixPQUFPLEFBQUUsQ0FBQSxXQUFXLGVBQWMsSUFBSyxJQUFJLElBQUs7QUFDbEQ7QUFFQSxTQUFTLFlBQWEsR0FBRyxFQUFFLFFBQVEsRUFBRSxlQUFlO0lBQ2xELE9BQU8sQUFBRSxDQUFBLFdBQVcsZUFBYyxJQUFLLElBQUksSUFBSztBQUNsRDtBQUVBLFNBQVMsWUFBYSxHQUFHO0lBQ3ZCLElBQUk7SUFDSixJQUFJLE9BQU8sUUFBUTtJQUNuQixJQUFJLFdBQVcsSUFBSSxDQUFDLEVBQUU7SUFDdEIsSUFBSSxrQkFBa0IsSUFBSSxDQUFDLEVBQUU7SUFFN0IsSUFBSSxNQUFNLElBQUksSUFBSSxZQUFZLEtBQUssVUFBVTtJQUU3QyxJQUFJLFVBQVU7SUFFZCxzRUFBc0U7SUFDdEUsSUFBSSxNQUFNLGtCQUFrQixJQUN4QixXQUFXLElBQ1g7SUFFSixJQUFJO0lBQ0osSUFBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUssRUFBRztRQUMzQixNQUNFLEFBQUMsU0FBUyxDQUFDLElBQUksVUFBVSxDQUFDLEdBQUcsSUFBSSxLQUNoQyxTQUFTLENBQUMsSUFBSSxVQUFVLENBQUMsSUFBSSxHQUFHLElBQUksS0FDcEMsU0FBUyxDQUFDLElBQUksVUFBVSxDQUFDLElBQUksR0FBRyxJQUFJLElBQ3JDLFNBQVMsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxJQUFJLEdBQUc7UUFDbEMsR0FBRyxDQUFDLFVBQVUsR0FBRyxBQUFDLE9BQU8sS0FBTTtRQUMvQixHQUFHLENBQUMsVUFBVSxHQUFHLEFBQUMsT0FBTyxJQUFLO1FBQzlCLEdBQUcsQ0FBQyxVQUFVLEdBQUcsTUFBTTtJQUN6QjtJQUVBLElBQUksb0JBQW9CLEdBQUc7UUFDekIsTUFDRSxBQUFDLFNBQVMsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxHQUFHLElBQUksSUFDaEMsU0FBUyxDQUFDLElBQUksVUFBVSxDQUFDLElBQUksR0FBRyxJQUFJO1FBQ3ZDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsTUFBTTtJQUN6QjtJQUVBLElBQUksb0JBQW9CLEdBQUc7UUFDekIsTUFDRSxBQUFDLFNBQVMsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxHQUFHLElBQUksS0FDaEMsU0FBUyxDQUFDLElBQUksVUFBVSxDQUFDLElBQUksR0FBRyxJQUFJLElBQ3BDLFNBQVMsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxJQUFJLEdBQUcsSUFBSTtRQUN2QyxHQUFHLENBQUMsVUFBVSxHQUFHLEFBQUMsT0FBTyxJQUFLO1FBQzlCLEdBQUcsQ0FBQyxVQUFVLEdBQUcsTUFBTTtJQUN6QjtJQUVBLE9BQU87QUFDVDtBQUVBLFNBQVMsZ0JBQWlCLEdBQUc7SUFDM0IsT0FBTyxNQUFNLENBQUMsT0FBTyxLQUFLLEtBQUssR0FDN0IsTUFBTSxDQUFDLE9BQU8sS0FBSyxLQUFLLEdBQ3hCLE1BQU0sQ0FBQyxPQUFPLElBQUksS0FBSyxHQUN2QixNQUFNLENBQUMsTUFBTSxLQUFLO0FBQ3RCO0FBRUEsU0FBUyxZQUFhLEtBQUssRUFBRSxLQUFLLEVBQUUsR0FBRztJQUNyQyxJQUFJO0lBQ0osSUFBSSxTQUFTLEVBQUU7SUFDZixJQUFLLElBQUksSUFBSSxPQUFPLElBQUksS0FBSyxLQUFLLEVBQUc7UUFDbkMsTUFDRSxBQUFDLENBQUEsQUFBQyxLQUFLLENBQUMsRUFBRSxJQUFJLEtBQU0sUUFBTyxJQUMxQixDQUFBLEFBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxJQUFJLElBQUssTUFBSyxJQUMzQixDQUFBLEtBQUssQ0FBQyxJQUFJLEVBQUUsR0FBRyxJQUFHO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQjtJQUM5QjtJQUNBLE9BQU8sT0FBTyxJQUFJLENBQUM7QUFDckI7QUFFQSxTQUFTLGNBQWUsS0FBSztJQUMzQixJQUFJO0lBQ0osSUFBSSxNQUFNLE1BQU0sTUFBTTtJQUN0QixJQUFJLGFBQWEsTUFBTSxFQUFFLHNDQUFzQzs7SUFDL0QsSUFBSSxRQUFRLEVBQUU7SUFDZCxJQUFJLGlCQUFpQixNQUFNLHdCQUF3Qjs7SUFFbkQsK0VBQStFO0lBQy9FLElBQUssSUFBSSxJQUFJLEdBQUcsT0FBTyxNQUFNLFlBQVksSUFBSSxNQUFNLEtBQUssZUFDdEQsTUFBTSxJQUFJLENBQUMsWUFBWSxPQUFPLEdBQUcsQUFBQyxJQUFJLGlCQUFrQixPQUFPLE9BQVEsSUFBSTtJQUc3RSxzRUFBc0U7SUFDdEUsSUFBSSxlQUFlLEdBQUc7UUFDcEIsTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFFO1FBQ3BCLE1BQU0sSUFBSSxDQUNSLE1BQU0sQ0FBQyxPQUFPLEVBQUUsR0FDaEIsTUFBTSxDQUFDLEFBQUMsT0FBTyxJQUFLLEtBQUssR0FDekI7SUFFSixPQUFPLElBQUksZUFBZSxHQUFHO1FBQzNCLE1BQU0sQUFBQyxDQUFBLEtBQUssQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFBLElBQUssS0FBSyxDQUFDLE1BQU0sRUFBRTtRQUM1QyxNQUFNLElBQUksQ0FDUixNQUFNLENBQUMsT0FBTyxHQUFHLEdBQ2pCLE1BQU0sQ0FBQyxBQUFDLE9BQU8sSUFBSyxLQUFLLEdBQ3pCLE1BQU0sQ0FBQyxBQUFDLE9BQU8sSUFBSyxLQUFLLEdBQ3pCO0lBRUo7SUFFQSxPQUFPLE1BQU0sSUFBSSxDQUFDO0FBQ3BCOzs7QUNySkEsdUZBQXVGLEdBQ3ZGLFFBQVEsSUFBSSxHQUFHLFNBQVUsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE1BQU07SUFDekQsSUFBSSxHQUFHO0lBQ1AsSUFBSSxPQUFPLEFBQUMsU0FBUyxJQUFLLE9BQU87SUFDakMsSUFBSSxPQUFPLEFBQUMsQ0FBQSxLQUFLLElBQUcsSUFBSztJQUN6QixJQUFJLFFBQVEsUUFBUTtJQUNwQixJQUFJLFFBQVE7SUFDWixJQUFJLElBQUksT0FBUSxTQUFTLElBQUs7SUFDOUIsSUFBSSxJQUFJLE9BQU8sS0FBSztJQUNwQixJQUFJLElBQUksTUFBTSxDQUFDLFNBQVMsRUFBRTtJQUUxQixLQUFLO0lBRUwsSUFBSSxJQUFLLEFBQUMsQ0FBQSxLQUFNLENBQUMsS0FBSyxJQUFLO0lBQzNCLE1BQU8sQ0FBQztJQUNSLFNBQVM7SUFDVCxNQUFPLFFBQVEsR0FBRyxJQUFJLEFBQUMsSUFBSSxNQUFPLE1BQU0sQ0FBQyxTQUFTLEVBQUUsRUFBRSxLQUFLLEdBQUcsU0FBUztJQUV2RSxJQUFJLElBQUssQUFBQyxDQUFBLEtBQU0sQ0FBQyxLQUFLLElBQUs7SUFDM0IsTUFBTyxDQUFDO0lBQ1IsU0FBUztJQUNULE1BQU8sUUFBUSxHQUFHLElBQUksQUFBQyxJQUFJLE1BQU8sTUFBTSxDQUFDLFNBQVMsRUFBRSxFQUFFLEtBQUssR0FBRyxTQUFTO0lBRXZFLElBQUksTUFBTSxHQUNSLElBQUksSUFBSTtTQUNILElBQUksTUFBTSxNQUNmLE9BQU8sSUFBSSxNQUFPLEFBQUMsQ0FBQSxJQUFJLEtBQUssQ0FBQSxJQUFLO1NBQzVCO1FBQ0wsSUFBSSxJQUFJLEtBQUssR0FBRyxDQUFDLEdBQUc7UUFDcEIsSUFBSSxJQUFJO0lBQ1Y7SUFDQSxPQUFPLEFBQUMsQ0FBQSxJQUFJLEtBQUssQ0FBQSxJQUFLLElBQUksS0FBSyxHQUFHLENBQUMsR0FBRyxJQUFJO0FBQzVDO0FBRUEsUUFBUSxLQUFLLEdBQUcsU0FBVSxNQUFNLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLE1BQU07SUFDakUsSUFBSSxHQUFHLEdBQUc7SUFDVixJQUFJLE9BQU8sQUFBQyxTQUFTLElBQUssT0FBTztJQUNqQyxJQUFJLE9BQU8sQUFBQyxDQUFBLEtBQUssSUFBRyxJQUFLO0lBQ3pCLElBQUksUUFBUSxRQUFRO0lBQ3BCLElBQUksS0FBTSxTQUFTLEtBQUssS0FBSyxHQUFHLENBQUMsR0FBRyxPQUFPLEtBQUssR0FBRyxDQUFDLEdBQUcsT0FBTztJQUM5RCxJQUFJLElBQUksT0FBTyxJQUFLLFNBQVM7SUFDN0IsSUFBSSxJQUFJLE9BQU8sSUFBSTtJQUNuQixJQUFJLElBQUksUUFBUSxLQUFNLFVBQVUsS0FBSyxJQUFJLFFBQVEsSUFBSyxJQUFJO0lBRTFELFFBQVEsS0FBSyxHQUFHLENBQUM7SUFFakIsSUFBSSxNQUFNLFVBQVUsVUFBVSxVQUFVO1FBQ3RDLElBQUksTUFBTSxTQUFTLElBQUk7UUFDdkIsSUFBSTtJQUNOLE9BQU87UUFDTCxJQUFJLEtBQUssS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLFNBQVMsS0FBSyxHQUFHO1FBQ3pDLElBQUksUUFBUyxDQUFBLElBQUksS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUMsSUFBSyxHQUFHO1lBQ3JDO1lBQ0EsS0FBSztRQUNQO1FBQ0EsSUFBSSxJQUFJLFNBQVMsR0FDZixTQUFTLEtBQUs7YUFFZCxTQUFTLEtBQUssS0FBSyxHQUFHLENBQUMsR0FBRyxJQUFJO1FBRWhDLElBQUksUUFBUSxLQUFLLEdBQUc7WUFDbEI7WUFDQSxLQUFLO1FBQ1A7UUFFQSxJQUFJLElBQUksU0FBUyxNQUFNO1lBQ3JCLElBQUk7WUFDSixJQUFJO1FBQ04sT0FBTyxJQUFJLElBQUksU0FBUyxHQUFHO1lBQ3pCLElBQUksQUFBQyxDQUFBLEFBQUMsUUFBUSxJQUFLLENBQUEsSUFBSyxLQUFLLEdBQUcsQ0FBQyxHQUFHO1lBQ3BDLElBQUksSUFBSTtRQUNWLE9BQU87WUFDTCxJQUFJLFFBQVEsS0FBSyxHQUFHLENBQUMsR0FBRyxRQUFRLEtBQUssS0FBSyxHQUFHLENBQUMsR0FBRztZQUNqRCxJQUFJO1FBQ047SUFDRjtJQUVBLE1BQU8sUUFBUSxHQUFHLE1BQU0sQ0FBQyxTQUFTLEVBQUUsR0FBRyxJQUFJLE1BQU0sS0FBSyxHQUFHLEtBQUssS0FBSyxRQUFRO0lBRTNFLElBQUksQUFBQyxLQUFLLE9BQVE7SUFDbEIsUUFBUTtJQUNSLE1BQU8sT0FBTyxHQUFHLE1BQU0sQ0FBQyxTQUFTLEVBQUUsR0FBRyxJQUFJLE1BQU0sS0FBSyxHQUFHLEtBQUssS0FBSyxRQUFRO0lBRTFFLE1BQU0sQ0FBQyxTQUFTLElBQUksRUFBRSxJQUFJLElBQUk7QUFDaEM7Ozs7O0FDbEZBOztBQUZBO0FBSUE7Ozs7Ozs7Ozs7Q0FVQyxHQUNELFNBQVMsV0FBVyxPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsUUFBUTtJQUMxRCxNQUFNLElBQUksQ0FBQyxJQUFJO0lBRWYsSUFBSSxNQUFNLGlCQUFpQixFQUN6QixNQUFNLGlCQUFpQixDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsV0FBVztTQUU5QyxJQUFJLENBQUMsS0FBSyxHQUFHLEFBQUMsSUFBSSxRQUFTLEtBQUs7SUFHbEMsSUFBSSxDQUFDLE9BQU8sR0FBRztJQUNmLElBQUksQ0FBQyxJQUFJLEdBQUc7SUFDWixRQUFTLENBQUEsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFHO0lBQ3hCLFVBQVcsQ0FBQSxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQUs7SUFDOUIsV0FBWSxDQUFBLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTTtJQUNqQyxZQUFhLENBQUEsSUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFPO0FBQ3RDO0FBRUEsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxRQUFRLENBQUMsWUFBWSxPQUFPO0lBQ2hDLFFBQVEsU0FBUztRQUNmLE9BQU87WUFDTCxXQUFXO1lBQ1gsU0FBUyxJQUFJLENBQUMsT0FBTztZQUNyQixNQUFNLElBQUksQ0FBQyxJQUFJO1lBQ2YsWUFBWTtZQUNaLGFBQWEsSUFBSSxDQUFDLFdBQVc7WUFDN0IsUUFBUSxJQUFJLENBQUMsTUFBTTtZQUNuQixVQUFVO1lBQ1YsVUFBVSxJQUFJLENBQUMsUUFBUTtZQUN2QixZQUFZLElBQUksQ0FBQyxVQUFVO1lBQzNCLGNBQWMsSUFBSSxDQUFDLFlBQVk7WUFDL0IsT0FBTyxJQUFJLENBQUMsS0FBSztZQUNqQixRQUFRO1lBQ1IsUUFBUSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTTtZQUN0QyxNQUFNLElBQUksQ0FBQyxJQUFJO1lBQ2YsUUFBUSxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHO1FBQ3pFO0lBQ0Y7QUFDRjtBQUVBLE1BQU0sWUFBWSxXQUFXLFNBQVM7QUFDdEMsTUFBTSxjQUFjLENBQUM7QUFFckI7SUFDRTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7Q0FFRCxDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBQ1IsV0FBVyxDQUFDLEtBQUssR0FBRztRQUFDLE9BQU87SUFBSTtBQUNsQztBQUVBLE9BQU8sZ0JBQWdCLENBQUMsWUFBWTtBQUNwQyxPQUFPLGNBQWMsQ0FBQyxXQUFXLGdCQUFnQjtJQUFDLE9BQU87QUFBSTtBQUU3RCxzQ0FBc0M7QUFDdEMsV0FBVyxJQUFJLEdBQUcsQ0FBQyxPQUFPLE1BQU0sUUFBUSxTQUFTLFVBQVU7SUFDekQsTUFBTSxhQUFhLE9BQU8sTUFBTSxDQUFDO0lBRWpDLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsWUFBWSxDQUFDLE9BQU8sWUFBWSxTQUFTLE9BQU8sR0FBRztRQUN2RCxPQUFPLFFBQVEsTUFBTSxTQUFTO0lBQ2hDLEdBQUcsQ0FBQTtRQUNELE9BQU8sU0FBUztJQUNsQjtJQUVBLFdBQVcsSUFBSSxDQUFDLFlBQVksTUFBTSxPQUFPLEVBQUUsTUFBTSxRQUFRLFNBQVM7SUFFbEUsV0FBVyxLQUFLLEdBQUc7SUFFbkIsV0FBVyxJQUFJLEdBQUcsTUFBTSxJQUFJO0lBRTVCLGVBQWUsT0FBTyxNQUFNLENBQUMsWUFBWTtJQUV6QyxPQUFPO0FBQ1Q7a0JBRWU7OztBQ25HZixrQ0FBa0M7OztrQkFDbkI7Ozs7O0FDQ2Y7O0FBRkE7QUFJQSxNQUFNO0lBQ0osYUFBYztRQUNaLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRTtJQUNwQjtJQUVBOzs7Ozs7O0dBT0MsR0FDRCxJQUFJLFNBQVMsRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFO1FBQ2hDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO1lBQ2pCO1lBQ0E7WUFDQSxhQUFhLFVBQVUsUUFBUSxXQUFXLEdBQUc7WUFDN0MsU0FBUyxVQUFVLFFBQVEsT0FBTyxHQUFHO1FBQ3ZDO1FBQ0EsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRztJQUNoQztJQUVBOzs7Ozs7R0FNQyxHQUNELE1BQU0sRUFBRSxFQUFFO1FBQ1IsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFDbkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLEdBQUc7SUFFeEI7SUFFQTs7OztHQUlDLEdBQ0QsUUFBUTtRQUNOLElBQUksSUFBSSxDQUFDLFFBQVEsRUFDZixJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUU7SUFFdEI7SUFFQTs7Ozs7Ozs7O0dBU0MsR0FDRCxRQUFRLEVBQUUsRUFBRTtRQUNWLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsU0FBUyxlQUFlLENBQUM7WUFDcEQsSUFBSSxNQUFNLE1BQ1IsR0FBRztRQUVQO0lBQ0Y7QUFDRjtrQkFFZTs7Ozs7NkNDckNTO0FBL0J4Qjs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFQQTtBQVNBOzs7Ozs7Q0FNQyxHQUNELFNBQVMsNkJBQTZCLE1BQU07SUFDMUMsSUFBSSxPQUFPLFdBQVcsRUFDcEIsT0FBTyxXQUFXLENBQUMsZ0JBQWdCO0lBR3JDLElBQUksT0FBTyxNQUFNLElBQUksT0FBTyxNQUFNLENBQUMsT0FBTyxFQUN4QyxNQUFNLElBQUksQ0FBQSxHQUFBLCtCQUFhLEFBQUQsRUFBRSxNQUFNO0FBRWxDO0FBU2UsU0FBUyxnQkFBZ0IsTUFBTTtJQUM1Qyw2QkFBNkI7SUFFN0IsT0FBTyxPQUFPLEdBQUcsQ0FBQSxHQUFBLDhCQUFZLEFBQUQsRUFBRSxJQUFJLENBQUMsT0FBTyxPQUFPO0lBRWpELHlCQUF5QjtJQUN6QixPQUFPLElBQUksR0FBRyxDQUFBLEdBQUEsK0JBQWEsQUFBRCxFQUFFLElBQUksQ0FDOUIsUUFDQSxPQUFPLGdCQUFnQjtJQUd6QixJQUFJO1FBQUM7UUFBUTtRQUFPO0tBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTyxNQUFNLE1BQU0sSUFDdEQsT0FBTyxPQUFPLENBQUMsY0FBYyxDQUFDLHFDQUFxQztJQUdyRSxNQUFNLFVBQVUsQ0FBQSxHQUFBLDBCQUFRLEFBQUQsRUFBRSxVQUFVLENBQUMsT0FBTyxPQUFPLElBQUksQ0FBQSxHQUFBLHVCQUFRLEFBQUQsRUFBRSxPQUFPO0lBRXRFLE9BQU8sUUFBUSxRQUFRLElBQUksQ0FBQyxTQUFTLG9CQUFvQixRQUFRO1FBQy9ELDZCQUE2QjtRQUU3QiwwQkFBMEI7UUFDMUIsU0FBUyxJQUFJLEdBQUcsQ0FBQSxHQUFBLCtCQUFhLEFBQUQsRUFBRSxJQUFJLENBQ2hDLFFBQ0EsT0FBTyxpQkFBaUIsRUFDeEI7UUFHRixTQUFTLE9BQU8sR0FBRyxDQUFBLEdBQUEsOEJBQVksQUFBRCxFQUFFLElBQUksQ0FBQyxTQUFTLE9BQU87UUFFckQsT0FBTztJQUNULEdBQUcsU0FBUyxtQkFBbUIsTUFBTTtRQUNuQyxJQUFJLENBQUMsQ0FBQSxHQUFBLDBCQUFRLEFBQUQsRUFBRSxTQUFTO1lBQ3JCLDZCQUE2QjtZQUU3QiwwQkFBMEI7WUFDMUIsSUFBSSxVQUFVLE9BQU8sUUFBUSxFQUFFO2dCQUM3QixPQUFPLFFBQVEsQ0FBQyxJQUFJLEdBQUcsQ0FBQSxHQUFBLCtCQUFhLEFBQUQsRUFBRSxJQUFJLENBQ3ZDLFFBQ0EsT0FBTyxpQkFBaUIsRUFDeEIsT0FBTyxRQUFRO2dCQUVqQixPQUFPLFFBQVEsQ0FBQyxPQUFPLEdBQUcsQ0FBQSxHQUFBLDhCQUFZLEFBQUQsRUFBRSxJQUFJLENBQUMsT0FBTyxRQUFRLENBQUMsT0FBTztZQUNyRTtRQUNGO1FBRUEsT0FBTyxRQUFRLE1BQU0sQ0FBQztJQUN4QjtBQUNGOzs7Ozs2Q0NsRXdCO0FBWnhCOztBQUNBOztBQUNBOztBQUpBO0FBY2UsU0FBUyxjQUFjLEdBQUcsRUFBRSxRQUFRO0lBQ2pELE1BQU0sU0FBUyxJQUFJLElBQUksQ0FBQSxHQUFBLHVCQUFRLEFBQUQ7SUFDOUIsTUFBTSxVQUFVLFlBQVk7SUFDNUIsTUFBTSxVQUFVLENBQUEsR0FBQSw4QkFBWSxBQUFELEVBQUUsSUFBSSxDQUFDLFFBQVEsT0FBTztJQUNqRCxJQUFJLE9BQU8sUUFBUSxJQUFJO0lBRXZCLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsT0FBTyxDQUFDLEtBQUssU0FBUyxVQUFVLEVBQUU7UUFDdEMsT0FBTyxHQUFHLElBQUksQ0FBQyxRQUFRLE1BQU0sUUFBUSxTQUFTLElBQUksV0FBVyxTQUFTLE1BQU0sR0FBRztJQUNqRjtJQUVBLFFBQVEsU0FBUztJQUVqQixPQUFPO0FBQ1Q7Ozs7O0FDekJBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQVJBO0FBVUE7Ozs7Ozs7OztDQVNDLEdBQ0QsU0FBUyxnQkFBZ0IsUUFBUSxFQUFFLE1BQU0sRUFBRSxPQUFPO0lBQ2hELElBQUksQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxRQUFRLENBQUMsV0FDakIsSUFBSTtRQUNELENBQUEsVUFBVSxLQUFLLEtBQUssQUFBRCxFQUFHO1FBQ3ZCLE9BQU8sQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxJQUFJLENBQUM7SUFDcEIsRUFBRSxPQUFPLEdBQUc7UUFDVixJQUFJLEVBQUUsSUFBSSxLQUFLLGVBQ2IsTUFBTTtJQUVWO0lBR0YsT0FBTyxBQUFDLENBQUEsV0FBVyxLQUFLLFNBQVMsQUFBRCxFQUFHO0FBQ3JDO0FBRUEsTUFBTSxXQUFXO0lBRWYsY0FBYyxDQUFBLEdBQUEsOEJBQW9CLEFBQUQ7SUFFakMsU0FBUztRQUFDO1FBQU87S0FBTztJQUV4QixrQkFBa0I7UUFBQyxTQUFTLGlCQUFpQixJQUFJLEVBQUUsT0FBTztZQUN4RCxNQUFNLGNBQWMsUUFBUSxjQUFjLE1BQU07WUFDaEQsTUFBTSxxQkFBcUIsWUFBWSxPQUFPLENBQUMsc0JBQXNCO1lBQ3JFLE1BQU0sa0JBQWtCLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsUUFBUSxDQUFDO1lBRXZDLElBQUksbUJBQW1CLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsVUFBVSxDQUFDLE9BQ3RDLE9BQU8sSUFBSSxTQUFTO1lBR3RCLE1BQU0sYUFBYSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFVBQVUsQ0FBQztZQUVwQyxJQUFJLFlBQ0YsT0FBTyxxQkFBcUIsS0FBSyxTQUFTLENBQUMsQ0FBQSxHQUFBLGdDQUFjLEFBQUQsRUFBRSxTQUFTO1lBR3JFLElBQUksQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxhQUFhLENBQUMsU0FDdEIsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxRQUFRLENBQUMsU0FDZixDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFFBQVEsQ0FBQyxTQUNmLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsTUFBTSxDQUFDLFNBQ2IsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxNQUFNLENBQUMsT0FFYixPQUFPO1lBRVQsSUFBSSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLGlCQUFpQixDQUFDLE9BQzFCLE9BQU8sS0FBSyxNQUFNO1lBRXBCLElBQUksQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxpQkFBaUIsQ0FBQyxPQUFPO2dCQUNqQyxRQUFRLGNBQWMsQ0FBQyxtREFBbUQ7Z0JBQzFFLE9BQU8sS0FBSyxRQUFRO1lBQ3RCO1lBRUEsSUFBSTtZQUVKLElBQUksaUJBQWlCO2dCQUNuQixJQUFJLFlBQVksT0FBTyxDQUFDLHVDQUF1QyxJQUM3RCxPQUFPLENBQUEsR0FBQSxrQ0FBZ0IsQUFBRCxFQUFFLE1BQU0sSUFBSSxDQUFDLGNBQWMsRUFBRSxRQUFRO2dCQUc3RCxJQUFJLEFBQUMsQ0FBQSxhQUFhLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsVUFBVSxDQUFDLEtBQUksS0FBTSxZQUFZLE9BQU8sQ0FBQyx5QkFBeUIsSUFBSTtvQkFDNUYsTUFBTSxZQUFZLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRO29CQUUvQyxPQUFPLENBQUEsR0FBQSw0QkFBVSxBQUFELEVBQ2QsYUFBYTt3QkFBQyxXQUFXO29CQUFJLElBQUksTUFDakMsYUFBYSxJQUFJLGFBQ2pCLElBQUksQ0FBQyxjQUFjO2dCQUV2QjtZQUNGO1lBRUEsSUFBSSxtQkFBbUIsb0JBQXFCO2dCQUMxQyxRQUFRLGNBQWMsQ0FBQyxvQkFBb0I7Z0JBQzNDLE9BQU8sZ0JBQWdCO1lBQ3pCO1lBRUEsT0FBTztRQUNUO0tBQUU7SUFFRixtQkFBbUI7UUFBQyxTQUFTLGtCQUFrQixJQUFJO1lBQ2pELE1BQU0sZUFBZSxJQUFJLENBQUMsWUFBWSxJQUFJLFNBQVMsWUFBWTtZQUMvRCxNQUFNLG9CQUFvQixnQkFBZ0IsYUFBYSxpQkFBaUI7WUFDeEUsTUFBTSxnQkFBZ0IsSUFBSSxDQUFDLFlBQVksS0FBSztZQUU1QyxJQUFJLFFBQVEsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxRQUFRLENBQUMsU0FBVSxDQUFBLEFBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLFlBQVksSUFBSyxhQUFZLEdBQUk7Z0JBQ2hHLE1BQU0sb0JBQW9CLGdCQUFnQixhQUFhLGlCQUFpQjtnQkFDeEUsTUFBTSxvQkFBb0IsQ0FBQyxxQkFBcUI7Z0JBRWhELElBQUk7b0JBQ0YsT0FBTyxLQUFLLEtBQUssQ0FBQztnQkFDcEIsRUFBRSxPQUFPLEdBQUc7b0JBQ1YsSUFBSSxtQkFBbUI7d0JBQ3JCLElBQUksRUFBRSxJQUFJLEtBQUssZUFDYixNQUFNLENBQUEsR0FBQSw0QkFBVSxBQUFELEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQSxHQUFBLDRCQUFVLEFBQUQsRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLEVBQUUsTUFBTSxJQUFJLENBQUMsUUFBUTt3QkFFakYsTUFBTTtvQkFDUjtnQkFDRjtZQUNGO1lBRUEsT0FBTztRQUNUO0tBQUU7SUFFRjs7O0dBR0MsR0FDRCxTQUFTO0lBRVQsZ0JBQWdCO0lBQ2hCLGdCQUFnQjtJQUVoQixrQkFBa0I7SUFDbEIsZUFBZTtJQUVmLEtBQUs7UUFDSCxVQUFVLENBQUEsR0FBQSx1QkFBUSxBQUFELEVBQUUsT0FBTyxDQUFDLFFBQVE7UUFDbkMsTUFBTSxDQUFBLEdBQUEsdUJBQVEsQUFBRCxFQUFFLE9BQU8sQ0FBQyxJQUFJO0lBQzdCO0lBRUEsZ0JBQWdCLFNBQVMsZUFBZSxNQUFNO1FBQzVDLE9BQU8sVUFBVSxPQUFPLFNBQVM7SUFDbkM7SUFFQSxTQUFTO1FBQ1AsUUFBUTtZQUNOLFVBQVU7WUFDVixnQkFBZ0I7UUFDbEI7SUFDRjtBQUNGO0FBRUEsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxPQUFPLENBQUM7SUFBQztJQUFVO0lBQU87SUFBUTtJQUFRO0lBQU87Q0FBUSxFQUFFLENBQUM7SUFDaEUsU0FBUyxPQUFPLENBQUMsT0FBTyxHQUFHLENBQUM7QUFDOUI7a0JBRWU7Ozs7O0FDM0pmO2tCQUVlO0lBQ2IsbUJBQW1CO0lBQ25CLG1CQUFtQjtJQUNuQixxQkFBcUI7QUFDdkI7Ozs7OzZDQ0F3QjtBQUp4Qjs7QUFDQTs7QUFDQTs7QUFKQTtBQU1lLFNBQVMsaUJBQWlCLElBQUksRUFBRSxPQUFPO0lBQ3BELE9BQU8sQ0FBQSxHQUFBLDRCQUFVLEFBQUQsRUFBRSxNQUFNLElBQUksQ0FBQSxHQUFBLHVCQUFRLEFBQUQsRUFBRSxPQUFPLENBQUMsZUFBZSxJQUFJLE9BQU8sTUFBTSxDQUFDO1FBQzVFLFNBQVMsU0FBUyxLQUFLLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxPQUFPO1lBQ3pDLElBQUksQ0FBQSxHQUFBLHVCQUFRLEFBQUQsRUFBRSxNQUFNLElBQUksQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxRQUFRLENBQUMsUUFBUTtnQkFDNUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLE1BQU0sUUFBUSxDQUFDO2dCQUNoQyxPQUFPO1lBQ1Q7WUFFQSxPQUFPLFFBQVEsY0FBYyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUU7UUFDNUM7SUFDRixHQUFHO0FBQ0w7Ozs7O0FDakJBOztBQUNBO2tCQUVlO0lBQ2IsR0FBRyxRQUFLO0lBQ1IsR0FBRyxDQUFBLEdBQUEsdUJBQVEsQUFBRCxDQUFDO0FBQ2I7Ozs7O0FDTkE7O0FBQ0E7O0FBQ0E7O2tCQUVlO0lBQ2IsV0FBVztJQUNYLFNBQVM7eUJBQ1AsQ0FBQSxHQUFBLGlDQUFlLEFBQUQ7a0JBQ2QsQ0FBQSxHQUFBLDBCQUFRLEFBQUQ7Y0FDUCxDQUFBLEdBQUEsc0JBQUksQUFBRDtJQUNMO0lBQ0EsV0FBVztRQUFDO1FBQVE7UUFBUztRQUFRO1FBQVE7UUFBTztLQUFPO0FBQzdEOzs7OztBQ1ZBOztBQUZBO2tCQUdlLE9BQU8sb0JBQW9CLGNBQWMsa0JBQWtCLENBQUEsR0FBQSxzQ0FBb0IsQUFBRDs7Ozs7QUNIN0Y7a0JBRWUsT0FBTyxhQUFhLGNBQWMsV0FBVzs7Ozs7QUNGNUQ7a0JBRWUsT0FBTyxTQUFTLGNBQWMsT0FBTzs7Ozs7QUN3Q3BELG1EQUNFO0FBREYsb0VBRUU7QUFGRiwyREFHRTtBQTdDRixNQUFNLGdCQUFnQixPQUFPLFdBQVcsZUFBZSxPQUFPLGFBQWE7QUFFM0U7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkMsR0FDRCxNQUFNLHdCQUF3QixBQUM1QixDQUFBLENBQUM7SUFDQyxPQUFPLGlCQUFpQjtRQUFDO1FBQWU7UUFBZ0I7S0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXO0FBQ25GLENBQUEsRUFBRyxPQUFPLGNBQWMsZUFBZSxVQUFVLE9BQU87QUFFMUQ7Ozs7Ozs7O0NBUUMsR0FDRCxNQUFNLGlDQUFpQyxBQUFDLENBQUE7SUFDdEMsT0FDRSxPQUFPLHNCQUFzQixlQUM3QixvQ0FBb0M7SUFDcEMsZ0JBQWdCLHFCQUNoQixPQUFPLEtBQUssYUFBYSxLQUFLO0FBRWxDLENBQUE7Ozs7O0FDdENBOztBQUZBO0FBSUE7Ozs7OztDQU1DLEdBQ0QsU0FBUyxjQUFjLElBQUk7SUFDekIsZUFBZTtJQUNmLFlBQVk7SUFDWixZQUFZO0lBQ1osWUFBWTtJQUNaLE9BQU8sQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxRQUFRLENBQUMsaUJBQWlCLE1BQU0sR0FBRyxDQUFDLENBQUE7UUFDL0MsT0FBTyxLQUFLLENBQUMsRUFBRSxLQUFLLE9BQU8sS0FBSyxLQUFLLENBQUMsRUFBRSxJQUFJLEtBQUssQ0FBQyxFQUFFO0lBQ3REO0FBQ0Y7QUFFQTs7Ozs7O0NBTUMsR0FDRCxTQUFTLGNBQWMsR0FBRztJQUN4QixNQUFNLE1BQU0sQ0FBQztJQUNiLE1BQU0sT0FBTyxPQUFPLElBQUksQ0FBQztJQUN6QixJQUFJO0lBQ0osTUFBTSxNQUFNLEtBQUssTUFBTTtJQUN2QixJQUFJO0lBQ0osSUFBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLElBQUs7UUFDeEIsTUFBTSxJQUFJLENBQUMsRUFBRTtRQUNiLEdBQUcsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDLElBQUk7SUFDckI7SUFDQSxPQUFPO0FBQ1Q7QUFFQTs7Ozs7O0NBTUMsR0FDRCxTQUFTLGVBQWUsUUFBUTtJQUM5QixTQUFTLFVBQVUsSUFBSSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsS0FBSztRQUMzQyxJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVE7UUFFeEIsSUFBSSxTQUFTLGFBQWEsT0FBTztRQUVqQyxNQUFNLGVBQWUsT0FBTyxRQUFRLENBQUMsQ0FBQztRQUN0QyxNQUFNLFNBQVMsU0FBUyxLQUFLLE1BQU07UUFDbkMsT0FBTyxDQUFDLFFBQVEsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxPQUFPLENBQUMsVUFBVSxPQUFPLE1BQU0sR0FBRztRQUV4RCxJQUFJLFFBQVE7WUFDVixJQUFJLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsVUFBVSxDQUFDLFFBQVEsT0FDM0IsTUFBTSxDQUFDLEtBQUssR0FBRztnQkFBQyxNQUFNLENBQUMsS0FBSztnQkFBRTthQUFNO2lCQUVwQyxNQUFNLENBQUMsS0FBSyxHQUFHO1lBR2pCLE9BQU8sQ0FBQztRQUNWO1FBRUEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxHQUMvQyxNQUFNLENBQUMsS0FBSyxHQUFHLEVBQUU7UUFHbkIsTUFBTSxTQUFTLFVBQVUsTUFBTSxPQUFPLE1BQU0sQ0FBQyxLQUFLLEVBQUU7UUFFcEQsSUFBSSxVQUFVLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQ3RDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsY0FBYyxNQUFNLENBQUMsS0FBSztRQUczQyxPQUFPLENBQUM7SUFDVjtJQUVBLElBQUksQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxVQUFVLENBQUMsYUFBYSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFVBQVUsQ0FBQyxTQUFTLE9BQU8sR0FBRztRQUNwRSxNQUFNLE1BQU0sQ0FBQztRQUViLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsWUFBWSxDQUFDLFVBQVUsQ0FBQyxNQUFNO1lBQ2xDLFVBQVUsY0FBYyxPQUFPLE9BQU8sS0FBSztRQUM3QztRQUVBLE9BQU87SUFDVDtJQUVBLE9BQU87QUFDVDtrQkFFZTs7Ozs7QUM1RmY7O0FBQ0E7O0FBSEE7QUFLQSxNQUFNLGFBQWEsT0FBTztBQUUxQixTQUFTLGdCQUFnQixNQUFNO0lBQzdCLE9BQU8sVUFBVSxPQUFPLFFBQVEsSUFBSSxHQUFHLFdBQVc7QUFDcEQ7QUFFQSxTQUFTLGVBQWUsS0FBSztJQUMzQixJQUFJLFVBQVUsU0FBUyxTQUFTLE1BQzlCLE9BQU87SUFHVCxPQUFPLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsT0FBTyxDQUFDLFNBQVMsTUFBTSxHQUFHLENBQUMsa0JBQWtCLE9BQU87QUFDbkU7QUFFQSxTQUFTLFlBQVksR0FBRztJQUN0QixNQUFNLFNBQVMsT0FBTyxNQUFNLENBQUM7SUFDN0IsTUFBTSxXQUFXO0lBQ2pCLElBQUk7SUFFSixNQUFRLFFBQVEsU0FBUyxJQUFJLENBQUMsS0FDNUIsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsRUFBRTtJQUc3QixPQUFPO0FBQ1Q7QUFFQSxNQUFNLG9CQUFvQixDQUFDLE1BQVEsaUNBQWlDLElBQUksQ0FBQyxJQUFJLElBQUk7QUFFakYsU0FBUyxpQkFBaUIsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLGtCQUFrQjtJQUMxRSxJQUFJLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsVUFBVSxDQUFDLFNBQ25CLE9BQU8sT0FBTyxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU87SUFHbEMsSUFBSSxvQkFDRixRQUFRO0lBR1YsSUFBSSxDQUFDLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsUUFBUSxDQUFDLFFBQVE7SUFFNUIsSUFBSSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFFBQVEsQ0FBQyxTQUNqQixPQUFPLE1BQU0sT0FBTyxDQUFDLFlBQVk7SUFHbkMsSUFBSSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFFBQVEsQ0FBQyxTQUNqQixPQUFPLE9BQU8sSUFBSSxDQUFDO0FBRXZCO0FBRUEsU0FBUyxhQUFhLE1BQU07SUFDMUIsT0FBTyxPQUFPLElBQUksR0FDZixXQUFXLEdBQUcsT0FBTyxDQUFDLG1CQUFtQixDQUFDLEdBQUcsTUFBTTtRQUNsRCxPQUFPLEtBQUssV0FBVyxLQUFLO0lBQzlCO0FBQ0o7QUFFQSxTQUFTLGVBQWUsR0FBRyxFQUFFLE1BQU07SUFDakMsTUFBTSxlQUFlLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsV0FBVyxDQUFDLE1BQU07SUFFN0M7UUFBQztRQUFPO1FBQU87S0FBTSxDQUFDLE9BQU8sQ0FBQyxDQUFBO1FBQzVCLE9BQU8sY0FBYyxDQUFDLEtBQUssYUFBYSxjQUFjO1lBQ3BELE9BQU8sU0FBUyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUk7Z0JBQzlCLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLFFBQVEsTUFBTSxNQUFNO1lBQ3pEO1lBQ0EsY0FBYztRQUNoQjtJQUNGO0FBQ0Y7QUFFQSxNQUFNO0lBQ0osWUFBWSxPQUFPLENBQUU7UUFDbkIsV0FBVyxJQUFJLENBQUMsR0FBRyxDQUFDO0lBQ3RCO0lBRUEsSUFBSSxNQUFNLEVBQUUsY0FBYyxFQUFFLE9BQU8sRUFBRTtRQUNuQyxNQUFNLE9BQU8sSUFBSTtRQUVqQixTQUFTLFVBQVUsTUFBTSxFQUFFLE9BQU8sRUFBRSxRQUFRO1lBQzFDLE1BQU0sVUFBVSxnQkFBZ0I7WUFFaEMsSUFBSSxDQUFDLFNBQ0gsTUFBTSxJQUFJLE1BQU07WUFHbEIsTUFBTSxNQUFNLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsT0FBTyxDQUFDLE1BQU07WUFFaEMsSUFBRyxDQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxhQUFhLGFBQWEsUUFBUyxhQUFhLGFBQWEsSUFBSSxDQUFDLElBQUksS0FBSyxPQUNsRyxJQUFJLENBQUMsT0FBTyxRQUFRLEdBQUcsZUFBZTtRQUUxQztRQUVBLE1BQU0sYUFBYSxDQUFDLFNBQVMsV0FDM0IsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLFFBQVEsVUFBWSxVQUFVLFFBQVEsU0FBUztRQUV6RSxJQUFJLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsYUFBYSxDQUFDLFdBQVcsa0JBQWtCLElBQUksQ0FBQyxXQUFXLEVBQ25FLFdBQVcsUUFBUTthQUNkLElBQUcsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxRQUFRLENBQUMsV0FBWSxDQUFBLFNBQVMsT0FBTyxJQUFJLEVBQUMsS0FBTSxDQUFDLGtCQUFrQixTQUNqRixXQUFXLENBQUEsR0FBQSw4QkFBWSxBQUFELEVBQUUsU0FBUzthQUVqQyxVQUFVLFFBQVEsVUFBVSxnQkFBZ0IsUUFBUTtRQUd0RCxPQUFPLElBQUk7SUFDYjtJQUVBLElBQUksTUFBTSxFQUFFLE1BQU0sRUFBRTtRQUNsQixTQUFTLGdCQUFnQjtRQUV6QixJQUFJLFFBQVE7WUFDVixNQUFNLE1BQU0sQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFO1lBRWhDLElBQUksS0FBSztnQkFDUCxNQUFNLFFBQVEsSUFBSSxDQUFDLElBQUk7Z0JBRXZCLElBQUksQ0FBQyxRQUNILE9BQU87Z0JBR1QsSUFBSSxXQUFXLE1BQ2IsT0FBTyxZQUFZO2dCQUdyQixJQUFJLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsVUFBVSxDQUFDLFNBQ25CLE9BQU8sT0FBTyxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU87Z0JBR2xDLElBQUksQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxRQUFRLENBQUMsU0FDakIsT0FBTyxPQUFPLElBQUksQ0FBQztnQkFHckIsTUFBTSxJQUFJLFVBQVU7WUFDdEI7UUFDRjtJQUNGO0lBRUEsSUFBSSxNQUFNLEVBQUUsT0FBTyxFQUFFO1FBQ25CLFNBQVMsZ0JBQWdCO1FBRXpCLElBQUksUUFBUTtZQUNWLE1BQU0sTUFBTSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUU7WUFFaEMsT0FBTyxDQUFDLENBQUUsQ0FBQSxPQUFPLElBQUksQ0FBQyxJQUFJLEtBQUssYUFBYyxDQUFBLENBQUMsV0FBVyxpQkFBaUIsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxRQUFPLENBQUM7UUFDMUc7UUFFQSxPQUFPO0lBQ1Q7SUFFQSxPQUFPLE1BQU0sRUFBRSxPQUFPLEVBQUU7UUFDdEIsTUFBTSxPQUFPLElBQUk7UUFDakIsSUFBSSxVQUFVO1FBRWQsU0FBUyxhQUFhLE9BQU87WUFDM0IsVUFBVSxnQkFBZ0I7WUFFMUIsSUFBSSxTQUFTO2dCQUNYLE1BQU0sTUFBTSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLE9BQU8sQ0FBQyxNQUFNO2dCQUVoQyxJQUFJLE9BQVEsQ0FBQSxDQUFDLFdBQVcsaUJBQWlCLE1BQU0sSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLFFBQU8sR0FBSTtvQkFDeEUsT0FBTyxJQUFJLENBQUMsSUFBSTtvQkFFaEIsVUFBVTtnQkFDWjtZQUNGO1FBQ0Y7UUFFQSxJQUFJLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsT0FBTyxDQUFDLFNBQ2hCLE9BQU8sT0FBTyxDQUFDO2FBRWYsYUFBYTtRQUdmLE9BQU87SUFDVDtJQUVBLE1BQU0sT0FBTyxFQUFFO1FBQ2IsTUFBTSxPQUFPLE9BQU8sSUFBSSxDQUFDLElBQUk7UUFDN0IsSUFBSSxJQUFJLEtBQUssTUFBTTtRQUNuQixJQUFJLFVBQVU7UUFFZCxNQUFPLElBQUs7WUFDVixNQUFNLE1BQU0sSUFBSSxDQUFDLEVBQUU7WUFDbkIsSUFBRyxDQUFDLFdBQVcsaUJBQWlCLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssU0FBUyxPQUFPO2dCQUNwRSxPQUFPLElBQUksQ0FBQyxJQUFJO2dCQUNoQixVQUFVO1lBQ1o7UUFDRjtRQUVBLE9BQU87SUFDVDtJQUVBLFVBQVUsTUFBTSxFQUFFO1FBQ2hCLE1BQU0sT0FBTyxJQUFJO1FBQ2pCLE1BQU0sVUFBVSxDQUFDO1FBRWpCLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxDQUFDLE9BQU87WUFDMUIsTUFBTSxNQUFNLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsT0FBTyxDQUFDLFNBQVM7WUFFbkMsSUFBSSxLQUFLO2dCQUNQLElBQUksQ0FBQyxJQUFJLEdBQUcsZUFBZTtnQkFDM0IsT0FBTyxJQUFJLENBQUMsT0FBTztnQkFDbkI7WUFDRjtZQUVBLE1BQU0sYUFBYSxTQUFTLGFBQWEsVUFBVSxPQUFPLFFBQVEsSUFBSTtZQUV0RSxJQUFJLGVBQWUsUUFDakIsT0FBTyxJQUFJLENBQUMsT0FBTztZQUdyQixJQUFJLENBQUMsV0FBVyxHQUFHLGVBQWU7WUFFbEMsT0FBTyxDQUFDLFdBQVcsR0FBRztRQUN4QjtRQUVBLE9BQU8sSUFBSTtJQUNiO0lBRUEsT0FBTyxHQUFHLE9BQU8sRUFBRTtRQUNqQixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSztJQUMxQztJQUVBLE9BQU8sU0FBUyxFQUFFO1FBQ2hCLE1BQU0sTUFBTSxPQUFPLE1BQU0sQ0FBQztRQUUxQixDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxPQUFPO1lBQzFCLFNBQVMsUUFBUSxVQUFVLFNBQVUsQ0FBQSxHQUFHLENBQUMsT0FBTyxHQUFHLGFBQWEsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxPQUFPLENBQUMsU0FBUyxNQUFNLElBQUksQ0FBQyxRQUFRLEtBQUk7UUFDaEg7UUFFQSxPQUFPO0lBQ1Q7SUFFQSxDQUFDLE9BQU8sUUFBUSxDQUFDLEdBQUc7UUFDbEIsT0FBTyxPQUFPLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsT0FBTyxRQUFRLENBQUM7SUFDdkQ7SUFFQSxXQUFXO1FBQ1QsT0FBTyxPQUFPLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxNQUFNLEdBQUssU0FBUyxPQUFPLE9BQU8sSUFBSSxDQUFDO0lBQzVGO0lBRUEsSUFBSSxDQUFDLE9BQU8sV0FBVyxDQUFDLEdBQUc7UUFDekIsT0FBTztJQUNUO0lBRUEsT0FBTyxLQUFLLEtBQUssRUFBRTtRQUNqQixPQUFPLGlCQUFpQixJQUFJLEdBQUcsUUFBUSxJQUFJLElBQUksQ0FBQztJQUNsRDtJQUVBLE9BQU8sT0FBTyxLQUFLLEVBQUUsR0FBRyxPQUFPLEVBQUU7UUFDL0IsTUFBTSxXQUFXLElBQUksSUFBSSxDQUFDO1FBRTFCLFFBQVEsT0FBTyxDQUFDLENBQUMsU0FBVyxTQUFTLEdBQUcsQ0FBQztRQUV6QyxPQUFPO0lBQ1Q7SUFFQSxPQUFPLFNBQVMsTUFBTSxFQUFFO1FBQ3RCLE1BQU0sWUFBWSxJQUFJLENBQUMsV0FBVyxHQUFJLElBQUksQ0FBQyxXQUFXLEdBQUc7WUFDdkQsV0FBVyxDQUFDO1FBQ2Q7UUFFQSxNQUFNLFlBQVksVUFBVSxTQUFTO1FBQ3JDLE1BQU0sWUFBWSxJQUFJLENBQUMsU0FBUztRQUVoQyxTQUFTLGVBQWUsT0FBTztZQUM3QixNQUFNLFVBQVUsZ0JBQWdCO1lBRWhDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFO2dCQUN2QixlQUFlLFdBQVc7Z0JBQzFCLFNBQVMsQ0FBQyxRQUFRLEdBQUc7WUFDdkI7UUFDRjtRQUVBLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsT0FBTyxDQUFDLFVBQVUsT0FBTyxPQUFPLENBQUMsa0JBQWtCLGVBQWU7UUFFeEUsT0FBTyxJQUFJO0lBQ2I7QUFDRjtBQUVBLGFBQWEsUUFBUSxDQUFDO0lBQUM7SUFBZ0I7SUFBa0I7SUFBVTtJQUFtQjtJQUFjO0NBQWdCO0FBRXBILHdCQUF3QjtBQUN4QixDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLGlCQUFpQixDQUFDLGFBQWEsU0FBUyxFQUFFLENBQUMsRUFBQyxLQUFLLEVBQUMsRUFBRTtJQUN4RCxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxXQUFXLEtBQUssSUFBSSxLQUFLLENBQUMsSUFBSSxxQkFBcUI7SUFDdkUsT0FBTztRQUNMLEtBQUssSUFBTTtRQUNYLEtBQUksV0FBVztZQUNiLElBQUksQ0FBQyxPQUFPLEdBQUc7UUFDakI7SUFDRjtBQUNGO0FBRUEsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxhQUFhLENBQUM7a0JBRUw7Ozs7O0FDdlNmOztBQUZBO0FBSUEsdURBQXVEO0FBQ3ZELDZEQUE2RDtBQUM3RCxNQUFNLG9CQUFvQixDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFdBQVcsQ0FBQztJQUMxQztJQUFPO0lBQWlCO0lBQWtCO0lBQWdCO0lBQzFEO0lBQVc7SUFBUTtJQUFRO0lBQXFCO0lBQ2hEO0lBQWlCO0lBQVk7SUFBZ0I7SUFDN0M7SUFBVztJQUFlO0NBQzNCO0FBRUQ7Ozs7Ozs7Ozs7Ozs7Q0FhQyxxQkFDYyxDQUFBO0lBQ2IsTUFBTSxTQUFTLENBQUM7SUFDaEIsSUFBSTtJQUNKLElBQUk7SUFDSixJQUFJO0lBRUosY0FBYyxXQUFXLEtBQUssQ0FBQyxNQUFNLE9BQU8sQ0FBQyxTQUFTLE9BQU8sSUFBSTtRQUMvRCxJQUFJLEtBQUssT0FBTyxDQUFDO1FBQ2pCLE1BQU0sS0FBSyxTQUFTLENBQUMsR0FBRyxHQUFHLElBQUksR0FBRyxXQUFXO1FBQzdDLE1BQU0sS0FBSyxTQUFTLENBQUMsSUFBSSxHQUFHLElBQUk7UUFFaEMsSUFBSSxDQUFDLE9BQVEsTUFBTSxDQUFDLElBQUksSUFBSSxpQkFBaUIsQ0FBQyxJQUFJLEVBQ2hEO1FBR0YsSUFBSSxRQUFRO1lBQ1YsSUFBSSxNQUFNLENBQUMsSUFBSSxFQUNiLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2lCQUVqQixNQUFNLENBQUMsSUFBSSxHQUFHO2dCQUFDO2FBQUk7ZUFHckIsTUFBTSxDQUFDLElBQUksR0FBRyxNQUFNLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLEdBQUcsT0FBTyxNQUFNO0lBRTNEO0lBRUEsT0FBTztBQUNUOzs7Ozs2Q0NwRHdCO0FBRnhCO0FBRWUsU0FBUyxTQUFTLEtBQUs7SUFDcEMsT0FBTyxDQUFDLENBQUUsQ0FBQSxTQUFTLE1BQU0sVUFBVSxBQUFEO0FBQ3BDOzs7OztBQ0ZBOztBQUNBOztBQUhBO0FBS0E7Ozs7Ozs7O0NBUUMsR0FDRCxTQUFTLGNBQWMsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPO0lBQzdDLDZDQUE2QztJQUM3QyxDQUFBLEdBQUEsNEJBQVUsQUFBRCxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUUsV0FBVyxPQUFPLGFBQWEsU0FBUyxDQUFBLEdBQUEsNEJBQVUsQUFBRCxFQUFFLFlBQVksRUFBRSxRQUFRO0lBQy9GLElBQUksQ0FBQyxJQUFJLEdBQUc7QUFDZDtBQUVBLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsUUFBUSxDQUFDLGVBQWUsQ0FBQSxHQUFBLDRCQUFVLEFBQUQsR0FBRztJQUN4QyxZQUFZO0FBQ2Q7a0JBRWU7Ozs7O0FDeEJmOztBQUNBOztBQUNBOztBQUNBOztBQUVBLE1BQU0sZ0JBQWdCO0lBQ3BCLE1BQU0sQ0FBQSxHQUFBLHNCQUFXLEFBQUQ7SUFDaEIsS0FBSyxDQUFBLEdBQUEscUJBQVUsQUFBRDtBQUNoQjtBQUVBLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsT0FBTyxDQUFDLGVBQWUsQ0FBQyxJQUFJO0lBQ2hDLElBQUksSUFBSTtRQUNOLElBQUk7WUFDRixPQUFPLGNBQWMsQ0FBQyxJQUFJLFFBQVE7Z0JBQUM7WUFBSztRQUMxQyxFQUFFLE9BQU8sR0FBRztRQUNWLG9DQUFvQztRQUN0QztRQUNBLE9BQU8sY0FBYyxDQUFDLElBQUksZUFBZTtZQUFDO1FBQUs7SUFDakQ7QUFDRjtBQUVBLE1BQU0sZUFBZSxDQUFDLFNBQVcsQ0FBQyxFQUFFLEVBQUUsT0FBTyxDQUFDO0FBRTlDLE1BQU0sbUJBQW1CLENBQUMsVUFBWSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFVBQVUsQ0FBQyxZQUFZLFlBQVksUUFBUSxZQUFZO2tCQUVwRjtJQUNiLFlBQVksQ0FBQztRQUNYLFdBQVcsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxPQUFPLENBQUMsWUFBWSxXQUFXO1lBQUM7U0FBUztRQUUxRCxNQUFNLEVBQUMsTUFBTSxFQUFDLEdBQUc7UUFDakIsSUFBSTtRQUNKLElBQUk7UUFFSixNQUFNLGtCQUFrQixDQUFDO1FBRXpCLElBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLElBQUs7WUFDL0IsZ0JBQWdCLFFBQVEsQ0FBQyxFQUFFO1lBQzNCLElBQUk7WUFFSixVQUFVO1lBRVYsSUFBSSxDQUFDLGlCQUFpQixnQkFBZ0I7Z0JBQ3BDLFVBQVUsYUFBYSxDQUFDLEFBQUMsQ0FBQSxLQUFLLE9BQU8sY0FBYSxFQUFHLFdBQVcsR0FBRztnQkFFbkUsSUFBSSxZQUFZLFdBQ2QsTUFBTSxJQUFJLENBQUEsR0FBQSw0QkFBVSxBQUFELEVBQUUsQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLENBQUMsQ0FBQztZQUVsRDtZQUVBLElBQUksU0FDRjtZQUdGLGVBQWUsQ0FBQyxNQUFNLE1BQU0sRUFBRSxHQUFHO1FBQ25DO1FBRUEsSUFBSSxDQUFDLFNBQVM7WUFFWixNQUFNLFVBQVUsT0FBTyxPQUFPLENBQUMsaUJBQzVCLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxNQUFNLEdBQUssQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FDbkMsQ0FBQSxVQUFVLFFBQVEsd0NBQXdDLCtCQUE4QjtZQUc3RixJQUFJLElBQUksU0FDTCxRQUFRLE1BQU0sR0FBRyxJQUFJLGNBQWMsUUFBUSxHQUFHLENBQUMsY0FBYyxJQUFJLENBQUMsUUFBUSxNQUFNLGFBQWEsT0FBTyxDQUFDLEVBQUUsSUFDeEc7WUFFRixNQUFNLElBQUksQ0FBQSxHQUFBLDRCQUFVLEFBQUQsRUFDakIsQ0FBQyxxREFBcUQsQ0FBQyxHQUFHLEdBQzFEO1FBRUo7UUFFQSxPQUFPO0lBQ1Q7SUFDQSxVQUFVO0FBQ1o7Ozs7O0FDMUVBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQUNBOztBQWRBO0FBZ0JBLFNBQVMscUJBQXFCLFFBQVEsRUFBRSxnQkFBZ0I7SUFDdEQsSUFBSSxnQkFBZ0I7SUFDcEIsTUFBTSxlQUFlLENBQUEsR0FBQSw2QkFBVyxBQUFELEVBQUUsSUFBSTtJQUVyQyxPQUFPLENBQUE7UUFDTCxNQUFNLFNBQVMsRUFBRSxNQUFNO1FBQ3ZCLE1BQU0sUUFBUSxFQUFFLGdCQUFnQixHQUFHLEVBQUUsS0FBSyxHQUFHO1FBQzdDLE1BQU0sZ0JBQWdCLFNBQVM7UUFDL0IsTUFBTSxPQUFPLGFBQWE7UUFDMUIsTUFBTSxVQUFVLFVBQVU7UUFFMUIsZ0JBQWdCO1FBRWhCLE1BQU0sT0FBTztZQUNYO1lBQ0E7WUFDQSxVQUFVLFFBQVMsU0FBUyxRQUFTO1lBQ3JDLE9BQU87WUFDUCxNQUFNLE9BQU8sT0FBTztZQUNwQixXQUFXLFFBQVEsU0FBUyxVQUFVLEFBQUMsQ0FBQSxRQUFRLE1BQUssSUFBSyxPQUFPO1lBQ2hFLE9BQU87UUFDVDtRQUVBLElBQUksQ0FBQyxtQkFBbUIsYUFBYSxTQUFTLEdBQUc7UUFFakQsU0FBUztJQUNYO0FBQ0Y7QUFFQSxNQUFNLHdCQUF3QixPQUFPLG1CQUFtQjtrQkFFekMseUJBQXlCLFNBQVUsTUFBTTtJQUN0RCxPQUFPLElBQUksUUFBUSxTQUFTLG1CQUFtQixPQUFPLEVBQUUsTUFBTTtRQUM1RCxJQUFJLGNBQWMsT0FBTyxJQUFJO1FBQzdCLE1BQU0saUJBQWlCLENBQUEsR0FBQSw4QkFBWSxBQUFELEVBQUUsSUFBSSxDQUFDLE9BQU8sT0FBTyxFQUFFLFNBQVM7UUFDbEUsSUFBSSxFQUFDLFlBQVksRUFBRSxhQUFhLEVBQUMsR0FBRztRQUNwQyxJQUFJO1FBQ0osU0FBUztZQUNQLElBQUksT0FBTyxXQUFXLEVBQ3BCLE9BQU8sV0FBVyxDQUFDLFdBQVcsQ0FBQztZQUdqQyxJQUFJLE9BQU8sTUFBTSxFQUNmLE9BQU8sTUFBTSxDQUFDLG1CQUFtQixDQUFDLFNBQVM7UUFFL0M7UUFFQSxJQUFJO1FBRUosSUFBSSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFVBQVUsQ0FBQyxjQUFjO1lBQ2pDLElBQUksQ0FBQSxHQUFBLHVCQUFRLEFBQUQsRUFBRSxxQkFBcUIsSUFBSSxDQUFBLEdBQUEsdUJBQVEsQUFBRCxFQUFFLDhCQUE4QixFQUMzRSxlQUFlLGNBQWMsQ0FBQyxRQUFRLHlCQUF5QjtpQkFDMUQsSUFBSSxBQUFDLENBQUEsY0FBYyxlQUFlLGNBQWMsRUFBQyxNQUFPLE9BQU87Z0JBQ3BFLDBFQUEwRTtnQkFDMUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxPQUFPLEdBQUcsY0FBYyxZQUFZLEtBQUssQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFBLFFBQVMsTUFBTSxJQUFJLElBQUksTUFBTSxDQUFDLFdBQVcsRUFBRTtnQkFDOUcsZUFBZSxjQUFjLENBQUM7b0JBQUMsUUFBUTt1QkFBMEI7aUJBQU8sQ0FBQyxJQUFJLENBQUM7WUFDaEY7UUFDRjtRQUVBLElBQUksVUFBVSxJQUFJO1FBRWxCLDRCQUE0QjtRQUM1QixJQUFJLE9BQU8sSUFBSSxFQUFFO1lBQ2YsTUFBTSxXQUFXLE9BQU8sSUFBSSxDQUFDLFFBQVEsSUFBSTtZQUN6QyxNQUFNLFdBQVcsT0FBTyxJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVMsbUJBQW1CLE9BQU8sSUFBSSxDQUFDLFFBQVEsS0FBSztZQUM3RixlQUFlLEdBQUcsQ0FBQyxpQkFBaUIsV0FBVyxLQUFLLFdBQVcsTUFBTTtRQUN2RTtRQUVBLE1BQU0sV0FBVyxDQUFBLEdBQUEsK0JBQWEsQUFBRCxFQUFFLE9BQU8sT0FBTyxFQUFFLE9BQU8sR0FBRztRQUV6RCxRQUFRLElBQUksQ0FBQyxPQUFPLE1BQU0sQ0FBQyxXQUFXLElBQUksQ0FBQSxHQUFBLDBCQUFRLEFBQUQsRUFBRSxVQUFVLE9BQU8sTUFBTSxFQUFFLE9BQU8sZ0JBQWdCLEdBQUc7UUFFdEcsZ0NBQWdDO1FBQ2hDLFFBQVEsT0FBTyxHQUFHLE9BQU8sT0FBTztRQUVoQyxTQUFTO1lBQ1AsSUFBSSxDQUFDLFNBQ0g7WUFFRix1QkFBdUI7WUFDdkIsTUFBTSxrQkFBa0IsQ0FBQSxHQUFBLDhCQUFZLEFBQUQsRUFBRSxJQUFJLENBQ3ZDLDJCQUEyQixXQUFXLFFBQVEscUJBQXFCO1lBRXJFLE1BQU0sZUFBZSxDQUFDLGdCQUFnQixpQkFBaUIsVUFBVSxpQkFBaUIsU0FDaEYsUUFBUSxZQUFZLEdBQUcsUUFBUSxRQUFRO1lBQ3pDLE1BQU0sV0FBVztnQkFDZixNQUFNO2dCQUNOLFFBQVEsUUFBUSxNQUFNO2dCQUN0QixZQUFZLFFBQVEsVUFBVTtnQkFDOUIsU0FBUztnQkFDVDtnQkFDQTtZQUNGO1lBRUEsQ0FBQSxHQUFBLHdCQUFNLEFBQUQsRUFBRSxTQUFTLFNBQVMsS0FBSztnQkFDNUIsUUFBUTtnQkFDUjtZQUNGLEdBQUcsU0FBUyxRQUFRLEdBQUc7Z0JBQ3JCLE9BQU87Z0JBQ1A7WUFDRixHQUFHO1lBRUgsbUJBQW1CO1lBQ25CLFVBQVU7UUFDWjtRQUVBLElBQUksZUFBZSxTQUNqQiw2QkFBNkI7UUFDN0IsUUFBUSxTQUFTLEdBQUc7YUFFcEIsOENBQThDO1FBQzlDLFFBQVEsa0JBQWtCLEdBQUcsU0FBUztZQUNwQyxJQUFJLENBQUMsV0FBVyxRQUFRLFVBQVUsS0FBSyxHQUNyQztZQUdGLHFFQUFxRTtZQUNyRSw2QkFBNkI7WUFDN0IsdUVBQXVFO1lBQ3ZFLGdFQUFnRTtZQUNoRSxJQUFJLFFBQVEsTUFBTSxLQUFLLEtBQUssQ0FBRSxDQUFBLFFBQVEsV0FBVyxJQUFJLFFBQVEsV0FBVyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUEsR0FDNUY7WUFFRixzRUFBc0U7WUFDdEUsaURBQWlEO1lBQ2pELFdBQVc7UUFDYjtRQUdGLDRFQUE0RTtRQUM1RSxRQUFRLE9BQU8sR0FBRyxTQUFTO1lBQ3pCLElBQUksQ0FBQyxTQUNIO1lBR0YsT0FBTyxJQUFJLENBQUEsR0FBQSw0QkFBVSxBQUFELEVBQUUsbUJBQW1CLENBQUEsR0FBQSw0QkFBVSxBQUFELEVBQUUsWUFBWSxFQUFFLFFBQVE7WUFFMUUsbUJBQW1CO1lBQ25CLFVBQVU7UUFDWjtRQUVBLGtDQUFrQztRQUNsQyxRQUFRLE9BQU8sR0FBRyxTQUFTO1lBQ3pCLGdEQUFnRDtZQUNoRCxtREFBbUQ7WUFDbkQsT0FBTyxJQUFJLENBQUEsR0FBQSw0QkFBVSxBQUFELEVBQUUsaUJBQWlCLENBQUEsR0FBQSw0QkFBVSxBQUFELEVBQUUsV0FBVyxFQUFFLFFBQVE7WUFFdkUsbUJBQW1CO1lBQ25CLFVBQVU7UUFDWjtRQUVBLGlCQUFpQjtRQUNqQixRQUFRLFNBQVMsR0FBRyxTQUFTO1lBQzNCLElBQUksc0JBQXNCLE9BQU8sT0FBTyxHQUFHLGdCQUFnQixPQUFPLE9BQU8sR0FBRyxnQkFBZ0I7WUFDNUYsTUFBTSxlQUFlLE9BQU8sWUFBWSxJQUFJLENBQUEsR0FBQSw4QkFBb0IsQUFBRDtZQUMvRCxJQUFJLE9BQU8sbUJBQW1CLEVBQzVCLHNCQUFzQixPQUFPLG1CQUFtQjtZQUVsRCxPQUFPLElBQUksQ0FBQSxHQUFBLDRCQUFVLEFBQUQsRUFDbEIscUJBQ0EsYUFBYSxtQkFBbUIsR0FBRyxDQUFBLEdBQUEsNEJBQVUsQUFBRCxFQUFFLFNBQVMsR0FBRyxDQUFBLEdBQUEsNEJBQVUsQUFBRCxFQUFFLFlBQVksRUFDakYsUUFDQTtZQUVGLG1CQUFtQjtZQUNuQixVQUFVO1FBQ1o7UUFFQSxrQkFBa0I7UUFDbEIsa0VBQWtFO1FBQ2xFLDhEQUE4RDtRQUM5RCxJQUFHLENBQUEsR0FBQSx1QkFBUSxBQUFELEVBQUUscUJBQXFCLEVBQUU7WUFDakMsaUJBQWlCLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsVUFBVSxDQUFDLGtCQUFtQixDQUFBLGdCQUFnQixjQUFjLE9BQU07WUFFekYsSUFBSSxpQkFBa0Isa0JBQWtCLFNBQVMsQ0FBQSxHQUFBLGlDQUFlLEFBQUQsRUFBRSxXQUFZO2dCQUMzRSxrQkFBa0I7Z0JBQ2xCLE1BQU0sWUFBWSxPQUFPLGNBQWMsSUFBSSxPQUFPLGNBQWMsSUFBSSxDQUFBLEdBQUEseUJBQU8sQUFBRCxFQUFFLElBQUksQ0FBQyxPQUFPLGNBQWM7Z0JBRXRHLElBQUksV0FDRixlQUFlLEdBQUcsQ0FBQyxPQUFPLGNBQWMsRUFBRTtZQUU5QztRQUNGO1FBRUEsMkNBQTJDO1FBQzNDLGdCQUFnQixhQUFhLGVBQWUsY0FBYyxDQUFDO1FBRTNELDZCQUE2QjtRQUM3QixJQUFJLHNCQUFzQixTQUN4QixDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLE9BQU8sQ0FBQyxlQUFlLE1BQU0sSUFBSSxTQUFTLGlCQUFpQixHQUFHLEVBQUUsR0FBRztZQUN2RSxRQUFRLGdCQUFnQixDQUFDLEtBQUs7UUFDaEM7UUFHRiwyQ0FBMkM7UUFDM0MsSUFBSSxDQUFDLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsV0FBVyxDQUFDLE9BQU8sZUFBZSxHQUMzQyxRQUFRLGVBQWUsR0FBRyxDQUFDLENBQUMsT0FBTyxlQUFlO1FBR3BELHdDQUF3QztRQUN4QyxJQUFJLGdCQUFnQixpQkFBaUIsUUFDbkMsUUFBUSxZQUFZLEdBQUcsT0FBTyxZQUFZO1FBRzVDLDRCQUE0QjtRQUM1QixJQUFJLE9BQU8sT0FBTyxrQkFBa0IsS0FBSyxZQUN2QyxRQUFRLGdCQUFnQixDQUFDLFlBQVkscUJBQXFCLE9BQU8sa0JBQWtCLEVBQUU7UUFHdkYseUNBQXlDO1FBQ3pDLElBQUksT0FBTyxPQUFPLGdCQUFnQixLQUFLLGNBQWMsUUFBUSxNQUFNLEVBQ2pFLFFBQVEsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFlBQVkscUJBQXFCLE9BQU8sZ0JBQWdCO1FBRzFGLElBQUksT0FBTyxXQUFXLElBQUksT0FBTyxNQUFNLEVBQUU7WUFDdkMsc0JBQXNCO1lBQ3RCLHNDQUFzQztZQUN0QyxhQUFhLENBQUE7Z0JBQ1gsSUFBSSxDQUFDLFNBQ0g7Z0JBRUYsT0FBTyxDQUFDLFVBQVUsT0FBTyxJQUFJLEdBQUcsSUFBSSxDQUFBLEdBQUEsK0JBQWEsQUFBRCxFQUFFLE1BQU0sUUFBUSxXQUFXO2dCQUMzRSxRQUFRLEtBQUs7Z0JBQ2IsVUFBVTtZQUNaO1lBRUEsT0FBTyxXQUFXLElBQUksT0FBTyxXQUFXLENBQUMsU0FBUyxDQUFDO1lBQ25ELElBQUksT0FBTyxNQUFNLEVBQ2YsT0FBTyxNQUFNLENBQUMsT0FBTyxHQUFHLGVBQWUsT0FBTyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsU0FBUztRQUVuRjtRQUVBLE1BQU0sV0FBVyxDQUFBLEdBQUEsK0JBQWEsQUFBRCxFQUFFO1FBRS9CLElBQUksWUFBWSxDQUFBLEdBQUEsdUJBQVEsQUFBRCxFQUFFLFNBQVMsQ0FBQyxPQUFPLENBQUMsY0FBYyxJQUFJO1lBQzNELE9BQU8sSUFBSSxDQUFBLEdBQUEsNEJBQVUsQUFBRCxFQUFFLDBCQUEwQixXQUFXLEtBQUssQ0FBQSxHQUFBLDRCQUFVLEFBQUQsRUFBRSxlQUFlLEVBQUU7WUFDNUY7UUFDRjtRQUdBLG1CQUFtQjtRQUNuQixRQUFRLElBQUksQ0FBQyxlQUFlO0lBQzlCO0FBQ0Y7Ozs7OzZDQ3RQd0I7QUFYeEI7O0FBRkE7QUFhZSxTQUFTLE9BQU8sT0FBTyxFQUFFLE1BQU0sRUFBRSxRQUFRO0lBQ3RELE1BQU0saUJBQWlCLFNBQVMsTUFBTSxDQUFDLGNBQWM7SUFDckQsSUFBSSxDQUFDLFNBQVMsTUFBTSxJQUFJLENBQUMsa0JBQWtCLGVBQWUsU0FBUyxNQUFNLEdBQ3ZFLFFBQVE7U0FFUixPQUFPLElBQUksQ0FBQSxHQUFBLDRCQUFVLEFBQUQsRUFDbEIscUNBQXFDLFNBQVMsTUFBTSxFQUNwRDtRQUFDLENBQUEsR0FBQSw0QkFBVSxBQUFELEVBQUUsZUFBZTtRQUFFLENBQUEsR0FBQSw0QkFBVSxBQUFELEVBQUUsZ0JBQWdCO0tBQUMsQ0FBQyxLQUFLLEtBQUssQ0FBQyxTQUFTLE1BQU0sR0FBRyxPQUFPLEVBQUUsRUFDaEcsU0FBUyxNQUFNLEVBQ2YsU0FBUyxPQUFPLEVBQ2hCO0FBR047Ozs7O0FDMUJBOztBQUNBOztrQkFFZSxDQUFBLEdBQUEsdUJBQVEsQUFBRCxFQUFFLHFCQUFxQixHQUUzQyxnREFBZ0Q7QUFDaEQ7SUFDRSxPQUFNLElBQUksRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsTUFBTTtRQUM5QyxNQUFNLFNBQVM7WUFBQyxPQUFPLE1BQU0sbUJBQW1CO1NBQU87UUFFdkQsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxRQUFRLENBQUMsWUFBWSxPQUFPLElBQUksQ0FBQyxhQUFhLElBQUksS0FBSyxTQUFTLFdBQVc7UUFFakYsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxRQUFRLENBQUMsU0FBUyxPQUFPLElBQUksQ0FBQyxVQUFVO1FBRTlDLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsUUFBUSxDQUFDLFdBQVcsT0FBTyxJQUFJLENBQUMsWUFBWTtRQUVsRCxXQUFXLFFBQVEsT0FBTyxJQUFJLENBQUM7UUFFL0IsU0FBUyxNQUFNLEdBQUcsT0FBTyxJQUFJLENBQUM7SUFDaEM7SUFFQSxNQUFLLElBQUk7UUFDUCxNQUFNLFFBQVEsU0FBUyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksT0FBTyxlQUFlLE9BQU87UUFDckUsT0FBUSxRQUFRLG1CQUFtQixLQUFLLENBQUMsRUFBRSxJQUFJO0lBQ2pEO0lBRUEsUUFBTyxJQUFJO1FBQ1QsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLElBQUksS0FBSyxHQUFHLEtBQUs7SUFDcEM7QUFDRixJQUlBLDRFQUE0RTtBQUM1RTtJQUNFLFVBQVM7SUFDVDtRQUNFLE9BQU87SUFDVDtJQUNBLFdBQVU7QUFDWjs7Ozs7NkNDekJzQjtBQWJ4Qjs7QUFDQTs7QUFIQTtBQWVlLFNBQVMsY0FBYyxPQUFPLEVBQUUsWUFBWTtJQUN6RCxJQUFJLFdBQVcsQ0FBQyxDQUFBLEdBQUEsK0JBQWEsQUFBRCxFQUFFLGVBQzVCLE9BQU8sQ0FBQSxHQUFBLDZCQUFXLEFBQUQsRUFBRSxTQUFTO0lBRTlCLE9BQU87QUFDVDs7Ozs7NkNDWHdCO0FBVHhCO0FBU2UsU0FBUyxjQUFjLEdBQUc7SUFDdkMsZ0dBQWdHO0lBQ2hHLGdHQUFnRztJQUNoRyxrRUFBa0U7SUFDbEUsT0FBTyw4QkFBOEIsSUFBSSxDQUFDO0FBQzVDOzs7Ozs2Q0NKd0I7QUFWeEI7QUFVZSxTQUFTLFlBQVksT0FBTyxFQUFFLFdBQVc7SUFDdEQsT0FBTyxjQUNILFFBQVEsT0FBTyxDQUFDLFVBQVUsTUFBTSxNQUFNLFlBQVksT0FBTyxDQUFDLFFBQVEsTUFDbEU7QUFDTjs7Ozs7QUNaQTs7QUFDQTs7QUFIQTtrQkFLZSxDQUFBLEdBQUEsdUJBQVEsQUFBRCxFQUFFLHFCQUFxQixHQUkzQyxBQUZGLHFFQUFxRTtBQUNyRSxxRUFBcUU7QUFDbEUsU0FBUztJQUNSLE1BQU0sT0FBTyxrQkFBa0IsSUFBSSxDQUFDLFVBQVUsU0FBUztJQUN2RCxNQUFNLGlCQUFpQixTQUFTLGFBQWEsQ0FBQztJQUM5QyxJQUFJO0lBRUo7Ozs7O0lBS0EsR0FDQSxTQUFTLFdBQVcsR0FBRztRQUNyQixJQUFJLE9BQU87UUFFWCxJQUFJLE1BQU07WUFDUix1REFBdUQ7WUFDdkQsZUFBZSxZQUFZLENBQUMsUUFBUTtZQUNwQyxPQUFPLGVBQWUsSUFBSTtRQUM1QjtRQUVBLGVBQWUsWUFBWSxDQUFDLFFBQVE7UUFFcEMsd0ZBQXdGO1FBQ3hGLE9BQU87WUFDTCxNQUFNLGVBQWUsSUFBSTtZQUN6QixVQUFVLGVBQWUsUUFBUSxHQUFHLGVBQWUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLE1BQU07WUFDaEYsTUFBTSxlQUFlLElBQUk7WUFDekIsUUFBUSxlQUFlLE1BQU0sR0FBRyxlQUFlLE1BQU0sQ0FBQyxPQUFPLENBQUMsT0FBTyxNQUFNO1lBQzNFLE1BQU0sZUFBZSxJQUFJLEdBQUcsZUFBZSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sTUFBTTtZQUNwRSxVQUFVLGVBQWUsUUFBUTtZQUNqQyxNQUFNLGVBQWUsSUFBSTtZQUN6QixVQUFVLEFBQUMsZUFBZSxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sTUFDL0MsZUFBZSxRQUFRLEdBQ3ZCLE1BQU0sZUFBZSxRQUFRO1FBQ2pDO0lBQ0Y7SUFFQSxZQUFZLFdBQVcsT0FBTyxRQUFRLENBQUMsSUFBSTtJQUUzQzs7Ozs7SUFLQSxHQUNBLE9BQU8sU0FBUyxnQkFBZ0IsVUFBVTtRQUN4QyxNQUFNLFNBQVMsQUFBQyxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFFBQVEsQ0FBQyxjQUFlLFdBQVcsY0FBYztRQUN2RSxPQUFRLE9BQU8sUUFBUSxLQUFLLFVBQVUsUUFBUSxJQUMxQyxPQUFPLElBQUksS0FBSyxVQUFVLElBQUk7SUFDcEM7QUFDRixNQUdBLEFBREEsNkVBQTZFO0FBQzVFLFNBQVM7SUFDUixPQUFPLFNBQVM7UUFDZCxPQUFPO0lBQ1Q7QUFDRjs7Ozs7NkNDaEVzQjtBQUZ4QjtBQUVlLFNBQVMsY0FBYyxHQUFHO0lBQ3ZDLE1BQU0sUUFBUSw0QkFBNEIsSUFBSSxDQUFDO0lBQy9DLE9BQU8sU0FBUyxLQUFLLENBQUMsRUFBRSxJQUFJO0FBQzlCOzs7OztBQ0xBO0FBRUE7Ozs7O0NBS0MsR0FDRCxTQUFTLFlBQVksWUFBWSxFQUFFLEdBQUc7SUFDcEMsZUFBZSxnQkFBZ0I7SUFDL0IsTUFBTSxRQUFRLElBQUksTUFBTTtJQUN4QixNQUFNLGFBQWEsSUFBSSxNQUFNO0lBQzdCLElBQUksT0FBTztJQUNYLElBQUksT0FBTztJQUNYLElBQUk7SUFFSixNQUFNLFFBQVEsWUFBWSxNQUFNO0lBRWhDLE9BQU8sU0FBUyxLQUFLLFdBQVc7UUFDOUIsTUFBTSxNQUFNLEtBQUssR0FBRztRQUVwQixNQUFNLFlBQVksVUFBVSxDQUFDLEtBQUs7UUFFbEMsSUFBSSxDQUFDLGVBQ0gsZ0JBQWdCO1FBR2xCLEtBQUssQ0FBQyxLQUFLLEdBQUc7UUFDZCxVQUFVLENBQUMsS0FBSyxHQUFHO1FBRW5CLElBQUksSUFBSTtRQUNSLElBQUksYUFBYTtRQUVqQixNQUFPLE1BQU0sS0FBTTtZQUNqQixjQUFjLEtBQUssQ0FBQyxJQUFJO1lBQ3hCLElBQUksSUFBSTtRQUNWO1FBRUEsT0FBTyxBQUFDLENBQUEsT0FBTyxDQUFBLElBQUs7UUFFcEIsSUFBSSxTQUFTLE1BQ1gsT0FBTyxBQUFDLENBQUEsT0FBTyxDQUFBLElBQUs7UUFHdEIsSUFBSSxNQUFNLGdCQUFnQixLQUN4QjtRQUdGLE1BQU0sU0FBUyxhQUFhLE1BQU07UUFFbEMsT0FBTyxTQUFTLEtBQUssS0FBSyxDQUFDLGFBQWEsT0FBTyxVQUFVO0lBQzNEO0FBQ0Y7a0JBRWU7Ozs7OzZDQ3RDUztBQWR4Qjs7QUFDQTs7QUFIQTtBQUtBLE1BQU0sa0JBQWtCLENBQUMsUUFBVSxpQkFBaUIsQ0FBQSxHQUFBLDhCQUFZLEFBQUQsSUFBSTtRQUFFLEdBQUcsS0FBSztJQUFDLElBQUk7QUFXbkUsU0FBUyxZQUFZLE9BQU8sRUFBRSxPQUFPO0lBQ2xELDZDQUE2QztJQUM3QyxVQUFVLFdBQVcsQ0FBQztJQUN0QixNQUFNLFNBQVMsQ0FBQztJQUVoQixTQUFTLGVBQWUsTUFBTSxFQUFFLE1BQU0sRUFBRSxRQUFRO1FBQzlDLElBQUksQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxhQUFhLENBQUMsV0FBVyxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLGFBQWEsQ0FBQyxTQUNyRCxPQUFPLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQztZQUFDO1FBQVEsR0FBRyxRQUFRO2FBQ3ZDLElBQUksQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxhQUFhLENBQUMsU0FDN0IsT0FBTyxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLEtBQUssQ0FBQyxDQUFDLEdBQUc7YUFDbEIsSUFBSSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLE9BQU8sQ0FBQyxTQUN2QixPQUFPLE9BQU8sS0FBSztRQUVyQixPQUFPO0lBQ1Q7SUFFQSw2Q0FBNkM7SUFDN0MsU0FBUyxvQkFBb0IsQ0FBQyxFQUFFLENBQUMsRUFBRSxRQUFRO1FBQ3pDLElBQUksQ0FBQyxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFdBQVcsQ0FBQyxJQUNyQixPQUFPLGVBQWUsR0FBRyxHQUFHO2FBQ3ZCLElBQUksQ0FBQyxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFdBQVcsQ0FBQyxJQUM1QixPQUFPLGVBQWUsV0FBVyxHQUFHO0lBRXhDO0lBRUEsNkNBQTZDO0lBQzdDLFNBQVMsaUJBQWlCLENBQUMsRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLFdBQVcsQ0FBQyxJQUNyQixPQUFPLGVBQWUsV0FBVztJQUVyQztJQUVBLDZDQUE2QztJQUM3QyxTQUFTLGlCQUFpQixDQUFDLEVBQUUsQ0FBQztRQUM1QixJQUFJLENBQUMsQ0FBQSxHQUFBLHVCQUFLLEFBQUQsRUFBRSxXQUFXLENBQUMsSUFDckIsT0FBTyxlQUFlLFdBQVc7YUFDNUIsSUFBSSxDQUFDLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsV0FBVyxDQUFDLElBQzVCLE9BQU8sZUFBZSxXQUFXO0lBRXJDO0lBRUEsNkNBQTZDO0lBQzdDLFNBQVMsZ0JBQWdCLENBQUMsRUFBRSxDQUFDLEVBQUUsSUFBSTtRQUNqQyxJQUFJLFFBQVEsU0FDVixPQUFPLGVBQWUsR0FBRzthQUNwQixJQUFJLFFBQVEsU0FDakIsT0FBTyxlQUFlLFdBQVc7SUFFckM7SUFFQSxNQUFNLFdBQVc7UUFDZixLQUFLO1FBQ0wsUUFBUTtRQUNSLE1BQU07UUFDTixTQUFTO1FBQ1Qsa0JBQWtCO1FBQ2xCLG1CQUFtQjtRQUNuQixrQkFBa0I7UUFDbEIsU0FBUztRQUNULGdCQUFnQjtRQUNoQixpQkFBaUI7UUFDakIsZUFBZTtRQUNmLFNBQVM7UUFDVCxjQUFjO1FBQ2QsZ0JBQWdCO1FBQ2hCLGdCQUFnQjtRQUNoQixrQkFBa0I7UUFDbEIsb0JBQW9CO1FBQ3BCLFlBQVk7UUFDWixrQkFBa0I7UUFDbEIsZUFBZTtRQUNmLGdCQUFnQjtRQUNoQixXQUFXO1FBQ1gsV0FBVztRQUNYLFlBQVk7UUFDWixhQUFhO1FBQ2IsWUFBWTtRQUNaLGtCQUFrQjtRQUNsQixnQkFBZ0I7UUFDaEIsU0FBUyxDQUFDLEdBQUcsSUFBTSxvQkFBb0IsZ0JBQWdCLElBQUksZ0JBQWdCLElBQUk7SUFDakY7SUFFQSxDQUFBLEdBQUEsdUJBQUssQUFBRCxFQUFFLE9BQU8sQ0FBQyxPQUFPLElBQUksQ0FBQyxPQUFPLE1BQU0sQ0FBQyxDQUFDLEdBQUcsU0FBUyxXQUFXLFNBQVMsbUJBQW1CLElBQUk7UUFDOUYsTUFBTSxRQUFRLFFBQVEsQ0FBQyxLQUFLLElBQUk7UUFDaEMsTUFBTSxjQUFjLE1BQU0sT0FBTyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsS0FBSyxFQUFFO1FBQ3ZELENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsV0FBVyxDQUFDLGdCQUFnQixVQUFVLG1CQUFxQixDQUFBLE1BQU0sQ0FBQyxLQUFLLEdBQUcsV0FBVTtJQUM3RjtJQUVBLE9BQU87QUFDVDs7Ozs7QUN2R0E7QUFDQTs7QUFIQTtBQUtBLE1BQU0sYUFBYSxDQUFDO0FBRXBCLHNDQUFzQztBQUN0QztJQUFDO0lBQVU7SUFBVztJQUFVO0lBQVk7SUFBVTtDQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTTtJQUM3RSxVQUFVLENBQUMsS0FBSyxHQUFHLFNBQVMsVUFBVSxLQUFLO1FBQ3pDLE9BQU8sT0FBTyxVQUFVLFFBQVEsTUFBTyxDQUFBLElBQUksSUFBSSxPQUFPLEdBQUUsSUFBSztJQUMvRDtBQUNGO0FBRUEsTUFBTSxxQkFBcUIsQ0FBQztBQUU1Qjs7Ozs7Ozs7Q0FRQyxHQUNELFdBQVcsWUFBWSxHQUFHLFNBQVMsYUFBYSxTQUFTLEVBQUUsT0FBTyxFQUFFLE9BQU87SUFDekUsU0FBUyxjQUFjLEdBQUcsRUFBRSxJQUFJO1FBQzlCLE9BQU8sYUFBYSxDQUFBLEdBQUEsZUFBTyxBQUFELElBQUksNEJBQTZCLE1BQU0sTUFBTyxPQUFRLENBQUEsVUFBVSxPQUFPLFVBQVUsRUFBQztJQUM5RztJQUVBLHNDQUFzQztJQUN0QyxPQUFPLENBQUMsT0FBTyxLQUFLO1FBQ2xCLElBQUksY0FBYyxPQUNoQixNQUFNLElBQUksQ0FBQSxHQUFBLDRCQUFVLEFBQUQsRUFDakIsY0FBYyxLQUFLLHNCQUF1QixDQUFBLFVBQVUsU0FBUyxVQUFVLEVBQUMsSUFDeEUsQ0FBQSxHQUFBLDRCQUFVLEFBQUQsRUFBRSxjQUFjO1FBSTdCLElBQUksV0FBVyxDQUFDLGtCQUFrQixDQUFDLElBQUksRUFBRTtZQUN2QyxrQkFBa0IsQ0FBQyxJQUFJLEdBQUc7WUFDMUIsc0NBQXNDO1lBQ3RDLFFBQVEsSUFBSSxDQUNWLGNBQ0UsS0FDQSxpQ0FBaUMsVUFBVTtRQUdqRDtRQUVBLE9BQU8sWUFBWSxVQUFVLE9BQU8sS0FBSyxRQUFRO0lBQ25EO0FBQ0Y7QUFFQTs7Ozs7Ozs7Q0FRQyxHQUVELFNBQVMsY0FBYyxPQUFPLEVBQUUsTUFBTSxFQUFFLFlBQVk7SUFDbEQsSUFBSSxPQUFPLFlBQVksVUFDckIsTUFBTSxJQUFJLENBQUEsR0FBQSw0QkFBVSxBQUFELEVBQUUsNkJBQTZCLENBQUEsR0FBQSw0QkFBVSxBQUFELEVBQUUsb0JBQW9CO0lBRW5GLE1BQU0sT0FBTyxPQUFPLElBQUksQ0FBQztJQUN6QixJQUFJLElBQUksS0FBSyxNQUFNO0lBQ25CLE1BQU8sTUFBTSxFQUFHO1FBQ2QsTUFBTSxNQUFNLElBQUksQ0FBQyxFQUFFO1FBQ25CLE1BQU0sWUFBWSxNQUFNLENBQUMsSUFBSTtRQUM3QixJQUFJLFdBQVc7WUFDYixNQUFNLFFBQVEsT0FBTyxDQUFDLElBQUk7WUFDMUIsTUFBTSxTQUFTLFVBQVUsYUFBYSxVQUFVLE9BQU8sS0FBSztZQUM1RCxJQUFJLFdBQVcsTUFDYixNQUFNLElBQUksQ0FBQSxHQUFBLDRCQUFVLEFBQUQsRUFBRSxZQUFZLE1BQU0sY0FBYyxRQUFRLENBQUEsR0FBQSw0QkFBVSxBQUFELEVBQUUsb0JBQW9CO1lBRTlGO1FBQ0Y7UUFDQSxJQUFJLGlCQUFpQixNQUNuQixNQUFNLElBQUksQ0FBQSxHQUFBLDRCQUFVLEFBQUQsRUFBRSxvQkFBb0IsS0FBSyxDQUFBLEdBQUEsNEJBQVUsQUFBRCxFQUFFLGNBQWM7SUFFM0U7QUFDRjtrQkFFZTtJQUNiO0lBQ0E7QUFDRjs7Ozs7NkNDMUZhO0FBQU4sTUFBTSxVQUFVOzs7OztBQ0V2Qjs7QUFGQTtBQUlBOzs7Ozs7Q0FNQyxHQUNELE1BQU07SUFDSixZQUFZLFFBQVEsQ0FBRTtRQUNwQixJQUFJLE9BQU8sYUFBYSxZQUN0QixNQUFNLElBQUksVUFBVTtRQUd0QixJQUFJO1FBRUosSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLFFBQVEsU0FBUyxnQkFBZ0IsT0FBTztZQUN6RCxpQkFBaUI7UUFDbkI7UUFFQSxNQUFNLFFBQVEsSUFBSTtRQUVsQixzQ0FBc0M7UUFDdEMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQTtZQUNoQixJQUFJLENBQUMsTUFBTSxVQUFVLEVBQUU7WUFFdkIsSUFBSSxJQUFJLE1BQU0sVUFBVSxDQUFDLE1BQU07WUFFL0IsTUFBTyxNQUFNLEVBQ1gsTUFBTSxVQUFVLENBQUMsRUFBRSxDQUFDO1lBRXRCLE1BQU0sVUFBVSxHQUFHO1FBQ3JCO1FBRUEsc0NBQXNDO1FBQ3RDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLENBQUE7WUFDbEIsSUFBSTtZQUNKLHNDQUFzQztZQUN0QyxNQUFNLFVBQVUsSUFBSSxRQUFRLENBQUE7Z0JBQzFCLE1BQU0sU0FBUyxDQUFDO2dCQUNoQixXQUFXO1lBQ2IsR0FBRyxJQUFJLENBQUM7WUFFUixRQUFRLE1BQU0sR0FBRyxTQUFTO2dCQUN4QixNQUFNLFdBQVcsQ0FBQztZQUNwQjtZQUVBLE9BQU87UUFDVDtRQUVBLFNBQVMsU0FBUyxPQUFPLE9BQU8sRUFBRSxNQUFNLEVBQUUsT0FBTztZQUMvQyxJQUFJLE1BQU0sTUFBTSxFQUNkLDBDQUEwQztZQUMxQztZQUdGLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQSxHQUFBLCtCQUFhLEFBQUQsRUFBRSxTQUFTLFFBQVE7WUFDbEQsZUFBZSxNQUFNLE1BQU07UUFDN0I7SUFDRjtJQUVBOztHQUVDLEdBQ0QsbUJBQW1CO1FBQ2pCLElBQUksSUFBSSxDQUFDLE1BQU0sRUFDYixNQUFNLElBQUksQ0FBQyxNQUFNO0lBRXJCO0lBRUE7O0dBRUMsR0FFRCxVQUFVLFFBQVEsRUFBRTtRQUNsQixJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDZixTQUFTLElBQUksQ0FBQyxNQUFNO1lBQ3BCO1FBQ0Y7UUFFQSxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQ2pCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO2FBRXJCLElBQUksQ0FBQyxVQUFVLEdBQUc7WUFBQztTQUFTO0lBRWhDO0lBRUE7O0dBRUMsR0FFRCxZQUFZLFFBQVEsRUFBRTtRQUNwQixJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFDbEI7UUFFRixNQUFNLFFBQVEsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7UUFDdEMsSUFBSSxVQUFVLElBQ1osSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTztJQUVsQztJQUVBOzs7R0FHQyxHQUNELE9BQU8sU0FBUztRQUNkLElBQUk7UUFDSixNQUFNLFFBQVEsSUFBSSxZQUFZLFNBQVMsU0FBUyxDQUFDO1lBQy9DLFNBQVM7UUFDWDtRQUNBLE9BQU87WUFDTDtZQUNBO1FBQ0Y7SUFDRjtBQUNGO2tCQUVlOzs7Ozs2Q0NqR1M7QUF2QnhCO0FBdUJlLFNBQVMsT0FBTyxRQUFRO0lBQ3JDLE9BQU8sU0FBUyxLQUFLLEdBQUc7UUFDdEIsT0FBTyxTQUFTLEtBQUssQ0FBQyxNQUFNO0lBQzlCO0FBQ0Y7Ozs7OzZDQ2hCd0I7QUFUeEI7O0FBRkE7QUFXZSxTQUFTLGFBQWEsT0FBTztJQUMxQyxPQUFPLENBQUEsR0FBQSx1QkFBSyxBQUFELEVBQUUsUUFBUSxDQUFDLFlBQWEsUUFBUSxZQUFZLEtBQUs7QUFDOUQ7Ozs7O0FDYkEsTUFBTSxpQkFBaUI7SUFDckIsVUFBVTtJQUNWLG9CQUFvQjtJQUNwQixZQUFZO0lBQ1osWUFBWTtJQUNaLElBQUk7SUFDSixTQUFTO0lBQ1QsVUFBVTtJQUNWLDZCQUE2QjtJQUM3QixXQUFXO0lBQ1gsY0FBYztJQUNkLGdCQUFnQjtJQUNoQixhQUFhO0lBQ2IsaUJBQWlCO0lBQ2pCLFFBQVE7SUFDUixpQkFBaUI7SUFDakIsa0JBQWtCO0lBQ2xCLE9BQU87SUFDUCxVQUFVO0lBQ1YsYUFBYTtJQUNiLFVBQVU7SUFDVixRQUFRO0lBQ1IsbUJBQW1CO0lBQ25CLG1CQUFtQjtJQUNuQixZQUFZO0lBQ1osY0FBYztJQUNkLGlCQUFpQjtJQUNqQixXQUFXO0lBQ1gsVUFBVTtJQUNWLGtCQUFrQjtJQUNsQixlQUFlO0lBQ2YsNkJBQTZCO0lBQzdCLGdCQUFnQjtJQUNoQixVQUFVO0lBQ1YsTUFBTTtJQUNOLGdCQUFnQjtJQUNoQixvQkFBb0I7SUFDcEIsaUJBQWlCO0lBQ2pCLFlBQVk7SUFDWixzQkFBc0I7SUFDdEIscUJBQXFCO0lBQ3JCLG1CQUFtQjtJQUNuQixXQUFXO0lBQ1gsb0JBQW9CO0lBQ3BCLHFCQUFxQjtJQUNyQixRQUFRO0lBQ1Isa0JBQWtCO0lBQ2xCLFVBQVU7SUFDVixpQkFBaUI7SUFDakIsc0JBQXNCO0lBQ3RCLGlCQUFpQjtJQUNqQiw2QkFBNkI7SUFDN0IsNEJBQTRCO0lBQzVCLHFCQUFxQjtJQUNyQixnQkFBZ0I7SUFDaEIsWUFBWTtJQUNaLG9CQUFvQjtJQUNwQixnQkFBZ0I7SUFDaEIseUJBQXlCO0lBQ3pCLHVCQUF1QjtJQUN2QixxQkFBcUI7SUFDckIsY0FBYztJQUNkLGFBQWE7SUFDYiwrQkFBK0I7QUFDakM7QUFFQSxPQUFPLE9BQU8sQ0FBQyxnQkFBZ0IsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU07SUFDbEQsY0FBYyxDQUFDLE1BQU0sR0FBRztBQUMxQjtrQkFFZSIsInNvdXJjZXMiOlsic291cmNlL2NvbnRlbnQuanMiLCJub2RlX21vZHVsZXMvYXhpb3MvaW5kZXguanMiLCJub2RlX21vZHVsZXMvYXhpb3MvbGliL2F4aW9zLmpzIiwibm9kZV9tb2R1bGVzL2F4aW9zL2xpYi91dGlscy5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvaGVscGVycy9iaW5kLmpzIiwibm9kZV9tb2R1bGVzL0BwYXJjZWwvdHJhbnNmb3JtZXItanMvc3JjL2VzbW9kdWxlLWhlbHBlcnMuanMiLCJub2RlX21vZHVsZXMvYXhpb3MvbGliL2NvcmUvQXhpb3MuanMiLCJub2RlX21vZHVsZXMvYXhpb3MvbGliL2hlbHBlcnMvYnVpbGRVUkwuanMiLCJub2RlX21vZHVsZXMvYXhpb3MvbGliL2hlbHBlcnMvQXhpb3NVUkxTZWFyY2hQYXJhbXMuanMiLCJub2RlX21vZHVsZXMvYXhpb3MvbGliL2hlbHBlcnMvdG9Gb3JtRGF0YS5qcyIsIm5vZGVfbW9kdWxlcy9idWZmZXIvaW5kZXguanMiLCJub2RlX21vZHVsZXMvYmFzZTY0LWpzL2luZGV4LmpzIiwibm9kZV9tb2R1bGVzL2llZWU3NTQvaW5kZXguanMiLCJub2RlX21vZHVsZXMvYXhpb3MvbGliL2NvcmUvQXhpb3NFcnJvci5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvaGVscGVycy9udWxsLmpzIiwibm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9jb3JlL0ludGVyY2VwdG9yTWFuYWdlci5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvY29yZS9kaXNwYXRjaFJlcXVlc3QuanMiLCJub2RlX21vZHVsZXMvYXhpb3MvbGliL2NvcmUvdHJhbnNmb3JtRGF0YS5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvZGVmYXVsdHMvaW5kZXguanMiLCJub2RlX21vZHVsZXMvYXhpb3MvbGliL2RlZmF1bHRzL3RyYW5zaXRpb25hbC5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvaGVscGVycy90b1VSTEVuY29kZWRGb3JtLmpzIiwibm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9wbGF0Zm9ybS9pbmRleC5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvcGxhdGZvcm0vYnJvd3Nlci9pbmRleC5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvcGxhdGZvcm0vYnJvd3Nlci9jbGFzc2VzL1VSTFNlYXJjaFBhcmFtcy5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvcGxhdGZvcm0vYnJvd3Nlci9jbGFzc2VzL0Zvcm1EYXRhLmpzIiwibm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9wbGF0Zm9ybS9icm93c2VyL2NsYXNzZXMvQmxvYi5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvcGxhdGZvcm0vY29tbW9uL3V0aWxzLmpzIiwibm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9oZWxwZXJzL2Zvcm1EYXRhVG9KU09OLmpzIiwibm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9jb3JlL0F4aW9zSGVhZGVycy5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvaGVscGVycy9wYXJzZUhlYWRlcnMuanMiLCJub2RlX21vZHVsZXMvYXhpb3MvbGliL2NhbmNlbC9pc0NhbmNlbC5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvY2FuY2VsL0NhbmNlbGVkRXJyb3IuanMiLCJub2RlX21vZHVsZXMvYXhpb3MvbGliL2FkYXB0ZXJzL2FkYXB0ZXJzLmpzIiwibm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9hZGFwdGVycy94aHIuanMiLCJub2RlX21vZHVsZXMvYXhpb3MvbGliL2NvcmUvc2V0dGxlLmpzIiwibm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9oZWxwZXJzL2Nvb2tpZXMuanMiLCJub2RlX21vZHVsZXMvYXhpb3MvbGliL2NvcmUvYnVpbGRGdWxsUGF0aC5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvaGVscGVycy9pc0Fic29sdXRlVVJMLmpzIiwibm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9oZWxwZXJzL2NvbWJpbmVVUkxzLmpzIiwibm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9oZWxwZXJzL2lzVVJMU2FtZU9yaWdpbi5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvaGVscGVycy9wYXJzZVByb3RvY29sLmpzIiwibm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9oZWxwZXJzL3NwZWVkb21ldGVyLmpzIiwibm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9jb3JlL21lcmdlQ29uZmlnLmpzIiwibm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9oZWxwZXJzL3ZhbGlkYXRvci5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvZW52L2RhdGEuanMiLCJub2RlX21vZHVsZXMvYXhpb3MvbGliL2NhbmNlbC9DYW5jZWxUb2tlbi5qcyIsIm5vZGVfbW9kdWxlcy9heGlvcy9saWIvaGVscGVycy9zcHJlYWQuanMiLCJub2RlX21vZHVsZXMvYXhpb3MvbGliL2hlbHBlcnMvaXNBeGlvc0Vycm9yLmpzIiwibm9kZV9tb2R1bGVzL2F4aW9zL2xpYi9oZWxwZXJzL0h0dHBTdGF0dXNDb2RlLmpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIjtcbmxldCB1c2VybmFtZTtcbmxldCBpc0Nocm9tZSA9IGZhbHNlO1xuXG4vL3N0b3JhZ2UgaGVscGVyc1xubGV0IGJyb3dzZXJTdG9yYWdlO1xuaWYgKHR5cGVvZiBicm93c2VyID09PSBcInVuZGVmaW5lZFwiKSB7XG5cdGJyb3dzZXJTdG9yYWdlID0gY2hyb21lLnN0b3JhZ2UubG9jYWw7XG5cdGlzQ2hyb21lID0gdHJ1ZTtcbn0gZWxzZSB7XG5cdGJyb3dzZXJTdG9yYWdlID0gYnJvd3Nlci5zdG9yYWdlLmxvY2FsO1xufVxuYXN5bmMgZnVuY3Rpb24gZ2V0KGtleSkge1xuXHRjb25zdCB1c2VyS2V5ID0gYCR7dXNlcm5hbWV9LSR7a2V5fWA7XG5cdHJldHVybiAoYXdhaXQgYnJvd3NlclN0b3JhZ2UuZ2V0KHVzZXJLZXkpKVt1c2VyS2V5XTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHNldChrZXksIHZhbCkge1xuXHRjb25zdCBkYXRhID0ge307XG5cdGNvbnN0IHVzZXJLZXkgPSBgJHt1c2VybmFtZX0tJHtrZXl9YDtcblx0ZGF0YVt1c2VyS2V5XSA9IHZhbDtcblx0YXdhaXQgYnJvd3NlclN0b3JhZ2Uuc2V0KGRhdGEpO1xufVxuXG5mdW5jdGlvbiBpc0Rlc2NlbmRhbnRPZlRhZyhlbGVtZW50LCB0YWdOYW1lKSB7XG5cdHdoaWxlIChlbGVtZW50LnBhcmVudEVsZW1lbnQpIHtcblx0XHRpZiAoZWxlbWVudC5wYXJlbnRFbGVtZW50LnRhZ05hbWUudG9Mb3dlckNhc2UoKSA9PT0gdGFnTmFtZS50b0xvd2VyQ2FzZSgpKSB7XG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9XG5cdFx0ZWxlbWVudCA9IGVsZW1lbnQucGFyZW50RWxlbWVudDtcblx0fVxuXHRyZXR1cm4gZmFsc2U7XG59XG5cbmZ1bmN0aW9uIGdldFVzZXJuYW1lKCkge1xuXHRjb25zdCBsaW5rcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ2FbaHJlZl49XCIvdXNlcnMvXCJdJyk7XG5cdGNvbnN0IGxpbmsgPSBBcnJheS5mcm9tKGxpbmtzKS5maW5kKFxuXHRcdChsaW5rKSA9PiAhaXNEZXNjZW5kYW50T2ZUYWcobGluaywgXCJ0YWJsZVwiKSxcblx0KTtcblx0aWYgKCFsaW5rIHx8ICFsaW5rLmhyZWYpIHJldHVybiB1bmRlZmluZWQ7XG5cdGNvbnN0IHBhcnRzID0gbGluay5ocmVmLnNwbGl0KFwiL3VzZXJzL1wiKTtcblx0aWYgKHBhcnRzLmxlbmd0aCA+IDEpIHtcblx0XHRyZXR1cm4gcGFydHNbMV07IC8vIFJldHVybnMgZXZlcnl0aGluZyBhZnRlciBcInVzZXJzL1wiXG5cdH1cbn1cbmFzeW5jIGZ1bmN0aW9uIHRpbWVvdXQobXMpIHtcblx0cmV0dXJuIGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIG1zKSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGdldFN1Ym1pc3Npb25QYWdlcyh1c2VybmFtZSwgZ2V0QWxsUGFnZXMpIHtcblx0Y29uc3Qgb3V0cHV0ID0gW107XG5cdGxldCBwYWdlID0gMDtcblx0d2hpbGUgKHRydWUpIHtcblx0XHRjb25zdCB1cmwgPSBgL3VzZXJzLyR7dXNlcm5hbWV9P3RhYj1zdWJtaXNzaW9ucyZwYWdlPSR7cGFnZX0mc3RhdHVzPUFDYDtcblx0XHRwYWdlKys7XG5cdFx0Y29uc3QgeyBkYXRhIH0gPSBhd2FpdCBheGlvcy5nZXQodXJsKTtcblx0XHRjb25zdCBwYXJzZXIgPSBuZXcgRE9NUGFyc2VyKCk7XG5cdFx0Y29uc3QgaHRtbERvYyA9IHBhcnNlci5wYXJzZUZyb21TdHJpbmcoZGF0YSwgXCJ0ZXh0L2h0bWxcIik7XG5cdFx0Y29uc3Qgcm93cyA9IGh0bWxEb2MucXVlcnlTZWxlY3RvckFsbChcIiNzdWJtaXNzaW9ucyB0Ym9keSB0clwiKTtcblx0XHRyb3dzLmZvckVhY2goKHJvdykgPT4ge1xuXHRcdFx0Y29uc3QgYWNjZXB0ZWQgPSByb3cucXVlcnlTZWxlY3RvcihcImRpdi5pcy1zdGF0dXMtYWNjZXB0ZWRcIik7XG5cdFx0XHRpZiAoYWNjZXB0ZWQpIHtcblx0XHRcdFx0bGV0IHRpbWUgPSByb3cucXVlcnlTZWxlY3RvcigndGRbZGF0YS10eXBlPVwidGltZVwiXScpLnRleHRDb250ZW50LnRyaW0oKTtcblx0XHRcdFx0aWYgKHRpbWUubGVuZ3RoIDw9IDEwKSB7XG5cdFx0XHRcdFx0Y29uc3QgY3VycmVudERhdGUgPSBuZXcgRGF0ZSgpO1xuXHRcdFx0XHRcdGNvbnN0IHllYXIgPSBjdXJyZW50RGF0ZS5nZXRGdWxsWWVhcigpO1xuXHRcdFx0XHRcdGNvbnN0IG1vbnRoID0gU3RyaW5nKGN1cnJlbnREYXRlLmdldE1vbnRoKCkgKyAxKS5wYWRTdGFydCgyLCBcIjBcIik7IC8vIE1vbnRoIHN0YXJ0cyBmcm9tIDBcblx0XHRcdFx0XHRjb25zdCBkYXkgPSBTdHJpbmcoY3VycmVudERhdGUuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCBcIjBcIik7XG5cdFx0XHRcdFx0Y29uc3QgZm9ybWF0dGVkRGF0ZSA9IGAke3llYXJ9LSR7bW9udGh9LSR7ZGF5fSBgO1xuXHRcdFx0XHRcdHRpbWUgPSBmb3JtYXR0ZWREYXRlICsgdGltZTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjb25zdCBzdWJtaXNzaW9uSWQgPSByb3dcblx0XHRcdFx0XHQucXVlcnlTZWxlY3RvcigndGRbZGF0YS10eXBlPVwiYWN0aW9uc1wiXSBhJylcblx0XHRcdFx0XHQuaHJlZi5zcGxpdChcIi9cIilcblx0XHRcdFx0XHQucG9wKCk7XG5cdFx0XHRcdGNvbnN0IHByb2JsZW1MaW5rcyA9IHJvdy5xdWVyeVNlbGVjdG9yQWxsKCd0ZFtkYXRhLXR5cGU9XCJwcm9ibGVtXCJdIGEnKTtcblx0XHRcdFx0Y29uc3QgcHJvYmxlbUlkID0gcHJvYmxlbUxpbmtzW3Byb2JsZW1MaW5rcy5sZW5ndGggLSAxXS5ocmVmXG5cdFx0XHRcdFx0LnNwbGl0KFwiL1wiKVxuXHRcdFx0XHRcdC5wb3AoKTtcblx0XHRcdFx0b3V0cHV0LnB1c2goe1xuXHRcdFx0XHRcdHByb2JsZW1JZCxcblx0XHRcdFx0XHRzdWJtaXNzaW9uSWQsXG5cdFx0XHRcdFx0dGltZXN0YW1wOiBuZXcgRGF0ZSh0aW1lKS5nZXRUaW1lKCksXG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdGF3YWl0IHRpbWVvdXQoMTAwMCk7XG5cdFx0aWYgKCFnZXRBbGxQYWdlcyB8fCByb3dzLmxlbmd0aCA9PT0gMCkge1xuXHRcdFx0YnJlYWs7XG5cdFx0fVxuXHR9XG5cdHJldHVybiBvdXRwdXQ7XG59XG5mdW5jdGlvbiBpc092ZXJBRGF5QWdvKGRhdGUpIHtcblx0cmV0dXJuIGRhdGUgPCBEYXRlLm5vdygpIC0gMTAwMCAqIDYwICogNjAgKiAyNDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc3VibWl0KHN1Ym1pc3Npb25zLCBpc0FsbCkge1xuXHRhd2FpdCBheGlvcy5wb3N0KFxuXHRcdFwiaHR0cHM6Ly9ieXUtY3BjLWJhY2tlbmQtdHF4ZmVlemdmYS11dy5hLnJ1bi5hcHAva2F0dGlzX3N1Ym1pdFwiLFxuXHRcdHtcblx0XHRcdHVzZXJuYW1lLFxuXHRcdFx0c3VibWlzc2lvbnMsXG5cdFx0XHRpc0FsbCxcblx0XHR9LFxuXHQpO1xufVxuYXN5bmMgZnVuY3Rpb24gc2V0U3VibWl0dGluZygpIHtcblx0Y29uc3QgYmFkZ2UgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuXHRiYWRnZS5pZCA9IFwic3luY2luZ0JhZGdlXCI7XG5cdGJhZGdlLmNsYXNzTGlzdC5hZGQoXCJzaHJpbmtcIik7XG5cdGJhZGdlLmlubmVySFRNTCA9IGBTeW5jaW5nIDxkaXYgY2xhc3M9XCJsZHMtcm9sbGVyXCI+PGRpdj48L2Rpdj48ZGl2PjwvZGl2PjxkaXY+PC9kaXY+PGRpdj48L2Rpdj48ZGl2PjwvZGl2PjxkaXY+PC9kaXY+PGRpdj48L2Rpdj48ZGl2PjwvZGl2PjwvZGl2PmA7XG5cdGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoYmFkZ2UpO1xuXHRjb25zdCBuZXdCYWRnZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwic3luY2luZ0JhZGdlXCIpO1xuXHRhd2FpdCB0aW1lb3V0KDEwKTtcblx0bmV3QmFkZ2UuY2xhc3NMaXN0LnJlbW92ZShcInNocmlua1wiKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gdW5zZXRTdWJtaXR0aW5nKCkge1xuXHRjb25zdCBiYWRnZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwic3luY2luZ0JhZGdlXCIpO1xuXHRiYWRnZS5jbGFzc0xpc3QuYWRkKFwic2hyaW5rXCIpO1xuXHRhd2FpdCB0aW1lb3V0KDUwMCk7XG5cdGlmIChiYWRnZSkge1xuXHRcdGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoYmFkZ2UpO1xuXHR9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHN5bmNBbmRTdWJtaXQodXNlcm5hbWUpIHtcblx0c2V0U3VibWl0dGluZygpO1xuXHRjb25zdCBpbml0aWFsU3luYyA9IGF3YWl0IGdldChcImluaXRpYWwtc3luY1wiKTtcblx0Y29uc3QgbGFzdEZ1bGxTeW5jID0gYXdhaXQgZ2V0KFwibGFzdC1mdWxsLXN5bmNcIik7XG5cdGNvbnN0IGdldEFsbFBhZ2VzID1cblx0XHQhaW5pdGlhbFN5bmMgfHwgIWxhc3RGdWxsU3luYyB8fCBpc092ZXJBRGF5QWdvKGxhc3RGdWxsU3luYyk7XG5cdGNvbnN0IHN1Ym1pc3Npb25zID0gYXdhaXQgZ2V0U3VibWlzc2lvblBhZ2VzKHVzZXJuYW1lLCBnZXRBbGxQYWdlcyk7XG5cdGF3YWl0IHN1Ym1pdChzdWJtaXNzaW9ucywgZ2V0QWxsUGFnZXMpO1xuXHRpZiAoZ2V0QWxsUGFnZXMpIHtcblx0XHRhd2FpdCBzZXQoXCJpbml0aWFsLXN5bmNcIiwgdHJ1ZSk7XG5cdFx0YXdhaXQgc2V0KFwibGFzdC1mdWxsLXN5bmNcIiwgRGF0ZS5ub3coKSk7XG5cdH1cblx0dW5zZXRTdWJtaXR0aW5nKCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG1haW4oKSB7XG5cdHVzZXJuYW1lID0gZ2V0VXNlcm5hbWUoKTtcblx0aWYgKCF1c2VybmFtZSkge1xuXHRcdHJldHVybjtcblx0fVxuXHRhd2FpdCBzeW5jQW5kU3VibWl0KHVzZXJuYW1lKTtcbn1cblxubWFpbigpO1xuIiwiaW1wb3J0IGF4aW9zIGZyb20gJy4vbGliL2F4aW9zLmpzJztcblxuLy8gVGhpcyBtb2R1bGUgaXMgaW50ZW5kZWQgdG8gdW53cmFwIEF4aW9zIGRlZmF1bHQgZXhwb3J0IGFzIG5hbWVkLlxuLy8gS2VlcCB0b3AtbGV2ZWwgZXhwb3J0IHNhbWUgd2l0aCBzdGF0aWMgcHJvcGVydGllc1xuLy8gc28gdGhhdCBpdCBjYW4ga2VlcCBzYW1lIHdpdGggZXMgbW9kdWxlIG9yIGNqc1xuY29uc3Qge1xuICBBeGlvcyxcbiAgQXhpb3NFcnJvcixcbiAgQ2FuY2VsZWRFcnJvcixcbiAgaXNDYW5jZWwsXG4gIENhbmNlbFRva2VuLFxuICBWRVJTSU9OLFxuICBhbGwsXG4gIENhbmNlbCxcbiAgaXNBeGlvc0Vycm9yLFxuICBzcHJlYWQsXG4gIHRvRm9ybURhdGEsXG4gIEF4aW9zSGVhZGVycyxcbiAgSHR0cFN0YXR1c0NvZGUsXG4gIGZvcm1Ub0pTT04sXG4gIGdldEFkYXB0ZXIsXG4gIG1lcmdlQ29uZmlnXG59ID0gYXhpb3M7XG5cbmV4cG9ydCB7XG4gIGF4aW9zIGFzIGRlZmF1bHQsXG4gIEF4aW9zLFxuICBBeGlvc0Vycm9yLFxuICBDYW5jZWxlZEVycm9yLFxuICBpc0NhbmNlbCxcbiAgQ2FuY2VsVG9rZW4sXG4gIFZFUlNJT04sXG4gIGFsbCxcbiAgQ2FuY2VsLFxuICBpc0F4aW9zRXJyb3IsXG4gIHNwcmVhZCxcbiAgdG9Gb3JtRGF0YSxcbiAgQXhpb3NIZWFkZXJzLFxuICBIdHRwU3RhdHVzQ29kZSxcbiAgZm9ybVRvSlNPTixcbiAgZ2V0QWRhcHRlcixcbiAgbWVyZ2VDb25maWdcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4vdXRpbHMuanMnO1xuaW1wb3J0IGJpbmQgZnJvbSAnLi9oZWxwZXJzL2JpbmQuanMnO1xuaW1wb3J0IEF4aW9zIGZyb20gJy4vY29yZS9BeGlvcy5qcyc7XG5pbXBvcnQgbWVyZ2VDb25maWcgZnJvbSAnLi9jb3JlL21lcmdlQ29uZmlnLmpzJztcbmltcG9ydCBkZWZhdWx0cyBmcm9tICcuL2RlZmF1bHRzL2luZGV4LmpzJztcbmltcG9ydCBmb3JtRGF0YVRvSlNPTiBmcm9tICcuL2hlbHBlcnMvZm9ybURhdGFUb0pTT04uanMnO1xuaW1wb3J0IENhbmNlbGVkRXJyb3IgZnJvbSAnLi9jYW5jZWwvQ2FuY2VsZWRFcnJvci5qcyc7XG5pbXBvcnQgQ2FuY2VsVG9rZW4gZnJvbSAnLi9jYW5jZWwvQ2FuY2VsVG9rZW4uanMnO1xuaW1wb3J0IGlzQ2FuY2VsIGZyb20gJy4vY2FuY2VsL2lzQ2FuY2VsLmpzJztcbmltcG9ydCB7VkVSU0lPTn0gZnJvbSAnLi9lbnYvZGF0YS5qcyc7XG5pbXBvcnQgdG9Gb3JtRGF0YSBmcm9tICcuL2hlbHBlcnMvdG9Gb3JtRGF0YS5qcyc7XG5pbXBvcnQgQXhpb3NFcnJvciBmcm9tICcuL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgc3ByZWFkIGZyb20gJy4vaGVscGVycy9zcHJlYWQuanMnO1xuaW1wb3J0IGlzQXhpb3NFcnJvciBmcm9tICcuL2hlbHBlcnMvaXNBeGlvc0Vycm9yLmpzJztcbmltcG9ydCBBeGlvc0hlYWRlcnMgZnJvbSBcIi4vY29yZS9BeGlvc0hlYWRlcnMuanNcIjtcbmltcG9ydCBhZGFwdGVycyBmcm9tICcuL2FkYXB0ZXJzL2FkYXB0ZXJzLmpzJztcbmltcG9ydCBIdHRwU3RhdHVzQ29kZSBmcm9tICcuL2hlbHBlcnMvSHR0cFN0YXR1c0NvZGUuanMnO1xuXG4vKipcbiAqIENyZWF0ZSBhbiBpbnN0YW5jZSBvZiBBeGlvc1xuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBkZWZhdWx0Q29uZmlnIFRoZSBkZWZhdWx0IGNvbmZpZyBmb3IgdGhlIGluc3RhbmNlXG4gKlxuICogQHJldHVybnMge0F4aW9zfSBBIG5ldyBpbnN0YW5jZSBvZiBBeGlvc1xuICovXG5mdW5jdGlvbiBjcmVhdGVJbnN0YW5jZShkZWZhdWx0Q29uZmlnKSB7XG4gIGNvbnN0IGNvbnRleHQgPSBuZXcgQXhpb3MoZGVmYXVsdENvbmZpZyk7XG4gIGNvbnN0IGluc3RhbmNlID0gYmluZChBeGlvcy5wcm90b3R5cGUucmVxdWVzdCwgY29udGV4dCk7XG5cbiAgLy8gQ29weSBheGlvcy5wcm90b3R5cGUgdG8gaW5zdGFuY2VcbiAgdXRpbHMuZXh0ZW5kKGluc3RhbmNlLCBBeGlvcy5wcm90b3R5cGUsIGNvbnRleHQsIHthbGxPd25LZXlzOiB0cnVlfSk7XG5cbiAgLy8gQ29weSBjb250ZXh0IHRvIGluc3RhbmNlXG4gIHV0aWxzLmV4dGVuZChpbnN0YW5jZSwgY29udGV4dCwgbnVsbCwge2FsbE93bktleXM6IHRydWV9KTtcblxuICAvLyBGYWN0b3J5IGZvciBjcmVhdGluZyBuZXcgaW5zdGFuY2VzXG4gIGluc3RhbmNlLmNyZWF0ZSA9IGZ1bmN0aW9uIGNyZWF0ZShpbnN0YW5jZUNvbmZpZykge1xuICAgIHJldHVybiBjcmVhdGVJbnN0YW5jZShtZXJnZUNvbmZpZyhkZWZhdWx0Q29uZmlnLCBpbnN0YW5jZUNvbmZpZykpO1xuICB9O1xuXG4gIHJldHVybiBpbnN0YW5jZTtcbn1cblxuLy8gQ3JlYXRlIHRoZSBkZWZhdWx0IGluc3RhbmNlIHRvIGJlIGV4cG9ydGVkXG5jb25zdCBheGlvcyA9IGNyZWF0ZUluc3RhbmNlKGRlZmF1bHRzKTtcblxuLy8gRXhwb3NlIEF4aW9zIGNsYXNzIHRvIGFsbG93IGNsYXNzIGluaGVyaXRhbmNlXG5heGlvcy5BeGlvcyA9IEF4aW9zO1xuXG4vLyBFeHBvc2UgQ2FuY2VsICYgQ2FuY2VsVG9rZW5cbmF4aW9zLkNhbmNlbGVkRXJyb3IgPSBDYW5jZWxlZEVycm9yO1xuYXhpb3MuQ2FuY2VsVG9rZW4gPSBDYW5jZWxUb2tlbjtcbmF4aW9zLmlzQ2FuY2VsID0gaXNDYW5jZWw7XG5heGlvcy5WRVJTSU9OID0gVkVSU0lPTjtcbmF4aW9zLnRvRm9ybURhdGEgPSB0b0Zvcm1EYXRhO1xuXG4vLyBFeHBvc2UgQXhpb3NFcnJvciBjbGFzc1xuYXhpb3MuQXhpb3NFcnJvciA9IEF4aW9zRXJyb3I7XG5cbi8vIGFsaWFzIGZvciBDYW5jZWxlZEVycm9yIGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5XG5heGlvcy5DYW5jZWwgPSBheGlvcy5DYW5jZWxlZEVycm9yO1xuXG4vLyBFeHBvc2UgYWxsL3NwcmVhZFxuYXhpb3MuYWxsID0gZnVuY3Rpb24gYWxsKHByb21pc2VzKSB7XG4gIHJldHVybiBQcm9taXNlLmFsbChwcm9taXNlcyk7XG59O1xuXG5heGlvcy5zcHJlYWQgPSBzcHJlYWQ7XG5cbi8vIEV4cG9zZSBpc0F4aW9zRXJyb3JcbmF4aW9zLmlzQXhpb3NFcnJvciA9IGlzQXhpb3NFcnJvcjtcblxuLy8gRXhwb3NlIG1lcmdlQ29uZmlnXG5heGlvcy5tZXJnZUNvbmZpZyA9IG1lcmdlQ29uZmlnO1xuXG5heGlvcy5BeGlvc0hlYWRlcnMgPSBBeGlvc0hlYWRlcnM7XG5cbmF4aW9zLmZvcm1Ub0pTT04gPSB0aGluZyA9PiBmb3JtRGF0YVRvSlNPTih1dGlscy5pc0hUTUxGb3JtKHRoaW5nKSA/IG5ldyBGb3JtRGF0YSh0aGluZykgOiB0aGluZyk7XG5cbmF4aW9zLmdldEFkYXB0ZXIgPSBhZGFwdGVycy5nZXRBZGFwdGVyO1xuXG5heGlvcy5IdHRwU3RhdHVzQ29kZSA9IEh0dHBTdGF0dXNDb2RlO1xuXG5heGlvcy5kZWZhdWx0ID0gYXhpb3M7XG5cbi8vIHRoaXMgbW9kdWxlIHNob3VsZCBvbmx5IGhhdmUgYSBkZWZhdWx0IGV4cG9ydFxuZXhwb3J0IGRlZmF1bHQgYXhpb3NcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IGJpbmQgZnJvbSAnLi9oZWxwZXJzL2JpbmQuanMnO1xuXG4vLyB1dGlscyBpcyBhIGxpYnJhcnkgb2YgZ2VuZXJpYyBoZWxwZXIgZnVuY3Rpb25zIG5vbi1zcGVjaWZpYyB0byBheGlvc1xuXG5jb25zdCB7dG9TdHJpbmd9ID0gT2JqZWN0LnByb3RvdHlwZTtcbmNvbnN0IHtnZXRQcm90b3R5cGVPZn0gPSBPYmplY3Q7XG5cbmNvbnN0IGtpbmRPZiA9IChjYWNoZSA9PiB0aGluZyA9PiB7XG4gICAgY29uc3Qgc3RyID0gdG9TdHJpbmcuY2FsbCh0aGluZyk7XG4gICAgcmV0dXJuIGNhY2hlW3N0cl0gfHwgKGNhY2hlW3N0cl0gPSBzdHIuc2xpY2UoOCwgLTEpLnRvTG93ZXJDYXNlKCkpO1xufSkoT2JqZWN0LmNyZWF0ZShudWxsKSk7XG5cbmNvbnN0IGtpbmRPZlRlc3QgPSAodHlwZSkgPT4ge1xuICB0eXBlID0gdHlwZS50b0xvd2VyQ2FzZSgpO1xuICByZXR1cm4gKHRoaW5nKSA9PiBraW5kT2YodGhpbmcpID09PSB0eXBlXG59XG5cbmNvbnN0IHR5cGVPZlRlc3QgPSB0eXBlID0+IHRoaW5nID0+IHR5cGVvZiB0aGluZyA9PT0gdHlwZTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhbiBBcnJheVxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhbiBBcnJheSwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IHtpc0FycmF5fSA9IEFycmF5O1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIHVuZGVmaW5lZFxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdGhlIHZhbHVlIGlzIHVuZGVmaW5lZCwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzVW5kZWZpbmVkID0gdHlwZU9mVGVzdCgndW5kZWZpbmVkJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBCdWZmZXJcbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgQnVmZmVyLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZnVuY3Rpb24gaXNCdWZmZXIodmFsKSB7XG4gIHJldHVybiB2YWwgIT09IG51bGwgJiYgIWlzVW5kZWZpbmVkKHZhbCkgJiYgdmFsLmNvbnN0cnVjdG9yICE9PSBudWxsICYmICFpc1VuZGVmaW5lZCh2YWwuY29uc3RydWN0b3IpXG4gICAgJiYgaXNGdW5jdGlvbih2YWwuY29uc3RydWN0b3IuaXNCdWZmZXIpICYmIHZhbC5jb25zdHJ1Y3Rvci5pc0J1ZmZlcih2YWwpO1xufVxuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGFuIEFycmF5QnVmZmVyXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhbiBBcnJheUJ1ZmZlciwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzQXJyYXlCdWZmZXIgPSBraW5kT2ZUZXN0KCdBcnJheUJ1ZmZlcicpO1xuXG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSB2aWV3IG9uIGFuIEFycmF5QnVmZmVyXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIHZpZXcgb24gYW4gQXJyYXlCdWZmZXIsIG90aGVyd2lzZSBmYWxzZVxuICovXG5mdW5jdGlvbiBpc0FycmF5QnVmZmVyVmlldyh2YWwpIHtcbiAgbGV0IHJlc3VsdDtcbiAgaWYgKCh0eXBlb2YgQXJyYXlCdWZmZXIgIT09ICd1bmRlZmluZWQnKSAmJiAoQXJyYXlCdWZmZXIuaXNWaWV3KSkge1xuICAgIHJlc3VsdCA9IEFycmF5QnVmZmVyLmlzVmlldyh2YWwpO1xuICB9IGVsc2Uge1xuICAgIHJlc3VsdCA9ICh2YWwpICYmICh2YWwuYnVmZmVyKSAmJiAoaXNBcnJheUJ1ZmZlcih2YWwuYnVmZmVyKSk7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhIFN0cmluZ1xuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBTdHJpbmcsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc1N0cmluZyA9IHR5cGVPZlRlc3QoJ3N0cmluZycpO1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgRnVuY3Rpb25cbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBGdW5jdGlvbiwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzRnVuY3Rpb24gPSB0eXBlT2ZUZXN0KCdmdW5jdGlvbicpO1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgTnVtYmVyXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIE51bWJlciwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzTnVtYmVyID0gdHlwZU9mVGVzdCgnbnVtYmVyJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYW4gT2JqZWN0XG4gKlxuICogQHBhcmFtIHsqfSB0aGluZyBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGFuIE9iamVjdCwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzT2JqZWN0ID0gKHRoaW5nKSA9PiB0aGluZyAhPT0gbnVsbCAmJiB0eXBlb2YgdGhpbmcgPT09ICdvYmplY3QnO1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgQm9vbGVhblxuICpcbiAqIEBwYXJhbSB7Kn0gdGhpbmcgVGhlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgQm9vbGVhbiwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmNvbnN0IGlzQm9vbGVhbiA9IHRoaW5nID0+IHRoaW5nID09PSB0cnVlIHx8IHRoaW5nID09PSBmYWxzZTtcblxuLyoqXG4gKiBEZXRlcm1pbmUgaWYgYSB2YWx1ZSBpcyBhIHBsYWluIE9iamVjdFxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBwbGFpbiBPYmplY3QsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc1BsYWluT2JqZWN0ID0gKHZhbCkgPT4ge1xuICBpZiAoa2luZE9mKHZhbCkgIT09ICdvYmplY3QnKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgY29uc3QgcHJvdG90eXBlID0gZ2V0UHJvdG90eXBlT2YodmFsKTtcbiAgcmV0dXJuIChwcm90b3R5cGUgPT09IG51bGwgfHwgcHJvdG90eXBlID09PSBPYmplY3QucHJvdG90eXBlIHx8IE9iamVjdC5nZXRQcm90b3R5cGVPZihwcm90b3R5cGUpID09PSBudWxsKSAmJiAhKFN5bWJvbC50b1N0cmluZ1RhZyBpbiB2YWwpICYmICEoU3ltYm9sLml0ZXJhdG9yIGluIHZhbCk7XG59XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBEYXRlXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIERhdGUsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc0RhdGUgPSBraW5kT2ZUZXN0KCdEYXRlJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGaWxlXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIEZpbGUsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc0ZpbGUgPSBraW5kT2ZUZXN0KCdGaWxlJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBCbG9iXG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIEJsb2IsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc0Jsb2IgPSBraW5kT2ZUZXN0KCdCbG9iJyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBGaWxlTGlzdFxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBGaWxlLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNGaWxlTGlzdCA9IGtpbmRPZlRlc3QoJ0ZpbGVMaXN0Jyk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBTdHJlYW1cbiAqXG4gKiBAcGFyYW0geyp9IHZhbCBUaGUgdmFsdWUgdG8gdGVzdFxuICpcbiAqIEByZXR1cm5zIHtib29sZWFufSBUcnVlIGlmIHZhbHVlIGlzIGEgU3RyZWFtLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNTdHJlYW0gPSAodmFsKSA9PiBpc09iamVjdCh2YWwpICYmIGlzRnVuY3Rpb24odmFsLnBpcGUpO1xuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgRm9ybURhdGFcbiAqXG4gKiBAcGFyYW0geyp9IHRoaW5nIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYW4gRm9ybURhdGEsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc0Zvcm1EYXRhID0gKHRoaW5nKSA9PiB7XG4gIGxldCBraW5kO1xuICByZXR1cm4gdGhpbmcgJiYgKFxuICAgICh0eXBlb2YgRm9ybURhdGEgPT09ICdmdW5jdGlvbicgJiYgdGhpbmcgaW5zdGFuY2VvZiBGb3JtRGF0YSkgfHwgKFxuICAgICAgaXNGdW5jdGlvbih0aGluZy5hcHBlbmQpICYmIChcbiAgICAgICAgKGtpbmQgPSBraW5kT2YodGhpbmcpKSA9PT0gJ2Zvcm1kYXRhJyB8fFxuICAgICAgICAvLyBkZXRlY3QgZm9ybS1kYXRhIGluc3RhbmNlXG4gICAgICAgIChraW5kID09PSAnb2JqZWN0JyAmJiBpc0Z1bmN0aW9uKHRoaW5nLnRvU3RyaW5nKSAmJiB0aGluZy50b1N0cmluZygpID09PSAnW29iamVjdCBGb3JtRGF0YV0nKVxuICAgICAgKVxuICAgIClcbiAgKVxufVxuXG4vKipcbiAqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgVVJMU2VhcmNoUGFyYW1zIG9iamVjdFxuICpcbiAqIEBwYXJhbSB7Kn0gdmFsIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdmFsdWUgaXMgYSBVUkxTZWFyY2hQYXJhbXMgb2JqZWN0LCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuY29uc3QgaXNVUkxTZWFyY2hQYXJhbXMgPSBraW5kT2ZUZXN0KCdVUkxTZWFyY2hQYXJhbXMnKTtcblxuLyoqXG4gKiBUcmltIGV4Y2VzcyB3aGl0ZXNwYWNlIG9mZiB0aGUgYmVnaW5uaW5nIGFuZCBlbmQgb2YgYSBzdHJpbmdcbiAqXG4gKiBAcGFyYW0ge1N0cmluZ30gc3RyIFRoZSBTdHJpbmcgdG8gdHJpbVxuICpcbiAqIEByZXR1cm5zIHtTdHJpbmd9IFRoZSBTdHJpbmcgZnJlZWQgb2YgZXhjZXNzIHdoaXRlc3BhY2VcbiAqL1xuY29uc3QgdHJpbSA9IChzdHIpID0+IHN0ci50cmltID9cbiAgc3RyLnRyaW0oKSA6IHN0ci5yZXBsYWNlKC9eW1xcc1xcdUZFRkZcXHhBMF0rfFtcXHNcXHVGRUZGXFx4QTBdKyQvZywgJycpO1xuXG4vKipcbiAqIEl0ZXJhdGUgb3ZlciBhbiBBcnJheSBvciBhbiBPYmplY3QgaW52b2tpbmcgYSBmdW5jdGlvbiBmb3IgZWFjaCBpdGVtLlxuICpcbiAqIElmIGBvYmpgIGlzIGFuIEFycmF5IGNhbGxiYWNrIHdpbGwgYmUgY2FsbGVkIHBhc3NpbmdcbiAqIHRoZSB2YWx1ZSwgaW5kZXgsIGFuZCBjb21wbGV0ZSBhcnJheSBmb3IgZWFjaCBpdGVtLlxuICpcbiAqIElmICdvYmonIGlzIGFuIE9iamVjdCBjYWxsYmFjayB3aWxsIGJlIGNhbGxlZCBwYXNzaW5nXG4gKiB0aGUgdmFsdWUsIGtleSwgYW5kIGNvbXBsZXRlIG9iamVjdCBmb3IgZWFjaCBwcm9wZXJ0eS5cbiAqXG4gKiBAcGFyYW0ge09iamVjdHxBcnJheX0gb2JqIFRoZSBvYmplY3QgdG8gaXRlcmF0ZVxuICogQHBhcmFtIHtGdW5jdGlvbn0gZm4gVGhlIGNhbGxiYWNrIHRvIGludm9rZSBmb3IgZWFjaCBpdGVtXG4gKlxuICogQHBhcmFtIHtCb29sZWFufSBbYWxsT3duS2V5cyA9IGZhbHNlXVxuICogQHJldHVybnMge2FueX1cbiAqL1xuZnVuY3Rpb24gZm9yRWFjaChvYmosIGZuLCB7YWxsT3duS2V5cyA9IGZhbHNlfSA9IHt9KSB7XG4gIC8vIERvbid0IGJvdGhlciBpZiBubyB2YWx1ZSBwcm92aWRlZFxuICBpZiAob2JqID09PSBudWxsIHx8IHR5cGVvZiBvYmogPT09ICd1bmRlZmluZWQnKSB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgbGV0IGk7XG4gIGxldCBsO1xuXG4gIC8vIEZvcmNlIGFuIGFycmF5IGlmIG5vdCBhbHJlYWR5IHNvbWV0aGluZyBpdGVyYWJsZVxuICBpZiAodHlwZW9mIG9iaiAhPT0gJ29iamVjdCcpIHtcbiAgICAvKmVzbGludCBuby1wYXJhbS1yZWFzc2lnbjowKi9cbiAgICBvYmogPSBbb2JqXTtcbiAgfVxuXG4gIGlmIChpc0FycmF5KG9iaikpIHtcbiAgICAvLyBJdGVyYXRlIG92ZXIgYXJyYXkgdmFsdWVzXG4gICAgZm9yIChpID0gMCwgbCA9IG9iai5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICAgIGZuLmNhbGwobnVsbCwgb2JqW2ldLCBpLCBvYmopO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICAvLyBJdGVyYXRlIG92ZXIgb2JqZWN0IGtleXNcbiAgICBjb25zdCBrZXlzID0gYWxsT3duS2V5cyA/IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKG9iaikgOiBPYmplY3Qua2V5cyhvYmopO1xuICAgIGNvbnN0IGxlbiA9IGtleXMubGVuZ3RoO1xuICAgIGxldCBrZXk7XG5cbiAgICBmb3IgKGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgIGtleSA9IGtleXNbaV07XG4gICAgICBmbi5jYWxsKG51bGwsIG9ialtrZXldLCBrZXksIG9iaik7XG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIGZpbmRLZXkob2JqLCBrZXkpIHtcbiAga2V5ID0ga2V5LnRvTG93ZXJDYXNlKCk7XG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhvYmopO1xuICBsZXQgaSA9IGtleXMubGVuZ3RoO1xuICBsZXQgX2tleTtcbiAgd2hpbGUgKGktLSA+IDApIHtcbiAgICBfa2V5ID0ga2V5c1tpXTtcbiAgICBpZiAoa2V5ID09PSBfa2V5LnRvTG93ZXJDYXNlKCkpIHtcbiAgICAgIHJldHVybiBfa2V5O1xuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuY29uc3QgX2dsb2JhbCA9ICgoKSA9PiB7XG4gIC8qZXNsaW50IG5vLXVuZGVmOjAqL1xuICBpZiAodHlwZW9mIGdsb2JhbFRoaXMgIT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBnbG9iYWxUaGlzO1xuICByZXR1cm4gdHlwZW9mIHNlbGYgIT09IFwidW5kZWZpbmVkXCIgPyBzZWxmIDogKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnID8gd2luZG93IDogZ2xvYmFsKVxufSkoKTtcblxuY29uc3QgaXNDb250ZXh0RGVmaW5lZCA9IChjb250ZXh0KSA9PiAhaXNVbmRlZmluZWQoY29udGV4dCkgJiYgY29udGV4dCAhPT0gX2dsb2JhbDtcblxuLyoqXG4gKiBBY2NlcHRzIHZhcmFyZ3MgZXhwZWN0aW5nIGVhY2ggYXJndW1lbnQgdG8gYmUgYW4gb2JqZWN0LCB0aGVuXG4gKiBpbW11dGFibHkgbWVyZ2VzIHRoZSBwcm9wZXJ0aWVzIG9mIGVhY2ggb2JqZWN0IGFuZCByZXR1cm5zIHJlc3VsdC5cbiAqXG4gKiBXaGVuIG11bHRpcGxlIG9iamVjdHMgY29udGFpbiB0aGUgc2FtZSBrZXkgdGhlIGxhdGVyIG9iamVjdCBpblxuICogdGhlIGFyZ3VtZW50cyBsaXN0IHdpbGwgdGFrZSBwcmVjZWRlbmNlLlxuICpcbiAqIEV4YW1wbGU6XG4gKlxuICogYGBganNcbiAqIHZhciByZXN1bHQgPSBtZXJnZSh7Zm9vOiAxMjN9LCB7Zm9vOiA0NTZ9KTtcbiAqIGNvbnNvbGUubG9nKHJlc3VsdC5mb28pOyAvLyBvdXRwdXRzIDQ1NlxuICogYGBgXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IG9iajEgT2JqZWN0IHRvIG1lcmdlXG4gKlxuICogQHJldHVybnMge09iamVjdH0gUmVzdWx0IG9mIGFsbCBtZXJnZSBwcm9wZXJ0aWVzXG4gKi9cbmZ1bmN0aW9uIG1lcmdlKC8qIG9iajEsIG9iajIsIG9iajMsIC4uLiAqLykge1xuICBjb25zdCB7Y2FzZWxlc3N9ID0gaXNDb250ZXh0RGVmaW5lZCh0aGlzKSAmJiB0aGlzIHx8IHt9O1xuICBjb25zdCByZXN1bHQgPSB7fTtcbiAgY29uc3QgYXNzaWduVmFsdWUgPSAodmFsLCBrZXkpID0+IHtcbiAgICBjb25zdCB0YXJnZXRLZXkgPSBjYXNlbGVzcyAmJiBmaW5kS2V5KHJlc3VsdCwga2V5KSB8fCBrZXk7XG4gICAgaWYgKGlzUGxhaW5PYmplY3QocmVzdWx0W3RhcmdldEtleV0pICYmIGlzUGxhaW5PYmplY3QodmFsKSkge1xuICAgICAgcmVzdWx0W3RhcmdldEtleV0gPSBtZXJnZShyZXN1bHRbdGFyZ2V0S2V5XSwgdmFsKTtcbiAgICB9IGVsc2UgaWYgKGlzUGxhaW5PYmplY3QodmFsKSkge1xuICAgICAgcmVzdWx0W3RhcmdldEtleV0gPSBtZXJnZSh7fSwgdmFsKTtcbiAgICB9IGVsc2UgaWYgKGlzQXJyYXkodmFsKSkge1xuICAgICAgcmVzdWx0W3RhcmdldEtleV0gPSB2YWwuc2xpY2UoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVzdWx0W3RhcmdldEtleV0gPSB2YWw7XG4gICAgfVxuICB9XG5cbiAgZm9yIChsZXQgaSA9IDAsIGwgPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgYXJndW1lbnRzW2ldICYmIGZvckVhY2goYXJndW1lbnRzW2ldLCBhc3NpZ25WYWx1ZSk7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuLyoqXG4gKiBFeHRlbmRzIG9iamVjdCBhIGJ5IG11dGFibHkgYWRkaW5nIHRvIGl0IHRoZSBwcm9wZXJ0aWVzIG9mIG9iamVjdCBiLlxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBhIFRoZSBvYmplY3QgdG8gYmUgZXh0ZW5kZWRcbiAqIEBwYXJhbSB7T2JqZWN0fSBiIFRoZSBvYmplY3QgdG8gY29weSBwcm9wZXJ0aWVzIGZyb21cbiAqIEBwYXJhbSB7T2JqZWN0fSB0aGlzQXJnIFRoZSBvYmplY3QgdG8gYmluZCBmdW5jdGlvbiB0b1xuICpcbiAqIEBwYXJhbSB7Qm9vbGVhbn0gW2FsbE93bktleXNdXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBUaGUgcmVzdWx0aW5nIHZhbHVlIG9mIG9iamVjdCBhXG4gKi9cbmNvbnN0IGV4dGVuZCA9IChhLCBiLCB0aGlzQXJnLCB7YWxsT3duS2V5c309IHt9KSA9PiB7XG4gIGZvckVhY2goYiwgKHZhbCwga2V5KSA9PiB7XG4gICAgaWYgKHRoaXNBcmcgJiYgaXNGdW5jdGlvbih2YWwpKSB7XG4gICAgICBhW2tleV0gPSBiaW5kKHZhbCwgdGhpc0FyZyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGFba2V5XSA9IHZhbDtcbiAgICB9XG4gIH0sIHthbGxPd25LZXlzfSk7XG4gIHJldHVybiBhO1xufVxuXG4vKipcbiAqIFJlbW92ZSBieXRlIG9yZGVyIG1hcmtlci4gVGhpcyBjYXRjaGVzIEVGIEJCIEJGICh0aGUgVVRGLTggQk9NKVxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBjb250ZW50IHdpdGggQk9NXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gY29udGVudCB2YWx1ZSB3aXRob3V0IEJPTVxuICovXG5jb25zdCBzdHJpcEJPTSA9IChjb250ZW50KSA9PiB7XG4gIGlmIChjb250ZW50LmNoYXJDb2RlQXQoMCkgPT09IDB4RkVGRikge1xuICAgIGNvbnRlbnQgPSBjb250ZW50LnNsaWNlKDEpO1xuICB9XG4gIHJldHVybiBjb250ZW50O1xufVxuXG4vKipcbiAqIEluaGVyaXQgdGhlIHByb3RvdHlwZSBtZXRob2RzIGZyb20gb25lIGNvbnN0cnVjdG9yIGludG8gYW5vdGhlclxuICogQHBhcmFtIHtmdW5jdGlvbn0gY29uc3RydWN0b3JcbiAqIEBwYXJhbSB7ZnVuY3Rpb259IHN1cGVyQ29uc3RydWN0b3JcbiAqIEBwYXJhbSB7b2JqZWN0fSBbcHJvcHNdXG4gKiBAcGFyYW0ge29iamVjdH0gW2Rlc2NyaXB0b3JzXVxuICpcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5jb25zdCBpbmhlcml0cyA9IChjb25zdHJ1Y3Rvciwgc3VwZXJDb25zdHJ1Y3RvciwgcHJvcHMsIGRlc2NyaXB0b3JzKSA9PiB7XG4gIGNvbnN0cnVjdG9yLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUoc3VwZXJDb25zdHJ1Y3Rvci5wcm90b3R5cGUsIGRlc2NyaXB0b3JzKTtcbiAgY29uc3RydWN0b3IucHJvdG90eXBlLmNvbnN0cnVjdG9yID0gY29uc3RydWN0b3I7XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjb25zdHJ1Y3RvciwgJ3N1cGVyJywge1xuICAgIHZhbHVlOiBzdXBlckNvbnN0cnVjdG9yLnByb3RvdHlwZVxuICB9KTtcbiAgcHJvcHMgJiYgT2JqZWN0LmFzc2lnbihjb25zdHJ1Y3Rvci5wcm90b3R5cGUsIHByb3BzKTtcbn1cblxuLyoqXG4gKiBSZXNvbHZlIG9iamVjdCB3aXRoIGRlZXAgcHJvdG90eXBlIGNoYWluIHRvIGEgZmxhdCBvYmplY3RcbiAqIEBwYXJhbSB7T2JqZWN0fSBzb3VyY2VPYmogc291cmNlIG9iamVjdFxuICogQHBhcmFtIHtPYmplY3R9IFtkZXN0T2JqXVxuICogQHBhcmFtIHtGdW5jdGlvbnxCb29sZWFufSBbZmlsdGVyXVxuICogQHBhcmFtIHtGdW5jdGlvbn0gW3Byb3BGaWx0ZXJdXG4gKlxuICogQHJldHVybnMge09iamVjdH1cbiAqL1xuY29uc3QgdG9GbGF0T2JqZWN0ID0gKHNvdXJjZU9iaiwgZGVzdE9iaiwgZmlsdGVyLCBwcm9wRmlsdGVyKSA9PiB7XG4gIGxldCBwcm9wcztcbiAgbGV0IGk7XG4gIGxldCBwcm9wO1xuICBjb25zdCBtZXJnZWQgPSB7fTtcblxuICBkZXN0T2JqID0gZGVzdE9iaiB8fCB7fTtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWVxLW51bGwsZXFlcWVxXG4gIGlmIChzb3VyY2VPYmogPT0gbnVsbCkgcmV0dXJuIGRlc3RPYmo7XG5cbiAgZG8ge1xuICAgIHByb3BzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMoc291cmNlT2JqKTtcbiAgICBpID0gcHJvcHMubGVuZ3RoO1xuICAgIHdoaWxlIChpLS0gPiAwKSB7XG4gICAgICBwcm9wID0gcHJvcHNbaV07XG4gICAgICBpZiAoKCFwcm9wRmlsdGVyIHx8IHByb3BGaWx0ZXIocHJvcCwgc291cmNlT2JqLCBkZXN0T2JqKSkgJiYgIW1lcmdlZFtwcm9wXSkge1xuICAgICAgICBkZXN0T2JqW3Byb3BdID0gc291cmNlT2JqW3Byb3BdO1xuICAgICAgICBtZXJnZWRbcHJvcF0gPSB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgICBzb3VyY2VPYmogPSBmaWx0ZXIgIT09IGZhbHNlICYmIGdldFByb3RvdHlwZU9mKHNvdXJjZU9iaik7XG4gIH0gd2hpbGUgKHNvdXJjZU9iaiAmJiAoIWZpbHRlciB8fCBmaWx0ZXIoc291cmNlT2JqLCBkZXN0T2JqKSkgJiYgc291cmNlT2JqICE9PSBPYmplY3QucHJvdG90eXBlKTtcblxuICByZXR1cm4gZGVzdE9iajtcbn1cblxuLyoqXG4gKiBEZXRlcm1pbmVzIHdoZXRoZXIgYSBzdHJpbmcgZW5kcyB3aXRoIHRoZSBjaGFyYWN0ZXJzIG9mIGEgc3BlY2lmaWVkIHN0cmluZ1xuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSBzdHJcbiAqIEBwYXJhbSB7U3RyaW5nfSBzZWFyY2hTdHJpbmdcbiAqIEBwYXJhbSB7TnVtYmVyfSBbcG9zaXRpb249IDBdXG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKi9cbmNvbnN0IGVuZHNXaXRoID0gKHN0ciwgc2VhcmNoU3RyaW5nLCBwb3NpdGlvbikgPT4ge1xuICBzdHIgPSBTdHJpbmcoc3RyKTtcbiAgaWYgKHBvc2l0aW9uID09PSB1bmRlZmluZWQgfHwgcG9zaXRpb24gPiBzdHIubGVuZ3RoKSB7XG4gICAgcG9zaXRpb24gPSBzdHIubGVuZ3RoO1xuICB9XG4gIHBvc2l0aW9uIC09IHNlYXJjaFN0cmluZy5sZW5ndGg7XG4gIGNvbnN0IGxhc3RJbmRleCA9IHN0ci5pbmRleE9mKHNlYXJjaFN0cmluZywgcG9zaXRpb24pO1xuICByZXR1cm4gbGFzdEluZGV4ICE9PSAtMSAmJiBsYXN0SW5kZXggPT09IHBvc2l0aW9uO1xufVxuXG5cbi8qKlxuICogUmV0dXJucyBuZXcgYXJyYXkgZnJvbSBhcnJheSBsaWtlIG9iamVjdCBvciBudWxsIGlmIGZhaWxlZFxuICpcbiAqIEBwYXJhbSB7Kn0gW3RoaW5nXVxuICpcbiAqIEByZXR1cm5zIHs/QXJyYXl9XG4gKi9cbmNvbnN0IHRvQXJyYXkgPSAodGhpbmcpID0+IHtcbiAgaWYgKCF0aGluZykgcmV0dXJuIG51bGw7XG4gIGlmIChpc0FycmF5KHRoaW5nKSkgcmV0dXJuIHRoaW5nO1xuICBsZXQgaSA9IHRoaW5nLmxlbmd0aDtcbiAgaWYgKCFpc051bWJlcihpKSkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IGFyciA9IG5ldyBBcnJheShpKTtcbiAgd2hpbGUgKGktLSA+IDApIHtcbiAgICBhcnJbaV0gPSB0aGluZ1tpXTtcbiAgfVxuICByZXR1cm4gYXJyO1xufVxuXG4vKipcbiAqIENoZWNraW5nIGlmIHRoZSBVaW50OEFycmF5IGV4aXN0cyBhbmQgaWYgaXQgZG9lcywgaXQgcmV0dXJucyBhIGZ1bmN0aW9uIHRoYXQgY2hlY2tzIGlmIHRoZVxuICogdGhpbmcgcGFzc2VkIGluIGlzIGFuIGluc3RhbmNlIG9mIFVpbnQ4QXJyYXlcbiAqXG4gKiBAcGFyYW0ge1R5cGVkQXJyYXl9XG4gKlxuICogQHJldHVybnMge0FycmF5fVxuICovXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuY29uc3QgaXNUeXBlZEFycmF5ID0gKFR5cGVkQXJyYXkgPT4ge1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuICByZXR1cm4gdGhpbmcgPT4ge1xuICAgIHJldHVybiBUeXBlZEFycmF5ICYmIHRoaW5nIGluc3RhbmNlb2YgVHlwZWRBcnJheTtcbiAgfTtcbn0pKHR5cGVvZiBVaW50OEFycmF5ICE9PSAndW5kZWZpbmVkJyAmJiBnZXRQcm90b3R5cGVPZihVaW50OEFycmF5KSk7XG5cbi8qKlxuICogRm9yIGVhY2ggZW50cnkgaW4gdGhlIG9iamVjdCwgY2FsbCB0aGUgZnVuY3Rpb24gd2l0aCB0aGUga2V5IGFuZCB2YWx1ZS5cbiAqXG4gKiBAcGFyYW0ge09iamVjdDxhbnksIGFueT59IG9iaiAtIFRoZSBvYmplY3QgdG8gaXRlcmF0ZSBvdmVyLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZm4gLSBUaGUgZnVuY3Rpb24gdG8gY2FsbCBmb3IgZWFjaCBlbnRyeS5cbiAqXG4gKiBAcmV0dXJucyB7dm9pZH1cbiAqL1xuY29uc3QgZm9yRWFjaEVudHJ5ID0gKG9iaiwgZm4pID0+IHtcbiAgY29uc3QgZ2VuZXJhdG9yID0gb2JqICYmIG9ialtTeW1ib2wuaXRlcmF0b3JdO1xuXG4gIGNvbnN0IGl0ZXJhdG9yID0gZ2VuZXJhdG9yLmNhbGwob2JqKTtcblxuICBsZXQgcmVzdWx0O1xuXG4gIHdoaWxlICgocmVzdWx0ID0gaXRlcmF0b3IubmV4dCgpKSAmJiAhcmVzdWx0LmRvbmUpIHtcbiAgICBjb25zdCBwYWlyID0gcmVzdWx0LnZhbHVlO1xuICAgIGZuLmNhbGwob2JqLCBwYWlyWzBdLCBwYWlyWzFdKTtcbiAgfVxufVxuXG4vKipcbiAqIEl0IHRha2VzIGEgcmVndWxhciBleHByZXNzaW9uIGFuZCBhIHN0cmluZywgYW5kIHJldHVybnMgYW4gYXJyYXkgb2YgYWxsIHRoZSBtYXRjaGVzXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IHJlZ0V4cCAtIFRoZSByZWd1bGFyIGV4cHJlc3Npb24gdG8gbWF0Y2ggYWdhaW5zdC5cbiAqIEBwYXJhbSB7c3RyaW5nfSBzdHIgLSBUaGUgc3RyaW5nIHRvIHNlYXJjaC5cbiAqXG4gKiBAcmV0dXJucyB7QXJyYXk8Ym9vbGVhbj59XG4gKi9cbmNvbnN0IG1hdGNoQWxsID0gKHJlZ0V4cCwgc3RyKSA9PiB7XG4gIGxldCBtYXRjaGVzO1xuICBjb25zdCBhcnIgPSBbXTtcblxuICB3aGlsZSAoKG1hdGNoZXMgPSByZWdFeHAuZXhlYyhzdHIpKSAhPT0gbnVsbCkge1xuICAgIGFyci5wdXNoKG1hdGNoZXMpO1xuICB9XG5cbiAgcmV0dXJuIGFycjtcbn1cblxuLyogQ2hlY2tpbmcgaWYgdGhlIGtpbmRPZlRlc3QgZnVuY3Rpb24gcmV0dXJucyB0cnVlIHdoZW4gcGFzc2VkIGFuIEhUTUxGb3JtRWxlbWVudC4gKi9cbmNvbnN0IGlzSFRNTEZvcm0gPSBraW5kT2ZUZXN0KCdIVE1MRm9ybUVsZW1lbnQnKTtcblxuY29uc3QgdG9DYW1lbENhc2UgPSBzdHIgPT4ge1xuICByZXR1cm4gc3RyLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvWy1fXFxzXShbYS16XFxkXSkoXFx3KikvZyxcbiAgICBmdW5jdGlvbiByZXBsYWNlcihtLCBwMSwgcDIpIHtcbiAgICAgIHJldHVybiBwMS50b1VwcGVyQ2FzZSgpICsgcDI7XG4gICAgfVxuICApO1xufTtcblxuLyogQ3JlYXRpbmcgYSBmdW5jdGlvbiB0aGF0IHdpbGwgY2hlY2sgaWYgYW4gb2JqZWN0IGhhcyBhIHByb3BlcnR5LiAqL1xuY29uc3QgaGFzT3duUHJvcGVydHkgPSAoKHtoYXNPd25Qcm9wZXJ0eX0pID0+IChvYmosIHByb3ApID0+IGhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkoT2JqZWN0LnByb3RvdHlwZSk7XG5cbi8qKlxuICogRGV0ZXJtaW5lIGlmIGEgdmFsdWUgaXMgYSBSZWdFeHAgb2JqZWN0XG4gKlxuICogQHBhcmFtIHsqfSB2YWwgVGhlIHZhbHVlIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB2YWx1ZSBpcyBhIFJlZ0V4cCBvYmplY3QsIG90aGVyd2lzZSBmYWxzZVxuICovXG5jb25zdCBpc1JlZ0V4cCA9IGtpbmRPZlRlc3QoJ1JlZ0V4cCcpO1xuXG5jb25zdCByZWR1Y2VEZXNjcmlwdG9ycyA9IChvYmosIHJlZHVjZXIpID0+IHtcbiAgY29uc3QgZGVzY3JpcHRvcnMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyhvYmopO1xuICBjb25zdCByZWR1Y2VkRGVzY3JpcHRvcnMgPSB7fTtcblxuICBmb3JFYWNoKGRlc2NyaXB0b3JzLCAoZGVzY3JpcHRvciwgbmFtZSkgPT4ge1xuICAgIGxldCByZXQ7XG4gICAgaWYgKChyZXQgPSByZWR1Y2VyKGRlc2NyaXB0b3IsIG5hbWUsIG9iaikpICE9PSBmYWxzZSkge1xuICAgICAgcmVkdWNlZERlc2NyaXB0b3JzW25hbWVdID0gcmV0IHx8IGRlc2NyaXB0b3I7XG4gICAgfVxuICB9KTtcblxuICBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhvYmosIHJlZHVjZWREZXNjcmlwdG9ycyk7XG59XG5cbi8qKlxuICogTWFrZXMgYWxsIG1ldGhvZHMgcmVhZC1vbmx5XG4gKiBAcGFyYW0ge09iamVjdH0gb2JqXG4gKi9cblxuY29uc3QgZnJlZXplTWV0aG9kcyA9IChvYmopID0+IHtcbiAgcmVkdWNlRGVzY3JpcHRvcnMob2JqLCAoZGVzY3JpcHRvciwgbmFtZSkgPT4ge1xuICAgIC8vIHNraXAgcmVzdHJpY3RlZCBwcm9wcyBpbiBzdHJpY3QgbW9kZVxuICAgIGlmIChpc0Z1bmN0aW9uKG9iaikgJiYgWydhcmd1bWVudHMnLCAnY2FsbGVyJywgJ2NhbGxlZSddLmluZGV4T2YobmFtZSkgIT09IC0xKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgY29uc3QgdmFsdWUgPSBvYmpbbmFtZV07XG5cbiAgICBpZiAoIWlzRnVuY3Rpb24odmFsdWUpKSByZXR1cm47XG5cbiAgICBkZXNjcmlwdG9yLmVudW1lcmFibGUgPSBmYWxzZTtcblxuICAgIGlmICgnd3JpdGFibGUnIGluIGRlc2NyaXB0b3IpIHtcbiAgICAgIGRlc2NyaXB0b3Iud3JpdGFibGUgPSBmYWxzZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoIWRlc2NyaXB0b3Iuc2V0KSB7XG4gICAgICBkZXNjcmlwdG9yLnNldCA9ICgpID0+IHtcbiAgICAgICAgdGhyb3cgRXJyb3IoJ0NhbiBub3QgcmV3cml0ZSByZWFkLW9ubHkgbWV0aG9kIFxcJycgKyBuYW1lICsgJ1xcJycpO1xuICAgICAgfTtcbiAgICB9XG4gIH0pO1xufVxuXG5jb25zdCB0b09iamVjdFNldCA9IChhcnJheU9yU3RyaW5nLCBkZWxpbWl0ZXIpID0+IHtcbiAgY29uc3Qgb2JqID0ge307XG5cbiAgY29uc3QgZGVmaW5lID0gKGFycikgPT4ge1xuICAgIGFyci5mb3JFYWNoKHZhbHVlID0+IHtcbiAgICAgIG9ialt2YWx1ZV0gPSB0cnVlO1xuICAgIH0pO1xuICB9XG5cbiAgaXNBcnJheShhcnJheU9yU3RyaW5nKSA/IGRlZmluZShhcnJheU9yU3RyaW5nKSA6IGRlZmluZShTdHJpbmcoYXJyYXlPclN0cmluZykuc3BsaXQoZGVsaW1pdGVyKSk7XG5cbiAgcmV0dXJuIG9iajtcbn1cblxuY29uc3Qgbm9vcCA9ICgpID0+IHt9XG5cbmNvbnN0IHRvRmluaXRlTnVtYmVyID0gKHZhbHVlLCBkZWZhdWx0VmFsdWUpID0+IHtcbiAgdmFsdWUgPSArdmFsdWU7XG4gIHJldHVybiBOdW1iZXIuaXNGaW5pdGUodmFsdWUpID8gdmFsdWUgOiBkZWZhdWx0VmFsdWU7XG59XG5cbmNvbnN0IEFMUEhBID0gJ2FiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6J1xuXG5jb25zdCBESUdJVCA9ICcwMTIzNDU2Nzg5JztcblxuY29uc3QgQUxQSEFCRVQgPSB7XG4gIERJR0lULFxuICBBTFBIQSxcbiAgQUxQSEFfRElHSVQ6IEFMUEhBICsgQUxQSEEudG9VcHBlckNhc2UoKSArIERJR0lUXG59XG5cbmNvbnN0IGdlbmVyYXRlU3RyaW5nID0gKHNpemUgPSAxNiwgYWxwaGFiZXQgPSBBTFBIQUJFVC5BTFBIQV9ESUdJVCkgPT4ge1xuICBsZXQgc3RyID0gJyc7XG4gIGNvbnN0IHtsZW5ndGh9ID0gYWxwaGFiZXQ7XG4gIHdoaWxlIChzaXplLS0pIHtcbiAgICBzdHIgKz0gYWxwaGFiZXRbTWF0aC5yYW5kb20oKSAqIGxlbmd0aHwwXVxuICB9XG5cbiAgcmV0dXJuIHN0cjtcbn1cblxuLyoqXG4gKiBJZiB0aGUgdGhpbmcgaXMgYSBGb3JtRGF0YSBvYmplY3QsIHJldHVybiB0cnVlLCBvdGhlcndpc2UgcmV0dXJuIGZhbHNlLlxuICpcbiAqIEBwYXJhbSB7dW5rbm93bn0gdGhpbmcgLSBUaGUgdGhpbmcgdG8gY2hlY2suXG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59XG4gKi9cbmZ1bmN0aW9uIGlzU3BlY0NvbXBsaWFudEZvcm0odGhpbmcpIHtcbiAgcmV0dXJuICEhKHRoaW5nICYmIGlzRnVuY3Rpb24odGhpbmcuYXBwZW5kKSAmJiB0aGluZ1tTeW1ib2wudG9TdHJpbmdUYWddID09PSAnRm9ybURhdGEnICYmIHRoaW5nW1N5bWJvbC5pdGVyYXRvcl0pO1xufVxuXG5jb25zdCB0b0pTT05PYmplY3QgPSAob2JqKSA9PiB7XG4gIGNvbnN0IHN0YWNrID0gbmV3IEFycmF5KDEwKTtcblxuICBjb25zdCB2aXNpdCA9IChzb3VyY2UsIGkpID0+IHtcblxuICAgIGlmIChpc09iamVjdChzb3VyY2UpKSB7XG4gICAgICBpZiAoc3RhY2suaW5kZXhPZihzb3VyY2UpID49IDApIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBpZighKCd0b0pTT04nIGluIHNvdXJjZSkpIHtcbiAgICAgICAgc3RhY2tbaV0gPSBzb3VyY2U7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGlzQXJyYXkoc291cmNlKSA/IFtdIDoge307XG5cbiAgICAgICAgZm9yRWFjaChzb3VyY2UsICh2YWx1ZSwga2V5KSA9PiB7XG4gICAgICAgICAgY29uc3QgcmVkdWNlZFZhbHVlID0gdmlzaXQodmFsdWUsIGkgKyAxKTtcbiAgICAgICAgICAhaXNVbmRlZmluZWQocmVkdWNlZFZhbHVlKSAmJiAodGFyZ2V0W2tleV0gPSByZWR1Y2VkVmFsdWUpO1xuICAgICAgICB9KTtcblxuICAgICAgICBzdGFja1tpXSA9IHVuZGVmaW5lZDtcblxuICAgICAgICByZXR1cm4gdGFyZ2V0O1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBzb3VyY2U7XG4gIH1cblxuICByZXR1cm4gdmlzaXQob2JqLCAwKTtcbn1cblxuY29uc3QgaXNBc3luY0ZuID0ga2luZE9mVGVzdCgnQXN5bmNGdW5jdGlvbicpO1xuXG5jb25zdCBpc1RoZW5hYmxlID0gKHRoaW5nKSA9PlxuICB0aGluZyAmJiAoaXNPYmplY3QodGhpbmcpIHx8IGlzRnVuY3Rpb24odGhpbmcpKSAmJiBpc0Z1bmN0aW9uKHRoaW5nLnRoZW4pICYmIGlzRnVuY3Rpb24odGhpbmcuY2F0Y2gpO1xuXG5leHBvcnQgZGVmYXVsdCB7XG4gIGlzQXJyYXksXG4gIGlzQXJyYXlCdWZmZXIsXG4gIGlzQnVmZmVyLFxuICBpc0Zvcm1EYXRhLFxuICBpc0FycmF5QnVmZmVyVmlldyxcbiAgaXNTdHJpbmcsXG4gIGlzTnVtYmVyLFxuICBpc0Jvb2xlYW4sXG4gIGlzT2JqZWN0LFxuICBpc1BsYWluT2JqZWN0LFxuICBpc1VuZGVmaW5lZCxcbiAgaXNEYXRlLFxuICBpc0ZpbGUsXG4gIGlzQmxvYixcbiAgaXNSZWdFeHAsXG4gIGlzRnVuY3Rpb24sXG4gIGlzU3RyZWFtLFxuICBpc1VSTFNlYXJjaFBhcmFtcyxcbiAgaXNUeXBlZEFycmF5LFxuICBpc0ZpbGVMaXN0LFxuICBmb3JFYWNoLFxuICBtZXJnZSxcbiAgZXh0ZW5kLFxuICB0cmltLFxuICBzdHJpcEJPTSxcbiAgaW5oZXJpdHMsXG4gIHRvRmxhdE9iamVjdCxcbiAga2luZE9mLFxuICBraW5kT2ZUZXN0LFxuICBlbmRzV2l0aCxcbiAgdG9BcnJheSxcbiAgZm9yRWFjaEVudHJ5LFxuICBtYXRjaEFsbCxcbiAgaXNIVE1MRm9ybSxcbiAgaGFzT3duUHJvcGVydHksXG4gIGhhc093blByb3A6IGhhc093blByb3BlcnR5LCAvLyBhbiBhbGlhcyB0byBhdm9pZCBFU0xpbnQgbm8tcHJvdG90eXBlLWJ1aWx0aW5zIGRldGVjdGlvblxuICByZWR1Y2VEZXNjcmlwdG9ycyxcbiAgZnJlZXplTWV0aG9kcyxcbiAgdG9PYmplY3RTZXQsXG4gIHRvQ2FtZWxDYXNlLFxuICBub29wLFxuICB0b0Zpbml0ZU51bWJlcixcbiAgZmluZEtleSxcbiAgZ2xvYmFsOiBfZ2xvYmFsLFxuICBpc0NvbnRleHREZWZpbmVkLFxuICBBTFBIQUJFVCxcbiAgZ2VuZXJhdGVTdHJpbmcsXG4gIGlzU3BlY0NvbXBsaWFudEZvcm0sXG4gIHRvSlNPTk9iamVjdCxcbiAgaXNBc3luY0ZuLFxuICBpc1RoZW5hYmxlXG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBiaW5kKGZuLCB0aGlzQXJnKSB7XG4gIHJldHVybiBmdW5jdGlvbiB3cmFwKCkge1xuICAgIHJldHVybiBmbi5hcHBseSh0aGlzQXJnLCBhcmd1bWVudHMpO1xuICB9O1xufVxuIiwiZXhwb3J0cy5pbnRlcm9wRGVmYXVsdCA9IGZ1bmN0aW9uIChhKSB7XG4gIHJldHVybiBhICYmIGEuX19lc01vZHVsZSA/IGEgOiB7ZGVmYXVsdDogYX07XG59O1xuXG5leHBvcnRzLmRlZmluZUludGVyb3BGbGFnID0gZnVuY3Rpb24gKGEpIHtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGEsICdfX2VzTW9kdWxlJywge3ZhbHVlOiB0cnVlfSk7XG59O1xuXG5leHBvcnRzLmV4cG9ydEFsbCA9IGZ1bmN0aW9uIChzb3VyY2UsIGRlc3QpIHtcbiAgT2JqZWN0LmtleXMoc291cmNlKS5mb3JFYWNoKGZ1bmN0aW9uIChrZXkpIHtcbiAgICBpZiAoXG4gICAgICBrZXkgPT09ICdkZWZhdWx0JyB8fFxuICAgICAga2V5ID09PSAnX19lc01vZHVsZScgfHxcbiAgICAgIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChkZXN0LCBrZXkpXG4gICAgKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGRlc3QsIGtleSwge1xuICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gc291cmNlW2tleV07XG4gICAgICB9LFxuICAgIH0pO1xuICB9KTtcblxuICByZXR1cm4gZGVzdDtcbn07XG5cbmV4cG9ydHMuZXhwb3J0ID0gZnVuY3Rpb24gKGRlc3QsIGRlc3ROYW1lLCBnZXQpIHtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGRlc3QsIGRlc3ROYW1lLCB7XG4gICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICBnZXQ6IGdldCxcbiAgfSk7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdXRpbHMgZnJvbSAnLi8uLi91dGlscy5qcyc7XG5pbXBvcnQgYnVpbGRVUkwgZnJvbSAnLi4vaGVscGVycy9idWlsZFVSTC5qcyc7XG5pbXBvcnQgSW50ZXJjZXB0b3JNYW5hZ2VyIGZyb20gJy4vSW50ZXJjZXB0b3JNYW5hZ2VyLmpzJztcbmltcG9ydCBkaXNwYXRjaFJlcXVlc3QgZnJvbSAnLi9kaXNwYXRjaFJlcXVlc3QuanMnO1xuaW1wb3J0IG1lcmdlQ29uZmlnIGZyb20gJy4vbWVyZ2VDb25maWcuanMnO1xuaW1wb3J0IGJ1aWxkRnVsbFBhdGggZnJvbSAnLi9idWlsZEZ1bGxQYXRoLmpzJztcbmltcG9ydCB2YWxpZGF0b3IgZnJvbSAnLi4vaGVscGVycy92YWxpZGF0b3IuanMnO1xuaW1wb3J0IEF4aW9zSGVhZGVycyBmcm9tICcuL0F4aW9zSGVhZGVycy5qcyc7XG5cbmNvbnN0IHZhbGlkYXRvcnMgPSB2YWxpZGF0b3IudmFsaWRhdG9ycztcblxuLyoqXG4gKiBDcmVhdGUgYSBuZXcgaW5zdGFuY2Ugb2YgQXhpb3NcbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gaW5zdGFuY2VDb25maWcgVGhlIGRlZmF1bHQgY29uZmlnIGZvciB0aGUgaW5zdGFuY2VcbiAqXG4gKiBAcmV0dXJuIHtBeGlvc30gQSBuZXcgaW5zdGFuY2Ugb2YgQXhpb3NcbiAqL1xuY2xhc3MgQXhpb3Mge1xuICBjb25zdHJ1Y3RvcihpbnN0YW5jZUNvbmZpZykge1xuICAgIHRoaXMuZGVmYXVsdHMgPSBpbnN0YW5jZUNvbmZpZztcbiAgICB0aGlzLmludGVyY2VwdG9ycyA9IHtcbiAgICAgIHJlcXVlc3Q6IG5ldyBJbnRlcmNlcHRvck1hbmFnZXIoKSxcbiAgICAgIHJlc3BvbnNlOiBuZXcgSW50ZXJjZXB0b3JNYW5hZ2VyKClcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIERpc3BhdGNoIGEgcmVxdWVzdFxuICAgKlxuICAgKiBAcGFyYW0ge1N0cmluZ3xPYmplY3R9IGNvbmZpZ09yVXJsIFRoZSBjb25maWcgc3BlY2lmaWMgZm9yIHRoaXMgcmVxdWVzdCAobWVyZ2VkIHdpdGggdGhpcy5kZWZhdWx0cylcbiAgICogQHBhcmFtIHs/T2JqZWN0fSBjb25maWdcbiAgICpcbiAgICogQHJldHVybnMge1Byb21pc2V9IFRoZSBQcm9taXNlIHRvIGJlIGZ1bGZpbGxlZFxuICAgKi9cbiAgYXN5bmMgcmVxdWVzdChjb25maWdPclVybCwgY29uZmlnKSB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLl9yZXF1ZXN0KGNvbmZpZ09yVXJsLCBjb25maWcpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICAgIGxldCBkdW1teTtcblxuICAgICAgICBFcnJvci5jYXB0dXJlU3RhY2tUcmFjZSA/IEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKGR1bW15ID0ge30pIDogKGR1bW15ID0gbmV3IEVycm9yKCkpO1xuXG4gICAgICAgIC8vIHNsaWNlIG9mZiB0aGUgRXJyb3I6IC4uLiBsaW5lXG4gICAgICAgIGNvbnN0IHN0YWNrID0gZHVtbXkuc3RhY2sgPyBkdW1teS5zdGFjay5yZXBsYWNlKC9eLitcXG4vLCAnJykgOiAnJztcblxuICAgICAgICBpZiAoIWVyci5zdGFjaykge1xuICAgICAgICAgIGVyci5zdGFjayA9IHN0YWNrO1xuICAgICAgICAgIC8vIG1hdGNoIHdpdGhvdXQgdGhlIDIgdG9wIHN0YWNrIGxpbmVzXG4gICAgICAgIH0gZWxzZSBpZiAoc3RhY2sgJiYgIVN0cmluZyhlcnIuc3RhY2spLmVuZHNXaXRoKHN0YWNrLnJlcGxhY2UoL14uK1xcbi4rXFxuLywgJycpKSkge1xuICAgICAgICAgIGVyci5zdGFjayArPSAnXFxuJyArIHN0YWNrXG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgdGhyb3cgZXJyO1xuICAgIH1cbiAgfVxuXG4gIF9yZXF1ZXN0KGNvbmZpZ09yVXJsLCBjb25maWcpIHtcbiAgICAvKmVzbGludCBuby1wYXJhbS1yZWFzc2lnbjowKi9cbiAgICAvLyBBbGxvdyBmb3IgYXhpb3MoJ2V4YW1wbGUvdXJsJ1ssIGNvbmZpZ10pIGEgbGEgZmV0Y2ggQVBJXG4gICAgaWYgKHR5cGVvZiBjb25maWdPclVybCA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGNvbmZpZyA9IGNvbmZpZyB8fCB7fTtcbiAgICAgIGNvbmZpZy51cmwgPSBjb25maWdPclVybDtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uZmlnID0gY29uZmlnT3JVcmwgfHwge307XG4gICAgfVxuXG4gICAgY29uZmlnID0gbWVyZ2VDb25maWcodGhpcy5kZWZhdWx0cywgY29uZmlnKTtcblxuICAgIGNvbnN0IHt0cmFuc2l0aW9uYWwsIHBhcmFtc1NlcmlhbGl6ZXIsIGhlYWRlcnN9ID0gY29uZmlnO1xuXG4gICAgaWYgKHRyYW5zaXRpb25hbCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB2YWxpZGF0b3IuYXNzZXJ0T3B0aW9ucyh0cmFuc2l0aW9uYWwsIHtcbiAgICAgICAgc2lsZW50SlNPTlBhcnNpbmc6IHZhbGlkYXRvcnMudHJhbnNpdGlvbmFsKHZhbGlkYXRvcnMuYm9vbGVhbiksXG4gICAgICAgIGZvcmNlZEpTT05QYXJzaW5nOiB2YWxpZGF0b3JzLnRyYW5zaXRpb25hbCh2YWxpZGF0b3JzLmJvb2xlYW4pLFxuICAgICAgICBjbGFyaWZ5VGltZW91dEVycm9yOiB2YWxpZGF0b3JzLnRyYW5zaXRpb25hbCh2YWxpZGF0b3JzLmJvb2xlYW4pXG4gICAgICB9LCBmYWxzZSk7XG4gICAgfVxuXG4gICAgaWYgKHBhcmFtc1NlcmlhbGl6ZXIgIT0gbnVsbCkge1xuICAgICAgaWYgKHV0aWxzLmlzRnVuY3Rpb24ocGFyYW1zU2VyaWFsaXplcikpIHtcbiAgICAgICAgY29uZmlnLnBhcmFtc1NlcmlhbGl6ZXIgPSB7XG4gICAgICAgICAgc2VyaWFsaXplOiBwYXJhbXNTZXJpYWxpemVyXG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHZhbGlkYXRvci5hc3NlcnRPcHRpb25zKHBhcmFtc1NlcmlhbGl6ZXIsIHtcbiAgICAgICAgICBlbmNvZGU6IHZhbGlkYXRvcnMuZnVuY3Rpb24sXG4gICAgICAgICAgc2VyaWFsaXplOiB2YWxpZGF0b3JzLmZ1bmN0aW9uXG4gICAgICAgIH0sIHRydWUpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFNldCBjb25maWcubWV0aG9kXG4gICAgY29uZmlnLm1ldGhvZCA9IChjb25maWcubWV0aG9kIHx8IHRoaXMuZGVmYXVsdHMubWV0aG9kIHx8ICdnZXQnKS50b0xvd2VyQ2FzZSgpO1xuXG4gICAgLy8gRmxhdHRlbiBoZWFkZXJzXG4gICAgbGV0IGNvbnRleHRIZWFkZXJzID0gaGVhZGVycyAmJiB1dGlscy5tZXJnZShcbiAgICAgIGhlYWRlcnMuY29tbW9uLFxuICAgICAgaGVhZGVyc1tjb25maWcubWV0aG9kXVxuICAgICk7XG5cbiAgICBoZWFkZXJzICYmIHV0aWxzLmZvckVhY2goXG4gICAgICBbJ2RlbGV0ZScsICdnZXQnLCAnaGVhZCcsICdwb3N0JywgJ3B1dCcsICdwYXRjaCcsICdjb21tb24nXSxcbiAgICAgIChtZXRob2QpID0+IHtcbiAgICAgICAgZGVsZXRlIGhlYWRlcnNbbWV0aG9kXTtcbiAgICAgIH1cbiAgICApO1xuXG4gICAgY29uZmlnLmhlYWRlcnMgPSBBeGlvc0hlYWRlcnMuY29uY2F0KGNvbnRleHRIZWFkZXJzLCBoZWFkZXJzKTtcblxuICAgIC8vIGZpbHRlciBvdXQgc2tpcHBlZCBpbnRlcmNlcHRvcnNcbiAgICBjb25zdCByZXF1ZXN0SW50ZXJjZXB0b3JDaGFpbiA9IFtdO1xuICAgIGxldCBzeW5jaHJvbm91c1JlcXVlc3RJbnRlcmNlcHRvcnMgPSB0cnVlO1xuICAgIHRoaXMuaW50ZXJjZXB0b3JzLnJlcXVlc3QuZm9yRWFjaChmdW5jdGlvbiB1bnNoaWZ0UmVxdWVzdEludGVyY2VwdG9ycyhpbnRlcmNlcHRvcikge1xuICAgICAgaWYgKHR5cGVvZiBpbnRlcmNlcHRvci5ydW5XaGVuID09PSAnZnVuY3Rpb24nICYmIGludGVyY2VwdG9yLnJ1bldoZW4oY29uZmlnKSA9PT0gZmFsc2UpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBzeW5jaHJvbm91c1JlcXVlc3RJbnRlcmNlcHRvcnMgPSBzeW5jaHJvbm91c1JlcXVlc3RJbnRlcmNlcHRvcnMgJiYgaW50ZXJjZXB0b3Iuc3luY2hyb25vdXM7XG5cbiAgICAgIHJlcXVlc3RJbnRlcmNlcHRvckNoYWluLnVuc2hpZnQoaW50ZXJjZXB0b3IuZnVsZmlsbGVkLCBpbnRlcmNlcHRvci5yZWplY3RlZCk7XG4gICAgfSk7XG5cbiAgICBjb25zdCByZXNwb25zZUludGVyY2VwdG9yQ2hhaW4gPSBbXTtcbiAgICB0aGlzLmludGVyY2VwdG9ycy5yZXNwb25zZS5mb3JFYWNoKGZ1bmN0aW9uIHB1c2hSZXNwb25zZUludGVyY2VwdG9ycyhpbnRlcmNlcHRvcikge1xuICAgICAgcmVzcG9uc2VJbnRlcmNlcHRvckNoYWluLnB1c2goaW50ZXJjZXB0b3IuZnVsZmlsbGVkLCBpbnRlcmNlcHRvci5yZWplY3RlZCk7XG4gICAgfSk7XG5cbiAgICBsZXQgcHJvbWlzZTtcbiAgICBsZXQgaSA9IDA7XG4gICAgbGV0IGxlbjtcblxuICAgIGlmICghc3luY2hyb25vdXNSZXF1ZXN0SW50ZXJjZXB0b3JzKSB7XG4gICAgICBjb25zdCBjaGFpbiA9IFtkaXNwYXRjaFJlcXVlc3QuYmluZCh0aGlzKSwgdW5kZWZpbmVkXTtcbiAgICAgIGNoYWluLnVuc2hpZnQuYXBwbHkoY2hhaW4sIHJlcXVlc3RJbnRlcmNlcHRvckNoYWluKTtcbiAgICAgIGNoYWluLnB1c2guYXBwbHkoY2hhaW4sIHJlc3BvbnNlSW50ZXJjZXB0b3JDaGFpbik7XG4gICAgICBsZW4gPSBjaGFpbi5sZW5ndGg7XG5cbiAgICAgIHByb21pc2UgPSBQcm9taXNlLnJlc29sdmUoY29uZmlnKTtcblxuICAgICAgd2hpbGUgKGkgPCBsZW4pIHtcbiAgICAgICAgcHJvbWlzZSA9IHByb21pc2UudGhlbihjaGFpbltpKytdLCBjaGFpbltpKytdKTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgfVxuXG4gICAgbGVuID0gcmVxdWVzdEludGVyY2VwdG9yQ2hhaW4ubGVuZ3RoO1xuXG4gICAgbGV0IG5ld0NvbmZpZyA9IGNvbmZpZztcblxuICAgIGkgPSAwO1xuXG4gICAgd2hpbGUgKGkgPCBsZW4pIHtcbiAgICAgIGNvbnN0IG9uRnVsZmlsbGVkID0gcmVxdWVzdEludGVyY2VwdG9yQ2hhaW5baSsrXTtcbiAgICAgIGNvbnN0IG9uUmVqZWN0ZWQgPSByZXF1ZXN0SW50ZXJjZXB0b3JDaGFpbltpKytdO1xuICAgICAgdHJ5IHtcbiAgICAgICAgbmV3Q29uZmlnID0gb25GdWxmaWxsZWQobmV3Q29uZmlnKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIG9uUmVqZWN0ZWQuY2FsbCh0aGlzLCBlcnJvcik7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBwcm9taXNlID0gZGlzcGF0Y2hSZXF1ZXN0LmNhbGwodGhpcywgbmV3Q29uZmlnKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgICB9XG5cbiAgICBpID0gMDtcbiAgICBsZW4gPSByZXNwb25zZUludGVyY2VwdG9yQ2hhaW4ubGVuZ3RoO1xuXG4gICAgd2hpbGUgKGkgPCBsZW4pIHtcbiAgICAgIHByb21pc2UgPSBwcm9taXNlLnRoZW4ocmVzcG9uc2VJbnRlcmNlcHRvckNoYWluW2krK10sIHJlc3BvbnNlSW50ZXJjZXB0b3JDaGFpbltpKytdKTtcbiAgICB9XG5cbiAgICByZXR1cm4gcHJvbWlzZTtcbiAgfVxuXG4gIGdldFVyaShjb25maWcpIHtcbiAgICBjb25maWcgPSBtZXJnZUNvbmZpZyh0aGlzLmRlZmF1bHRzLCBjb25maWcpO1xuICAgIGNvbnN0IGZ1bGxQYXRoID0gYnVpbGRGdWxsUGF0aChjb25maWcuYmFzZVVSTCwgY29uZmlnLnVybCk7XG4gICAgcmV0dXJuIGJ1aWxkVVJMKGZ1bGxQYXRoLCBjb25maWcucGFyYW1zLCBjb25maWcucGFyYW1zU2VyaWFsaXplcik7XG4gIH1cbn1cblxuLy8gUHJvdmlkZSBhbGlhc2VzIGZvciBzdXBwb3J0ZWQgcmVxdWVzdCBtZXRob2RzXG51dGlscy5mb3JFYWNoKFsnZGVsZXRlJywgJ2dldCcsICdoZWFkJywgJ29wdGlvbnMnXSwgZnVuY3Rpb24gZm9yRWFjaE1ldGhvZE5vRGF0YShtZXRob2QpIHtcbiAgLyplc2xpbnQgZnVuYy1uYW1lczowKi9cbiAgQXhpb3MucHJvdG90eXBlW21ldGhvZF0gPSBmdW5jdGlvbih1cmwsIGNvbmZpZykge1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3QobWVyZ2VDb25maWcoY29uZmlnIHx8IHt9LCB7XG4gICAgICBtZXRob2QsXG4gICAgICB1cmwsXG4gICAgICBkYXRhOiAoY29uZmlnIHx8IHt9KS5kYXRhXG4gICAgfSkpO1xuICB9O1xufSk7XG5cbnV0aWxzLmZvckVhY2goWydwb3N0JywgJ3B1dCcsICdwYXRjaCddLCBmdW5jdGlvbiBmb3JFYWNoTWV0aG9kV2l0aERhdGEobWV0aG9kKSB7XG4gIC8qZXNsaW50IGZ1bmMtbmFtZXM6MCovXG5cbiAgZnVuY3Rpb24gZ2VuZXJhdGVIVFRQTWV0aG9kKGlzRm9ybSkge1xuICAgIHJldHVybiBmdW5jdGlvbiBodHRwTWV0aG9kKHVybCwgZGF0YSwgY29uZmlnKSB7XG4gICAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KG1lcmdlQ29uZmlnKGNvbmZpZyB8fCB7fSwge1xuICAgICAgICBtZXRob2QsXG4gICAgICAgIGhlYWRlcnM6IGlzRm9ybSA/IHtcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ211bHRpcGFydC9mb3JtLWRhdGEnXG4gICAgICAgIH0gOiB7fSxcbiAgICAgICAgdXJsLFxuICAgICAgICBkYXRhXG4gICAgICB9KSk7XG4gICAgfTtcbiAgfVxuXG4gIEF4aW9zLnByb3RvdHlwZVttZXRob2RdID0gZ2VuZXJhdGVIVFRQTWV0aG9kKCk7XG5cbiAgQXhpb3MucHJvdG90eXBlW21ldGhvZCArICdGb3JtJ10gPSBnZW5lcmF0ZUhUVFBNZXRob2QodHJ1ZSk7XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgQXhpb3M7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgQXhpb3NVUkxTZWFyY2hQYXJhbXMgZnJvbSAnLi4vaGVscGVycy9BeGlvc1VSTFNlYXJjaFBhcmFtcy5qcyc7XG5cbi8qKlxuICogSXQgcmVwbGFjZXMgYWxsIGluc3RhbmNlcyBvZiB0aGUgY2hhcmFjdGVycyBgOmAsIGAkYCwgYCxgLCBgK2AsIGBbYCwgYW5kIGBdYCB3aXRoIHRoZWlyXG4gKiBVUkkgZW5jb2RlZCBjb3VudGVycGFydHNcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gdmFsIFRoZSB2YWx1ZSB0byBiZSBlbmNvZGVkLlxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBlbmNvZGVkIHZhbHVlLlxuICovXG5mdW5jdGlvbiBlbmNvZGUodmFsKSB7XG4gIHJldHVybiBlbmNvZGVVUklDb21wb25lbnQodmFsKS5cbiAgICByZXBsYWNlKC8lM0EvZ2ksICc6JykuXG4gICAgcmVwbGFjZSgvJTI0L2csICckJykuXG4gICAgcmVwbGFjZSgvJTJDL2dpLCAnLCcpLlxuICAgIHJlcGxhY2UoLyUyMC9nLCAnKycpLlxuICAgIHJlcGxhY2UoLyU1Qi9naSwgJ1snKS5cbiAgICByZXBsYWNlKC8lNUQvZ2ksICddJyk7XG59XG5cbi8qKlxuICogQnVpbGQgYSBVUkwgYnkgYXBwZW5kaW5nIHBhcmFtcyB0byB0aGUgZW5kXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IHVybCBUaGUgYmFzZSBvZiB0aGUgdXJsIChlLmcuLCBodHRwOi8vd3d3Lmdvb2dsZS5jb20pXG4gKiBAcGFyYW0ge29iamVjdH0gW3BhcmFtc10gVGhlIHBhcmFtcyB0byBiZSBhcHBlbmRlZFxuICogQHBhcmFtIHs/b2JqZWN0fSBvcHRpb25zXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gVGhlIGZvcm1hdHRlZCB1cmxcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gYnVpbGRVUkwodXJsLCBwYXJhbXMsIG9wdGlvbnMpIHtcbiAgLyplc2xpbnQgbm8tcGFyYW0tcmVhc3NpZ246MCovXG4gIGlmICghcGFyYW1zKSB7XG4gICAgcmV0dXJuIHVybDtcbiAgfVxuICBcbiAgY29uc3QgX2VuY29kZSA9IG9wdGlvbnMgJiYgb3B0aW9ucy5lbmNvZGUgfHwgZW5jb2RlO1xuXG4gIGNvbnN0IHNlcmlhbGl6ZUZuID0gb3B0aW9ucyAmJiBvcHRpb25zLnNlcmlhbGl6ZTtcblxuICBsZXQgc2VyaWFsaXplZFBhcmFtcztcblxuICBpZiAoc2VyaWFsaXplRm4pIHtcbiAgICBzZXJpYWxpemVkUGFyYW1zID0gc2VyaWFsaXplRm4ocGFyYW1zLCBvcHRpb25zKTtcbiAgfSBlbHNlIHtcbiAgICBzZXJpYWxpemVkUGFyYW1zID0gdXRpbHMuaXNVUkxTZWFyY2hQYXJhbXMocGFyYW1zKSA/XG4gICAgICBwYXJhbXMudG9TdHJpbmcoKSA6XG4gICAgICBuZXcgQXhpb3NVUkxTZWFyY2hQYXJhbXMocGFyYW1zLCBvcHRpb25zKS50b1N0cmluZyhfZW5jb2RlKTtcbiAgfVxuXG4gIGlmIChzZXJpYWxpemVkUGFyYW1zKSB7XG4gICAgY29uc3QgaGFzaG1hcmtJbmRleCA9IHVybC5pbmRleE9mKFwiI1wiKTtcblxuICAgIGlmIChoYXNobWFya0luZGV4ICE9PSAtMSkge1xuICAgICAgdXJsID0gdXJsLnNsaWNlKDAsIGhhc2htYXJrSW5kZXgpO1xuICAgIH1cbiAgICB1cmwgKz0gKHVybC5pbmRleE9mKCc/JykgPT09IC0xID8gJz8nIDogJyYnKSArIHNlcmlhbGl6ZWRQYXJhbXM7XG4gIH1cblxuICByZXR1cm4gdXJsO1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdG9Gb3JtRGF0YSBmcm9tICcuL3RvRm9ybURhdGEuanMnO1xuXG4vKipcbiAqIEl0IGVuY29kZXMgYSBzdHJpbmcgYnkgcmVwbGFjaW5nIGFsbCBjaGFyYWN0ZXJzIHRoYXQgYXJlIG5vdCBpbiB0aGUgdW5yZXNlcnZlZCBzZXQgd2l0aFxuICogdGhlaXIgcGVyY2VudC1lbmNvZGVkIGVxdWl2YWxlbnRzXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IHN0ciAtIFRoZSBzdHJpbmcgdG8gZW5jb2RlLlxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBlbmNvZGVkIHN0cmluZy5cbiAqL1xuZnVuY3Rpb24gZW5jb2RlKHN0cikge1xuICBjb25zdCBjaGFyTWFwID0ge1xuICAgICchJzogJyUyMScsXG4gICAgXCInXCI6ICclMjcnLFxuICAgICcoJzogJyUyOCcsXG4gICAgJyknOiAnJTI5JyxcbiAgICAnfic6ICclN0UnLFxuICAgICclMjAnOiAnKycsXG4gICAgJyUwMCc6ICdcXHgwMCdcbiAgfTtcbiAgcmV0dXJuIGVuY29kZVVSSUNvbXBvbmVudChzdHIpLnJlcGxhY2UoL1shJygpfl18JTIwfCUwMC9nLCBmdW5jdGlvbiByZXBsYWNlcihtYXRjaCkge1xuICAgIHJldHVybiBjaGFyTWFwW21hdGNoXTtcbiAgfSk7XG59XG5cbi8qKlxuICogSXQgdGFrZXMgYSBwYXJhbXMgb2JqZWN0IGFuZCBjb252ZXJ0cyBpdCB0byBhIEZvcm1EYXRhIG9iamVjdFxuICpcbiAqIEBwYXJhbSB7T2JqZWN0PHN0cmluZywgYW55Pn0gcGFyYW1zIC0gVGhlIHBhcmFtZXRlcnMgdG8gYmUgY29udmVydGVkIHRvIGEgRm9ybURhdGEgb2JqZWN0LlxuICogQHBhcmFtIHtPYmplY3Q8c3RyaW5nLCBhbnk+fSBvcHRpb25zIC0gVGhlIG9wdGlvbnMgb2JqZWN0IHBhc3NlZCB0byB0aGUgQXhpb3MgY29uc3RydWN0b3IuXG4gKlxuICogQHJldHVybnMge3ZvaWR9XG4gKi9cbmZ1bmN0aW9uIEF4aW9zVVJMU2VhcmNoUGFyYW1zKHBhcmFtcywgb3B0aW9ucykge1xuICB0aGlzLl9wYWlycyA9IFtdO1xuXG4gIHBhcmFtcyAmJiB0b0Zvcm1EYXRhKHBhcmFtcywgdGhpcywgb3B0aW9ucyk7XG59XG5cbmNvbnN0IHByb3RvdHlwZSA9IEF4aW9zVVJMU2VhcmNoUGFyYW1zLnByb3RvdHlwZTtcblxucHJvdG90eXBlLmFwcGVuZCA9IGZ1bmN0aW9uIGFwcGVuZChuYW1lLCB2YWx1ZSkge1xuICB0aGlzLl9wYWlycy5wdXNoKFtuYW1lLCB2YWx1ZV0pO1xufTtcblxucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24gdG9TdHJpbmcoZW5jb2Rlcikge1xuICBjb25zdCBfZW5jb2RlID0gZW5jb2RlciA/IGZ1bmN0aW9uKHZhbHVlKSB7XG4gICAgcmV0dXJuIGVuY29kZXIuY2FsbCh0aGlzLCB2YWx1ZSwgZW5jb2RlKTtcbiAgfSA6IGVuY29kZTtcblxuICByZXR1cm4gdGhpcy5fcGFpcnMubWFwKGZ1bmN0aW9uIGVhY2gocGFpcikge1xuICAgIHJldHVybiBfZW5jb2RlKHBhaXJbMF0pICsgJz0nICsgX2VuY29kZShwYWlyWzFdKTtcbiAgfSwgJycpLmpvaW4oJyYnKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEF4aW9zVVJMU2VhcmNoUGFyYW1zO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdXRpbHMgZnJvbSAnLi4vdXRpbHMuanMnO1xuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi4vY29yZS9BeGlvc0Vycm9yLmpzJztcbi8vIHRlbXBvcmFyeSBob3RmaXggdG8gYXZvaWQgY2lyY3VsYXIgcmVmZXJlbmNlcyB1bnRpbCBBeGlvc1VSTFNlYXJjaFBhcmFtcyBpcyByZWZhY3RvcmVkXG5pbXBvcnQgUGxhdGZvcm1Gb3JtRGF0YSBmcm9tICcuLi9wbGF0Zm9ybS9ub2RlL2NsYXNzZXMvRm9ybURhdGEuanMnO1xuXG4vKipcbiAqIERldGVybWluZXMgaWYgdGhlIGdpdmVuIHRoaW5nIGlzIGEgYXJyYXkgb3IganMgb2JqZWN0LlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSB0aGluZyAtIFRoZSBvYmplY3Qgb3IgYXJyYXkgdG8gYmUgdmlzaXRlZC5cbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuZnVuY3Rpb24gaXNWaXNpdGFibGUodGhpbmcpIHtcbiAgcmV0dXJuIHV0aWxzLmlzUGxhaW5PYmplY3QodGhpbmcpIHx8IHV0aWxzLmlzQXJyYXkodGhpbmcpO1xufVxuXG4vKipcbiAqIEl0IHJlbW92ZXMgdGhlIGJyYWNrZXRzIGZyb20gdGhlIGVuZCBvZiBhIHN0cmluZ1xuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBrZXkgLSBUaGUga2V5IG9mIHRoZSBwYXJhbWV0ZXIuXG4gKlxuICogQHJldHVybnMge3N0cmluZ30gdGhlIGtleSB3aXRob3V0IHRoZSBicmFja2V0cy5cbiAqL1xuZnVuY3Rpb24gcmVtb3ZlQnJhY2tldHMoa2V5KSB7XG4gIHJldHVybiB1dGlscy5lbmRzV2l0aChrZXksICdbXScpID8ga2V5LnNsaWNlKDAsIC0yKSA6IGtleTtcbn1cblxuLyoqXG4gKiBJdCB0YWtlcyBhIHBhdGgsIGEga2V5LCBhbmQgYSBib29sZWFuLCBhbmQgcmV0dXJucyBhIHN0cmluZ1xuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBwYXRoIC0gVGhlIHBhdGggdG8gdGhlIGN1cnJlbnQga2V5LlxuICogQHBhcmFtIHtzdHJpbmd9IGtleSAtIFRoZSBrZXkgb2YgdGhlIGN1cnJlbnQgb2JqZWN0IGJlaW5nIGl0ZXJhdGVkIG92ZXIuXG4gKiBAcGFyYW0ge3N0cmluZ30gZG90cyAtIElmIHRydWUsIHRoZSBrZXkgd2lsbCBiZSByZW5kZXJlZCB3aXRoIGRvdHMgaW5zdGVhZCBvZiBicmFja2V0cy5cbiAqXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBUaGUgcGF0aCB0byB0aGUgY3VycmVudCBrZXkuXG4gKi9cbmZ1bmN0aW9uIHJlbmRlcktleShwYXRoLCBrZXksIGRvdHMpIHtcbiAgaWYgKCFwYXRoKSByZXR1cm4ga2V5O1xuICByZXR1cm4gcGF0aC5jb25jYXQoa2V5KS5tYXAoZnVuY3Rpb24gZWFjaCh0b2tlbiwgaSkge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuICAgIHRva2VuID0gcmVtb3ZlQnJhY2tldHModG9rZW4pO1xuICAgIHJldHVybiAhZG90cyAmJiBpID8gJ1snICsgdG9rZW4gKyAnXScgOiB0b2tlbjtcbiAgfSkuam9pbihkb3RzID8gJy4nIDogJycpO1xufVxuXG4vKipcbiAqIElmIHRoZSBhcnJheSBpcyBhbiBhcnJheSBhbmQgbm9uZSBvZiBpdHMgZWxlbWVudHMgYXJlIHZpc2l0YWJsZSwgdGhlbiBpdCdzIGEgZmxhdCBhcnJheS5cbiAqXG4gKiBAcGFyYW0ge0FycmF5PGFueT59IGFyciAtIFRoZSBhcnJheSB0byBjaGVja1xuICpcbiAqIEByZXR1cm5zIHtib29sZWFufVxuICovXG5mdW5jdGlvbiBpc0ZsYXRBcnJheShhcnIpIHtcbiAgcmV0dXJuIHV0aWxzLmlzQXJyYXkoYXJyKSAmJiAhYXJyLnNvbWUoaXNWaXNpdGFibGUpO1xufVxuXG5jb25zdCBwcmVkaWNhdGVzID0gdXRpbHMudG9GbGF0T2JqZWN0KHV0aWxzLCB7fSwgbnVsbCwgZnVuY3Rpb24gZmlsdGVyKHByb3ApIHtcbiAgcmV0dXJuIC9eaXNbQS1aXS8udGVzdChwcm9wKTtcbn0pO1xuXG4vKipcbiAqIENvbnZlcnQgYSBkYXRhIG9iamVjdCB0byBGb3JtRGF0YVxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmpcbiAqIEBwYXJhbSB7P09iamVjdH0gW2Zvcm1EYXRhXVxuICogQHBhcmFtIHs/T2JqZWN0fSBbb3B0aW9uc11cbiAqIEBwYXJhbSB7RnVuY3Rpb259IFtvcHRpb25zLnZpc2l0b3JdXG4gKiBAcGFyYW0ge0Jvb2xlYW59IFtvcHRpb25zLm1ldGFUb2tlbnMgPSB0cnVlXVxuICogQHBhcmFtIHtCb29sZWFufSBbb3B0aW9ucy5kb3RzID0gZmFsc2VdXG4gKiBAcGFyYW0gez9Cb29sZWFufSBbb3B0aW9ucy5pbmRleGVzID0gZmFsc2VdXG4gKlxuICogQHJldHVybnMge09iamVjdH1cbiAqKi9cblxuLyoqXG4gKiBJdCBjb252ZXJ0cyBhbiBvYmplY3QgaW50byBhIEZvcm1EYXRhIG9iamVjdFxuICpcbiAqIEBwYXJhbSB7T2JqZWN0PGFueSwgYW55Pn0gb2JqIC0gVGhlIG9iamVjdCB0byBjb252ZXJ0IHRvIGZvcm0gZGF0YS5cbiAqIEBwYXJhbSB7c3RyaW5nfSBmb3JtRGF0YSAtIFRoZSBGb3JtRGF0YSBvYmplY3QgdG8gYXBwZW5kIHRvLlxuICogQHBhcmFtIHtPYmplY3Q8c3RyaW5nLCBhbnk+fSBvcHRpb25zXG4gKlxuICogQHJldHVybnNcbiAqL1xuZnVuY3Rpb24gdG9Gb3JtRGF0YShvYmosIGZvcm1EYXRhLCBvcHRpb25zKSB7XG4gIGlmICghdXRpbHMuaXNPYmplY3Qob2JqKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ3RhcmdldCBtdXN0IGJlIGFuIG9iamVjdCcpO1xuICB9XG5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gIGZvcm1EYXRhID0gZm9ybURhdGEgfHwgbmV3IChQbGF0Zm9ybUZvcm1EYXRhIHx8IEZvcm1EYXRhKSgpO1xuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuICBvcHRpb25zID0gdXRpbHMudG9GbGF0T2JqZWN0KG9wdGlvbnMsIHtcbiAgICBtZXRhVG9rZW5zOiB0cnVlLFxuICAgIGRvdHM6IGZhbHNlLFxuICAgIGluZGV4ZXM6IGZhbHNlXG4gIH0sIGZhbHNlLCBmdW5jdGlvbiBkZWZpbmVkKG9wdGlvbiwgc291cmNlKSB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWVxLW51bGwsZXFlcWVxXG4gICAgcmV0dXJuICF1dGlscy5pc1VuZGVmaW5lZChzb3VyY2Vbb3B0aW9uXSk7XG4gIH0pO1xuXG4gIGNvbnN0IG1ldGFUb2tlbnMgPSBvcHRpb25zLm1ldGFUb2tlbnM7XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11c2UtYmVmb3JlLWRlZmluZVxuICBjb25zdCB2aXNpdG9yID0gb3B0aW9ucy52aXNpdG9yIHx8IGRlZmF1bHRWaXNpdG9yO1xuICBjb25zdCBkb3RzID0gb3B0aW9ucy5kb3RzO1xuICBjb25zdCBpbmRleGVzID0gb3B0aW9ucy5pbmRleGVzO1xuICBjb25zdCBfQmxvYiA9IG9wdGlvbnMuQmxvYiB8fCB0eXBlb2YgQmxvYiAhPT0gJ3VuZGVmaW5lZCcgJiYgQmxvYjtcbiAgY29uc3QgdXNlQmxvYiA9IF9CbG9iICYmIHV0aWxzLmlzU3BlY0NvbXBsaWFudEZvcm0oZm9ybURhdGEpO1xuXG4gIGlmICghdXRpbHMuaXNGdW5jdGlvbih2aXNpdG9yKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ3Zpc2l0b3IgbXVzdCBiZSBhIGZ1bmN0aW9uJyk7XG4gIH1cblxuICBmdW5jdGlvbiBjb252ZXJ0VmFsdWUodmFsdWUpIHtcbiAgICBpZiAodmFsdWUgPT09IG51bGwpIHJldHVybiAnJztcblxuICAgIGlmICh1dGlscy5pc0RhdGUodmFsdWUpKSB7XG4gICAgICByZXR1cm4gdmFsdWUudG9JU09TdHJpbmcoKTtcbiAgICB9XG5cbiAgICBpZiAoIXVzZUJsb2IgJiYgdXRpbHMuaXNCbG9iKHZhbHVlKSkge1xuICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoJ0Jsb2IgaXMgbm90IHN1cHBvcnRlZC4gVXNlIGEgQnVmZmVyIGluc3RlYWQuJyk7XG4gICAgfVxuXG4gICAgaWYgKHV0aWxzLmlzQXJyYXlCdWZmZXIodmFsdWUpIHx8IHV0aWxzLmlzVHlwZWRBcnJheSh2YWx1ZSkpIHtcbiAgICAgIHJldHVybiB1c2VCbG9iICYmIHR5cGVvZiBCbG9iID09PSAnZnVuY3Rpb24nID8gbmV3IEJsb2IoW3ZhbHVlXSkgOiBCdWZmZXIuZnJvbSh2YWx1ZSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG5cbiAgLyoqXG4gICAqIERlZmF1bHQgdmlzaXRvci5cbiAgICpcbiAgICogQHBhcmFtIHsqfSB2YWx1ZVxuICAgKiBAcGFyYW0ge1N0cmluZ3xOdW1iZXJ9IGtleVxuICAgKiBAcGFyYW0ge0FycmF5PFN0cmluZ3xOdW1iZXI+fSBwYXRoXG4gICAqIEB0aGlzIHtGb3JtRGF0YX1cbiAgICpcbiAgICogQHJldHVybnMge2Jvb2xlYW59IHJldHVybiB0cnVlIHRvIHZpc2l0IHRoZSBlYWNoIHByb3Agb2YgdGhlIHZhbHVlIHJlY3Vyc2l2ZWx5XG4gICAqL1xuICBmdW5jdGlvbiBkZWZhdWx0VmlzaXRvcih2YWx1ZSwga2V5LCBwYXRoKSB7XG4gICAgbGV0IGFyciA9IHZhbHVlO1xuXG4gICAgaWYgKHZhbHVlICYmICFwYXRoICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcpIHtcbiAgICAgIGlmICh1dGlscy5lbmRzV2l0aChrZXksICd7fScpKSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1wYXJhbS1yZWFzc2lnblxuICAgICAgICBrZXkgPSBtZXRhVG9rZW5zID8ga2V5IDoga2V5LnNsaWNlKDAsIC0yKTtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gICAgICAgIHZhbHVlID0gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgKHV0aWxzLmlzQXJyYXkodmFsdWUpICYmIGlzRmxhdEFycmF5KHZhbHVlKSkgfHxcbiAgICAgICAgKCh1dGlscy5pc0ZpbGVMaXN0KHZhbHVlKSB8fCB1dGlscy5lbmRzV2l0aChrZXksICdbXScpKSAmJiAoYXJyID0gdXRpbHMudG9BcnJheSh2YWx1ZSkpXG4gICAgICAgICkpIHtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gICAgICAgIGtleSA9IHJlbW92ZUJyYWNrZXRzKGtleSk7XG5cbiAgICAgICAgYXJyLmZvckVhY2goZnVuY3Rpb24gZWFjaChlbCwgaW5kZXgpIHtcbiAgICAgICAgICAhKHV0aWxzLmlzVW5kZWZpbmVkKGVsKSB8fCBlbCA9PT0gbnVsbCkgJiYgZm9ybURhdGEuYXBwZW5kKFxuICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLW5lc3RlZC10ZXJuYXJ5XG4gICAgICAgICAgICBpbmRleGVzID09PSB0cnVlID8gcmVuZGVyS2V5KFtrZXldLCBpbmRleCwgZG90cykgOiAoaW5kZXhlcyA9PT0gbnVsbCA/IGtleSA6IGtleSArICdbXScpLFxuICAgICAgICAgICAgY29udmVydFZhbHVlKGVsKVxuICAgICAgICAgICk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGlzVmlzaXRhYmxlKHZhbHVlKSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgZm9ybURhdGEuYXBwZW5kKHJlbmRlcktleShwYXRoLCBrZXksIGRvdHMpLCBjb252ZXJ0VmFsdWUodmFsdWUpKTtcblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIGNvbnN0IHN0YWNrID0gW107XG5cbiAgY29uc3QgZXhwb3NlZEhlbHBlcnMgPSBPYmplY3QuYXNzaWduKHByZWRpY2F0ZXMsIHtcbiAgICBkZWZhdWx0VmlzaXRvcixcbiAgICBjb252ZXJ0VmFsdWUsXG4gICAgaXNWaXNpdGFibGVcbiAgfSk7XG5cbiAgZnVuY3Rpb24gYnVpbGQodmFsdWUsIHBhdGgpIHtcbiAgICBpZiAodXRpbHMuaXNVbmRlZmluZWQodmFsdWUpKSByZXR1cm47XG5cbiAgICBpZiAoc3RhY2suaW5kZXhPZih2YWx1ZSkgIT09IC0xKSB7XG4gICAgICB0aHJvdyBFcnJvcignQ2lyY3VsYXIgcmVmZXJlbmNlIGRldGVjdGVkIGluICcgKyBwYXRoLmpvaW4oJy4nKSk7XG4gICAgfVxuXG4gICAgc3RhY2sucHVzaCh2YWx1ZSk7XG5cbiAgICB1dGlscy5mb3JFYWNoKHZhbHVlLCBmdW5jdGlvbiBlYWNoKGVsLCBrZXkpIHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9ICEodXRpbHMuaXNVbmRlZmluZWQoZWwpIHx8IGVsID09PSBudWxsKSAmJiB2aXNpdG9yLmNhbGwoXG4gICAgICAgIGZvcm1EYXRhLCBlbCwgdXRpbHMuaXNTdHJpbmcoa2V5KSA/IGtleS50cmltKCkgOiBrZXksIHBhdGgsIGV4cG9zZWRIZWxwZXJzXG4gICAgICApO1xuXG4gICAgICBpZiAocmVzdWx0ID09PSB0cnVlKSB7XG4gICAgICAgIGJ1aWxkKGVsLCBwYXRoID8gcGF0aC5jb25jYXQoa2V5KSA6IFtrZXldKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHN0YWNrLnBvcCgpO1xuICB9XG5cbiAgaWYgKCF1dGlscy5pc09iamVjdChvYmopKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignZGF0YSBtdXN0IGJlIGFuIG9iamVjdCcpO1xuICB9XG5cbiAgYnVpbGQob2JqKTtcblxuICByZXR1cm4gZm9ybURhdGE7XG59XG5cbmV4cG9ydCBkZWZhdWx0IHRvRm9ybURhdGE7XG4iLCIvKiFcbiAqIFRoZSBidWZmZXIgbW9kdWxlIGZyb20gbm9kZS5qcywgZm9yIHRoZSBicm93c2VyLlxuICpcbiAqIEBhdXRob3IgICBGZXJvc3MgQWJvdWtoYWRpamVoIDxodHRwczovL2Zlcm9zcy5vcmc+XG4gKiBAbGljZW5zZSAgTUlUXG4gKi9cbi8qIGVzbGludC1kaXNhYmxlIG5vLXByb3RvICovXG5cbid1c2Ugc3RyaWN0J1xuXG5jb25zdCBiYXNlNjQgPSByZXF1aXJlKCdiYXNlNjQtanMnKVxuY29uc3QgaWVlZTc1NCA9IHJlcXVpcmUoJ2llZWU3NTQnKVxuY29uc3QgY3VzdG9tSW5zcGVjdFN5bWJvbCA9XG4gICh0eXBlb2YgU3ltYm9sID09PSAnZnVuY3Rpb24nICYmIHR5cGVvZiBTeW1ib2xbJ2ZvciddID09PSAnZnVuY3Rpb24nKSAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIGRvdC1ub3RhdGlvblxuICAgID8gU3ltYm9sWydmb3InXSgnbm9kZWpzLnV0aWwuaW5zcGVjdC5jdXN0b20nKSAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIGRvdC1ub3RhdGlvblxuICAgIDogbnVsbFxuXG5leHBvcnRzLkJ1ZmZlciA9IEJ1ZmZlclxuZXhwb3J0cy5TbG93QnVmZmVyID0gU2xvd0J1ZmZlclxuZXhwb3J0cy5JTlNQRUNUX01BWF9CWVRFUyA9IDUwXG5cbmNvbnN0IEtfTUFYX0xFTkdUSCA9IDB4N2ZmZmZmZmZcbmV4cG9ydHMua01heExlbmd0aCA9IEtfTUFYX0xFTkdUSFxuXG4vKipcbiAqIElmIGBCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVGA6XG4gKiAgID09PSB0cnVlICAgIFVzZSBVaW50OEFycmF5IGltcGxlbWVudGF0aW9uIChmYXN0ZXN0KVxuICogICA9PT0gZmFsc2UgICBQcmludCB3YXJuaW5nIGFuZCByZWNvbW1lbmQgdXNpbmcgYGJ1ZmZlcmAgdjQueCB3aGljaCBoYXMgYW4gT2JqZWN0XG4gKiAgICAgICAgICAgICAgIGltcGxlbWVudGF0aW9uIChtb3N0IGNvbXBhdGlibGUsIGV2ZW4gSUU2KVxuICpcbiAqIEJyb3dzZXJzIHRoYXQgc3VwcG9ydCB0eXBlZCBhcnJheXMgYXJlIElFIDEwKywgRmlyZWZveCA0KywgQ2hyb21lIDcrLCBTYWZhcmkgNS4xKyxcbiAqIE9wZXJhIDExLjYrLCBpT1MgNC4yKy5cbiAqXG4gKiBXZSByZXBvcnQgdGhhdCB0aGUgYnJvd3NlciBkb2VzIG5vdCBzdXBwb3J0IHR5cGVkIGFycmF5cyBpZiB0aGUgYXJlIG5vdCBzdWJjbGFzc2FibGVcbiAqIHVzaW5nIF9fcHJvdG9fXy4gRmlyZWZveCA0LTI5IGxhY2tzIHN1cHBvcnQgZm9yIGFkZGluZyBuZXcgcHJvcGVydGllcyB0byBgVWludDhBcnJheWBcbiAqIChTZWU6IGh0dHBzOi8vYnVnemlsbGEubW96aWxsYS5vcmcvc2hvd19idWcuY2dpP2lkPTY5NTQzOCkuIElFIDEwIGxhY2tzIHN1cHBvcnRcbiAqIGZvciBfX3Byb3RvX18gYW5kIGhhcyBhIGJ1Z2d5IHR5cGVkIGFycmF5IGltcGxlbWVudGF0aW9uLlxuICovXG5CdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCA9IHR5cGVkQXJyYXlTdXBwb3J0KClcblxuaWYgKCFCdWZmZXIuVFlQRURfQVJSQVlfU1VQUE9SVCAmJiB0eXBlb2YgY29uc29sZSAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICB0eXBlb2YgY29uc29sZS5lcnJvciA9PT0gJ2Z1bmN0aW9uJykge1xuICBjb25zb2xlLmVycm9yKFxuICAgICdUaGlzIGJyb3dzZXIgbGFja3MgdHlwZWQgYXJyYXkgKFVpbnQ4QXJyYXkpIHN1cHBvcnQgd2hpY2ggaXMgcmVxdWlyZWQgYnkgJyArXG4gICAgJ2BidWZmZXJgIHY1LnguIFVzZSBgYnVmZmVyYCB2NC54IGlmIHlvdSByZXF1aXJlIG9sZCBicm93c2VyIHN1cHBvcnQuJ1xuICApXG59XG5cbmZ1bmN0aW9uIHR5cGVkQXJyYXlTdXBwb3J0ICgpIHtcbiAgLy8gQ2FuIHR5cGVkIGFycmF5IGluc3RhbmNlcyBjYW4gYmUgYXVnbWVudGVkP1xuICB0cnkge1xuICAgIGNvbnN0IGFyciA9IG5ldyBVaW50OEFycmF5KDEpXG4gICAgY29uc3QgcHJvdG8gPSB7IGZvbzogZnVuY3Rpb24gKCkgeyByZXR1cm4gNDIgfSB9XG4gICAgT2JqZWN0LnNldFByb3RvdHlwZU9mKHByb3RvLCBVaW50OEFycmF5LnByb3RvdHlwZSlcbiAgICBPYmplY3Quc2V0UHJvdG90eXBlT2YoYXJyLCBwcm90bylcbiAgICByZXR1cm4gYXJyLmZvbygpID09PSA0MlxuICB9IGNhdGNoIChlKSB7XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cbn1cblxuT2JqZWN0LmRlZmluZVByb3BlcnR5KEJ1ZmZlci5wcm90b3R5cGUsICdwYXJlbnQnLCB7XG4gIGVudW1lcmFibGU6IHRydWUsXG4gIGdldDogZnVuY3Rpb24gKCkge1xuICAgIGlmICghQnVmZmVyLmlzQnVmZmVyKHRoaXMpKSByZXR1cm4gdW5kZWZpbmVkXG4gICAgcmV0dXJuIHRoaXMuYnVmZmVyXG4gIH1cbn0pXG5cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShCdWZmZXIucHJvdG90eXBlLCAnb2Zmc2V0Jywge1xuICBlbnVtZXJhYmxlOiB0cnVlLFxuICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoIUJ1ZmZlci5pc0J1ZmZlcih0aGlzKSkgcmV0dXJuIHVuZGVmaW5lZFxuICAgIHJldHVybiB0aGlzLmJ5dGVPZmZzZXRcbiAgfVxufSlcblxuZnVuY3Rpb24gY3JlYXRlQnVmZmVyIChsZW5ndGgpIHtcbiAgaWYgKGxlbmd0aCA+IEtfTUFYX0xFTkdUSCkge1xuICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdUaGUgdmFsdWUgXCInICsgbGVuZ3RoICsgJ1wiIGlzIGludmFsaWQgZm9yIG9wdGlvbiBcInNpemVcIicpXG4gIH1cbiAgLy8gUmV0dXJuIGFuIGF1Z21lbnRlZCBgVWludDhBcnJheWAgaW5zdGFuY2VcbiAgY29uc3QgYnVmID0gbmV3IFVpbnQ4QXJyYXkobGVuZ3RoKVxuICBPYmplY3Quc2V0UHJvdG90eXBlT2YoYnVmLCBCdWZmZXIucHJvdG90eXBlKVxuICByZXR1cm4gYnVmXG59XG5cbi8qKlxuICogVGhlIEJ1ZmZlciBjb25zdHJ1Y3RvciByZXR1cm5zIGluc3RhbmNlcyBvZiBgVWludDhBcnJheWAgdGhhdCBoYXZlIHRoZWlyXG4gKiBwcm90b3R5cGUgY2hhbmdlZCB0byBgQnVmZmVyLnByb3RvdHlwZWAuIEZ1cnRoZXJtb3JlLCBgQnVmZmVyYCBpcyBhIHN1YmNsYXNzIG9mXG4gKiBgVWludDhBcnJheWAsIHNvIHRoZSByZXR1cm5lZCBpbnN0YW5jZXMgd2lsbCBoYXZlIGFsbCB0aGUgbm9kZSBgQnVmZmVyYCBtZXRob2RzXG4gKiBhbmQgdGhlIGBVaW50OEFycmF5YCBtZXRob2RzLiBTcXVhcmUgYnJhY2tldCBub3RhdGlvbiB3b3JrcyBhcyBleHBlY3RlZCAtLSBpdFxuICogcmV0dXJucyBhIHNpbmdsZSBvY3RldC5cbiAqXG4gKiBUaGUgYFVpbnQ4QXJyYXlgIHByb3RvdHlwZSByZW1haW5zIHVubW9kaWZpZWQuXG4gKi9cblxuZnVuY3Rpb24gQnVmZmVyIChhcmcsIGVuY29kaW5nT3JPZmZzZXQsIGxlbmd0aCkge1xuICAvLyBDb21tb24gY2FzZS5cbiAgaWYgKHR5cGVvZiBhcmcgPT09ICdudW1iZXInKSB7XG4gICAgaWYgKHR5cGVvZiBlbmNvZGluZ09yT2Zmc2V0ID09PSAnc3RyaW5nJykge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcbiAgICAgICAgJ1RoZSBcInN0cmluZ1wiIGFyZ3VtZW50IG11c3QgYmUgb2YgdHlwZSBzdHJpbmcuIFJlY2VpdmVkIHR5cGUgbnVtYmVyJ1xuICAgICAgKVxuICAgIH1cbiAgICByZXR1cm4gYWxsb2NVbnNhZmUoYXJnKVxuICB9XG4gIHJldHVybiBmcm9tKGFyZywgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKVxufVxuXG5CdWZmZXIucG9vbFNpemUgPSA4MTkyIC8vIG5vdCB1c2VkIGJ5IHRoaXMgaW1wbGVtZW50YXRpb25cblxuZnVuY3Rpb24gZnJvbSAodmFsdWUsIGVuY29kaW5nT3JPZmZzZXQsIGxlbmd0aCkge1xuICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykge1xuICAgIHJldHVybiBmcm9tU3RyaW5nKHZhbHVlLCBlbmNvZGluZ09yT2Zmc2V0KVxuICB9XG5cbiAgaWYgKEFycmF5QnVmZmVyLmlzVmlldyh2YWx1ZSkpIHtcbiAgICByZXR1cm4gZnJvbUFycmF5Vmlldyh2YWx1ZSlcbiAgfVxuXG4gIGlmICh2YWx1ZSA9PSBudWxsKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcbiAgICAgICdUaGUgZmlyc3QgYXJndW1lbnQgbXVzdCBiZSBvbmUgb2YgdHlwZSBzdHJpbmcsIEJ1ZmZlciwgQXJyYXlCdWZmZXIsIEFycmF5LCAnICtcbiAgICAgICdvciBBcnJheS1saWtlIE9iamVjdC4gUmVjZWl2ZWQgdHlwZSAnICsgKHR5cGVvZiB2YWx1ZSlcbiAgICApXG4gIH1cblxuICBpZiAoaXNJbnN0YW5jZSh2YWx1ZSwgQXJyYXlCdWZmZXIpIHx8XG4gICAgICAodmFsdWUgJiYgaXNJbnN0YW5jZSh2YWx1ZS5idWZmZXIsIEFycmF5QnVmZmVyKSkpIHtcbiAgICByZXR1cm4gZnJvbUFycmF5QnVmZmVyKHZhbHVlLCBlbmNvZGluZ09yT2Zmc2V0LCBsZW5ndGgpXG4gIH1cblxuICBpZiAodHlwZW9mIFNoYXJlZEFycmF5QnVmZmVyICE9PSAndW5kZWZpbmVkJyAmJlxuICAgICAgKGlzSW5zdGFuY2UodmFsdWUsIFNoYXJlZEFycmF5QnVmZmVyKSB8fFxuICAgICAgKHZhbHVlICYmIGlzSW5zdGFuY2UodmFsdWUuYnVmZmVyLCBTaGFyZWRBcnJheUJ1ZmZlcikpKSkge1xuICAgIHJldHVybiBmcm9tQXJyYXlCdWZmZXIodmFsdWUsIGVuY29kaW5nT3JPZmZzZXQsIGxlbmd0aClcbiAgfVxuXG4gIGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcbiAgICAgICdUaGUgXCJ2YWx1ZVwiIGFyZ3VtZW50IG11c3Qgbm90IGJlIG9mIHR5cGUgbnVtYmVyLiBSZWNlaXZlZCB0eXBlIG51bWJlcidcbiAgICApXG4gIH1cblxuICBjb25zdCB2YWx1ZU9mID0gdmFsdWUudmFsdWVPZiAmJiB2YWx1ZS52YWx1ZU9mKClcbiAgaWYgKHZhbHVlT2YgIT0gbnVsbCAmJiB2YWx1ZU9mICE9PSB2YWx1ZSkge1xuICAgIHJldHVybiBCdWZmZXIuZnJvbSh2YWx1ZU9mLCBlbmNvZGluZ09yT2Zmc2V0LCBsZW5ndGgpXG4gIH1cblxuICBjb25zdCBiID0gZnJvbU9iamVjdCh2YWx1ZSlcbiAgaWYgKGIpIHJldHVybiBiXG5cbiAgaWYgKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1ByaW1pdGl2ZSAhPSBudWxsICYmXG4gICAgICB0eXBlb2YgdmFsdWVbU3ltYm9sLnRvUHJpbWl0aXZlXSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIHJldHVybiBCdWZmZXIuZnJvbSh2YWx1ZVtTeW1ib2wudG9QcmltaXRpdmVdKCdzdHJpbmcnKSwgZW5jb2RpbmdPck9mZnNldCwgbGVuZ3RoKVxuICB9XG5cbiAgdGhyb3cgbmV3IFR5cGVFcnJvcihcbiAgICAnVGhlIGZpcnN0IGFyZ3VtZW50IG11c3QgYmUgb25lIG9mIHR5cGUgc3RyaW5nLCBCdWZmZXIsIEFycmF5QnVmZmVyLCBBcnJheSwgJyArXG4gICAgJ29yIEFycmF5LWxpa2UgT2JqZWN0LiBSZWNlaXZlZCB0eXBlICcgKyAodHlwZW9mIHZhbHVlKVxuICApXG59XG5cbi8qKlxuICogRnVuY3Rpb25hbGx5IGVxdWl2YWxlbnQgdG8gQnVmZmVyKGFyZywgZW5jb2RpbmcpIGJ1dCB0aHJvd3MgYSBUeXBlRXJyb3JcbiAqIGlmIHZhbHVlIGlzIGEgbnVtYmVyLlxuICogQnVmZmVyLmZyb20oc3RyWywgZW5jb2RpbmddKVxuICogQnVmZmVyLmZyb20oYXJyYXkpXG4gKiBCdWZmZXIuZnJvbShidWZmZXIpXG4gKiBCdWZmZXIuZnJvbShhcnJheUJ1ZmZlclssIGJ5dGVPZmZzZXRbLCBsZW5ndGhdXSlcbiAqKi9cbkJ1ZmZlci5mcm9tID0gZnVuY3Rpb24gKHZhbHVlLCBlbmNvZGluZ09yT2Zmc2V0LCBsZW5ndGgpIHtcbiAgcmV0dXJuIGZyb20odmFsdWUsIGVuY29kaW5nT3JPZmZzZXQsIGxlbmd0aClcbn1cblxuLy8gTm90ZTogQ2hhbmdlIHByb3RvdHlwZSAqYWZ0ZXIqIEJ1ZmZlci5mcm9tIGlzIGRlZmluZWQgdG8gd29ya2Fyb3VuZCBDaHJvbWUgYnVnOlxuLy8gaHR0cHM6Ly9naXRodWIuY29tL2Zlcm9zcy9idWZmZXIvcHVsbC8xNDhcbk9iamVjdC5zZXRQcm90b3R5cGVPZihCdWZmZXIucHJvdG90eXBlLCBVaW50OEFycmF5LnByb3RvdHlwZSlcbk9iamVjdC5zZXRQcm90b3R5cGVPZihCdWZmZXIsIFVpbnQ4QXJyYXkpXG5cbmZ1bmN0aW9uIGFzc2VydFNpemUgKHNpemUpIHtcbiAgaWYgKHR5cGVvZiBzaXplICE9PSAnbnVtYmVyJykge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1wic2l6ZVwiIGFyZ3VtZW50IG11c3QgYmUgb2YgdHlwZSBudW1iZXInKVxuICB9IGVsc2UgaWYgKHNpemUgPCAwKSB7XG4gICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ1RoZSB2YWx1ZSBcIicgKyBzaXplICsgJ1wiIGlzIGludmFsaWQgZm9yIG9wdGlvbiBcInNpemVcIicpXG4gIH1cbn1cblxuZnVuY3Rpb24gYWxsb2MgKHNpemUsIGZpbGwsIGVuY29kaW5nKSB7XG4gIGFzc2VydFNpemUoc2l6ZSlcbiAgaWYgKHNpemUgPD0gMCkge1xuICAgIHJldHVybiBjcmVhdGVCdWZmZXIoc2l6ZSlcbiAgfVxuICBpZiAoZmlsbCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgLy8gT25seSBwYXkgYXR0ZW50aW9uIHRvIGVuY29kaW5nIGlmIGl0J3MgYSBzdHJpbmcuIFRoaXNcbiAgICAvLyBwcmV2ZW50cyBhY2NpZGVudGFsbHkgc2VuZGluZyBpbiBhIG51bWJlciB0aGF0IHdvdWxkXG4gICAgLy8gYmUgaW50ZXJwcmV0ZWQgYXMgYSBzdGFydCBvZmZzZXQuXG4gICAgcmV0dXJuIHR5cGVvZiBlbmNvZGluZyA9PT0gJ3N0cmluZydcbiAgICAgID8gY3JlYXRlQnVmZmVyKHNpemUpLmZpbGwoZmlsbCwgZW5jb2RpbmcpXG4gICAgICA6IGNyZWF0ZUJ1ZmZlcihzaXplKS5maWxsKGZpbGwpXG4gIH1cbiAgcmV0dXJuIGNyZWF0ZUJ1ZmZlcihzaXplKVxufVxuXG4vKipcbiAqIENyZWF0ZXMgYSBuZXcgZmlsbGVkIEJ1ZmZlciBpbnN0YW5jZS5cbiAqIGFsbG9jKHNpemVbLCBmaWxsWywgZW5jb2RpbmddXSlcbiAqKi9cbkJ1ZmZlci5hbGxvYyA9IGZ1bmN0aW9uIChzaXplLCBmaWxsLCBlbmNvZGluZykge1xuICByZXR1cm4gYWxsb2Moc2l6ZSwgZmlsbCwgZW5jb2RpbmcpXG59XG5cbmZ1bmN0aW9uIGFsbG9jVW5zYWZlIChzaXplKSB7XG4gIGFzc2VydFNpemUoc2l6ZSlcbiAgcmV0dXJuIGNyZWF0ZUJ1ZmZlcihzaXplIDwgMCA/IDAgOiBjaGVja2VkKHNpemUpIHwgMClcbn1cblxuLyoqXG4gKiBFcXVpdmFsZW50IHRvIEJ1ZmZlcihudW0pLCBieSBkZWZhdWx0IGNyZWF0ZXMgYSBub24temVyby1maWxsZWQgQnVmZmVyIGluc3RhbmNlLlxuICogKi9cbkJ1ZmZlci5hbGxvY1Vuc2FmZSA9IGZ1bmN0aW9uIChzaXplKSB7XG4gIHJldHVybiBhbGxvY1Vuc2FmZShzaXplKVxufVxuLyoqXG4gKiBFcXVpdmFsZW50IHRvIFNsb3dCdWZmZXIobnVtKSwgYnkgZGVmYXVsdCBjcmVhdGVzIGEgbm9uLXplcm8tZmlsbGVkIEJ1ZmZlciBpbnN0YW5jZS5cbiAqL1xuQnVmZmVyLmFsbG9jVW5zYWZlU2xvdyA9IGZ1bmN0aW9uIChzaXplKSB7XG4gIHJldHVybiBhbGxvY1Vuc2FmZShzaXplKVxufVxuXG5mdW5jdGlvbiBmcm9tU3RyaW5nIChzdHJpbmcsIGVuY29kaW5nKSB7XG4gIGlmICh0eXBlb2YgZW5jb2RpbmcgIT09ICdzdHJpbmcnIHx8IGVuY29kaW5nID09PSAnJykge1xuICAgIGVuY29kaW5nID0gJ3V0ZjgnXG4gIH1cblxuICBpZiAoIUJ1ZmZlci5pc0VuY29kaW5nKGVuY29kaW5nKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1Vua25vd24gZW5jb2Rpbmc6ICcgKyBlbmNvZGluZylcbiAgfVxuXG4gIGNvbnN0IGxlbmd0aCA9IGJ5dGVMZW5ndGgoc3RyaW5nLCBlbmNvZGluZykgfCAwXG4gIGxldCBidWYgPSBjcmVhdGVCdWZmZXIobGVuZ3RoKVxuXG4gIGNvbnN0IGFjdHVhbCA9IGJ1Zi53cml0ZShzdHJpbmcsIGVuY29kaW5nKVxuXG4gIGlmIChhY3R1YWwgIT09IGxlbmd0aCkge1xuICAgIC8vIFdyaXRpbmcgYSBoZXggc3RyaW5nLCBmb3IgZXhhbXBsZSwgdGhhdCBjb250YWlucyBpbnZhbGlkIGNoYXJhY3RlcnMgd2lsbFxuICAgIC8vIGNhdXNlIGV2ZXJ5dGhpbmcgYWZ0ZXIgdGhlIGZpcnN0IGludmFsaWQgY2hhcmFjdGVyIHRvIGJlIGlnbm9yZWQuIChlLmcuXG4gICAgLy8gJ2FieHhjZCcgd2lsbCBiZSB0cmVhdGVkIGFzICdhYicpXG4gICAgYnVmID0gYnVmLnNsaWNlKDAsIGFjdHVhbClcbiAgfVxuXG4gIHJldHVybiBidWZcbn1cblxuZnVuY3Rpb24gZnJvbUFycmF5TGlrZSAoYXJyYXkpIHtcbiAgY29uc3QgbGVuZ3RoID0gYXJyYXkubGVuZ3RoIDwgMCA/IDAgOiBjaGVja2VkKGFycmF5Lmxlbmd0aCkgfCAwXG4gIGNvbnN0IGJ1ZiA9IGNyZWF0ZUJ1ZmZlcihsZW5ndGgpXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuZ3RoOyBpICs9IDEpIHtcbiAgICBidWZbaV0gPSBhcnJheVtpXSAmIDI1NVxuICB9XG4gIHJldHVybiBidWZcbn1cblxuZnVuY3Rpb24gZnJvbUFycmF5VmlldyAoYXJyYXlWaWV3KSB7XG4gIGlmIChpc0luc3RhbmNlKGFycmF5VmlldywgVWludDhBcnJheSkpIHtcbiAgICBjb25zdCBjb3B5ID0gbmV3IFVpbnQ4QXJyYXkoYXJyYXlWaWV3KVxuICAgIHJldHVybiBmcm9tQXJyYXlCdWZmZXIoY29weS5idWZmZXIsIGNvcHkuYnl0ZU9mZnNldCwgY29weS5ieXRlTGVuZ3RoKVxuICB9XG4gIHJldHVybiBmcm9tQXJyYXlMaWtlKGFycmF5Vmlldylcbn1cblxuZnVuY3Rpb24gZnJvbUFycmF5QnVmZmVyIChhcnJheSwgYnl0ZU9mZnNldCwgbGVuZ3RoKSB7XG4gIGlmIChieXRlT2Zmc2V0IDwgMCB8fCBhcnJheS5ieXRlTGVuZ3RoIDwgYnl0ZU9mZnNldCkge1xuICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdcIm9mZnNldFwiIGlzIG91dHNpZGUgb2YgYnVmZmVyIGJvdW5kcycpXG4gIH1cblxuICBpZiAoYXJyYXkuYnl0ZUxlbmd0aCA8IGJ5dGVPZmZzZXQgKyAobGVuZ3RoIHx8IDApKSB7XG4gICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ1wibGVuZ3RoXCIgaXMgb3V0c2lkZSBvZiBidWZmZXIgYm91bmRzJylcbiAgfVxuXG4gIGxldCBidWZcbiAgaWYgKGJ5dGVPZmZzZXQgPT09IHVuZGVmaW5lZCAmJiBsZW5ndGggPT09IHVuZGVmaW5lZCkge1xuICAgIGJ1ZiA9IG5ldyBVaW50OEFycmF5KGFycmF5KVxuICB9IGVsc2UgaWYgKGxlbmd0aCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgYnVmID0gbmV3IFVpbnQ4QXJyYXkoYXJyYXksIGJ5dGVPZmZzZXQpXG4gIH0gZWxzZSB7XG4gICAgYnVmID0gbmV3IFVpbnQ4QXJyYXkoYXJyYXksIGJ5dGVPZmZzZXQsIGxlbmd0aClcbiAgfVxuXG4gIC8vIFJldHVybiBhbiBhdWdtZW50ZWQgYFVpbnQ4QXJyYXlgIGluc3RhbmNlXG4gIE9iamVjdC5zZXRQcm90b3R5cGVPZihidWYsIEJ1ZmZlci5wcm90b3R5cGUpXG5cbiAgcmV0dXJuIGJ1ZlxufVxuXG5mdW5jdGlvbiBmcm9tT2JqZWN0IChvYmopIHtcbiAgaWYgKEJ1ZmZlci5pc0J1ZmZlcihvYmopKSB7XG4gICAgY29uc3QgbGVuID0gY2hlY2tlZChvYmoubGVuZ3RoKSB8IDBcbiAgICBjb25zdCBidWYgPSBjcmVhdGVCdWZmZXIobGVuKVxuXG4gICAgaWYgKGJ1Zi5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBidWZcbiAgICB9XG5cbiAgICBvYmouY29weShidWYsIDAsIDAsIGxlbilcbiAgICByZXR1cm4gYnVmXG4gIH1cblxuICBpZiAob2JqLmxlbmd0aCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgaWYgKHR5cGVvZiBvYmoubGVuZ3RoICE9PSAnbnVtYmVyJyB8fCBudW1iZXJJc05hTihvYmoubGVuZ3RoKSkge1xuICAgICAgcmV0dXJuIGNyZWF0ZUJ1ZmZlcigwKVxuICAgIH1cbiAgICByZXR1cm4gZnJvbUFycmF5TGlrZShvYmopXG4gIH1cblxuICBpZiAob2JqLnR5cGUgPT09ICdCdWZmZXInICYmIEFycmF5LmlzQXJyYXkob2JqLmRhdGEpKSB7XG4gICAgcmV0dXJuIGZyb21BcnJheUxpa2Uob2JqLmRhdGEpXG4gIH1cbn1cblxuZnVuY3Rpb24gY2hlY2tlZCAobGVuZ3RoKSB7XG4gIC8vIE5vdGU6IGNhbm5vdCB1c2UgYGxlbmd0aCA8IEtfTUFYX0xFTkdUSGAgaGVyZSBiZWNhdXNlIHRoYXQgZmFpbHMgd2hlblxuICAvLyBsZW5ndGggaXMgTmFOICh3aGljaCBpcyBvdGhlcndpc2UgY29lcmNlZCB0byB6ZXJvLilcbiAgaWYgKGxlbmd0aCA+PSBLX01BWF9MRU5HVEgpIHtcbiAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcignQXR0ZW1wdCB0byBhbGxvY2F0ZSBCdWZmZXIgbGFyZ2VyIHRoYW4gbWF4aW11bSAnICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAnc2l6ZTogMHgnICsgS19NQVhfTEVOR1RILnRvU3RyaW5nKDE2KSArICcgYnl0ZXMnKVxuICB9XG4gIHJldHVybiBsZW5ndGggfCAwXG59XG5cbmZ1bmN0aW9uIFNsb3dCdWZmZXIgKGxlbmd0aCkge1xuICBpZiAoK2xlbmd0aCAhPSBsZW5ndGgpIHsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBlcWVxZXFcbiAgICBsZW5ndGggPSAwXG4gIH1cbiAgcmV0dXJuIEJ1ZmZlci5hbGxvYygrbGVuZ3RoKVxufVxuXG5CdWZmZXIuaXNCdWZmZXIgPSBmdW5jdGlvbiBpc0J1ZmZlciAoYikge1xuICByZXR1cm4gYiAhPSBudWxsICYmIGIuX2lzQnVmZmVyID09PSB0cnVlICYmXG4gICAgYiAhPT0gQnVmZmVyLnByb3RvdHlwZSAvLyBzbyBCdWZmZXIuaXNCdWZmZXIoQnVmZmVyLnByb3RvdHlwZSkgd2lsbCBiZSBmYWxzZVxufVxuXG5CdWZmZXIuY29tcGFyZSA9IGZ1bmN0aW9uIGNvbXBhcmUgKGEsIGIpIHtcbiAgaWYgKGlzSW5zdGFuY2UoYSwgVWludDhBcnJheSkpIGEgPSBCdWZmZXIuZnJvbShhLCBhLm9mZnNldCwgYS5ieXRlTGVuZ3RoKVxuICBpZiAoaXNJbnN0YW5jZShiLCBVaW50OEFycmF5KSkgYiA9IEJ1ZmZlci5mcm9tKGIsIGIub2Zmc2V0LCBiLmJ5dGVMZW5ndGgpXG4gIGlmICghQnVmZmVyLmlzQnVmZmVyKGEpIHx8ICFCdWZmZXIuaXNCdWZmZXIoYikpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFxuICAgICAgJ1RoZSBcImJ1ZjFcIiwgXCJidWYyXCIgYXJndW1lbnRzIG11c3QgYmUgb25lIG9mIHR5cGUgQnVmZmVyIG9yIFVpbnQ4QXJyYXknXG4gICAgKVxuICB9XG5cbiAgaWYgKGEgPT09IGIpIHJldHVybiAwXG5cbiAgbGV0IHggPSBhLmxlbmd0aFxuICBsZXQgeSA9IGIubGVuZ3RoXG5cbiAgZm9yIChsZXQgaSA9IDAsIGxlbiA9IE1hdGgubWluKHgsIHkpOyBpIDwgbGVuOyArK2kpIHtcbiAgICBpZiAoYVtpXSAhPT0gYltpXSkge1xuICAgICAgeCA9IGFbaV1cbiAgICAgIHkgPSBiW2ldXG4gICAgICBicmVha1xuICAgIH1cbiAgfVxuXG4gIGlmICh4IDwgeSkgcmV0dXJuIC0xXG4gIGlmICh5IDwgeCkgcmV0dXJuIDFcbiAgcmV0dXJuIDBcbn1cblxuQnVmZmVyLmlzRW5jb2RpbmcgPSBmdW5jdGlvbiBpc0VuY29kaW5nIChlbmNvZGluZykge1xuICBzd2l0Y2ggKFN0cmluZyhlbmNvZGluZykudG9Mb3dlckNhc2UoKSkge1xuICAgIGNhc2UgJ2hleCc6XG4gICAgY2FzZSAndXRmOCc6XG4gICAgY2FzZSAndXRmLTgnOlxuICAgIGNhc2UgJ2FzY2lpJzpcbiAgICBjYXNlICdsYXRpbjEnOlxuICAgIGNhc2UgJ2JpbmFyeSc6XG4gICAgY2FzZSAnYmFzZTY0JzpcbiAgICBjYXNlICd1Y3MyJzpcbiAgICBjYXNlICd1Y3MtMic6XG4gICAgY2FzZSAndXRmMTZsZSc6XG4gICAgY2FzZSAndXRmLTE2bGUnOlxuICAgICAgcmV0dXJuIHRydWVcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIGZhbHNlXG4gIH1cbn1cblxuQnVmZmVyLmNvbmNhdCA9IGZ1bmN0aW9uIGNvbmNhdCAobGlzdCwgbGVuZ3RoKSB7XG4gIGlmICghQXJyYXkuaXNBcnJheShsaXN0KSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1wibGlzdFwiIGFyZ3VtZW50IG11c3QgYmUgYW4gQXJyYXkgb2YgQnVmZmVycycpXG4gIH1cblxuICBpZiAobGlzdC5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gQnVmZmVyLmFsbG9jKDApXG4gIH1cblxuICBsZXQgaVxuICBpZiAobGVuZ3RoID09PSB1bmRlZmluZWQpIHtcbiAgICBsZW5ndGggPSAwXG4gICAgZm9yIChpID0gMDsgaSA8IGxpc3QubGVuZ3RoOyArK2kpIHtcbiAgICAgIGxlbmd0aCArPSBsaXN0W2ldLmxlbmd0aFxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGJ1ZmZlciA9IEJ1ZmZlci5hbGxvY1Vuc2FmZShsZW5ndGgpXG4gIGxldCBwb3MgPSAwXG4gIGZvciAoaSA9IDA7IGkgPCBsaXN0Lmxlbmd0aDsgKytpKSB7XG4gICAgbGV0IGJ1ZiA9IGxpc3RbaV1cbiAgICBpZiAoaXNJbnN0YW5jZShidWYsIFVpbnQ4QXJyYXkpKSB7XG4gICAgICBpZiAocG9zICsgYnVmLmxlbmd0aCA+IGJ1ZmZlci5sZW5ndGgpIHtcbiAgICAgICAgaWYgKCFCdWZmZXIuaXNCdWZmZXIoYnVmKSkgYnVmID0gQnVmZmVyLmZyb20oYnVmKVxuICAgICAgICBidWYuY29weShidWZmZXIsIHBvcylcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIFVpbnQ4QXJyYXkucHJvdG90eXBlLnNldC5jYWxsKFxuICAgICAgICAgIGJ1ZmZlcixcbiAgICAgICAgICBidWYsXG4gICAgICAgICAgcG9zXG4gICAgICAgIClcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKCFCdWZmZXIuaXNCdWZmZXIoYnVmKSkge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignXCJsaXN0XCIgYXJndW1lbnQgbXVzdCBiZSBhbiBBcnJheSBvZiBCdWZmZXJzJylcbiAgICB9IGVsc2Uge1xuICAgICAgYnVmLmNvcHkoYnVmZmVyLCBwb3MpXG4gICAgfVxuICAgIHBvcyArPSBidWYubGVuZ3RoXG4gIH1cbiAgcmV0dXJuIGJ1ZmZlclxufVxuXG5mdW5jdGlvbiBieXRlTGVuZ3RoIChzdHJpbmcsIGVuY29kaW5nKSB7XG4gIGlmIChCdWZmZXIuaXNCdWZmZXIoc3RyaW5nKSkge1xuICAgIHJldHVybiBzdHJpbmcubGVuZ3RoXG4gIH1cbiAgaWYgKEFycmF5QnVmZmVyLmlzVmlldyhzdHJpbmcpIHx8IGlzSW5zdGFuY2Uoc3RyaW5nLCBBcnJheUJ1ZmZlcikpIHtcbiAgICByZXR1cm4gc3RyaW5nLmJ5dGVMZW5ndGhcbiAgfVxuICBpZiAodHlwZW9mIHN0cmluZyAhPT0gJ3N0cmluZycpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFxuICAgICAgJ1RoZSBcInN0cmluZ1wiIGFyZ3VtZW50IG11c3QgYmUgb25lIG9mIHR5cGUgc3RyaW5nLCBCdWZmZXIsIG9yIEFycmF5QnVmZmVyLiAnICtcbiAgICAgICdSZWNlaXZlZCB0eXBlICcgKyB0eXBlb2Ygc3RyaW5nXG4gICAgKVxuICB9XG5cbiAgY29uc3QgbGVuID0gc3RyaW5nLmxlbmd0aFxuICBjb25zdCBtdXN0TWF0Y2ggPSAoYXJndW1lbnRzLmxlbmd0aCA+IDIgJiYgYXJndW1lbnRzWzJdID09PSB0cnVlKVxuICBpZiAoIW11c3RNYXRjaCAmJiBsZW4gPT09IDApIHJldHVybiAwXG5cbiAgLy8gVXNlIGEgZm9yIGxvb3AgdG8gYXZvaWQgcmVjdXJzaW9uXG4gIGxldCBsb3dlcmVkQ2FzZSA9IGZhbHNlXG4gIGZvciAoOzspIHtcbiAgICBzd2l0Y2ggKGVuY29kaW5nKSB7XG4gICAgICBjYXNlICdhc2NpaSc6XG4gICAgICBjYXNlICdsYXRpbjEnOlxuICAgICAgY2FzZSAnYmluYXJ5JzpcbiAgICAgICAgcmV0dXJuIGxlblxuICAgICAgY2FzZSAndXRmOCc6XG4gICAgICBjYXNlICd1dGYtOCc6XG4gICAgICAgIHJldHVybiB1dGY4VG9CeXRlcyhzdHJpbmcpLmxlbmd0aFxuICAgICAgY2FzZSAndWNzMic6XG4gICAgICBjYXNlICd1Y3MtMic6XG4gICAgICBjYXNlICd1dGYxNmxlJzpcbiAgICAgIGNhc2UgJ3V0Zi0xNmxlJzpcbiAgICAgICAgcmV0dXJuIGxlbiAqIDJcbiAgICAgIGNhc2UgJ2hleCc6XG4gICAgICAgIHJldHVybiBsZW4gPj4+IDFcbiAgICAgIGNhc2UgJ2Jhc2U2NCc6XG4gICAgICAgIHJldHVybiBiYXNlNjRUb0J5dGVzKHN0cmluZykubGVuZ3RoXG4gICAgICBkZWZhdWx0OlxuICAgICAgICBpZiAobG93ZXJlZENhc2UpIHtcbiAgICAgICAgICByZXR1cm4gbXVzdE1hdGNoID8gLTEgOiB1dGY4VG9CeXRlcyhzdHJpbmcpLmxlbmd0aCAvLyBhc3N1bWUgdXRmOFxuICAgICAgICB9XG4gICAgICAgIGVuY29kaW5nID0gKCcnICsgZW5jb2RpbmcpLnRvTG93ZXJDYXNlKClcbiAgICAgICAgbG93ZXJlZENhc2UgPSB0cnVlXG4gICAgfVxuICB9XG59XG5CdWZmZXIuYnl0ZUxlbmd0aCA9IGJ5dGVMZW5ndGhcblxuZnVuY3Rpb24gc2xvd1RvU3RyaW5nIChlbmNvZGluZywgc3RhcnQsIGVuZCkge1xuICBsZXQgbG93ZXJlZENhc2UgPSBmYWxzZVxuXG4gIC8vIE5vIG5lZWQgdG8gdmVyaWZ5IHRoYXQgXCJ0aGlzLmxlbmd0aCA8PSBNQVhfVUlOVDMyXCIgc2luY2UgaXQncyBhIHJlYWQtb25seVxuICAvLyBwcm9wZXJ0eSBvZiBhIHR5cGVkIGFycmF5LlxuXG4gIC8vIFRoaXMgYmVoYXZlcyBuZWl0aGVyIGxpa2UgU3RyaW5nIG5vciBVaW50OEFycmF5IGluIHRoYXQgd2Ugc2V0IHN0YXJ0L2VuZFxuICAvLyB0byB0aGVpciB1cHBlci9sb3dlciBib3VuZHMgaWYgdGhlIHZhbHVlIHBhc3NlZCBpcyBvdXQgb2YgcmFuZ2UuXG4gIC8vIHVuZGVmaW5lZCBpcyBoYW5kbGVkIHNwZWNpYWxseSBhcyBwZXIgRUNNQS0yNjIgNnRoIEVkaXRpb24sXG4gIC8vIFNlY3Rpb24gMTMuMy4zLjcgUnVudGltZSBTZW1hbnRpY3M6IEtleWVkQmluZGluZ0luaXRpYWxpemF0aW9uLlxuICBpZiAoc3RhcnQgPT09IHVuZGVmaW5lZCB8fCBzdGFydCA8IDApIHtcbiAgICBzdGFydCA9IDBcbiAgfVxuICAvLyBSZXR1cm4gZWFybHkgaWYgc3RhcnQgPiB0aGlzLmxlbmd0aC4gRG9uZSBoZXJlIHRvIHByZXZlbnQgcG90ZW50aWFsIHVpbnQzMlxuICAvLyBjb2VyY2lvbiBmYWlsIGJlbG93LlxuICBpZiAoc3RhcnQgPiB0aGlzLmxlbmd0aCkge1xuICAgIHJldHVybiAnJ1xuICB9XG5cbiAgaWYgKGVuZCA9PT0gdW5kZWZpbmVkIHx8IGVuZCA+IHRoaXMubGVuZ3RoKSB7XG4gICAgZW5kID0gdGhpcy5sZW5ndGhcbiAgfVxuXG4gIGlmIChlbmQgPD0gMCkge1xuICAgIHJldHVybiAnJ1xuICB9XG5cbiAgLy8gRm9yY2UgY29lcmNpb24gdG8gdWludDMyLiBUaGlzIHdpbGwgYWxzbyBjb2VyY2UgZmFsc2V5L05hTiB2YWx1ZXMgdG8gMC5cbiAgZW5kID4+Pj0gMFxuICBzdGFydCA+Pj49IDBcblxuICBpZiAoZW5kIDw9IHN0YXJ0KSB7XG4gICAgcmV0dXJuICcnXG4gIH1cblxuICBpZiAoIWVuY29kaW5nKSBlbmNvZGluZyA9ICd1dGY4J1xuXG4gIHdoaWxlICh0cnVlKSB7XG4gICAgc3dpdGNoIChlbmNvZGluZykge1xuICAgICAgY2FzZSAnaGV4JzpcbiAgICAgICAgcmV0dXJuIGhleFNsaWNlKHRoaXMsIHN0YXJ0LCBlbmQpXG5cbiAgICAgIGNhc2UgJ3V0ZjgnOlxuICAgICAgY2FzZSAndXRmLTgnOlxuICAgICAgICByZXR1cm4gdXRmOFNsaWNlKHRoaXMsIHN0YXJ0LCBlbmQpXG5cbiAgICAgIGNhc2UgJ2FzY2lpJzpcbiAgICAgICAgcmV0dXJuIGFzY2lpU2xpY2UodGhpcywgc3RhcnQsIGVuZClcblxuICAgICAgY2FzZSAnbGF0aW4xJzpcbiAgICAgIGNhc2UgJ2JpbmFyeSc6XG4gICAgICAgIHJldHVybiBsYXRpbjFTbGljZSh0aGlzLCBzdGFydCwgZW5kKVxuXG4gICAgICBjYXNlICdiYXNlNjQnOlxuICAgICAgICByZXR1cm4gYmFzZTY0U2xpY2UodGhpcywgc3RhcnQsIGVuZClcblxuICAgICAgY2FzZSAndWNzMic6XG4gICAgICBjYXNlICd1Y3MtMic6XG4gICAgICBjYXNlICd1dGYxNmxlJzpcbiAgICAgIGNhc2UgJ3V0Zi0xNmxlJzpcbiAgICAgICAgcmV0dXJuIHV0ZjE2bGVTbGljZSh0aGlzLCBzdGFydCwgZW5kKVxuXG4gICAgICBkZWZhdWx0OlxuICAgICAgICBpZiAobG93ZXJlZENhc2UpIHRocm93IG5ldyBUeXBlRXJyb3IoJ1Vua25vd24gZW5jb2Rpbmc6ICcgKyBlbmNvZGluZylcbiAgICAgICAgZW5jb2RpbmcgPSAoZW5jb2RpbmcgKyAnJykudG9Mb3dlckNhc2UoKVxuICAgICAgICBsb3dlcmVkQ2FzZSA9IHRydWVcbiAgICB9XG4gIH1cbn1cblxuLy8gVGhpcyBwcm9wZXJ0eSBpcyB1c2VkIGJ5IGBCdWZmZXIuaXNCdWZmZXJgIChhbmQgdGhlIGBpcy1idWZmZXJgIG5wbSBwYWNrYWdlKVxuLy8gdG8gZGV0ZWN0IGEgQnVmZmVyIGluc3RhbmNlLiBJdCdzIG5vdCBwb3NzaWJsZSB0byB1c2UgYGluc3RhbmNlb2YgQnVmZmVyYFxuLy8gcmVsaWFibHkgaW4gYSBicm93c2VyaWZ5IGNvbnRleHQgYmVjYXVzZSB0aGVyZSBjb3VsZCBiZSBtdWx0aXBsZSBkaWZmZXJlbnRcbi8vIGNvcGllcyBvZiB0aGUgJ2J1ZmZlcicgcGFja2FnZSBpbiB1c2UuIFRoaXMgbWV0aG9kIHdvcmtzIGV2ZW4gZm9yIEJ1ZmZlclxuLy8gaW5zdGFuY2VzIHRoYXQgd2VyZSBjcmVhdGVkIGZyb20gYW5vdGhlciBjb3B5IG9mIHRoZSBgYnVmZmVyYCBwYWNrYWdlLlxuLy8gU2VlOiBodHRwczovL2dpdGh1Yi5jb20vZmVyb3NzL2J1ZmZlci9pc3N1ZXMvMTU0XG5CdWZmZXIucHJvdG90eXBlLl9pc0J1ZmZlciA9IHRydWVcblxuZnVuY3Rpb24gc3dhcCAoYiwgbiwgbSkge1xuICBjb25zdCBpID0gYltuXVxuICBiW25dID0gYlttXVxuICBiW21dID0gaVxufVxuXG5CdWZmZXIucHJvdG90eXBlLnN3YXAxNiA9IGZ1bmN0aW9uIHN3YXAxNiAoKSB7XG4gIGNvbnN0IGxlbiA9IHRoaXMubGVuZ3RoXG4gIGlmIChsZW4gJSAyICE9PSAwKSB7XG4gICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0J1ZmZlciBzaXplIG11c3QgYmUgYSBtdWx0aXBsZSBvZiAxNi1iaXRzJylcbiAgfVxuICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSArPSAyKSB7XG4gICAgc3dhcCh0aGlzLCBpLCBpICsgMSlcbiAgfVxuICByZXR1cm4gdGhpc1xufVxuXG5CdWZmZXIucHJvdG90eXBlLnN3YXAzMiA9IGZ1bmN0aW9uIHN3YXAzMiAoKSB7XG4gIGNvbnN0IGxlbiA9IHRoaXMubGVuZ3RoXG4gIGlmIChsZW4gJSA0ICE9PSAwKSB7XG4gICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0J1ZmZlciBzaXplIG11c3QgYmUgYSBtdWx0aXBsZSBvZiAzMi1iaXRzJylcbiAgfVxuICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSArPSA0KSB7XG4gICAgc3dhcCh0aGlzLCBpLCBpICsgMylcbiAgICBzd2FwKHRoaXMsIGkgKyAxLCBpICsgMilcbiAgfVxuICByZXR1cm4gdGhpc1xufVxuXG5CdWZmZXIucHJvdG90eXBlLnN3YXA2NCA9IGZ1bmN0aW9uIHN3YXA2NCAoKSB7XG4gIGNvbnN0IGxlbiA9IHRoaXMubGVuZ3RoXG4gIGlmIChsZW4gJSA4ICE9PSAwKSB7XG4gICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0J1ZmZlciBzaXplIG11c3QgYmUgYSBtdWx0aXBsZSBvZiA2NC1iaXRzJylcbiAgfVxuICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSArPSA4KSB7XG4gICAgc3dhcCh0aGlzLCBpLCBpICsgNylcbiAgICBzd2FwKHRoaXMsIGkgKyAxLCBpICsgNilcbiAgICBzd2FwKHRoaXMsIGkgKyAyLCBpICsgNSlcbiAgICBzd2FwKHRoaXMsIGkgKyAzLCBpICsgNClcbiAgfVxuICByZXR1cm4gdGhpc1xufVxuXG5CdWZmZXIucHJvdG90eXBlLnRvU3RyaW5nID0gZnVuY3Rpb24gdG9TdHJpbmcgKCkge1xuICBjb25zdCBsZW5ndGggPSB0aGlzLmxlbmd0aFxuICBpZiAobGVuZ3RoID09PSAwKSByZXR1cm4gJydcbiAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPT09IDApIHJldHVybiB1dGY4U2xpY2UodGhpcywgMCwgbGVuZ3RoKVxuICByZXR1cm4gc2xvd1RvU3RyaW5nLmFwcGx5KHRoaXMsIGFyZ3VtZW50cylcbn1cblxuQnVmZmVyLnByb3RvdHlwZS50b0xvY2FsZVN0cmluZyA9IEJ1ZmZlci5wcm90b3R5cGUudG9TdHJpbmdcblxuQnVmZmVyLnByb3RvdHlwZS5lcXVhbHMgPSBmdW5jdGlvbiBlcXVhbHMgKGIpIHtcbiAgaWYgKCFCdWZmZXIuaXNCdWZmZXIoYikpIHRocm93IG5ldyBUeXBlRXJyb3IoJ0FyZ3VtZW50IG11c3QgYmUgYSBCdWZmZXInKVxuICBpZiAodGhpcyA9PT0gYikgcmV0dXJuIHRydWVcbiAgcmV0dXJuIEJ1ZmZlci5jb21wYXJlKHRoaXMsIGIpID09PSAwXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUuaW5zcGVjdCA9IGZ1bmN0aW9uIGluc3BlY3QgKCkge1xuICBsZXQgc3RyID0gJydcbiAgY29uc3QgbWF4ID0gZXhwb3J0cy5JTlNQRUNUX01BWF9CWVRFU1xuICBzdHIgPSB0aGlzLnRvU3RyaW5nKCdoZXgnLCAwLCBtYXgpLnJlcGxhY2UoLyguezJ9KS9nLCAnJDEgJykudHJpbSgpXG4gIGlmICh0aGlzLmxlbmd0aCA+IG1heCkgc3RyICs9ICcgLi4uICdcbiAgcmV0dXJuICc8QnVmZmVyICcgKyBzdHIgKyAnPidcbn1cbmlmIChjdXN0b21JbnNwZWN0U3ltYm9sKSB7XG4gIEJ1ZmZlci5wcm90b3R5cGVbY3VzdG9tSW5zcGVjdFN5bWJvbF0gPSBCdWZmZXIucHJvdG90eXBlLmluc3BlY3Rcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5jb21wYXJlID0gZnVuY3Rpb24gY29tcGFyZSAodGFyZ2V0LCBzdGFydCwgZW5kLCB0aGlzU3RhcnQsIHRoaXNFbmQpIHtcbiAgaWYgKGlzSW5zdGFuY2UodGFyZ2V0LCBVaW50OEFycmF5KSkge1xuICAgIHRhcmdldCA9IEJ1ZmZlci5mcm9tKHRhcmdldCwgdGFyZ2V0Lm9mZnNldCwgdGFyZ2V0LmJ5dGVMZW5ndGgpXG4gIH1cbiAgaWYgKCFCdWZmZXIuaXNCdWZmZXIodGFyZ2V0KSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXG4gICAgICAnVGhlIFwidGFyZ2V0XCIgYXJndW1lbnQgbXVzdCBiZSBvbmUgb2YgdHlwZSBCdWZmZXIgb3IgVWludDhBcnJheS4gJyArXG4gICAgICAnUmVjZWl2ZWQgdHlwZSAnICsgKHR5cGVvZiB0YXJnZXQpXG4gICAgKVxuICB9XG5cbiAgaWYgKHN0YXJ0ID09PSB1bmRlZmluZWQpIHtcbiAgICBzdGFydCA9IDBcbiAgfVxuICBpZiAoZW5kID09PSB1bmRlZmluZWQpIHtcbiAgICBlbmQgPSB0YXJnZXQgPyB0YXJnZXQubGVuZ3RoIDogMFxuICB9XG4gIGlmICh0aGlzU3RhcnQgPT09IHVuZGVmaW5lZCkge1xuICAgIHRoaXNTdGFydCA9IDBcbiAgfVxuICBpZiAodGhpc0VuZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdGhpc0VuZCA9IHRoaXMubGVuZ3RoXG4gIH1cblxuICBpZiAoc3RhcnQgPCAwIHx8IGVuZCA+IHRhcmdldC5sZW5ndGggfHwgdGhpc1N0YXJ0IDwgMCB8fCB0aGlzRW5kID4gdGhpcy5sZW5ndGgpIHtcbiAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcignb3V0IG9mIHJhbmdlIGluZGV4JylcbiAgfVxuXG4gIGlmICh0aGlzU3RhcnQgPj0gdGhpc0VuZCAmJiBzdGFydCA+PSBlbmQpIHtcbiAgICByZXR1cm4gMFxuICB9XG4gIGlmICh0aGlzU3RhcnQgPj0gdGhpc0VuZCkge1xuICAgIHJldHVybiAtMVxuICB9XG4gIGlmIChzdGFydCA+PSBlbmQpIHtcbiAgICByZXR1cm4gMVxuICB9XG5cbiAgc3RhcnQgPj4+PSAwXG4gIGVuZCA+Pj49IDBcbiAgdGhpc1N0YXJ0ID4+Pj0gMFxuICB0aGlzRW5kID4+Pj0gMFxuXG4gIGlmICh0aGlzID09PSB0YXJnZXQpIHJldHVybiAwXG5cbiAgbGV0IHggPSB0aGlzRW5kIC0gdGhpc1N0YXJ0XG4gIGxldCB5ID0gZW5kIC0gc3RhcnRcbiAgY29uc3QgbGVuID0gTWF0aC5taW4oeCwgeSlcblxuICBjb25zdCB0aGlzQ29weSA9IHRoaXMuc2xpY2UodGhpc1N0YXJ0LCB0aGlzRW5kKVxuICBjb25zdCB0YXJnZXRDb3B5ID0gdGFyZ2V0LnNsaWNlKHN0YXJ0LCBlbmQpXG5cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47ICsraSkge1xuICAgIGlmICh0aGlzQ29weVtpXSAhPT0gdGFyZ2V0Q29weVtpXSkge1xuICAgICAgeCA9IHRoaXNDb3B5W2ldXG4gICAgICB5ID0gdGFyZ2V0Q29weVtpXVxuICAgICAgYnJlYWtcbiAgICB9XG4gIH1cblxuICBpZiAoeCA8IHkpIHJldHVybiAtMVxuICBpZiAoeSA8IHgpIHJldHVybiAxXG4gIHJldHVybiAwXG59XG5cbi8vIEZpbmRzIGVpdGhlciB0aGUgZmlyc3QgaW5kZXggb2YgYHZhbGAgaW4gYGJ1ZmZlcmAgYXQgb2Zmc2V0ID49IGBieXRlT2Zmc2V0YCxcbi8vIE9SIHRoZSBsYXN0IGluZGV4IG9mIGB2YWxgIGluIGBidWZmZXJgIGF0IG9mZnNldCA8PSBgYnl0ZU9mZnNldGAuXG4vL1xuLy8gQXJndW1lbnRzOlxuLy8gLSBidWZmZXIgLSBhIEJ1ZmZlciB0byBzZWFyY2hcbi8vIC0gdmFsIC0gYSBzdHJpbmcsIEJ1ZmZlciwgb3IgbnVtYmVyXG4vLyAtIGJ5dGVPZmZzZXQgLSBhbiBpbmRleCBpbnRvIGBidWZmZXJgOyB3aWxsIGJlIGNsYW1wZWQgdG8gYW4gaW50MzJcbi8vIC0gZW5jb2RpbmcgLSBhbiBvcHRpb25hbCBlbmNvZGluZywgcmVsZXZhbnQgaXMgdmFsIGlzIGEgc3RyaW5nXG4vLyAtIGRpciAtIHRydWUgZm9yIGluZGV4T2YsIGZhbHNlIGZvciBsYXN0SW5kZXhPZlxuZnVuY3Rpb24gYmlkaXJlY3Rpb25hbEluZGV4T2YgKGJ1ZmZlciwgdmFsLCBieXRlT2Zmc2V0LCBlbmNvZGluZywgZGlyKSB7XG4gIC8vIEVtcHR5IGJ1ZmZlciBtZWFucyBubyBtYXRjaFxuICBpZiAoYnVmZmVyLmxlbmd0aCA9PT0gMCkgcmV0dXJuIC0xXG5cbiAgLy8gTm9ybWFsaXplIGJ5dGVPZmZzZXRcbiAgaWYgKHR5cGVvZiBieXRlT2Zmc2V0ID09PSAnc3RyaW5nJykge1xuICAgIGVuY29kaW5nID0gYnl0ZU9mZnNldFxuICAgIGJ5dGVPZmZzZXQgPSAwXG4gIH0gZWxzZSBpZiAoYnl0ZU9mZnNldCA+IDB4N2ZmZmZmZmYpIHtcbiAgICBieXRlT2Zmc2V0ID0gMHg3ZmZmZmZmZlxuICB9IGVsc2UgaWYgKGJ5dGVPZmZzZXQgPCAtMHg4MDAwMDAwMCkge1xuICAgIGJ5dGVPZmZzZXQgPSAtMHg4MDAwMDAwMFxuICB9XG4gIGJ5dGVPZmZzZXQgPSArYnl0ZU9mZnNldCAvLyBDb2VyY2UgdG8gTnVtYmVyLlxuICBpZiAobnVtYmVySXNOYU4oYnl0ZU9mZnNldCkpIHtcbiAgICAvLyBieXRlT2Zmc2V0OiBpdCBpdCdzIHVuZGVmaW5lZCwgbnVsbCwgTmFOLCBcImZvb1wiLCBldGMsIHNlYXJjaCB3aG9sZSBidWZmZXJcbiAgICBieXRlT2Zmc2V0ID0gZGlyID8gMCA6IChidWZmZXIubGVuZ3RoIC0gMSlcbiAgfVxuXG4gIC8vIE5vcm1hbGl6ZSBieXRlT2Zmc2V0OiBuZWdhdGl2ZSBvZmZzZXRzIHN0YXJ0IGZyb20gdGhlIGVuZCBvZiB0aGUgYnVmZmVyXG4gIGlmIChieXRlT2Zmc2V0IDwgMCkgYnl0ZU9mZnNldCA9IGJ1ZmZlci5sZW5ndGggKyBieXRlT2Zmc2V0XG4gIGlmIChieXRlT2Zmc2V0ID49IGJ1ZmZlci5sZW5ndGgpIHtcbiAgICBpZiAoZGlyKSByZXR1cm4gLTFcbiAgICBlbHNlIGJ5dGVPZmZzZXQgPSBidWZmZXIubGVuZ3RoIC0gMVxuICB9IGVsc2UgaWYgKGJ5dGVPZmZzZXQgPCAwKSB7XG4gICAgaWYgKGRpcikgYnl0ZU9mZnNldCA9IDBcbiAgICBlbHNlIHJldHVybiAtMVxuICB9XG5cbiAgLy8gTm9ybWFsaXplIHZhbFxuICBpZiAodHlwZW9mIHZhbCA9PT0gJ3N0cmluZycpIHtcbiAgICB2YWwgPSBCdWZmZXIuZnJvbSh2YWwsIGVuY29kaW5nKVxuICB9XG5cbiAgLy8gRmluYWxseSwgc2VhcmNoIGVpdGhlciBpbmRleE9mIChpZiBkaXIgaXMgdHJ1ZSkgb3IgbGFzdEluZGV4T2ZcbiAgaWYgKEJ1ZmZlci5pc0J1ZmZlcih2YWwpKSB7XG4gICAgLy8gU3BlY2lhbCBjYXNlOiBsb29raW5nIGZvciBlbXB0eSBzdHJpbmcvYnVmZmVyIGFsd2F5cyBmYWlsc1xuICAgIGlmICh2YWwubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gLTFcbiAgICB9XG4gICAgcmV0dXJuIGFycmF5SW5kZXhPZihidWZmZXIsIHZhbCwgYnl0ZU9mZnNldCwgZW5jb2RpbmcsIGRpcilcbiAgfSBlbHNlIGlmICh0eXBlb2YgdmFsID09PSAnbnVtYmVyJykge1xuICAgIHZhbCA9IHZhbCAmIDB4RkYgLy8gU2VhcmNoIGZvciBhIGJ5dGUgdmFsdWUgWzAtMjU1XVxuICAgIGlmICh0eXBlb2YgVWludDhBcnJheS5wcm90b3R5cGUuaW5kZXhPZiA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgaWYgKGRpcikge1xuICAgICAgICByZXR1cm4gVWludDhBcnJheS5wcm90b3R5cGUuaW5kZXhPZi5jYWxsKGJ1ZmZlciwgdmFsLCBieXRlT2Zmc2V0KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIFVpbnQ4QXJyYXkucHJvdG90eXBlLmxhc3RJbmRleE9mLmNhbGwoYnVmZmVyLCB2YWwsIGJ5dGVPZmZzZXQpXG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBhcnJheUluZGV4T2YoYnVmZmVyLCBbdmFsXSwgYnl0ZU9mZnNldCwgZW5jb2RpbmcsIGRpcilcbiAgfVxuXG4gIHRocm93IG5ldyBUeXBlRXJyb3IoJ3ZhbCBtdXN0IGJlIHN0cmluZywgbnVtYmVyIG9yIEJ1ZmZlcicpXG59XG5cbmZ1bmN0aW9uIGFycmF5SW5kZXhPZiAoYXJyLCB2YWwsIGJ5dGVPZmZzZXQsIGVuY29kaW5nLCBkaXIpIHtcbiAgbGV0IGluZGV4U2l6ZSA9IDFcbiAgbGV0IGFyckxlbmd0aCA9IGFyci5sZW5ndGhcbiAgbGV0IHZhbExlbmd0aCA9IHZhbC5sZW5ndGhcblxuICBpZiAoZW5jb2RpbmcgIT09IHVuZGVmaW5lZCkge1xuICAgIGVuY29kaW5nID0gU3RyaW5nKGVuY29kaW5nKS50b0xvd2VyQ2FzZSgpXG4gICAgaWYgKGVuY29kaW5nID09PSAndWNzMicgfHwgZW5jb2RpbmcgPT09ICd1Y3MtMicgfHxcbiAgICAgICAgZW5jb2RpbmcgPT09ICd1dGYxNmxlJyB8fCBlbmNvZGluZyA9PT0gJ3V0Zi0xNmxlJykge1xuICAgICAgaWYgKGFyci5sZW5ndGggPCAyIHx8IHZhbC5sZW5ndGggPCAyKSB7XG4gICAgICAgIHJldHVybiAtMVxuICAgICAgfVxuICAgICAgaW5kZXhTaXplID0gMlxuICAgICAgYXJyTGVuZ3RoIC89IDJcbiAgICAgIHZhbExlbmd0aCAvPSAyXG4gICAgICBieXRlT2Zmc2V0IC89IDJcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiByZWFkIChidWYsIGkpIHtcbiAgICBpZiAoaW5kZXhTaXplID09PSAxKSB7XG4gICAgICByZXR1cm4gYnVmW2ldXG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBidWYucmVhZFVJbnQxNkJFKGkgKiBpbmRleFNpemUpXG4gICAgfVxuICB9XG5cbiAgbGV0IGlcbiAgaWYgKGRpcikge1xuICAgIGxldCBmb3VuZEluZGV4ID0gLTFcbiAgICBmb3IgKGkgPSBieXRlT2Zmc2V0OyBpIDwgYXJyTGVuZ3RoOyBpKyspIHtcbiAgICAgIGlmIChyZWFkKGFyciwgaSkgPT09IHJlYWQodmFsLCBmb3VuZEluZGV4ID09PSAtMSA/IDAgOiBpIC0gZm91bmRJbmRleCkpIHtcbiAgICAgICAgaWYgKGZvdW5kSW5kZXggPT09IC0xKSBmb3VuZEluZGV4ID0gaVxuICAgICAgICBpZiAoaSAtIGZvdW5kSW5kZXggKyAxID09PSB2YWxMZW5ndGgpIHJldHVybiBmb3VuZEluZGV4ICogaW5kZXhTaXplXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAoZm91bmRJbmRleCAhPT0gLTEpIGkgLT0gaSAtIGZvdW5kSW5kZXhcbiAgICAgICAgZm91bmRJbmRleCA9IC0xXG4gICAgICB9XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGlmIChieXRlT2Zmc2V0ICsgdmFsTGVuZ3RoID4gYXJyTGVuZ3RoKSBieXRlT2Zmc2V0ID0gYXJyTGVuZ3RoIC0gdmFsTGVuZ3RoXG4gICAgZm9yIChpID0gYnl0ZU9mZnNldDsgaSA+PSAwOyBpLS0pIHtcbiAgICAgIGxldCBmb3VuZCA9IHRydWVcbiAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgdmFsTGVuZ3RoOyBqKyspIHtcbiAgICAgICAgaWYgKHJlYWQoYXJyLCBpICsgaikgIT09IHJlYWQodmFsLCBqKSkge1xuICAgICAgICAgIGZvdW5kID0gZmFsc2VcbiAgICAgICAgICBicmVha1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoZm91bmQpIHJldHVybiBpXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIC0xXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUuaW5jbHVkZXMgPSBmdW5jdGlvbiBpbmNsdWRlcyAodmFsLCBieXRlT2Zmc2V0LCBlbmNvZGluZykge1xuICByZXR1cm4gdGhpcy5pbmRleE9mKHZhbCwgYnl0ZU9mZnNldCwgZW5jb2RpbmcpICE9PSAtMVxufVxuXG5CdWZmZXIucHJvdG90eXBlLmluZGV4T2YgPSBmdW5jdGlvbiBpbmRleE9mICh2YWwsIGJ5dGVPZmZzZXQsIGVuY29kaW5nKSB7XG4gIHJldHVybiBiaWRpcmVjdGlvbmFsSW5kZXhPZih0aGlzLCB2YWwsIGJ5dGVPZmZzZXQsIGVuY29kaW5nLCB0cnVlKVxufVxuXG5CdWZmZXIucHJvdG90eXBlLmxhc3RJbmRleE9mID0gZnVuY3Rpb24gbGFzdEluZGV4T2YgKHZhbCwgYnl0ZU9mZnNldCwgZW5jb2RpbmcpIHtcbiAgcmV0dXJuIGJpZGlyZWN0aW9uYWxJbmRleE9mKHRoaXMsIHZhbCwgYnl0ZU9mZnNldCwgZW5jb2RpbmcsIGZhbHNlKVxufVxuXG5mdW5jdGlvbiBoZXhXcml0ZSAoYnVmLCBzdHJpbmcsIG9mZnNldCwgbGVuZ3RoKSB7XG4gIG9mZnNldCA9IE51bWJlcihvZmZzZXQpIHx8IDBcbiAgY29uc3QgcmVtYWluaW5nID0gYnVmLmxlbmd0aCAtIG9mZnNldFxuICBpZiAoIWxlbmd0aCkge1xuICAgIGxlbmd0aCA9IHJlbWFpbmluZ1xuICB9IGVsc2Uge1xuICAgIGxlbmd0aCA9IE51bWJlcihsZW5ndGgpXG4gICAgaWYgKGxlbmd0aCA+IHJlbWFpbmluZykge1xuICAgICAgbGVuZ3RoID0gcmVtYWluaW5nXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgc3RyTGVuID0gc3RyaW5nLmxlbmd0aFxuXG4gIGlmIChsZW5ndGggPiBzdHJMZW4gLyAyKSB7XG4gICAgbGVuZ3RoID0gc3RyTGVuIC8gMlxuICB9XG4gIGxldCBpXG4gIGZvciAoaSA9IDA7IGkgPCBsZW5ndGg7ICsraSkge1xuICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlSW50KHN0cmluZy5zdWJzdHIoaSAqIDIsIDIpLCAxNilcbiAgICBpZiAobnVtYmVySXNOYU4ocGFyc2VkKSkgcmV0dXJuIGlcbiAgICBidWZbb2Zmc2V0ICsgaV0gPSBwYXJzZWRcbiAgfVxuICByZXR1cm4gaVxufVxuXG5mdW5jdGlvbiB1dGY4V3JpdGUgKGJ1Ziwgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aCkge1xuICByZXR1cm4gYmxpdEJ1ZmZlcih1dGY4VG9CeXRlcyhzdHJpbmcsIGJ1Zi5sZW5ndGggLSBvZmZzZXQpLCBidWYsIG9mZnNldCwgbGVuZ3RoKVxufVxuXG5mdW5jdGlvbiBhc2NpaVdyaXRlIChidWYsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpIHtcbiAgcmV0dXJuIGJsaXRCdWZmZXIoYXNjaWlUb0J5dGVzKHN0cmluZyksIGJ1Ziwgb2Zmc2V0LCBsZW5ndGgpXG59XG5cbmZ1bmN0aW9uIGJhc2U2NFdyaXRlIChidWYsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpIHtcbiAgcmV0dXJuIGJsaXRCdWZmZXIoYmFzZTY0VG9CeXRlcyhzdHJpbmcpLCBidWYsIG9mZnNldCwgbGVuZ3RoKVxufVxuXG5mdW5jdGlvbiB1Y3MyV3JpdGUgKGJ1Ziwgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aCkge1xuICByZXR1cm4gYmxpdEJ1ZmZlcih1dGYxNmxlVG9CeXRlcyhzdHJpbmcsIGJ1Zi5sZW5ndGggLSBvZmZzZXQpLCBidWYsIG9mZnNldCwgbGVuZ3RoKVxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlID0gZnVuY3Rpb24gd3JpdGUgKHN0cmluZywgb2Zmc2V0LCBsZW5ndGgsIGVuY29kaW5nKSB7XG4gIC8vIEJ1ZmZlciN3cml0ZShzdHJpbmcpXG4gIGlmIChvZmZzZXQgPT09IHVuZGVmaW5lZCkge1xuICAgIGVuY29kaW5nID0gJ3V0ZjgnXG4gICAgbGVuZ3RoID0gdGhpcy5sZW5ndGhcbiAgICBvZmZzZXQgPSAwXG4gIC8vIEJ1ZmZlciN3cml0ZShzdHJpbmcsIGVuY29kaW5nKVxuICB9IGVsc2UgaWYgKGxlbmd0aCA9PT0gdW5kZWZpbmVkICYmIHR5cGVvZiBvZmZzZXQgPT09ICdzdHJpbmcnKSB7XG4gICAgZW5jb2RpbmcgPSBvZmZzZXRcbiAgICBsZW5ndGggPSB0aGlzLmxlbmd0aFxuICAgIG9mZnNldCA9IDBcbiAgLy8gQnVmZmVyI3dyaXRlKHN0cmluZywgb2Zmc2V0WywgbGVuZ3RoXVssIGVuY29kaW5nXSlcbiAgfSBlbHNlIGlmIChpc0Zpbml0ZShvZmZzZXQpKSB7XG4gICAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gICAgaWYgKGlzRmluaXRlKGxlbmd0aCkpIHtcbiAgICAgIGxlbmd0aCA9IGxlbmd0aCA+Pj4gMFxuICAgICAgaWYgKGVuY29kaW5nID09PSB1bmRlZmluZWQpIGVuY29kaW5nID0gJ3V0ZjgnXG4gICAgfSBlbHNlIHtcbiAgICAgIGVuY29kaW5nID0gbGVuZ3RoXG4gICAgICBsZW5ndGggPSB1bmRlZmluZWRcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgJ0J1ZmZlci53cml0ZShzdHJpbmcsIGVuY29kaW5nLCBvZmZzZXRbLCBsZW5ndGhdKSBpcyBubyBsb25nZXIgc3VwcG9ydGVkJ1xuICAgIClcbiAgfVxuXG4gIGNvbnN0IHJlbWFpbmluZyA9IHRoaXMubGVuZ3RoIC0gb2Zmc2V0XG4gIGlmIChsZW5ndGggPT09IHVuZGVmaW5lZCB8fCBsZW5ndGggPiByZW1haW5pbmcpIGxlbmd0aCA9IHJlbWFpbmluZ1xuXG4gIGlmICgoc3RyaW5nLmxlbmd0aCA+IDAgJiYgKGxlbmd0aCA8IDAgfHwgb2Zmc2V0IDwgMCkpIHx8IG9mZnNldCA+IHRoaXMubGVuZ3RoKSB7XG4gICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0F0dGVtcHQgdG8gd3JpdGUgb3V0c2lkZSBidWZmZXIgYm91bmRzJylcbiAgfVxuXG4gIGlmICghZW5jb2RpbmcpIGVuY29kaW5nID0gJ3V0ZjgnXG5cbiAgbGV0IGxvd2VyZWRDYXNlID0gZmFsc2VcbiAgZm9yICg7Oykge1xuICAgIHN3aXRjaCAoZW5jb2RpbmcpIHtcbiAgICAgIGNhc2UgJ2hleCc6XG4gICAgICAgIHJldHVybiBoZXhXcml0ZSh0aGlzLCBzdHJpbmcsIG9mZnNldCwgbGVuZ3RoKVxuXG4gICAgICBjYXNlICd1dGY4JzpcbiAgICAgIGNhc2UgJ3V0Zi04JzpcbiAgICAgICAgcmV0dXJuIHV0ZjhXcml0ZSh0aGlzLCBzdHJpbmcsIG9mZnNldCwgbGVuZ3RoKVxuXG4gICAgICBjYXNlICdhc2NpaSc6XG4gICAgICBjYXNlICdsYXRpbjEnOlxuICAgICAgY2FzZSAnYmluYXJ5JzpcbiAgICAgICAgcmV0dXJuIGFzY2lpV3JpdGUodGhpcywgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aClcblxuICAgICAgY2FzZSAnYmFzZTY0JzpcbiAgICAgICAgLy8gV2FybmluZzogbWF4TGVuZ3RoIG5vdCB0YWtlbiBpbnRvIGFjY291bnQgaW4gYmFzZTY0V3JpdGVcbiAgICAgICAgcmV0dXJuIGJhc2U2NFdyaXRlKHRoaXMsIHN0cmluZywgb2Zmc2V0LCBsZW5ndGgpXG5cbiAgICAgIGNhc2UgJ3VjczInOlxuICAgICAgY2FzZSAndWNzLTInOlxuICAgICAgY2FzZSAndXRmMTZsZSc6XG4gICAgICBjYXNlICd1dGYtMTZsZSc6XG4gICAgICAgIHJldHVybiB1Y3MyV3JpdGUodGhpcywgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aClcblxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgaWYgKGxvd2VyZWRDYXNlKSB0aHJvdyBuZXcgVHlwZUVycm9yKCdVbmtub3duIGVuY29kaW5nOiAnICsgZW5jb2RpbmcpXG4gICAgICAgIGVuY29kaW5nID0gKCcnICsgZW5jb2RpbmcpLnRvTG93ZXJDYXNlKClcbiAgICAgICAgbG93ZXJlZENhc2UgPSB0cnVlXG4gICAgfVxuICB9XG59XG5cbkJ1ZmZlci5wcm90b3R5cGUudG9KU09OID0gZnVuY3Rpb24gdG9KU09OICgpIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiAnQnVmZmVyJyxcbiAgICBkYXRhOiBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbCh0aGlzLl9hcnIgfHwgdGhpcywgMClcbiAgfVxufVxuXG5mdW5jdGlvbiBiYXNlNjRTbGljZSAoYnVmLCBzdGFydCwgZW5kKSB7XG4gIGlmIChzdGFydCA9PT0gMCAmJiBlbmQgPT09IGJ1Zi5sZW5ndGgpIHtcbiAgICByZXR1cm4gYmFzZTY0LmZyb21CeXRlQXJyYXkoYnVmKVxuICB9IGVsc2Uge1xuICAgIHJldHVybiBiYXNlNjQuZnJvbUJ5dGVBcnJheShidWYuc2xpY2Uoc3RhcnQsIGVuZCkpXG4gIH1cbn1cblxuZnVuY3Rpb24gdXRmOFNsaWNlIChidWYsIHN0YXJ0LCBlbmQpIHtcbiAgZW5kID0gTWF0aC5taW4oYnVmLmxlbmd0aCwgZW5kKVxuICBjb25zdCByZXMgPSBbXVxuXG4gIGxldCBpID0gc3RhcnRcbiAgd2hpbGUgKGkgPCBlbmQpIHtcbiAgICBjb25zdCBmaXJzdEJ5dGUgPSBidWZbaV1cbiAgICBsZXQgY29kZVBvaW50ID0gbnVsbFxuICAgIGxldCBieXRlc1BlclNlcXVlbmNlID0gKGZpcnN0Qnl0ZSA+IDB4RUYpXG4gICAgICA/IDRcbiAgICAgIDogKGZpcnN0Qnl0ZSA+IDB4REYpXG4gICAgICAgICAgPyAzXG4gICAgICAgICAgOiAoZmlyc3RCeXRlID4gMHhCRilcbiAgICAgICAgICAgICAgPyAyXG4gICAgICAgICAgICAgIDogMVxuXG4gICAgaWYgKGkgKyBieXRlc1BlclNlcXVlbmNlIDw9IGVuZCkge1xuICAgICAgbGV0IHNlY29uZEJ5dGUsIHRoaXJkQnl0ZSwgZm91cnRoQnl0ZSwgdGVtcENvZGVQb2ludFxuXG4gICAgICBzd2l0Y2ggKGJ5dGVzUGVyU2VxdWVuY2UpIHtcbiAgICAgICAgY2FzZSAxOlxuICAgICAgICAgIGlmIChmaXJzdEJ5dGUgPCAweDgwKSB7XG4gICAgICAgICAgICBjb2RlUG9pbnQgPSBmaXJzdEJ5dGVcbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSAyOlxuICAgICAgICAgIHNlY29uZEJ5dGUgPSBidWZbaSArIDFdXG4gICAgICAgICAgaWYgKChzZWNvbmRCeXRlICYgMHhDMCkgPT09IDB4ODApIHtcbiAgICAgICAgICAgIHRlbXBDb2RlUG9pbnQgPSAoZmlyc3RCeXRlICYgMHgxRikgPDwgMHg2IHwgKHNlY29uZEJ5dGUgJiAweDNGKVxuICAgICAgICAgICAgaWYgKHRlbXBDb2RlUG9pbnQgPiAweDdGKSB7XG4gICAgICAgICAgICAgIGNvZGVQb2ludCA9IHRlbXBDb2RlUG9pbnRcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSAzOlxuICAgICAgICAgIHNlY29uZEJ5dGUgPSBidWZbaSArIDFdXG4gICAgICAgICAgdGhpcmRCeXRlID0gYnVmW2kgKyAyXVxuICAgICAgICAgIGlmICgoc2Vjb25kQnl0ZSAmIDB4QzApID09PSAweDgwICYmICh0aGlyZEJ5dGUgJiAweEMwKSA9PT0gMHg4MCkge1xuICAgICAgICAgICAgdGVtcENvZGVQb2ludCA9IChmaXJzdEJ5dGUgJiAweEYpIDw8IDB4QyB8IChzZWNvbmRCeXRlICYgMHgzRikgPDwgMHg2IHwgKHRoaXJkQnl0ZSAmIDB4M0YpXG4gICAgICAgICAgICBpZiAodGVtcENvZGVQb2ludCA+IDB4N0ZGICYmICh0ZW1wQ29kZVBvaW50IDwgMHhEODAwIHx8IHRlbXBDb2RlUG9pbnQgPiAweERGRkYpKSB7XG4gICAgICAgICAgICAgIGNvZGVQb2ludCA9IHRlbXBDb2RlUG9pbnRcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgY2FzZSA0OlxuICAgICAgICAgIHNlY29uZEJ5dGUgPSBidWZbaSArIDFdXG4gICAgICAgICAgdGhpcmRCeXRlID0gYnVmW2kgKyAyXVxuICAgICAgICAgIGZvdXJ0aEJ5dGUgPSBidWZbaSArIDNdXG4gICAgICAgICAgaWYgKChzZWNvbmRCeXRlICYgMHhDMCkgPT09IDB4ODAgJiYgKHRoaXJkQnl0ZSAmIDB4QzApID09PSAweDgwICYmIChmb3VydGhCeXRlICYgMHhDMCkgPT09IDB4ODApIHtcbiAgICAgICAgICAgIHRlbXBDb2RlUG9pbnQgPSAoZmlyc3RCeXRlICYgMHhGKSA8PCAweDEyIHwgKHNlY29uZEJ5dGUgJiAweDNGKSA8PCAweEMgfCAodGhpcmRCeXRlICYgMHgzRikgPDwgMHg2IHwgKGZvdXJ0aEJ5dGUgJiAweDNGKVxuICAgICAgICAgICAgaWYgKHRlbXBDb2RlUG9pbnQgPiAweEZGRkYgJiYgdGVtcENvZGVQb2ludCA8IDB4MTEwMDAwKSB7XG4gICAgICAgICAgICAgIGNvZGVQb2ludCA9IHRlbXBDb2RlUG9pbnRcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKGNvZGVQb2ludCA9PT0gbnVsbCkge1xuICAgICAgLy8gd2UgZGlkIG5vdCBnZW5lcmF0ZSBhIHZhbGlkIGNvZGVQb2ludCBzbyBpbnNlcnQgYVxuICAgICAgLy8gcmVwbGFjZW1lbnQgY2hhciAoVStGRkZEKSBhbmQgYWR2YW5jZSBvbmx5IDEgYnl0ZVxuICAgICAgY29kZVBvaW50ID0gMHhGRkZEXG4gICAgICBieXRlc1BlclNlcXVlbmNlID0gMVxuICAgIH0gZWxzZSBpZiAoY29kZVBvaW50ID4gMHhGRkZGKSB7XG4gICAgICAvLyBlbmNvZGUgdG8gdXRmMTYgKHN1cnJvZ2F0ZSBwYWlyIGRhbmNlKVxuICAgICAgY29kZVBvaW50IC09IDB4MTAwMDBcbiAgICAgIHJlcy5wdXNoKGNvZGVQb2ludCA+Pj4gMTAgJiAweDNGRiB8IDB4RDgwMClcbiAgICAgIGNvZGVQb2ludCA9IDB4REMwMCB8IGNvZGVQb2ludCAmIDB4M0ZGXG4gICAgfVxuXG4gICAgcmVzLnB1c2goY29kZVBvaW50KVxuICAgIGkgKz0gYnl0ZXNQZXJTZXF1ZW5jZVxuICB9XG5cbiAgcmV0dXJuIGRlY29kZUNvZGVQb2ludHNBcnJheShyZXMpXG59XG5cbi8vIEJhc2VkIG9uIGh0dHA6Ly9zdGFja292ZXJmbG93LmNvbS9hLzIyNzQ3MjcyLzY4MDc0MiwgdGhlIGJyb3dzZXIgd2l0aFxuLy8gdGhlIGxvd2VzdCBsaW1pdCBpcyBDaHJvbWUsIHdpdGggMHgxMDAwMCBhcmdzLlxuLy8gV2UgZ28gMSBtYWduaXR1ZGUgbGVzcywgZm9yIHNhZmV0eVxuY29uc3QgTUFYX0FSR1VNRU5UU19MRU5HVEggPSAweDEwMDBcblxuZnVuY3Rpb24gZGVjb2RlQ29kZVBvaW50c0FycmF5IChjb2RlUG9pbnRzKSB7XG4gIGNvbnN0IGxlbiA9IGNvZGVQb2ludHMubGVuZ3RoXG4gIGlmIChsZW4gPD0gTUFYX0FSR1VNRU5UU19MRU5HVEgpIHtcbiAgICByZXR1cm4gU3RyaW5nLmZyb21DaGFyQ29kZS5hcHBseShTdHJpbmcsIGNvZGVQb2ludHMpIC8vIGF2b2lkIGV4dHJhIHNsaWNlKClcbiAgfVxuXG4gIC8vIERlY29kZSBpbiBjaHVua3MgdG8gYXZvaWQgXCJjYWxsIHN0YWNrIHNpemUgZXhjZWVkZWRcIi5cbiAgbGV0IHJlcyA9ICcnXG4gIGxldCBpID0gMFxuICB3aGlsZSAoaSA8IGxlbikge1xuICAgIHJlcyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlLmFwcGx5KFxuICAgICAgU3RyaW5nLFxuICAgICAgY29kZVBvaW50cy5zbGljZShpLCBpICs9IE1BWF9BUkdVTUVOVFNfTEVOR1RIKVxuICAgIClcbiAgfVxuICByZXR1cm4gcmVzXG59XG5cbmZ1bmN0aW9uIGFzY2lpU2xpY2UgKGJ1Ziwgc3RhcnQsIGVuZCkge1xuICBsZXQgcmV0ID0gJydcbiAgZW5kID0gTWF0aC5taW4oYnVmLmxlbmd0aCwgZW5kKVxuXG4gIGZvciAobGV0IGkgPSBzdGFydDsgaSA8IGVuZDsgKytpKSB7XG4gICAgcmV0ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYnVmW2ldICYgMHg3RilcbiAgfVxuICByZXR1cm4gcmV0XG59XG5cbmZ1bmN0aW9uIGxhdGluMVNsaWNlIChidWYsIHN0YXJ0LCBlbmQpIHtcbiAgbGV0IHJldCA9ICcnXG4gIGVuZCA9IE1hdGgubWluKGJ1Zi5sZW5ndGgsIGVuZClcblxuICBmb3IgKGxldCBpID0gc3RhcnQ7IGkgPCBlbmQ7ICsraSkge1xuICAgIHJldCArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKGJ1ZltpXSlcbiAgfVxuICByZXR1cm4gcmV0XG59XG5cbmZ1bmN0aW9uIGhleFNsaWNlIChidWYsIHN0YXJ0LCBlbmQpIHtcbiAgY29uc3QgbGVuID0gYnVmLmxlbmd0aFxuXG4gIGlmICghc3RhcnQgfHwgc3RhcnQgPCAwKSBzdGFydCA9IDBcbiAgaWYgKCFlbmQgfHwgZW5kIDwgMCB8fCBlbmQgPiBsZW4pIGVuZCA9IGxlblxuXG4gIGxldCBvdXQgPSAnJ1xuICBmb3IgKGxldCBpID0gc3RhcnQ7IGkgPCBlbmQ7ICsraSkge1xuICAgIG91dCArPSBoZXhTbGljZUxvb2t1cFRhYmxlW2J1ZltpXV1cbiAgfVxuICByZXR1cm4gb3V0XG59XG5cbmZ1bmN0aW9uIHV0ZjE2bGVTbGljZSAoYnVmLCBzdGFydCwgZW5kKSB7XG4gIGNvbnN0IGJ5dGVzID0gYnVmLnNsaWNlKHN0YXJ0LCBlbmQpXG4gIGxldCByZXMgPSAnJ1xuICAvLyBJZiBieXRlcy5sZW5ndGggaXMgb2RkLCB0aGUgbGFzdCA4IGJpdHMgbXVzdCBiZSBpZ25vcmVkIChzYW1lIGFzIG5vZGUuanMpXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYnl0ZXMubGVuZ3RoIC0gMTsgaSArPSAyKSB7XG4gICAgcmVzICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYnl0ZXNbaV0gKyAoYnl0ZXNbaSArIDFdICogMjU2KSlcbiAgfVxuICByZXR1cm4gcmVzXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUuc2xpY2UgPSBmdW5jdGlvbiBzbGljZSAoc3RhcnQsIGVuZCkge1xuICBjb25zdCBsZW4gPSB0aGlzLmxlbmd0aFxuICBzdGFydCA9IH5+c3RhcnRcbiAgZW5kID0gZW5kID09PSB1bmRlZmluZWQgPyBsZW4gOiB+fmVuZFxuXG4gIGlmIChzdGFydCA8IDApIHtcbiAgICBzdGFydCArPSBsZW5cbiAgICBpZiAoc3RhcnQgPCAwKSBzdGFydCA9IDBcbiAgfSBlbHNlIGlmIChzdGFydCA+IGxlbikge1xuICAgIHN0YXJ0ID0gbGVuXG4gIH1cblxuICBpZiAoZW5kIDwgMCkge1xuICAgIGVuZCArPSBsZW5cbiAgICBpZiAoZW5kIDwgMCkgZW5kID0gMFxuICB9IGVsc2UgaWYgKGVuZCA+IGxlbikge1xuICAgIGVuZCA9IGxlblxuICB9XG5cbiAgaWYgKGVuZCA8IHN0YXJ0KSBlbmQgPSBzdGFydFxuXG4gIGNvbnN0IG5ld0J1ZiA9IHRoaXMuc3ViYXJyYXkoc3RhcnQsIGVuZClcbiAgLy8gUmV0dXJuIGFuIGF1Z21lbnRlZCBgVWludDhBcnJheWAgaW5zdGFuY2VcbiAgT2JqZWN0LnNldFByb3RvdHlwZU9mKG5ld0J1ZiwgQnVmZmVyLnByb3RvdHlwZSlcblxuICByZXR1cm4gbmV3QnVmXG59XG5cbi8qXG4gKiBOZWVkIHRvIG1ha2Ugc3VyZSB0aGF0IGJ1ZmZlciBpc24ndCB0cnlpbmcgdG8gd3JpdGUgb3V0IG9mIGJvdW5kcy5cbiAqL1xuZnVuY3Rpb24gY2hlY2tPZmZzZXQgKG9mZnNldCwgZXh0LCBsZW5ndGgpIHtcbiAgaWYgKChvZmZzZXQgJSAxKSAhPT0gMCB8fCBvZmZzZXQgPCAwKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcignb2Zmc2V0IGlzIG5vdCB1aW50JylcbiAgaWYgKG9mZnNldCArIGV4dCA+IGxlbmd0aCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ1RyeWluZyB0byBhY2Nlc3MgYmV5b25kIGJ1ZmZlciBsZW5ndGgnKVxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRVaW50TEUgPVxuQnVmZmVyLnByb3RvdHlwZS5yZWFkVUludExFID0gZnVuY3Rpb24gcmVhZFVJbnRMRSAob2Zmc2V0LCBieXRlTGVuZ3RoLCBub0Fzc2VydCkge1xuICBvZmZzZXQgPSBvZmZzZXQgPj4+IDBcbiAgYnl0ZUxlbmd0aCA9IGJ5dGVMZW5ndGggPj4+IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCBieXRlTGVuZ3RoLCB0aGlzLmxlbmd0aClcblxuICBsZXQgdmFsID0gdGhpc1tvZmZzZXRdXG4gIGxldCBtdWwgPSAxXG4gIGxldCBpID0gMFxuICB3aGlsZSAoKytpIDwgYnl0ZUxlbmd0aCAmJiAobXVsICo9IDB4MTAwKSkge1xuICAgIHZhbCArPSB0aGlzW29mZnNldCArIGldICogbXVsXG4gIH1cblxuICByZXR1cm4gdmFsXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZFVpbnRCRSA9XG5CdWZmZXIucHJvdG90eXBlLnJlYWRVSW50QkUgPSBmdW5jdGlvbiByZWFkVUludEJFIChvZmZzZXQsIGJ5dGVMZW5ndGgsIG5vQXNzZXJ0KSB7XG4gIG9mZnNldCA9IG9mZnNldCA+Pj4gMFxuICBieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aCA+Pj4gMFxuICBpZiAoIW5vQXNzZXJ0KSB7XG4gICAgY2hlY2tPZmZzZXQob2Zmc2V0LCBieXRlTGVuZ3RoLCB0aGlzLmxlbmd0aClcbiAgfVxuXG4gIGxldCB2YWwgPSB0aGlzW29mZnNldCArIC0tYnl0ZUxlbmd0aF1cbiAgbGV0IG11bCA9IDFcbiAgd2hpbGUgKGJ5dGVMZW5ndGggPiAwICYmIChtdWwgKj0gMHgxMDApKSB7XG4gICAgdmFsICs9IHRoaXNbb2Zmc2V0ICsgLS1ieXRlTGVuZ3RoXSAqIG11bFxuICB9XG5cbiAgcmV0dXJuIHZhbFxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRVaW50OCA9XG5CdWZmZXIucHJvdG90eXBlLnJlYWRVSW50OCA9IGZ1bmN0aW9uIHJlYWRVSW50OCAob2Zmc2V0LCBub0Fzc2VydCkge1xuICBvZmZzZXQgPSBvZmZzZXQgPj4+IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCAxLCB0aGlzLmxlbmd0aClcbiAgcmV0dXJuIHRoaXNbb2Zmc2V0XVxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRVaW50MTZMRSA9XG5CdWZmZXIucHJvdG90eXBlLnJlYWRVSW50MTZMRSA9IGZ1bmN0aW9uIHJlYWRVSW50MTZMRSAob2Zmc2V0LCBub0Fzc2VydCkge1xuICBvZmZzZXQgPSBvZmZzZXQgPj4+IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCAyLCB0aGlzLmxlbmd0aClcbiAgcmV0dXJuIHRoaXNbb2Zmc2V0XSB8ICh0aGlzW29mZnNldCArIDFdIDw8IDgpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZFVpbnQxNkJFID1cbkJ1ZmZlci5wcm90b3R5cGUucmVhZFVJbnQxNkJFID0gZnVuY3Rpb24gcmVhZFVJbnQxNkJFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIG9mZnNldCA9IG9mZnNldCA+Pj4gMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDIsIHRoaXMubGVuZ3RoKVxuICByZXR1cm4gKHRoaXNbb2Zmc2V0XSA8PCA4KSB8IHRoaXNbb2Zmc2V0ICsgMV1cbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkVWludDMyTEUgPVxuQnVmZmVyLnByb3RvdHlwZS5yZWFkVUludDMyTEUgPSBmdW5jdGlvbiByZWFkVUludDMyTEUgKG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgNCwgdGhpcy5sZW5ndGgpXG5cbiAgcmV0dXJuICgodGhpc1tvZmZzZXRdKSB8XG4gICAgICAodGhpc1tvZmZzZXQgKyAxXSA8PCA4KSB8XG4gICAgICAodGhpc1tvZmZzZXQgKyAyXSA8PCAxNikpICtcbiAgICAgICh0aGlzW29mZnNldCArIDNdICogMHgxMDAwMDAwKVxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRVaW50MzJCRSA9XG5CdWZmZXIucHJvdG90eXBlLnJlYWRVSW50MzJCRSA9IGZ1bmN0aW9uIHJlYWRVSW50MzJCRSAob2Zmc2V0LCBub0Fzc2VydCkge1xuICBvZmZzZXQgPSBvZmZzZXQgPj4+IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCA0LCB0aGlzLmxlbmd0aClcblxuICByZXR1cm4gKHRoaXNbb2Zmc2V0XSAqIDB4MTAwMDAwMCkgK1xuICAgICgodGhpc1tvZmZzZXQgKyAxXSA8PCAxNikgfFxuICAgICh0aGlzW29mZnNldCArIDJdIDw8IDgpIHxcbiAgICB0aGlzW29mZnNldCArIDNdKVxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRCaWdVSW50NjRMRSA9IGRlZmluZUJpZ0ludE1ldGhvZChmdW5jdGlvbiByZWFkQmlnVUludDY0TEUgKG9mZnNldCkge1xuICBvZmZzZXQgPSBvZmZzZXQgPj4+IDBcbiAgdmFsaWRhdGVOdW1iZXIob2Zmc2V0LCAnb2Zmc2V0JylcbiAgY29uc3QgZmlyc3QgPSB0aGlzW29mZnNldF1cbiAgY29uc3QgbGFzdCA9IHRoaXNbb2Zmc2V0ICsgN11cbiAgaWYgKGZpcnN0ID09PSB1bmRlZmluZWQgfHwgbGFzdCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgYm91bmRzRXJyb3Iob2Zmc2V0LCB0aGlzLmxlbmd0aCAtIDgpXG4gIH1cblxuICBjb25zdCBsbyA9IGZpcnN0ICtcbiAgICB0aGlzWysrb2Zmc2V0XSAqIDIgKiogOCArXG4gICAgdGhpc1srK29mZnNldF0gKiAyICoqIDE2ICtcbiAgICB0aGlzWysrb2Zmc2V0XSAqIDIgKiogMjRcblxuICBjb25zdCBoaSA9IHRoaXNbKytvZmZzZXRdICtcbiAgICB0aGlzWysrb2Zmc2V0XSAqIDIgKiogOCArXG4gICAgdGhpc1srK29mZnNldF0gKiAyICoqIDE2ICtcbiAgICBsYXN0ICogMiAqKiAyNFxuXG4gIHJldHVybiBCaWdJbnQobG8pICsgKEJpZ0ludChoaSkgPDwgQmlnSW50KDMyKSlcbn0pXG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZEJpZ1VJbnQ2NEJFID0gZGVmaW5lQmlnSW50TWV0aG9kKGZ1bmN0aW9uIHJlYWRCaWdVSW50NjRCRSAob2Zmc2V0KSB7XG4gIG9mZnNldCA9IG9mZnNldCA+Pj4gMFxuICB2YWxpZGF0ZU51bWJlcihvZmZzZXQsICdvZmZzZXQnKVxuICBjb25zdCBmaXJzdCA9IHRoaXNbb2Zmc2V0XVxuICBjb25zdCBsYXN0ID0gdGhpc1tvZmZzZXQgKyA3XVxuICBpZiAoZmlyc3QgPT09IHVuZGVmaW5lZCB8fCBsYXN0ID09PSB1bmRlZmluZWQpIHtcbiAgICBib3VuZHNFcnJvcihvZmZzZXQsIHRoaXMubGVuZ3RoIC0gOClcbiAgfVxuXG4gIGNvbnN0IGhpID0gZmlyc3QgKiAyICoqIDI0ICtcbiAgICB0aGlzWysrb2Zmc2V0XSAqIDIgKiogMTYgK1xuICAgIHRoaXNbKytvZmZzZXRdICogMiAqKiA4ICtcbiAgICB0aGlzWysrb2Zmc2V0XVxuXG4gIGNvbnN0IGxvID0gdGhpc1srK29mZnNldF0gKiAyICoqIDI0ICtcbiAgICB0aGlzWysrb2Zmc2V0XSAqIDIgKiogMTYgK1xuICAgIHRoaXNbKytvZmZzZXRdICogMiAqKiA4ICtcbiAgICBsYXN0XG5cbiAgcmV0dXJuIChCaWdJbnQoaGkpIDw8IEJpZ0ludCgzMikpICsgQmlnSW50KGxvKVxufSlcblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkSW50TEUgPSBmdW5jdGlvbiByZWFkSW50TEUgKG9mZnNldCwgYnl0ZUxlbmd0aCwgbm9Bc3NlcnQpIHtcbiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gIGJ5dGVMZW5ndGggPSBieXRlTGVuZ3RoID4+PiAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgYnl0ZUxlbmd0aCwgdGhpcy5sZW5ndGgpXG5cbiAgbGV0IHZhbCA9IHRoaXNbb2Zmc2V0XVxuICBsZXQgbXVsID0gMVxuICBsZXQgaSA9IDBcbiAgd2hpbGUgKCsraSA8IGJ5dGVMZW5ndGggJiYgKG11bCAqPSAweDEwMCkpIHtcbiAgICB2YWwgKz0gdGhpc1tvZmZzZXQgKyBpXSAqIG11bFxuICB9XG4gIG11bCAqPSAweDgwXG5cbiAgaWYgKHZhbCA+PSBtdWwpIHZhbCAtPSBNYXRoLnBvdygyLCA4ICogYnl0ZUxlbmd0aClcblxuICByZXR1cm4gdmFsXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZEludEJFID0gZnVuY3Rpb24gcmVhZEludEJFIChvZmZzZXQsIGJ5dGVMZW5ndGgsIG5vQXNzZXJ0KSB7XG4gIG9mZnNldCA9IG9mZnNldCA+Pj4gMFxuICBieXRlTGVuZ3RoID0gYnl0ZUxlbmd0aCA+Pj4gMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIGJ5dGVMZW5ndGgsIHRoaXMubGVuZ3RoKVxuXG4gIGxldCBpID0gYnl0ZUxlbmd0aFxuICBsZXQgbXVsID0gMVxuICBsZXQgdmFsID0gdGhpc1tvZmZzZXQgKyAtLWldXG4gIHdoaWxlIChpID4gMCAmJiAobXVsICo9IDB4MTAwKSkge1xuICAgIHZhbCArPSB0aGlzW29mZnNldCArIC0taV0gKiBtdWxcbiAgfVxuICBtdWwgKj0gMHg4MFxuXG4gIGlmICh2YWwgPj0gbXVsKSB2YWwgLT0gTWF0aC5wb3coMiwgOCAqIGJ5dGVMZW5ndGgpXG5cbiAgcmV0dXJuIHZhbFxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRJbnQ4ID0gZnVuY3Rpb24gcmVhZEludDggKG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgMSwgdGhpcy5sZW5ndGgpXG4gIGlmICghKHRoaXNbb2Zmc2V0XSAmIDB4ODApKSByZXR1cm4gKHRoaXNbb2Zmc2V0XSlcbiAgcmV0dXJuICgoMHhmZiAtIHRoaXNbb2Zmc2V0XSArIDEpICogLTEpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZEludDE2TEUgPSBmdW5jdGlvbiByZWFkSW50MTZMRSAob2Zmc2V0LCBub0Fzc2VydCkge1xuICBvZmZzZXQgPSBvZmZzZXQgPj4+IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCAyLCB0aGlzLmxlbmd0aClcbiAgY29uc3QgdmFsID0gdGhpc1tvZmZzZXRdIHwgKHRoaXNbb2Zmc2V0ICsgMV0gPDwgOClcbiAgcmV0dXJuICh2YWwgJiAweDgwMDApID8gdmFsIHwgMHhGRkZGMDAwMCA6IHZhbFxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRJbnQxNkJFID0gZnVuY3Rpb24gcmVhZEludDE2QkUgKG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgMiwgdGhpcy5sZW5ndGgpXG4gIGNvbnN0IHZhbCA9IHRoaXNbb2Zmc2V0ICsgMV0gfCAodGhpc1tvZmZzZXRdIDw8IDgpXG4gIHJldHVybiAodmFsICYgMHg4MDAwKSA/IHZhbCB8IDB4RkZGRjAwMDAgOiB2YWxcbn1cblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkSW50MzJMRSA9IGZ1bmN0aW9uIHJlYWRJbnQzMkxFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIG9mZnNldCA9IG9mZnNldCA+Pj4gMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDQsIHRoaXMubGVuZ3RoKVxuXG4gIHJldHVybiAodGhpc1tvZmZzZXRdKSB8XG4gICAgKHRoaXNbb2Zmc2V0ICsgMV0gPDwgOCkgfFxuICAgICh0aGlzW29mZnNldCArIDJdIDw8IDE2KSB8XG4gICAgKHRoaXNbb2Zmc2V0ICsgM10gPDwgMjQpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZEludDMyQkUgPSBmdW5jdGlvbiByZWFkSW50MzJCRSAob2Zmc2V0LCBub0Fzc2VydCkge1xuICBvZmZzZXQgPSBvZmZzZXQgPj4+IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCA0LCB0aGlzLmxlbmd0aClcblxuICByZXR1cm4gKHRoaXNbb2Zmc2V0XSA8PCAyNCkgfFxuICAgICh0aGlzW29mZnNldCArIDFdIDw8IDE2KSB8XG4gICAgKHRoaXNbb2Zmc2V0ICsgMl0gPDwgOCkgfFxuICAgICh0aGlzW29mZnNldCArIDNdKVxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRCaWdJbnQ2NExFID0gZGVmaW5lQmlnSW50TWV0aG9kKGZ1bmN0aW9uIHJlYWRCaWdJbnQ2NExFIChvZmZzZXQpIHtcbiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gIHZhbGlkYXRlTnVtYmVyKG9mZnNldCwgJ29mZnNldCcpXG4gIGNvbnN0IGZpcnN0ID0gdGhpc1tvZmZzZXRdXG4gIGNvbnN0IGxhc3QgPSB0aGlzW29mZnNldCArIDddXG4gIGlmIChmaXJzdCA9PT0gdW5kZWZpbmVkIHx8IGxhc3QgPT09IHVuZGVmaW5lZCkge1xuICAgIGJvdW5kc0Vycm9yKG9mZnNldCwgdGhpcy5sZW5ndGggLSA4KVxuICB9XG5cbiAgY29uc3QgdmFsID0gdGhpc1tvZmZzZXQgKyA0XSArXG4gICAgdGhpc1tvZmZzZXQgKyA1XSAqIDIgKiogOCArXG4gICAgdGhpc1tvZmZzZXQgKyA2XSAqIDIgKiogMTYgK1xuICAgIChsYXN0IDw8IDI0KSAvLyBPdmVyZmxvd1xuXG4gIHJldHVybiAoQmlnSW50KHZhbCkgPDwgQmlnSW50KDMyKSkgK1xuICAgIEJpZ0ludChmaXJzdCArXG4gICAgdGhpc1srK29mZnNldF0gKiAyICoqIDggK1xuICAgIHRoaXNbKytvZmZzZXRdICogMiAqKiAxNiArXG4gICAgdGhpc1srK29mZnNldF0gKiAyICoqIDI0KVxufSlcblxuQnVmZmVyLnByb3RvdHlwZS5yZWFkQmlnSW50NjRCRSA9IGRlZmluZUJpZ0ludE1ldGhvZChmdW5jdGlvbiByZWFkQmlnSW50NjRCRSAob2Zmc2V0KSB7XG4gIG9mZnNldCA9IG9mZnNldCA+Pj4gMFxuICB2YWxpZGF0ZU51bWJlcihvZmZzZXQsICdvZmZzZXQnKVxuICBjb25zdCBmaXJzdCA9IHRoaXNbb2Zmc2V0XVxuICBjb25zdCBsYXN0ID0gdGhpc1tvZmZzZXQgKyA3XVxuICBpZiAoZmlyc3QgPT09IHVuZGVmaW5lZCB8fCBsYXN0ID09PSB1bmRlZmluZWQpIHtcbiAgICBib3VuZHNFcnJvcihvZmZzZXQsIHRoaXMubGVuZ3RoIC0gOClcbiAgfVxuXG4gIGNvbnN0IHZhbCA9IChmaXJzdCA8PCAyNCkgKyAvLyBPdmVyZmxvd1xuICAgIHRoaXNbKytvZmZzZXRdICogMiAqKiAxNiArXG4gICAgdGhpc1srK29mZnNldF0gKiAyICoqIDggK1xuICAgIHRoaXNbKytvZmZzZXRdXG5cbiAgcmV0dXJuIChCaWdJbnQodmFsKSA8PCBCaWdJbnQoMzIpKSArXG4gICAgQmlnSW50KHRoaXNbKytvZmZzZXRdICogMiAqKiAyNCArXG4gICAgdGhpc1srK29mZnNldF0gKiAyICoqIDE2ICtcbiAgICB0aGlzWysrb2Zmc2V0XSAqIDIgKiogOCArXG4gICAgbGFzdClcbn0pXG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZEZsb2F0TEUgPSBmdW5jdGlvbiByZWFkRmxvYXRMRSAob2Zmc2V0LCBub0Fzc2VydCkge1xuICBvZmZzZXQgPSBvZmZzZXQgPj4+IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tPZmZzZXQob2Zmc2V0LCA0LCB0aGlzLmxlbmd0aClcbiAgcmV0dXJuIGllZWU3NTQucmVhZCh0aGlzLCBvZmZzZXQsIHRydWUsIDIzLCA0KVxufVxuXG5CdWZmZXIucHJvdG90eXBlLnJlYWRGbG9hdEJFID0gZnVuY3Rpb24gcmVhZEZsb2F0QkUgKG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrT2Zmc2V0KG9mZnNldCwgNCwgdGhpcy5sZW5ndGgpXG4gIHJldHVybiBpZWVlNzU0LnJlYWQodGhpcywgb2Zmc2V0LCBmYWxzZSwgMjMsIDQpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZERvdWJsZUxFID0gZnVuY3Rpb24gcmVhZERvdWJsZUxFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIG9mZnNldCA9IG9mZnNldCA+Pj4gMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDgsIHRoaXMubGVuZ3RoKVxuICByZXR1cm4gaWVlZTc1NC5yZWFkKHRoaXMsIG9mZnNldCwgdHJ1ZSwgNTIsIDgpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUucmVhZERvdWJsZUJFID0gZnVuY3Rpb24gcmVhZERvdWJsZUJFIChvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIG9mZnNldCA9IG9mZnNldCA+Pj4gMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja09mZnNldChvZmZzZXQsIDgsIHRoaXMubGVuZ3RoKVxuICByZXR1cm4gaWVlZTc1NC5yZWFkKHRoaXMsIG9mZnNldCwgZmFsc2UsIDUyLCA4KVxufVxuXG5mdW5jdGlvbiBjaGVja0ludCAoYnVmLCB2YWx1ZSwgb2Zmc2V0LCBleHQsIG1heCwgbWluKSB7XG4gIGlmICghQnVmZmVyLmlzQnVmZmVyKGJ1ZikpIHRocm93IG5ldyBUeXBlRXJyb3IoJ1wiYnVmZmVyXCIgYXJndW1lbnQgbXVzdCBiZSBhIEJ1ZmZlciBpbnN0YW5jZScpXG4gIGlmICh2YWx1ZSA+IG1heCB8fCB2YWx1ZSA8IG1pbikgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ1widmFsdWVcIiBhcmd1bWVudCBpcyBvdXQgb2YgYm91bmRzJylcbiAgaWYgKG9mZnNldCArIGV4dCA+IGJ1Zi5sZW5ndGgpIHRocm93IG5ldyBSYW5nZUVycm9yKCdJbmRleCBvdXQgb2YgcmFuZ2UnKVxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlVWludExFID1cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVSW50TEUgPSBmdW5jdGlvbiB3cml0ZVVJbnRMRSAodmFsdWUsIG9mZnNldCwgYnl0ZUxlbmd0aCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gIGJ5dGVMZW5ndGggPSBieXRlTGVuZ3RoID4+PiAwXG4gIGlmICghbm9Bc3NlcnQpIHtcbiAgICBjb25zdCBtYXhCeXRlcyA9IE1hdGgucG93KDIsIDggKiBieXRlTGVuZ3RoKSAtIDFcbiAgICBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCBieXRlTGVuZ3RoLCBtYXhCeXRlcywgMClcbiAgfVxuXG4gIGxldCBtdWwgPSAxXG4gIGxldCBpID0gMFxuICB0aGlzW29mZnNldF0gPSB2YWx1ZSAmIDB4RkZcbiAgd2hpbGUgKCsraSA8IGJ5dGVMZW5ndGggJiYgKG11bCAqPSAweDEwMCkpIHtcbiAgICB0aGlzW29mZnNldCArIGldID0gKHZhbHVlIC8gbXVsKSAmIDB4RkZcbiAgfVxuXG4gIHJldHVybiBvZmZzZXQgKyBieXRlTGVuZ3RoXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVaW50QkUgPVxuQnVmZmVyLnByb3RvdHlwZS53cml0ZVVJbnRCRSA9IGZ1bmN0aW9uIHdyaXRlVUludEJFICh2YWx1ZSwgb2Zmc2V0LCBieXRlTGVuZ3RoLCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgPj4+IDBcbiAgYnl0ZUxlbmd0aCA9IGJ5dGVMZW5ndGggPj4+IDBcbiAgaWYgKCFub0Fzc2VydCkge1xuICAgIGNvbnN0IG1heEJ5dGVzID0gTWF0aC5wb3coMiwgOCAqIGJ5dGVMZW5ndGgpIC0gMVxuICAgIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIGJ5dGVMZW5ndGgsIG1heEJ5dGVzLCAwKVxuICB9XG5cbiAgbGV0IGkgPSBieXRlTGVuZ3RoIC0gMVxuICBsZXQgbXVsID0gMVxuICB0aGlzW29mZnNldCArIGldID0gdmFsdWUgJiAweEZGXG4gIHdoaWxlICgtLWkgPj0gMCAmJiAobXVsICo9IDB4MTAwKSkge1xuICAgIHRoaXNbb2Zmc2V0ICsgaV0gPSAodmFsdWUgLyBtdWwpICYgMHhGRlxuICB9XG5cbiAgcmV0dXJuIG9mZnNldCArIGJ5dGVMZW5ndGhcbn1cblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZVVpbnQ4ID1cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVSW50OCA9IGZ1bmN0aW9uIHdyaXRlVUludDggKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIHZhbHVlID0gK3ZhbHVlXG4gIG9mZnNldCA9IG9mZnNldCA+Pj4gMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCAxLCAweGZmLCAwKVxuICB0aGlzW29mZnNldF0gPSAodmFsdWUgJiAweGZmKVxuICByZXR1cm4gb2Zmc2V0ICsgMVxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlVWludDE2TEUgPVxuQnVmZmVyLnByb3RvdHlwZS53cml0ZVVJbnQxNkxFID0gZnVuY3Rpb24gd3JpdGVVSW50MTZMRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDIsIDB4ZmZmZiwgMClcbiAgdGhpc1tvZmZzZXRdID0gKHZhbHVlICYgMHhmZilcbiAgdGhpc1tvZmZzZXQgKyAxXSA9ICh2YWx1ZSA+Pj4gOClcbiAgcmV0dXJuIG9mZnNldCArIDJcbn1cblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZVVpbnQxNkJFID1cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVSW50MTZCRSA9IGZ1bmN0aW9uIHdyaXRlVUludDE2QkUgKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIHZhbHVlID0gK3ZhbHVlXG4gIG9mZnNldCA9IG9mZnNldCA+Pj4gMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCAyLCAweGZmZmYsIDApXG4gIHRoaXNbb2Zmc2V0XSA9ICh2YWx1ZSA+Pj4gOClcbiAgdGhpc1tvZmZzZXQgKyAxXSA9ICh2YWx1ZSAmIDB4ZmYpXG4gIHJldHVybiBvZmZzZXQgKyAyXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVVaW50MzJMRSA9XG5CdWZmZXIucHJvdG90eXBlLndyaXRlVUludDMyTEUgPSBmdW5jdGlvbiB3cml0ZVVJbnQzMkxFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgPj4+IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tJbnQodGhpcywgdmFsdWUsIG9mZnNldCwgNCwgMHhmZmZmZmZmZiwgMClcbiAgdGhpc1tvZmZzZXQgKyAzXSA9ICh2YWx1ZSA+Pj4gMjQpXG4gIHRoaXNbb2Zmc2V0ICsgMl0gPSAodmFsdWUgPj4+IDE2KVxuICB0aGlzW29mZnNldCArIDFdID0gKHZhbHVlID4+PiA4KVxuICB0aGlzW29mZnNldF0gPSAodmFsdWUgJiAweGZmKVxuICByZXR1cm4gb2Zmc2V0ICsgNFxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlVWludDMyQkUgPVxuQnVmZmVyLnByb3RvdHlwZS53cml0ZVVJbnQzMkJFID0gZnVuY3Rpb24gd3JpdGVVSW50MzJCRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDQsIDB4ZmZmZmZmZmYsIDApXG4gIHRoaXNbb2Zmc2V0XSA9ICh2YWx1ZSA+Pj4gMjQpXG4gIHRoaXNbb2Zmc2V0ICsgMV0gPSAodmFsdWUgPj4+IDE2KVxuICB0aGlzW29mZnNldCArIDJdID0gKHZhbHVlID4+PiA4KVxuICB0aGlzW29mZnNldCArIDNdID0gKHZhbHVlICYgMHhmZilcbiAgcmV0dXJuIG9mZnNldCArIDRcbn1cblxuZnVuY3Rpb24gd3J0QmlnVUludDY0TEUgKGJ1ZiwgdmFsdWUsIG9mZnNldCwgbWluLCBtYXgpIHtcbiAgY2hlY2tJbnRCSSh2YWx1ZSwgbWluLCBtYXgsIGJ1Ziwgb2Zmc2V0LCA3KVxuXG4gIGxldCBsbyA9IE51bWJlcih2YWx1ZSAmIEJpZ0ludCgweGZmZmZmZmZmKSlcbiAgYnVmW29mZnNldCsrXSA9IGxvXG4gIGxvID0gbG8gPj4gOFxuICBidWZbb2Zmc2V0KytdID0gbG9cbiAgbG8gPSBsbyA+PiA4XG4gIGJ1ZltvZmZzZXQrK10gPSBsb1xuICBsbyA9IGxvID4+IDhcbiAgYnVmW29mZnNldCsrXSA9IGxvXG4gIGxldCBoaSA9IE51bWJlcih2YWx1ZSA+PiBCaWdJbnQoMzIpICYgQmlnSW50KDB4ZmZmZmZmZmYpKVxuICBidWZbb2Zmc2V0KytdID0gaGlcbiAgaGkgPSBoaSA+PiA4XG4gIGJ1ZltvZmZzZXQrK10gPSBoaVxuICBoaSA9IGhpID4+IDhcbiAgYnVmW29mZnNldCsrXSA9IGhpXG4gIGhpID0gaGkgPj4gOFxuICBidWZbb2Zmc2V0KytdID0gaGlcbiAgcmV0dXJuIG9mZnNldFxufVxuXG5mdW5jdGlvbiB3cnRCaWdVSW50NjRCRSAoYnVmLCB2YWx1ZSwgb2Zmc2V0LCBtaW4sIG1heCkge1xuICBjaGVja0ludEJJKHZhbHVlLCBtaW4sIG1heCwgYnVmLCBvZmZzZXQsIDcpXG5cbiAgbGV0IGxvID0gTnVtYmVyKHZhbHVlICYgQmlnSW50KDB4ZmZmZmZmZmYpKVxuICBidWZbb2Zmc2V0ICsgN10gPSBsb1xuICBsbyA9IGxvID4+IDhcbiAgYnVmW29mZnNldCArIDZdID0gbG9cbiAgbG8gPSBsbyA+PiA4XG4gIGJ1ZltvZmZzZXQgKyA1XSA9IGxvXG4gIGxvID0gbG8gPj4gOFxuICBidWZbb2Zmc2V0ICsgNF0gPSBsb1xuICBsZXQgaGkgPSBOdW1iZXIodmFsdWUgPj4gQmlnSW50KDMyKSAmIEJpZ0ludCgweGZmZmZmZmZmKSlcbiAgYnVmW29mZnNldCArIDNdID0gaGlcbiAgaGkgPSBoaSA+PiA4XG4gIGJ1ZltvZmZzZXQgKyAyXSA9IGhpXG4gIGhpID0gaGkgPj4gOFxuICBidWZbb2Zmc2V0ICsgMV0gPSBoaVxuICBoaSA9IGhpID4+IDhcbiAgYnVmW29mZnNldF0gPSBoaVxuICByZXR1cm4gb2Zmc2V0ICsgOFxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlQmlnVUludDY0TEUgPSBkZWZpbmVCaWdJbnRNZXRob2QoZnVuY3Rpb24gd3JpdGVCaWdVSW50NjRMRSAodmFsdWUsIG9mZnNldCA9IDApIHtcbiAgcmV0dXJuIHdydEJpZ1VJbnQ2NExFKHRoaXMsIHZhbHVlLCBvZmZzZXQsIEJpZ0ludCgwKSwgQmlnSW50KCcweGZmZmZmZmZmZmZmZmZmZmYnKSlcbn0pXG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVCaWdVSW50NjRCRSA9IGRlZmluZUJpZ0ludE1ldGhvZChmdW5jdGlvbiB3cml0ZUJpZ1VJbnQ2NEJFICh2YWx1ZSwgb2Zmc2V0ID0gMCkge1xuICByZXR1cm4gd3J0QmlnVUludDY0QkUodGhpcywgdmFsdWUsIG9mZnNldCwgQmlnSW50KDApLCBCaWdJbnQoJzB4ZmZmZmZmZmZmZmZmZmZmZicpKVxufSlcblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZUludExFID0gZnVuY3Rpb24gd3JpdGVJbnRMRSAodmFsdWUsIG9mZnNldCwgYnl0ZUxlbmd0aCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gIGlmICghbm9Bc3NlcnQpIHtcbiAgICBjb25zdCBsaW1pdCA9IE1hdGgucG93KDIsICg4ICogYnl0ZUxlbmd0aCkgLSAxKVxuXG4gICAgY2hlY2tJbnQodGhpcywgdmFsdWUsIG9mZnNldCwgYnl0ZUxlbmd0aCwgbGltaXQgLSAxLCAtbGltaXQpXG4gIH1cblxuICBsZXQgaSA9IDBcbiAgbGV0IG11bCA9IDFcbiAgbGV0IHN1YiA9IDBcbiAgdGhpc1tvZmZzZXRdID0gdmFsdWUgJiAweEZGXG4gIHdoaWxlICgrK2kgPCBieXRlTGVuZ3RoICYmIChtdWwgKj0gMHgxMDApKSB7XG4gICAgaWYgKHZhbHVlIDwgMCAmJiBzdWIgPT09IDAgJiYgdGhpc1tvZmZzZXQgKyBpIC0gMV0gIT09IDApIHtcbiAgICAgIHN1YiA9IDFcbiAgICB9XG4gICAgdGhpc1tvZmZzZXQgKyBpXSA9ICgodmFsdWUgLyBtdWwpID4+IDApIC0gc3ViICYgMHhGRlxuICB9XG5cbiAgcmV0dXJuIG9mZnNldCArIGJ5dGVMZW5ndGhcbn1cblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZUludEJFID0gZnVuY3Rpb24gd3JpdGVJbnRCRSAodmFsdWUsIG9mZnNldCwgYnl0ZUxlbmd0aCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gIGlmICghbm9Bc3NlcnQpIHtcbiAgICBjb25zdCBsaW1pdCA9IE1hdGgucG93KDIsICg4ICogYnl0ZUxlbmd0aCkgLSAxKVxuXG4gICAgY2hlY2tJbnQodGhpcywgdmFsdWUsIG9mZnNldCwgYnl0ZUxlbmd0aCwgbGltaXQgLSAxLCAtbGltaXQpXG4gIH1cblxuICBsZXQgaSA9IGJ5dGVMZW5ndGggLSAxXG4gIGxldCBtdWwgPSAxXG4gIGxldCBzdWIgPSAwXG4gIHRoaXNbb2Zmc2V0ICsgaV0gPSB2YWx1ZSAmIDB4RkZcbiAgd2hpbGUgKC0taSA+PSAwICYmIChtdWwgKj0gMHgxMDApKSB7XG4gICAgaWYgKHZhbHVlIDwgMCAmJiBzdWIgPT09IDAgJiYgdGhpc1tvZmZzZXQgKyBpICsgMV0gIT09IDApIHtcbiAgICAgIHN1YiA9IDFcbiAgICB9XG4gICAgdGhpc1tvZmZzZXQgKyBpXSA9ICgodmFsdWUgLyBtdWwpID4+IDApIC0gc3ViICYgMHhGRlxuICB9XG5cbiAgcmV0dXJuIG9mZnNldCArIGJ5dGVMZW5ndGhcbn1cblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZUludDggPSBmdW5jdGlvbiB3cml0ZUludDggKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIHZhbHVlID0gK3ZhbHVlXG4gIG9mZnNldCA9IG9mZnNldCA+Pj4gMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCAxLCAweDdmLCAtMHg4MClcbiAgaWYgKHZhbHVlIDwgMCkgdmFsdWUgPSAweGZmICsgdmFsdWUgKyAxXG4gIHRoaXNbb2Zmc2V0XSA9ICh2YWx1ZSAmIDB4ZmYpXG4gIHJldHVybiBvZmZzZXQgKyAxXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVJbnQxNkxFID0gZnVuY3Rpb24gd3JpdGVJbnQxNkxFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgPj4+IDBcbiAgaWYgKCFub0Fzc2VydCkgY2hlY2tJbnQodGhpcywgdmFsdWUsIG9mZnNldCwgMiwgMHg3ZmZmLCAtMHg4MDAwKVxuICB0aGlzW29mZnNldF0gPSAodmFsdWUgJiAweGZmKVxuICB0aGlzW29mZnNldCArIDFdID0gKHZhbHVlID4+PiA4KVxuICByZXR1cm4gb2Zmc2V0ICsgMlxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlSW50MTZCRSA9IGZ1bmN0aW9uIHdyaXRlSW50MTZCRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDIsIDB4N2ZmZiwgLTB4ODAwMClcbiAgdGhpc1tvZmZzZXRdID0gKHZhbHVlID4+PiA4KVxuICB0aGlzW29mZnNldCArIDFdID0gKHZhbHVlICYgMHhmZilcbiAgcmV0dXJuIG9mZnNldCArIDJcbn1cblxuQnVmZmVyLnByb3RvdHlwZS53cml0ZUludDMyTEUgPSBmdW5jdGlvbiB3cml0ZUludDMyTEUgKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIHZhbHVlID0gK3ZhbHVlXG4gIG9mZnNldCA9IG9mZnNldCA+Pj4gMFxuICBpZiAoIW5vQXNzZXJ0KSBjaGVja0ludCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCA0LCAweDdmZmZmZmZmLCAtMHg4MDAwMDAwMClcbiAgdGhpc1tvZmZzZXRdID0gKHZhbHVlICYgMHhmZilcbiAgdGhpc1tvZmZzZXQgKyAxXSA9ICh2YWx1ZSA+Pj4gOClcbiAgdGhpc1tvZmZzZXQgKyAyXSA9ICh2YWx1ZSA+Pj4gMTYpXG4gIHRoaXNbb2Zmc2V0ICsgM10gPSAodmFsdWUgPj4+IDI0KVxuICByZXR1cm4gb2Zmc2V0ICsgNFxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlSW50MzJCRSA9IGZ1bmN0aW9uIHdyaXRlSW50MzJCRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gIGlmICghbm9Bc3NlcnQpIGNoZWNrSW50KHRoaXMsIHZhbHVlLCBvZmZzZXQsIDQsIDB4N2ZmZmZmZmYsIC0weDgwMDAwMDAwKVxuICBpZiAodmFsdWUgPCAwKSB2YWx1ZSA9IDB4ZmZmZmZmZmYgKyB2YWx1ZSArIDFcbiAgdGhpc1tvZmZzZXRdID0gKHZhbHVlID4+PiAyNClcbiAgdGhpc1tvZmZzZXQgKyAxXSA9ICh2YWx1ZSA+Pj4gMTYpXG4gIHRoaXNbb2Zmc2V0ICsgMl0gPSAodmFsdWUgPj4+IDgpXG4gIHRoaXNbb2Zmc2V0ICsgM10gPSAodmFsdWUgJiAweGZmKVxuICByZXR1cm4gb2Zmc2V0ICsgNFxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlQmlnSW50NjRMRSA9IGRlZmluZUJpZ0ludE1ldGhvZChmdW5jdGlvbiB3cml0ZUJpZ0ludDY0TEUgKHZhbHVlLCBvZmZzZXQgPSAwKSB7XG4gIHJldHVybiB3cnRCaWdVSW50NjRMRSh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCAtQmlnSW50KCcweDgwMDAwMDAwMDAwMDAwMDAnKSwgQmlnSW50KCcweDdmZmZmZmZmZmZmZmZmZmYnKSlcbn0pXG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVCaWdJbnQ2NEJFID0gZGVmaW5lQmlnSW50TWV0aG9kKGZ1bmN0aW9uIHdyaXRlQmlnSW50NjRCRSAodmFsdWUsIG9mZnNldCA9IDApIHtcbiAgcmV0dXJuIHdydEJpZ1VJbnQ2NEJFKHRoaXMsIHZhbHVlLCBvZmZzZXQsIC1CaWdJbnQoJzB4ODAwMDAwMDAwMDAwMDAwMCcpLCBCaWdJbnQoJzB4N2ZmZmZmZmZmZmZmZmZmZicpKVxufSlcblxuZnVuY3Rpb24gY2hlY2tJRUVFNzU0IChidWYsIHZhbHVlLCBvZmZzZXQsIGV4dCwgbWF4LCBtaW4pIHtcbiAgaWYgKG9mZnNldCArIGV4dCA+IGJ1Zi5sZW5ndGgpIHRocm93IG5ldyBSYW5nZUVycm9yKCdJbmRleCBvdXQgb2YgcmFuZ2UnKVxuICBpZiAob2Zmc2V0IDwgMCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0luZGV4IG91dCBvZiByYW5nZScpXG59XG5cbmZ1bmN0aW9uIHdyaXRlRmxvYXQgKGJ1ZiwgdmFsdWUsIG9mZnNldCwgbGl0dGxlRW5kaWFuLCBub0Fzc2VydCkge1xuICB2YWx1ZSA9ICt2YWx1ZVxuICBvZmZzZXQgPSBvZmZzZXQgPj4+IDBcbiAgaWYgKCFub0Fzc2VydCkge1xuICAgIGNoZWNrSUVFRTc1NChidWYsIHZhbHVlLCBvZmZzZXQsIDQsIDMuNDAyODIzNDY2Mzg1Mjg4NmUrMzgsIC0zLjQwMjgyMzQ2NjM4NTI4ODZlKzM4KVxuICB9XG4gIGllZWU3NTQud3JpdGUoYnVmLCB2YWx1ZSwgb2Zmc2V0LCBsaXR0bGVFbmRpYW4sIDIzLCA0KVxuICByZXR1cm4gb2Zmc2V0ICsgNFxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlRmxvYXRMRSA9IGZ1bmN0aW9uIHdyaXRlRmxvYXRMRSAodmFsdWUsIG9mZnNldCwgbm9Bc3NlcnQpIHtcbiAgcmV0dXJuIHdyaXRlRmxvYXQodGhpcywgdmFsdWUsIG9mZnNldCwgdHJ1ZSwgbm9Bc3NlcnQpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVGbG9hdEJFID0gZnVuY3Rpb24gd3JpdGVGbG9hdEJFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICByZXR1cm4gd3JpdGVGbG9hdCh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCBmYWxzZSwgbm9Bc3NlcnQpXG59XG5cbmZ1bmN0aW9uIHdyaXRlRG91YmxlIChidWYsIHZhbHVlLCBvZmZzZXQsIGxpdHRsZUVuZGlhbiwgbm9Bc3NlcnQpIHtcbiAgdmFsdWUgPSArdmFsdWVcbiAgb2Zmc2V0ID0gb2Zmc2V0ID4+PiAwXG4gIGlmICghbm9Bc3NlcnQpIHtcbiAgICBjaGVja0lFRUU3NTQoYnVmLCB2YWx1ZSwgb2Zmc2V0LCA4LCAxLjc5NzY5MzEzNDg2MjMxNTdFKzMwOCwgLTEuNzk3NjkzMTM0ODYyMzE1N0UrMzA4KVxuICB9XG4gIGllZWU3NTQud3JpdGUoYnVmLCB2YWx1ZSwgb2Zmc2V0LCBsaXR0bGVFbmRpYW4sIDUyLCA4KVxuICByZXR1cm4gb2Zmc2V0ICsgOFxufVxuXG5CdWZmZXIucHJvdG90eXBlLndyaXRlRG91YmxlTEUgPSBmdW5jdGlvbiB3cml0ZURvdWJsZUxFICh2YWx1ZSwgb2Zmc2V0LCBub0Fzc2VydCkge1xuICByZXR1cm4gd3JpdGVEb3VibGUodGhpcywgdmFsdWUsIG9mZnNldCwgdHJ1ZSwgbm9Bc3NlcnQpXG59XG5cbkJ1ZmZlci5wcm90b3R5cGUud3JpdGVEb3VibGVCRSA9IGZ1bmN0aW9uIHdyaXRlRG91YmxlQkUgKHZhbHVlLCBvZmZzZXQsIG5vQXNzZXJ0KSB7XG4gIHJldHVybiB3cml0ZURvdWJsZSh0aGlzLCB2YWx1ZSwgb2Zmc2V0LCBmYWxzZSwgbm9Bc3NlcnQpXG59XG5cbi8vIGNvcHkodGFyZ2V0QnVmZmVyLCB0YXJnZXRTdGFydD0wLCBzb3VyY2VTdGFydD0wLCBzb3VyY2VFbmQ9YnVmZmVyLmxlbmd0aClcbkJ1ZmZlci5wcm90b3R5cGUuY29weSA9IGZ1bmN0aW9uIGNvcHkgKHRhcmdldCwgdGFyZ2V0U3RhcnQsIHN0YXJ0LCBlbmQpIHtcbiAgaWYgKCFCdWZmZXIuaXNCdWZmZXIodGFyZ2V0KSkgdGhyb3cgbmV3IFR5cGVFcnJvcignYXJndW1lbnQgc2hvdWxkIGJlIGEgQnVmZmVyJylcbiAgaWYgKCFzdGFydCkgc3RhcnQgPSAwXG4gIGlmICghZW5kICYmIGVuZCAhPT0gMCkgZW5kID0gdGhpcy5sZW5ndGhcbiAgaWYgKHRhcmdldFN0YXJ0ID49IHRhcmdldC5sZW5ndGgpIHRhcmdldFN0YXJ0ID0gdGFyZ2V0Lmxlbmd0aFxuICBpZiAoIXRhcmdldFN0YXJ0KSB0YXJnZXRTdGFydCA9IDBcbiAgaWYgKGVuZCA+IDAgJiYgZW5kIDwgc3RhcnQpIGVuZCA9IHN0YXJ0XG5cbiAgLy8gQ29weSAwIGJ5dGVzOyB3ZSdyZSBkb25lXG4gIGlmIChlbmQgPT09IHN0YXJ0KSByZXR1cm4gMFxuICBpZiAodGFyZ2V0Lmxlbmd0aCA9PT0gMCB8fCB0aGlzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIDBcblxuICAvLyBGYXRhbCBlcnJvciBjb25kaXRpb25zXG4gIGlmICh0YXJnZXRTdGFydCA8IDApIHtcbiAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcigndGFyZ2V0U3RhcnQgb3V0IG9mIGJvdW5kcycpXG4gIH1cbiAgaWYgKHN0YXJ0IDwgMCB8fCBzdGFydCA+PSB0aGlzLmxlbmd0aCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0luZGV4IG91dCBvZiByYW5nZScpXG4gIGlmIChlbmQgPCAwKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcignc291cmNlRW5kIG91dCBvZiBib3VuZHMnKVxuXG4gIC8vIEFyZSB3ZSBvb2I/XG4gIGlmIChlbmQgPiB0aGlzLmxlbmd0aCkgZW5kID0gdGhpcy5sZW5ndGhcbiAgaWYgKHRhcmdldC5sZW5ndGggLSB0YXJnZXRTdGFydCA8IGVuZCAtIHN0YXJ0KSB7XG4gICAgZW5kID0gdGFyZ2V0Lmxlbmd0aCAtIHRhcmdldFN0YXJ0ICsgc3RhcnRcbiAgfVxuXG4gIGNvbnN0IGxlbiA9IGVuZCAtIHN0YXJ0XG5cbiAgaWYgKHRoaXMgPT09IHRhcmdldCAmJiB0eXBlb2YgVWludDhBcnJheS5wcm90b3R5cGUuY29weVdpdGhpbiA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIC8vIFVzZSBidWlsdC1pbiB3aGVuIGF2YWlsYWJsZSwgbWlzc2luZyBmcm9tIElFMTFcbiAgICB0aGlzLmNvcHlXaXRoaW4odGFyZ2V0U3RhcnQsIHN0YXJ0LCBlbmQpXG4gIH0gZWxzZSB7XG4gICAgVWludDhBcnJheS5wcm90b3R5cGUuc2V0LmNhbGwoXG4gICAgICB0YXJnZXQsXG4gICAgICB0aGlzLnN1YmFycmF5KHN0YXJ0LCBlbmQpLFxuICAgICAgdGFyZ2V0U3RhcnRcbiAgICApXG4gIH1cblxuICByZXR1cm4gbGVuXG59XG5cbi8vIFVzYWdlOlxuLy8gICAgYnVmZmVyLmZpbGwobnVtYmVyWywgb2Zmc2V0WywgZW5kXV0pXG4vLyAgICBidWZmZXIuZmlsbChidWZmZXJbLCBvZmZzZXRbLCBlbmRdXSlcbi8vICAgIGJ1ZmZlci5maWxsKHN0cmluZ1ssIG9mZnNldFssIGVuZF1dWywgZW5jb2RpbmddKVxuQnVmZmVyLnByb3RvdHlwZS5maWxsID0gZnVuY3Rpb24gZmlsbCAodmFsLCBzdGFydCwgZW5kLCBlbmNvZGluZykge1xuICAvLyBIYW5kbGUgc3RyaW5nIGNhc2VzOlxuICBpZiAodHlwZW9mIHZhbCA9PT0gJ3N0cmluZycpIHtcbiAgICBpZiAodHlwZW9mIHN0YXJ0ID09PSAnc3RyaW5nJykge1xuICAgICAgZW5jb2RpbmcgPSBzdGFydFxuICAgICAgc3RhcnQgPSAwXG4gICAgICBlbmQgPSB0aGlzLmxlbmd0aFxuICAgIH0gZWxzZSBpZiAodHlwZW9mIGVuZCA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGVuY29kaW5nID0gZW5kXG4gICAgICBlbmQgPSB0aGlzLmxlbmd0aFxuICAgIH1cbiAgICBpZiAoZW5jb2RpbmcgIT09IHVuZGVmaW5lZCAmJiB0eXBlb2YgZW5jb2RpbmcgIT09ICdzdHJpbmcnKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdlbmNvZGluZyBtdXN0IGJlIGEgc3RyaW5nJylcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBlbmNvZGluZyA9PT0gJ3N0cmluZycgJiYgIUJ1ZmZlci5pc0VuY29kaW5nKGVuY29kaW5nKSkge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignVW5rbm93biBlbmNvZGluZzogJyArIGVuY29kaW5nKVxuICAgIH1cbiAgICBpZiAodmFsLmxlbmd0aCA9PT0gMSkge1xuICAgICAgY29uc3QgY29kZSA9IHZhbC5jaGFyQ29kZUF0KDApXG4gICAgICBpZiAoKGVuY29kaW5nID09PSAndXRmOCcgJiYgY29kZSA8IDEyOCkgfHxcbiAgICAgICAgICBlbmNvZGluZyA9PT0gJ2xhdGluMScpIHtcbiAgICAgICAgLy8gRmFzdCBwYXRoOiBJZiBgdmFsYCBmaXRzIGludG8gYSBzaW5nbGUgYnl0ZSwgdXNlIHRoYXQgbnVtZXJpYyB2YWx1ZS5cbiAgICAgICAgdmFsID0gY29kZVxuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIGlmICh0eXBlb2YgdmFsID09PSAnbnVtYmVyJykge1xuICAgIHZhbCA9IHZhbCAmIDI1NVxuICB9IGVsc2UgaWYgKHR5cGVvZiB2YWwgPT09ICdib29sZWFuJykge1xuICAgIHZhbCA9IE51bWJlcih2YWwpXG4gIH1cblxuICAvLyBJbnZhbGlkIHJhbmdlcyBhcmUgbm90IHNldCB0byBhIGRlZmF1bHQsIHNvIGNhbiByYW5nZSBjaGVjayBlYXJseS5cbiAgaWYgKHN0YXJ0IDwgMCB8fCB0aGlzLmxlbmd0aCA8IHN0YXJ0IHx8IHRoaXMubGVuZ3RoIDwgZW5kKSB7XG4gICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ091dCBvZiByYW5nZSBpbmRleCcpXG4gIH1cblxuICBpZiAoZW5kIDw9IHN0YXJ0KSB7XG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIHN0YXJ0ID0gc3RhcnQgPj4+IDBcbiAgZW5kID0gZW5kID09PSB1bmRlZmluZWQgPyB0aGlzLmxlbmd0aCA6IGVuZCA+Pj4gMFxuXG4gIGlmICghdmFsKSB2YWwgPSAwXG5cbiAgbGV0IGlcbiAgaWYgKHR5cGVvZiB2YWwgPT09ICdudW1iZXInKSB7XG4gICAgZm9yIChpID0gc3RhcnQ7IGkgPCBlbmQ7ICsraSkge1xuICAgICAgdGhpc1tpXSA9IHZhbFxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBjb25zdCBieXRlcyA9IEJ1ZmZlci5pc0J1ZmZlcih2YWwpXG4gICAgICA/IHZhbFxuICAgICAgOiBCdWZmZXIuZnJvbSh2YWwsIGVuY29kaW5nKVxuICAgIGNvbnN0IGxlbiA9IGJ5dGVzLmxlbmd0aFxuICAgIGlmIChsZW4gPT09IDApIHtcbiAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1RoZSB2YWx1ZSBcIicgKyB2YWwgK1xuICAgICAgICAnXCIgaXMgaW52YWxpZCBmb3IgYXJndW1lbnQgXCJ2YWx1ZVwiJylcbiAgICB9XG4gICAgZm9yIChpID0gMDsgaSA8IGVuZCAtIHN0YXJ0OyArK2kpIHtcbiAgICAgIHRoaXNbaSArIHN0YXJ0XSA9IGJ5dGVzW2kgJSBsZW5dXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHRoaXNcbn1cblxuLy8gQ1VTVE9NIEVSUk9SU1xuLy8gPT09PT09PT09PT09PVxuXG4vLyBTaW1wbGlmaWVkIHZlcnNpb25zIGZyb20gTm9kZSwgY2hhbmdlZCBmb3IgQnVmZmVyLW9ubHkgdXNhZ2VcbmNvbnN0IGVycm9ycyA9IHt9XG5mdW5jdGlvbiBFIChzeW0sIGdldE1lc3NhZ2UsIEJhc2UpIHtcbiAgZXJyb3JzW3N5bV0gPSBjbGFzcyBOb2RlRXJyb3IgZXh0ZW5kcyBCYXNlIHtcbiAgICBjb25zdHJ1Y3RvciAoKSB7XG4gICAgICBzdXBlcigpXG5cbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCAnbWVzc2FnZScsIHtcbiAgICAgICAgdmFsdWU6IGdldE1lc3NhZ2UuYXBwbHkodGhpcywgYXJndW1lbnRzKSxcbiAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZVxuICAgICAgfSlcblxuICAgICAgLy8gQWRkIHRoZSBlcnJvciBjb2RlIHRvIHRoZSBuYW1lIHRvIGluY2x1ZGUgaXQgaW4gdGhlIHN0YWNrIHRyYWNlLlxuICAgICAgdGhpcy5uYW1lID0gYCR7dGhpcy5uYW1lfSBbJHtzeW19XWBcbiAgICAgIC8vIEFjY2VzcyB0aGUgc3RhY2sgdG8gZ2VuZXJhdGUgdGhlIGVycm9yIG1lc3NhZ2UgaW5jbHVkaW5nIHRoZSBlcnJvciBjb2RlXG4gICAgICAvLyBmcm9tIHRoZSBuYW1lLlxuICAgICAgdGhpcy5zdGFjayAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXVudXNlZC1leHByZXNzaW9uc1xuICAgICAgLy8gUmVzZXQgdGhlIG5hbWUgdG8gdGhlIGFjdHVhbCBuYW1lLlxuICAgICAgZGVsZXRlIHRoaXMubmFtZVxuICAgIH1cblxuICAgIGdldCBjb2RlICgpIHtcbiAgICAgIHJldHVybiBzeW1cbiAgICB9XG5cbiAgICBzZXQgY29kZSAodmFsdWUpIHtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0aGlzLCAnY29kZScsIHtcbiAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICB2YWx1ZSxcbiAgICAgICAgd3JpdGFibGU6IHRydWVcbiAgICAgIH0pXG4gICAgfVxuXG4gICAgdG9TdHJpbmcgKCkge1xuICAgICAgcmV0dXJuIGAke3RoaXMubmFtZX0gWyR7c3ltfV06ICR7dGhpcy5tZXNzYWdlfWBcbiAgICB9XG4gIH1cbn1cblxuRSgnRVJSX0JVRkZFUl9PVVRfT0ZfQk9VTkRTJyxcbiAgZnVuY3Rpb24gKG5hbWUpIHtcbiAgICBpZiAobmFtZSkge1xuICAgICAgcmV0dXJuIGAke25hbWV9IGlzIG91dHNpZGUgb2YgYnVmZmVyIGJvdW5kc2BcbiAgICB9XG5cbiAgICByZXR1cm4gJ0F0dGVtcHQgdG8gYWNjZXNzIG1lbW9yeSBvdXRzaWRlIGJ1ZmZlciBib3VuZHMnXG4gIH0sIFJhbmdlRXJyb3IpXG5FKCdFUlJfSU5WQUxJRF9BUkdfVFlQRScsXG4gIGZ1bmN0aW9uIChuYW1lLCBhY3R1YWwpIHtcbiAgICByZXR1cm4gYFRoZSBcIiR7bmFtZX1cIiBhcmd1bWVudCBtdXN0IGJlIG9mIHR5cGUgbnVtYmVyLiBSZWNlaXZlZCB0eXBlICR7dHlwZW9mIGFjdHVhbH1gXG4gIH0sIFR5cGVFcnJvcilcbkUoJ0VSUl9PVVRfT0ZfUkFOR0UnLFxuICBmdW5jdGlvbiAoc3RyLCByYW5nZSwgaW5wdXQpIHtcbiAgICBsZXQgbXNnID0gYFRoZSB2YWx1ZSBvZiBcIiR7c3RyfVwiIGlzIG91dCBvZiByYW5nZS5gXG4gICAgbGV0IHJlY2VpdmVkID0gaW5wdXRcbiAgICBpZiAoTnVtYmVyLmlzSW50ZWdlcihpbnB1dCkgJiYgTWF0aC5hYnMoaW5wdXQpID4gMiAqKiAzMikge1xuICAgICAgcmVjZWl2ZWQgPSBhZGROdW1lcmljYWxTZXBhcmF0b3IoU3RyaW5nKGlucHV0KSlcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBpbnB1dCA9PT0gJ2JpZ2ludCcpIHtcbiAgICAgIHJlY2VpdmVkID0gU3RyaW5nKGlucHV0KVxuICAgICAgaWYgKGlucHV0ID4gQmlnSW50KDIpICoqIEJpZ0ludCgzMikgfHwgaW5wdXQgPCAtKEJpZ0ludCgyKSAqKiBCaWdJbnQoMzIpKSkge1xuICAgICAgICByZWNlaXZlZCA9IGFkZE51bWVyaWNhbFNlcGFyYXRvcihyZWNlaXZlZClcbiAgICAgIH1cbiAgICAgIHJlY2VpdmVkICs9ICduJ1xuICAgIH1cbiAgICBtc2cgKz0gYCBJdCBtdXN0IGJlICR7cmFuZ2V9LiBSZWNlaXZlZCAke3JlY2VpdmVkfWBcbiAgICByZXR1cm4gbXNnXG4gIH0sIFJhbmdlRXJyb3IpXG5cbmZ1bmN0aW9uIGFkZE51bWVyaWNhbFNlcGFyYXRvciAodmFsKSB7XG4gIGxldCByZXMgPSAnJ1xuICBsZXQgaSA9IHZhbC5sZW5ndGhcbiAgY29uc3Qgc3RhcnQgPSB2YWxbMF0gPT09ICctJyA/IDEgOiAwXG4gIGZvciAoOyBpID49IHN0YXJ0ICsgNDsgaSAtPSAzKSB7XG4gICAgcmVzID0gYF8ke3ZhbC5zbGljZShpIC0gMywgaSl9JHtyZXN9YFxuICB9XG4gIHJldHVybiBgJHt2YWwuc2xpY2UoMCwgaSl9JHtyZXN9YFxufVxuXG4vLyBDSEVDSyBGVU5DVElPTlNcbi8vID09PT09PT09PT09PT09PVxuXG5mdW5jdGlvbiBjaGVja0JvdW5kcyAoYnVmLCBvZmZzZXQsIGJ5dGVMZW5ndGgpIHtcbiAgdmFsaWRhdGVOdW1iZXIob2Zmc2V0LCAnb2Zmc2V0JylcbiAgaWYgKGJ1ZltvZmZzZXRdID09PSB1bmRlZmluZWQgfHwgYnVmW29mZnNldCArIGJ5dGVMZW5ndGhdID09PSB1bmRlZmluZWQpIHtcbiAgICBib3VuZHNFcnJvcihvZmZzZXQsIGJ1Zi5sZW5ndGggLSAoYnl0ZUxlbmd0aCArIDEpKVxuICB9XG59XG5cbmZ1bmN0aW9uIGNoZWNrSW50QkkgKHZhbHVlLCBtaW4sIG1heCwgYnVmLCBvZmZzZXQsIGJ5dGVMZW5ndGgpIHtcbiAgaWYgKHZhbHVlID4gbWF4IHx8IHZhbHVlIDwgbWluKSB7XG4gICAgY29uc3QgbiA9IHR5cGVvZiBtaW4gPT09ICdiaWdpbnQnID8gJ24nIDogJydcbiAgICBsZXQgcmFuZ2VcbiAgICBpZiAoYnl0ZUxlbmd0aCA+IDMpIHtcbiAgICAgIGlmIChtaW4gPT09IDAgfHwgbWluID09PSBCaWdJbnQoMCkpIHtcbiAgICAgICAgcmFuZ2UgPSBgPj0gMCR7bn0gYW5kIDwgMiR7bn0gKiogJHsoYnl0ZUxlbmd0aCArIDEpICogOH0ke259YFxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmFuZ2UgPSBgPj0gLSgyJHtufSAqKiAkeyhieXRlTGVuZ3RoICsgMSkgKiA4IC0gMX0ke259KSBhbmQgPCAyICoqIGAgK1xuICAgICAgICAgICAgICAgIGAkeyhieXRlTGVuZ3RoICsgMSkgKiA4IC0gMX0ke259YFxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICByYW5nZSA9IGA+PSAke21pbn0ke259IGFuZCA8PSAke21heH0ke259YFxuICAgIH1cbiAgICB0aHJvdyBuZXcgZXJyb3JzLkVSUl9PVVRfT0ZfUkFOR0UoJ3ZhbHVlJywgcmFuZ2UsIHZhbHVlKVxuICB9XG4gIGNoZWNrQm91bmRzKGJ1Ziwgb2Zmc2V0LCBieXRlTGVuZ3RoKVxufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZU51bWJlciAodmFsdWUsIG5hbWUpIHtcbiAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ251bWJlcicpIHtcbiAgICB0aHJvdyBuZXcgZXJyb3JzLkVSUl9JTlZBTElEX0FSR19UWVBFKG5hbWUsICdudW1iZXInLCB2YWx1ZSlcbiAgfVxufVxuXG5mdW5jdGlvbiBib3VuZHNFcnJvciAodmFsdWUsIGxlbmd0aCwgdHlwZSkge1xuICBpZiAoTWF0aC5mbG9vcih2YWx1ZSkgIT09IHZhbHVlKSB7XG4gICAgdmFsaWRhdGVOdW1iZXIodmFsdWUsIHR5cGUpXG4gICAgdGhyb3cgbmV3IGVycm9ycy5FUlJfT1VUX09GX1JBTkdFKHR5cGUgfHwgJ29mZnNldCcsICdhbiBpbnRlZ2VyJywgdmFsdWUpXG4gIH1cblxuICBpZiAobGVuZ3RoIDwgMCkge1xuICAgIHRocm93IG5ldyBlcnJvcnMuRVJSX0JVRkZFUl9PVVRfT0ZfQk9VTkRTKClcbiAgfVxuXG4gIHRocm93IG5ldyBlcnJvcnMuRVJSX09VVF9PRl9SQU5HRSh0eXBlIHx8ICdvZmZzZXQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYD49ICR7dHlwZSA/IDEgOiAwfSBhbmQgPD0gJHtsZW5ndGh9YCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlKVxufVxuXG4vLyBIRUxQRVIgRlVOQ1RJT05TXG4vLyA9PT09PT09PT09PT09PT09XG5cbmNvbnN0IElOVkFMSURfQkFTRTY0X1JFID0gL1teKy8wLTlBLVphLXotX10vZ1xuXG5mdW5jdGlvbiBiYXNlNjRjbGVhbiAoc3RyKSB7XG4gIC8vIE5vZGUgdGFrZXMgZXF1YWwgc2lnbnMgYXMgZW5kIG9mIHRoZSBCYXNlNjQgZW5jb2RpbmdcbiAgc3RyID0gc3RyLnNwbGl0KCc9JylbMF1cbiAgLy8gTm9kZSBzdHJpcHMgb3V0IGludmFsaWQgY2hhcmFjdGVycyBsaWtlIFxcbiBhbmQgXFx0IGZyb20gdGhlIHN0cmluZywgYmFzZTY0LWpzIGRvZXMgbm90XG4gIHN0ciA9IHN0ci50cmltKCkucmVwbGFjZShJTlZBTElEX0JBU0U2NF9SRSwgJycpXG4gIC8vIE5vZGUgY29udmVydHMgc3RyaW5ncyB3aXRoIGxlbmd0aCA8IDIgdG8gJydcbiAgaWYgKHN0ci5sZW5ndGggPCAyKSByZXR1cm4gJydcbiAgLy8gTm9kZSBhbGxvd3MgZm9yIG5vbi1wYWRkZWQgYmFzZTY0IHN0cmluZ3MgKG1pc3NpbmcgdHJhaWxpbmcgPT09KSwgYmFzZTY0LWpzIGRvZXMgbm90XG4gIHdoaWxlIChzdHIubGVuZ3RoICUgNCAhPT0gMCkge1xuICAgIHN0ciA9IHN0ciArICc9J1xuICB9XG4gIHJldHVybiBzdHJcbn1cblxuZnVuY3Rpb24gdXRmOFRvQnl0ZXMgKHN0cmluZywgdW5pdHMpIHtcbiAgdW5pdHMgPSB1bml0cyB8fCBJbmZpbml0eVxuICBsZXQgY29kZVBvaW50XG4gIGNvbnN0IGxlbmd0aCA9IHN0cmluZy5sZW5ndGhcbiAgbGV0IGxlYWRTdXJyb2dhdGUgPSBudWxsXG4gIGNvbnN0IGJ5dGVzID0gW11cblxuICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbmd0aDsgKytpKSB7XG4gICAgY29kZVBvaW50ID0gc3RyaW5nLmNoYXJDb2RlQXQoaSlcblxuICAgIC8vIGlzIHN1cnJvZ2F0ZSBjb21wb25lbnRcbiAgICBpZiAoY29kZVBvaW50ID4gMHhEN0ZGICYmIGNvZGVQb2ludCA8IDB4RTAwMCkge1xuICAgICAgLy8gbGFzdCBjaGFyIHdhcyBhIGxlYWRcbiAgICAgIGlmICghbGVhZFN1cnJvZ2F0ZSkge1xuICAgICAgICAvLyBubyBsZWFkIHlldFxuICAgICAgICBpZiAoY29kZVBvaW50ID4gMHhEQkZGKSB7XG4gICAgICAgICAgLy8gdW5leHBlY3RlZCB0cmFpbFxuICAgICAgICAgIGlmICgodW5pdHMgLT0gMykgPiAtMSkgYnl0ZXMucHVzaCgweEVGLCAweEJGLCAweEJEKVxuICAgICAgICAgIGNvbnRpbnVlXG4gICAgICAgIH0gZWxzZSBpZiAoaSArIDEgPT09IGxlbmd0aCkge1xuICAgICAgICAgIC8vIHVucGFpcmVkIGxlYWRcbiAgICAgICAgICBpZiAoKHVuaXRzIC09IDMpID4gLTEpIGJ5dGVzLnB1c2goMHhFRiwgMHhCRiwgMHhCRClcbiAgICAgICAgICBjb250aW51ZVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gdmFsaWQgbGVhZFxuICAgICAgICBsZWFkU3Vycm9nYXRlID0gY29kZVBvaW50XG5cbiAgICAgICAgY29udGludWVcbiAgICAgIH1cblxuICAgICAgLy8gMiBsZWFkcyBpbiBhIHJvd1xuICAgICAgaWYgKGNvZGVQb2ludCA8IDB4REMwMCkge1xuICAgICAgICBpZiAoKHVuaXRzIC09IDMpID4gLTEpIGJ5dGVzLnB1c2goMHhFRiwgMHhCRiwgMHhCRClcbiAgICAgICAgbGVhZFN1cnJvZ2F0ZSA9IGNvZGVQb2ludFxuICAgICAgICBjb250aW51ZVxuICAgICAgfVxuXG4gICAgICAvLyB2YWxpZCBzdXJyb2dhdGUgcGFpclxuICAgICAgY29kZVBvaW50ID0gKGxlYWRTdXJyb2dhdGUgLSAweEQ4MDAgPDwgMTAgfCBjb2RlUG9pbnQgLSAweERDMDApICsgMHgxMDAwMFxuICAgIH0gZWxzZSBpZiAobGVhZFN1cnJvZ2F0ZSkge1xuICAgICAgLy8gdmFsaWQgYm1wIGNoYXIsIGJ1dCBsYXN0IGNoYXIgd2FzIGEgbGVhZFxuICAgICAgaWYgKCh1bml0cyAtPSAzKSA+IC0xKSBieXRlcy5wdXNoKDB4RUYsIDB4QkYsIDB4QkQpXG4gICAgfVxuXG4gICAgbGVhZFN1cnJvZ2F0ZSA9IG51bGxcblxuICAgIC8vIGVuY29kZSB1dGY4XG4gICAgaWYgKGNvZGVQb2ludCA8IDB4ODApIHtcbiAgICAgIGlmICgodW5pdHMgLT0gMSkgPCAwKSBicmVha1xuICAgICAgYnl0ZXMucHVzaChjb2RlUG9pbnQpXG4gICAgfSBlbHNlIGlmIChjb2RlUG9pbnQgPCAweDgwMCkge1xuICAgICAgaWYgKCh1bml0cyAtPSAyKSA8IDApIGJyZWFrXG4gICAgICBieXRlcy5wdXNoKFxuICAgICAgICBjb2RlUG9pbnQgPj4gMHg2IHwgMHhDMCxcbiAgICAgICAgY29kZVBvaW50ICYgMHgzRiB8IDB4ODBcbiAgICAgIClcbiAgICB9IGVsc2UgaWYgKGNvZGVQb2ludCA8IDB4MTAwMDApIHtcbiAgICAgIGlmICgodW5pdHMgLT0gMykgPCAwKSBicmVha1xuICAgICAgYnl0ZXMucHVzaChcbiAgICAgICAgY29kZVBvaW50ID4+IDB4QyB8IDB4RTAsXG4gICAgICAgIGNvZGVQb2ludCA+PiAweDYgJiAweDNGIHwgMHg4MCxcbiAgICAgICAgY29kZVBvaW50ICYgMHgzRiB8IDB4ODBcbiAgICAgIClcbiAgICB9IGVsc2UgaWYgKGNvZGVQb2ludCA8IDB4MTEwMDAwKSB7XG4gICAgICBpZiAoKHVuaXRzIC09IDQpIDwgMCkgYnJlYWtcbiAgICAgIGJ5dGVzLnB1c2goXG4gICAgICAgIGNvZGVQb2ludCA+PiAweDEyIHwgMHhGMCxcbiAgICAgICAgY29kZVBvaW50ID4+IDB4QyAmIDB4M0YgfCAweDgwLFxuICAgICAgICBjb2RlUG9pbnQgPj4gMHg2ICYgMHgzRiB8IDB4ODAsXG4gICAgICAgIGNvZGVQb2ludCAmIDB4M0YgfCAweDgwXG4gICAgICApXG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBjb2RlIHBvaW50JylcbiAgICB9XG4gIH1cblxuICByZXR1cm4gYnl0ZXNcbn1cblxuZnVuY3Rpb24gYXNjaWlUb0J5dGVzIChzdHIpIHtcbiAgY29uc3QgYnl0ZUFycmF5ID0gW11cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdHIubGVuZ3RoOyArK2kpIHtcbiAgICAvLyBOb2RlJ3MgY29kZSBzZWVtcyB0byBiZSBkb2luZyB0aGlzIGFuZCBub3QgJiAweDdGLi5cbiAgICBieXRlQXJyYXkucHVzaChzdHIuY2hhckNvZGVBdChpKSAmIDB4RkYpXG4gIH1cbiAgcmV0dXJuIGJ5dGVBcnJheVxufVxuXG5mdW5jdGlvbiB1dGYxNmxlVG9CeXRlcyAoc3RyLCB1bml0cykge1xuICBsZXQgYywgaGksIGxvXG4gIGNvbnN0IGJ5dGVBcnJheSA9IFtdXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgc3RyLmxlbmd0aDsgKytpKSB7XG4gICAgaWYgKCh1bml0cyAtPSAyKSA8IDApIGJyZWFrXG5cbiAgICBjID0gc3RyLmNoYXJDb2RlQXQoaSlcbiAgICBoaSA9IGMgPj4gOFxuICAgIGxvID0gYyAlIDI1NlxuICAgIGJ5dGVBcnJheS5wdXNoKGxvKVxuICAgIGJ5dGVBcnJheS5wdXNoKGhpKVxuICB9XG5cbiAgcmV0dXJuIGJ5dGVBcnJheVxufVxuXG5mdW5jdGlvbiBiYXNlNjRUb0J5dGVzIChzdHIpIHtcbiAgcmV0dXJuIGJhc2U2NC50b0J5dGVBcnJheShiYXNlNjRjbGVhbihzdHIpKVxufVxuXG5mdW5jdGlvbiBibGl0QnVmZmVyIChzcmMsIGRzdCwgb2Zmc2V0LCBsZW5ndGgpIHtcbiAgbGV0IGlcbiAgZm9yIChpID0gMDsgaSA8IGxlbmd0aDsgKytpKSB7XG4gICAgaWYgKChpICsgb2Zmc2V0ID49IGRzdC5sZW5ndGgpIHx8IChpID49IHNyYy5sZW5ndGgpKSBicmVha1xuICAgIGRzdFtpICsgb2Zmc2V0XSA9IHNyY1tpXVxuICB9XG4gIHJldHVybiBpXG59XG5cbi8vIEFycmF5QnVmZmVyIG9yIFVpbnQ4QXJyYXkgb2JqZWN0cyBmcm9tIG90aGVyIGNvbnRleHRzIChpLmUuIGlmcmFtZXMpIGRvIG5vdCBwYXNzXG4vLyB0aGUgYGluc3RhbmNlb2ZgIGNoZWNrIGJ1dCB0aGV5IHNob3VsZCBiZSB0cmVhdGVkIGFzIG9mIHRoYXQgdHlwZS5cbi8vIFNlZTogaHR0cHM6Ly9naXRodWIuY29tL2Zlcm9zcy9idWZmZXIvaXNzdWVzLzE2NlxuZnVuY3Rpb24gaXNJbnN0YW5jZSAob2JqLCB0eXBlKSB7XG4gIHJldHVybiBvYmogaW5zdGFuY2VvZiB0eXBlIHx8XG4gICAgKG9iaiAhPSBudWxsICYmIG9iai5jb25zdHJ1Y3RvciAhPSBudWxsICYmIG9iai5jb25zdHJ1Y3Rvci5uYW1lICE9IG51bGwgJiZcbiAgICAgIG9iai5jb25zdHJ1Y3Rvci5uYW1lID09PSB0eXBlLm5hbWUpXG59XG5mdW5jdGlvbiBudW1iZXJJc05hTiAob2JqKSB7XG4gIC8vIEZvciBJRTExIHN1cHBvcnRcbiAgcmV0dXJuIG9iaiAhPT0gb2JqIC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tc2VsZi1jb21wYXJlXG59XG5cbi8vIENyZWF0ZSBsb29rdXAgdGFibGUgZm9yIGB0b1N0cmluZygnaGV4JylgXG4vLyBTZWU6IGh0dHBzOi8vZ2l0aHViLmNvbS9mZXJvc3MvYnVmZmVyL2lzc3Vlcy8yMTlcbmNvbnN0IGhleFNsaWNlTG9va3VwVGFibGUgPSAoZnVuY3Rpb24gKCkge1xuICBjb25zdCBhbHBoYWJldCA9ICcwMTIzNDU2Nzg5YWJjZGVmJ1xuICBjb25zdCB0YWJsZSA9IG5ldyBBcnJheSgyNTYpXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgMTY7ICsraSkge1xuICAgIGNvbnN0IGkxNiA9IGkgKiAxNlxuICAgIGZvciAobGV0IGogPSAwOyBqIDwgMTY7ICsraikge1xuICAgICAgdGFibGVbaTE2ICsgal0gPSBhbHBoYWJldFtpXSArIGFscGhhYmV0W2pdXG4gICAgfVxuICB9XG4gIHJldHVybiB0YWJsZVxufSkoKVxuXG4vLyBSZXR1cm4gbm90IGZ1bmN0aW9uIHdpdGggRXJyb3IgaWYgQmlnSW50IG5vdCBzdXBwb3J0ZWRcbmZ1bmN0aW9uIGRlZmluZUJpZ0ludE1ldGhvZCAoZm4pIHtcbiAgcmV0dXJuIHR5cGVvZiBCaWdJbnQgPT09ICd1bmRlZmluZWQnID8gQnVmZmVyQmlnSW50Tm90RGVmaW5lZCA6IGZuXG59XG5cbmZ1bmN0aW9uIEJ1ZmZlckJpZ0ludE5vdERlZmluZWQgKCkge1xuICB0aHJvdyBuZXcgRXJyb3IoJ0JpZ0ludCBub3Qgc3VwcG9ydGVkJylcbn1cbiIsIid1c2Ugc3RyaWN0J1xuXG5leHBvcnRzLmJ5dGVMZW5ndGggPSBieXRlTGVuZ3RoXG5leHBvcnRzLnRvQnl0ZUFycmF5ID0gdG9CeXRlQXJyYXlcbmV4cG9ydHMuZnJvbUJ5dGVBcnJheSA9IGZyb21CeXRlQXJyYXlcblxudmFyIGxvb2t1cCA9IFtdXG52YXIgcmV2TG9va3VwID0gW11cbnZhciBBcnIgPSB0eXBlb2YgVWludDhBcnJheSAhPT0gJ3VuZGVmaW5lZCcgPyBVaW50OEFycmF5IDogQXJyYXlcblxudmFyIGNvZGUgPSAnQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLydcbmZvciAodmFyIGkgPSAwLCBsZW4gPSBjb2RlLmxlbmd0aDsgaSA8IGxlbjsgKytpKSB7XG4gIGxvb2t1cFtpXSA9IGNvZGVbaV1cbiAgcmV2TG9va3VwW2NvZGUuY2hhckNvZGVBdChpKV0gPSBpXG59XG5cbi8vIFN1cHBvcnQgZGVjb2RpbmcgVVJMLXNhZmUgYmFzZTY0IHN0cmluZ3MsIGFzIE5vZGUuanMgZG9lcy5cbi8vIFNlZTogaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvQmFzZTY0I1VSTF9hcHBsaWNhdGlvbnNcbnJldkxvb2t1cFsnLScuY2hhckNvZGVBdCgwKV0gPSA2MlxucmV2TG9va3VwWydfJy5jaGFyQ29kZUF0KDApXSA9IDYzXG5cbmZ1bmN0aW9uIGdldExlbnMgKGI2NCkge1xuICB2YXIgbGVuID0gYjY0Lmxlbmd0aFxuXG4gIGlmIChsZW4gJSA0ID4gMCkge1xuICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBzdHJpbmcuIExlbmd0aCBtdXN0IGJlIGEgbXVsdGlwbGUgb2YgNCcpXG4gIH1cblxuICAvLyBUcmltIG9mZiBleHRyYSBieXRlcyBhZnRlciBwbGFjZWhvbGRlciBieXRlcyBhcmUgZm91bmRcbiAgLy8gU2VlOiBodHRwczovL2dpdGh1Yi5jb20vYmVhdGdhbW1pdC9iYXNlNjQtanMvaXNzdWVzLzQyXG4gIHZhciB2YWxpZExlbiA9IGI2NC5pbmRleE9mKCc9JylcbiAgaWYgKHZhbGlkTGVuID09PSAtMSkgdmFsaWRMZW4gPSBsZW5cblxuICB2YXIgcGxhY2VIb2xkZXJzTGVuID0gdmFsaWRMZW4gPT09IGxlblxuICAgID8gMFxuICAgIDogNCAtICh2YWxpZExlbiAlIDQpXG5cbiAgcmV0dXJuIFt2YWxpZExlbiwgcGxhY2VIb2xkZXJzTGVuXVxufVxuXG4vLyBiYXNlNjQgaXMgNC8zICsgdXAgdG8gdHdvIGNoYXJhY3RlcnMgb2YgdGhlIG9yaWdpbmFsIGRhdGFcbmZ1bmN0aW9uIGJ5dGVMZW5ndGggKGI2NCkge1xuICB2YXIgbGVucyA9IGdldExlbnMoYjY0KVxuICB2YXIgdmFsaWRMZW4gPSBsZW5zWzBdXG4gIHZhciBwbGFjZUhvbGRlcnNMZW4gPSBsZW5zWzFdXG4gIHJldHVybiAoKHZhbGlkTGVuICsgcGxhY2VIb2xkZXJzTGVuKSAqIDMgLyA0KSAtIHBsYWNlSG9sZGVyc0xlblxufVxuXG5mdW5jdGlvbiBfYnl0ZUxlbmd0aCAoYjY0LCB2YWxpZExlbiwgcGxhY2VIb2xkZXJzTGVuKSB7XG4gIHJldHVybiAoKHZhbGlkTGVuICsgcGxhY2VIb2xkZXJzTGVuKSAqIDMgLyA0KSAtIHBsYWNlSG9sZGVyc0xlblxufVxuXG5mdW5jdGlvbiB0b0J5dGVBcnJheSAoYjY0KSB7XG4gIHZhciB0bXBcbiAgdmFyIGxlbnMgPSBnZXRMZW5zKGI2NClcbiAgdmFyIHZhbGlkTGVuID0gbGVuc1swXVxuICB2YXIgcGxhY2VIb2xkZXJzTGVuID0gbGVuc1sxXVxuXG4gIHZhciBhcnIgPSBuZXcgQXJyKF9ieXRlTGVuZ3RoKGI2NCwgdmFsaWRMZW4sIHBsYWNlSG9sZGVyc0xlbikpXG5cbiAgdmFyIGN1ckJ5dGUgPSAwXG5cbiAgLy8gaWYgdGhlcmUgYXJlIHBsYWNlaG9sZGVycywgb25seSBnZXQgdXAgdG8gdGhlIGxhc3QgY29tcGxldGUgNCBjaGFyc1xuICB2YXIgbGVuID0gcGxhY2VIb2xkZXJzTGVuID4gMFxuICAgID8gdmFsaWRMZW4gLSA0XG4gICAgOiB2YWxpZExlblxuXG4gIHZhciBpXG4gIGZvciAoaSA9IDA7IGkgPCBsZW47IGkgKz0gNCkge1xuICAgIHRtcCA9XG4gICAgICAocmV2TG9va3VwW2I2NC5jaGFyQ29kZUF0KGkpXSA8PCAxOCkgfFxuICAgICAgKHJldkxvb2t1cFtiNjQuY2hhckNvZGVBdChpICsgMSldIDw8IDEyKSB8XG4gICAgICAocmV2TG9va3VwW2I2NC5jaGFyQ29kZUF0KGkgKyAyKV0gPDwgNikgfFxuICAgICAgcmV2TG9va3VwW2I2NC5jaGFyQ29kZUF0KGkgKyAzKV1cbiAgICBhcnJbY3VyQnl0ZSsrXSA9ICh0bXAgPj4gMTYpICYgMHhGRlxuICAgIGFycltjdXJCeXRlKytdID0gKHRtcCA+PiA4KSAmIDB4RkZcbiAgICBhcnJbY3VyQnl0ZSsrXSA9IHRtcCAmIDB4RkZcbiAgfVxuXG4gIGlmIChwbGFjZUhvbGRlcnNMZW4gPT09IDIpIHtcbiAgICB0bXAgPVxuICAgICAgKHJldkxvb2t1cFtiNjQuY2hhckNvZGVBdChpKV0gPDwgMikgfFxuICAgICAgKHJldkxvb2t1cFtiNjQuY2hhckNvZGVBdChpICsgMSldID4+IDQpXG4gICAgYXJyW2N1ckJ5dGUrK10gPSB0bXAgJiAweEZGXG4gIH1cblxuICBpZiAocGxhY2VIb2xkZXJzTGVuID09PSAxKSB7XG4gICAgdG1wID1cbiAgICAgIChyZXZMb29rdXBbYjY0LmNoYXJDb2RlQXQoaSldIDw8IDEwKSB8XG4gICAgICAocmV2TG9va3VwW2I2NC5jaGFyQ29kZUF0KGkgKyAxKV0gPDwgNCkgfFxuICAgICAgKHJldkxvb2t1cFtiNjQuY2hhckNvZGVBdChpICsgMildID4+IDIpXG4gICAgYXJyW2N1ckJ5dGUrK10gPSAodG1wID4+IDgpICYgMHhGRlxuICAgIGFycltjdXJCeXRlKytdID0gdG1wICYgMHhGRlxuICB9XG5cbiAgcmV0dXJuIGFyclxufVxuXG5mdW5jdGlvbiB0cmlwbGV0VG9CYXNlNjQgKG51bSkge1xuICByZXR1cm4gbG9va3VwW251bSA+PiAxOCAmIDB4M0ZdICtcbiAgICBsb29rdXBbbnVtID4+IDEyICYgMHgzRl0gK1xuICAgIGxvb2t1cFtudW0gPj4gNiAmIDB4M0ZdICtcbiAgICBsb29rdXBbbnVtICYgMHgzRl1cbn1cblxuZnVuY3Rpb24gZW5jb2RlQ2h1bmsgKHVpbnQ4LCBzdGFydCwgZW5kKSB7XG4gIHZhciB0bXBcbiAgdmFyIG91dHB1dCA9IFtdXG4gIGZvciAodmFyIGkgPSBzdGFydDsgaSA8IGVuZDsgaSArPSAzKSB7XG4gICAgdG1wID1cbiAgICAgICgodWludDhbaV0gPDwgMTYpICYgMHhGRjAwMDApICtcbiAgICAgICgodWludDhbaSArIDFdIDw8IDgpICYgMHhGRjAwKSArXG4gICAgICAodWludDhbaSArIDJdICYgMHhGRilcbiAgICBvdXRwdXQucHVzaCh0cmlwbGV0VG9CYXNlNjQodG1wKSlcbiAgfVxuICByZXR1cm4gb3V0cHV0LmpvaW4oJycpXG59XG5cbmZ1bmN0aW9uIGZyb21CeXRlQXJyYXkgKHVpbnQ4KSB7XG4gIHZhciB0bXBcbiAgdmFyIGxlbiA9IHVpbnQ4Lmxlbmd0aFxuICB2YXIgZXh0cmFCeXRlcyA9IGxlbiAlIDMgLy8gaWYgd2UgaGF2ZSAxIGJ5dGUgbGVmdCwgcGFkIDIgYnl0ZXNcbiAgdmFyIHBhcnRzID0gW11cbiAgdmFyIG1heENodW5rTGVuZ3RoID0gMTYzODMgLy8gbXVzdCBiZSBtdWx0aXBsZSBvZiAzXG5cbiAgLy8gZ28gdGhyb3VnaCB0aGUgYXJyYXkgZXZlcnkgdGhyZWUgYnl0ZXMsIHdlJ2xsIGRlYWwgd2l0aCB0cmFpbGluZyBzdHVmZiBsYXRlclxuICBmb3IgKHZhciBpID0gMCwgbGVuMiA9IGxlbiAtIGV4dHJhQnl0ZXM7IGkgPCBsZW4yOyBpICs9IG1heENodW5rTGVuZ3RoKSB7XG4gICAgcGFydHMucHVzaChlbmNvZGVDaHVuayh1aW50OCwgaSwgKGkgKyBtYXhDaHVua0xlbmd0aCkgPiBsZW4yID8gbGVuMiA6IChpICsgbWF4Q2h1bmtMZW5ndGgpKSlcbiAgfVxuXG4gIC8vIHBhZCB0aGUgZW5kIHdpdGggemVyb3MsIGJ1dCBtYWtlIHN1cmUgdG8gbm90IGZvcmdldCB0aGUgZXh0cmEgYnl0ZXNcbiAgaWYgKGV4dHJhQnl0ZXMgPT09IDEpIHtcbiAgICB0bXAgPSB1aW50OFtsZW4gLSAxXVxuICAgIHBhcnRzLnB1c2goXG4gICAgICBsb29rdXBbdG1wID4+IDJdICtcbiAgICAgIGxvb2t1cFsodG1wIDw8IDQpICYgMHgzRl0gK1xuICAgICAgJz09J1xuICAgIClcbiAgfSBlbHNlIGlmIChleHRyYUJ5dGVzID09PSAyKSB7XG4gICAgdG1wID0gKHVpbnQ4W2xlbiAtIDJdIDw8IDgpICsgdWludDhbbGVuIC0gMV1cbiAgICBwYXJ0cy5wdXNoKFxuICAgICAgbG9va3VwW3RtcCA+PiAxMF0gK1xuICAgICAgbG9va3VwWyh0bXAgPj4gNCkgJiAweDNGXSArXG4gICAgICBsb29rdXBbKHRtcCA8PCAyKSAmIDB4M0ZdICtcbiAgICAgICc9J1xuICAgIClcbiAgfVxuXG4gIHJldHVybiBwYXJ0cy5qb2luKCcnKVxufVxuIiwiLyohIGllZWU3NTQuIEJTRC0zLUNsYXVzZSBMaWNlbnNlLiBGZXJvc3MgQWJvdWtoYWRpamVoIDxodHRwczovL2Zlcm9zcy5vcmcvb3BlbnNvdXJjZT4gKi9cbmV4cG9ydHMucmVhZCA9IGZ1bmN0aW9uIChidWZmZXIsIG9mZnNldCwgaXNMRSwgbUxlbiwgbkJ5dGVzKSB7XG4gIHZhciBlLCBtXG4gIHZhciBlTGVuID0gKG5CeXRlcyAqIDgpIC0gbUxlbiAtIDFcbiAgdmFyIGVNYXggPSAoMSA8PCBlTGVuKSAtIDFcbiAgdmFyIGVCaWFzID0gZU1heCA+PiAxXG4gIHZhciBuQml0cyA9IC03XG4gIHZhciBpID0gaXNMRSA/IChuQnl0ZXMgLSAxKSA6IDBcbiAgdmFyIGQgPSBpc0xFID8gLTEgOiAxXG4gIHZhciBzID0gYnVmZmVyW29mZnNldCArIGldXG5cbiAgaSArPSBkXG5cbiAgZSA9IHMgJiAoKDEgPDwgKC1uQml0cykpIC0gMSlcbiAgcyA+Pj0gKC1uQml0cylcbiAgbkJpdHMgKz0gZUxlblxuICBmb3IgKDsgbkJpdHMgPiAwOyBlID0gKGUgKiAyNTYpICsgYnVmZmVyW29mZnNldCArIGldLCBpICs9IGQsIG5CaXRzIC09IDgpIHt9XG5cbiAgbSA9IGUgJiAoKDEgPDwgKC1uQml0cykpIC0gMSlcbiAgZSA+Pj0gKC1uQml0cylcbiAgbkJpdHMgKz0gbUxlblxuICBmb3IgKDsgbkJpdHMgPiAwOyBtID0gKG0gKiAyNTYpICsgYnVmZmVyW29mZnNldCArIGldLCBpICs9IGQsIG5CaXRzIC09IDgpIHt9XG5cbiAgaWYgKGUgPT09IDApIHtcbiAgICBlID0gMSAtIGVCaWFzXG4gIH0gZWxzZSBpZiAoZSA9PT0gZU1heCkge1xuICAgIHJldHVybiBtID8gTmFOIDogKChzID8gLTEgOiAxKSAqIEluZmluaXR5KVxuICB9IGVsc2Uge1xuICAgIG0gPSBtICsgTWF0aC5wb3coMiwgbUxlbilcbiAgICBlID0gZSAtIGVCaWFzXG4gIH1cbiAgcmV0dXJuIChzID8gLTEgOiAxKSAqIG0gKiBNYXRoLnBvdygyLCBlIC0gbUxlbilcbn1cblxuZXhwb3J0cy53cml0ZSA9IGZ1bmN0aW9uIChidWZmZXIsIHZhbHVlLCBvZmZzZXQsIGlzTEUsIG1MZW4sIG5CeXRlcykge1xuICB2YXIgZSwgbSwgY1xuICB2YXIgZUxlbiA9IChuQnl0ZXMgKiA4KSAtIG1MZW4gLSAxXG4gIHZhciBlTWF4ID0gKDEgPDwgZUxlbikgLSAxXG4gIHZhciBlQmlhcyA9IGVNYXggPj4gMVxuICB2YXIgcnQgPSAobUxlbiA9PT0gMjMgPyBNYXRoLnBvdygyLCAtMjQpIC0gTWF0aC5wb3coMiwgLTc3KSA6IDApXG4gIHZhciBpID0gaXNMRSA/IDAgOiAobkJ5dGVzIC0gMSlcbiAgdmFyIGQgPSBpc0xFID8gMSA6IC0xXG4gIHZhciBzID0gdmFsdWUgPCAwIHx8ICh2YWx1ZSA9PT0gMCAmJiAxIC8gdmFsdWUgPCAwKSA/IDEgOiAwXG5cbiAgdmFsdWUgPSBNYXRoLmFicyh2YWx1ZSlcblxuICBpZiAoaXNOYU4odmFsdWUpIHx8IHZhbHVlID09PSBJbmZpbml0eSkge1xuICAgIG0gPSBpc05hTih2YWx1ZSkgPyAxIDogMFxuICAgIGUgPSBlTWF4XG4gIH0gZWxzZSB7XG4gICAgZSA9IE1hdGguZmxvb3IoTWF0aC5sb2codmFsdWUpIC8gTWF0aC5MTjIpXG4gICAgaWYgKHZhbHVlICogKGMgPSBNYXRoLnBvdygyLCAtZSkpIDwgMSkge1xuICAgICAgZS0tXG4gICAgICBjICo9IDJcbiAgICB9XG4gICAgaWYgKGUgKyBlQmlhcyA+PSAxKSB7XG4gICAgICB2YWx1ZSArPSBydCAvIGNcbiAgICB9IGVsc2Uge1xuICAgICAgdmFsdWUgKz0gcnQgKiBNYXRoLnBvdygyLCAxIC0gZUJpYXMpXG4gICAgfVxuICAgIGlmICh2YWx1ZSAqIGMgPj0gMikge1xuICAgICAgZSsrXG4gICAgICBjIC89IDJcbiAgICB9XG5cbiAgICBpZiAoZSArIGVCaWFzID49IGVNYXgpIHtcbiAgICAgIG0gPSAwXG4gICAgICBlID0gZU1heFxuICAgIH0gZWxzZSBpZiAoZSArIGVCaWFzID49IDEpIHtcbiAgICAgIG0gPSAoKHZhbHVlICogYykgLSAxKSAqIE1hdGgucG93KDIsIG1MZW4pXG4gICAgICBlID0gZSArIGVCaWFzXG4gICAgfSBlbHNlIHtcbiAgICAgIG0gPSB2YWx1ZSAqIE1hdGgucG93KDIsIGVCaWFzIC0gMSkgKiBNYXRoLnBvdygyLCBtTGVuKVxuICAgICAgZSA9IDBcbiAgICB9XG4gIH1cblxuICBmb3IgKDsgbUxlbiA+PSA4OyBidWZmZXJbb2Zmc2V0ICsgaV0gPSBtICYgMHhmZiwgaSArPSBkLCBtIC89IDI1NiwgbUxlbiAtPSA4KSB7fVxuXG4gIGUgPSAoZSA8PCBtTGVuKSB8IG1cbiAgZUxlbiArPSBtTGVuXG4gIGZvciAoOyBlTGVuID4gMDsgYnVmZmVyW29mZnNldCArIGldID0gZSAmIDB4ZmYsIGkgKz0gZCwgZSAvPSAyNTYsIGVMZW4gLT0gOCkge31cblxuICBidWZmZXJbb2Zmc2V0ICsgaSAtIGRdIHw9IHMgKiAxMjhcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcblxuLyoqXG4gKiBDcmVhdGUgYW4gRXJyb3Igd2l0aCB0aGUgc3BlY2lmaWVkIG1lc3NhZ2UsIGNvbmZpZywgZXJyb3IgY29kZSwgcmVxdWVzdCBhbmQgcmVzcG9uc2UuXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IG1lc3NhZ2UgVGhlIGVycm9yIG1lc3NhZ2UuXG4gKiBAcGFyYW0ge3N0cmluZ30gW2NvZGVdIFRoZSBlcnJvciBjb2RlIChmb3IgZXhhbXBsZSwgJ0VDT05OQUJPUlRFRCcpLlxuICogQHBhcmFtIHtPYmplY3R9IFtjb25maWddIFRoZSBjb25maWcuXG4gKiBAcGFyYW0ge09iamVjdH0gW3JlcXVlc3RdIFRoZSByZXF1ZXN0LlxuICogQHBhcmFtIHtPYmplY3R9IFtyZXNwb25zZV0gVGhlIHJlc3BvbnNlLlxuICpcbiAqIEByZXR1cm5zIHtFcnJvcn0gVGhlIGNyZWF0ZWQgZXJyb3IuXG4gKi9cbmZ1bmN0aW9uIEF4aW9zRXJyb3IobWVzc2FnZSwgY29kZSwgY29uZmlnLCByZXF1ZXN0LCByZXNwb25zZSkge1xuICBFcnJvci5jYWxsKHRoaXMpO1xuXG4gIGlmIChFcnJvci5jYXB0dXJlU3RhY2tUcmFjZSkge1xuICAgIEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKHRoaXMsIHRoaXMuY29uc3RydWN0b3IpO1xuICB9IGVsc2Uge1xuICAgIHRoaXMuc3RhY2sgPSAobmV3IEVycm9yKCkpLnN0YWNrO1xuICB9XG5cbiAgdGhpcy5tZXNzYWdlID0gbWVzc2FnZTtcbiAgdGhpcy5uYW1lID0gJ0F4aW9zRXJyb3InO1xuICBjb2RlICYmICh0aGlzLmNvZGUgPSBjb2RlKTtcbiAgY29uZmlnICYmICh0aGlzLmNvbmZpZyA9IGNvbmZpZyk7XG4gIHJlcXVlc3QgJiYgKHRoaXMucmVxdWVzdCA9IHJlcXVlc3QpO1xuICByZXNwb25zZSAmJiAodGhpcy5yZXNwb25zZSA9IHJlc3BvbnNlKTtcbn1cblxudXRpbHMuaW5oZXJpdHMoQXhpb3NFcnJvciwgRXJyb3IsIHtcbiAgdG9KU09OOiBmdW5jdGlvbiB0b0pTT04oKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC8vIFN0YW5kYXJkXG4gICAgICBtZXNzYWdlOiB0aGlzLm1lc3NhZ2UsXG4gICAgICBuYW1lOiB0aGlzLm5hbWUsXG4gICAgICAvLyBNaWNyb3NvZnRcbiAgICAgIGRlc2NyaXB0aW9uOiB0aGlzLmRlc2NyaXB0aW9uLFxuICAgICAgbnVtYmVyOiB0aGlzLm51bWJlcixcbiAgICAgIC8vIE1vemlsbGFcbiAgICAgIGZpbGVOYW1lOiB0aGlzLmZpbGVOYW1lLFxuICAgICAgbGluZU51bWJlcjogdGhpcy5saW5lTnVtYmVyLFxuICAgICAgY29sdW1uTnVtYmVyOiB0aGlzLmNvbHVtbk51bWJlcixcbiAgICAgIHN0YWNrOiB0aGlzLnN0YWNrLFxuICAgICAgLy8gQXhpb3NcbiAgICAgIGNvbmZpZzogdXRpbHMudG9KU09OT2JqZWN0KHRoaXMuY29uZmlnKSxcbiAgICAgIGNvZGU6IHRoaXMuY29kZSxcbiAgICAgIHN0YXR1czogdGhpcy5yZXNwb25zZSAmJiB0aGlzLnJlc3BvbnNlLnN0YXR1cyA/IHRoaXMucmVzcG9uc2Uuc3RhdHVzIDogbnVsbFxuICAgIH07XG4gIH1cbn0pO1xuXG5jb25zdCBwcm90b3R5cGUgPSBBeGlvc0Vycm9yLnByb3RvdHlwZTtcbmNvbnN0IGRlc2NyaXB0b3JzID0ge307XG5cbltcbiAgJ0VSUl9CQURfT1BUSU9OX1ZBTFVFJyxcbiAgJ0VSUl9CQURfT1BUSU9OJyxcbiAgJ0VDT05OQUJPUlRFRCcsXG4gICdFVElNRURPVVQnLFxuICAnRVJSX05FVFdPUksnLFxuICAnRVJSX0ZSX1RPT19NQU5ZX1JFRElSRUNUUycsXG4gICdFUlJfREVQUkVDQVRFRCcsXG4gICdFUlJfQkFEX1JFU1BPTlNFJyxcbiAgJ0VSUl9CQURfUkVRVUVTVCcsXG4gICdFUlJfQ0FOQ0VMRUQnLFxuICAnRVJSX05PVF9TVVBQT1JUJyxcbiAgJ0VSUl9JTlZBTElEX1VSTCdcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG5dLmZvckVhY2goY29kZSA9PiB7XG4gIGRlc2NyaXB0b3JzW2NvZGVdID0ge3ZhbHVlOiBjb2RlfTtcbn0pO1xuXG5PYmplY3QuZGVmaW5lUHJvcGVydGllcyhBeGlvc0Vycm9yLCBkZXNjcmlwdG9ycyk7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkocHJvdG90eXBlLCAnaXNBeGlvc0Vycm9yJywge3ZhbHVlOiB0cnVlfSk7XG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG5BeGlvc0Vycm9yLmZyb20gPSAoZXJyb3IsIGNvZGUsIGNvbmZpZywgcmVxdWVzdCwgcmVzcG9uc2UsIGN1c3RvbVByb3BzKSA9PiB7XG4gIGNvbnN0IGF4aW9zRXJyb3IgPSBPYmplY3QuY3JlYXRlKHByb3RvdHlwZSk7XG5cbiAgdXRpbHMudG9GbGF0T2JqZWN0KGVycm9yLCBheGlvc0Vycm9yLCBmdW5jdGlvbiBmaWx0ZXIob2JqKSB7XG4gICAgcmV0dXJuIG9iaiAhPT0gRXJyb3IucHJvdG90eXBlO1xuICB9LCBwcm9wID0+IHtcbiAgICByZXR1cm4gcHJvcCAhPT0gJ2lzQXhpb3NFcnJvcic7XG4gIH0pO1xuXG4gIEF4aW9zRXJyb3IuY2FsbChheGlvc0Vycm9yLCBlcnJvci5tZXNzYWdlLCBjb2RlLCBjb25maWcsIHJlcXVlc3QsIHJlc3BvbnNlKTtcblxuICBheGlvc0Vycm9yLmNhdXNlID0gZXJyb3I7XG5cbiAgYXhpb3NFcnJvci5uYW1lID0gZXJyb3IubmFtZTtcblxuICBjdXN0b21Qcm9wcyAmJiBPYmplY3QuYXNzaWduKGF4aW9zRXJyb3IsIGN1c3RvbVByb3BzKTtcblxuICByZXR1cm4gYXhpb3NFcnJvcjtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEF4aW9zRXJyb3I7XG4iLCIvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgc3RyaWN0XG5leHBvcnQgZGVmYXVsdCBudWxsO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdXRpbHMgZnJvbSAnLi8uLi91dGlscy5qcyc7XG5cbmNsYXNzIEludGVyY2VwdG9yTWFuYWdlciB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMuaGFuZGxlcnMgPSBbXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGQgYSBuZXcgaW50ZXJjZXB0b3IgdG8gdGhlIHN0YWNrXG4gICAqXG4gICAqIEBwYXJhbSB7RnVuY3Rpb259IGZ1bGZpbGxlZCBUaGUgZnVuY3Rpb24gdG8gaGFuZGxlIGB0aGVuYCBmb3IgYSBgUHJvbWlzZWBcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gcmVqZWN0ZWQgVGhlIGZ1bmN0aW9uIHRvIGhhbmRsZSBgcmVqZWN0YCBmb3IgYSBgUHJvbWlzZWBcbiAgICpcbiAgICogQHJldHVybiB7TnVtYmVyfSBBbiBJRCB1c2VkIHRvIHJlbW92ZSBpbnRlcmNlcHRvciBsYXRlclxuICAgKi9cbiAgdXNlKGZ1bGZpbGxlZCwgcmVqZWN0ZWQsIG9wdGlvbnMpIHtcbiAgICB0aGlzLmhhbmRsZXJzLnB1c2goe1xuICAgICAgZnVsZmlsbGVkLFxuICAgICAgcmVqZWN0ZWQsXG4gICAgICBzeW5jaHJvbm91czogb3B0aW9ucyA/IG9wdGlvbnMuc3luY2hyb25vdXMgOiBmYWxzZSxcbiAgICAgIHJ1bldoZW46IG9wdGlvbnMgPyBvcHRpb25zLnJ1bldoZW4gOiBudWxsXG4gICAgfSk7XG4gICAgcmV0dXJuIHRoaXMuaGFuZGxlcnMubGVuZ3RoIC0gMTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW1vdmUgYW4gaW50ZXJjZXB0b3IgZnJvbSB0aGUgc3RhY2tcbiAgICpcbiAgICogQHBhcmFtIHtOdW1iZXJ9IGlkIFRoZSBJRCB0aGF0IHdhcyByZXR1cm5lZCBieSBgdXNlYFxuICAgKlxuICAgKiBAcmV0dXJucyB7Qm9vbGVhbn0gYHRydWVgIGlmIHRoZSBpbnRlcmNlcHRvciB3YXMgcmVtb3ZlZCwgYGZhbHNlYCBvdGhlcndpc2VcbiAgICovXG4gIGVqZWN0KGlkKSB7XG4gICAgaWYgKHRoaXMuaGFuZGxlcnNbaWRdKSB7XG4gICAgICB0aGlzLmhhbmRsZXJzW2lkXSA9IG51bGw7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIENsZWFyIGFsbCBpbnRlcmNlcHRvcnMgZnJvbSB0aGUgc3RhY2tcbiAgICpcbiAgICogQHJldHVybnMge3ZvaWR9XG4gICAqL1xuICBjbGVhcigpIHtcbiAgICBpZiAodGhpcy5oYW5kbGVycykge1xuICAgICAgdGhpcy5oYW5kbGVycyA9IFtdO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBJdGVyYXRlIG92ZXIgYWxsIHRoZSByZWdpc3RlcmVkIGludGVyY2VwdG9yc1xuICAgKlxuICAgKiBUaGlzIG1ldGhvZCBpcyBwYXJ0aWN1bGFybHkgdXNlZnVsIGZvciBza2lwcGluZyBvdmVyIGFueVxuICAgKiBpbnRlcmNlcHRvcnMgdGhhdCBtYXkgaGF2ZSBiZWNvbWUgYG51bGxgIGNhbGxpbmcgYGVqZWN0YC5cbiAgICpcbiAgICogQHBhcmFtIHtGdW5jdGlvbn0gZm4gVGhlIGZ1bmN0aW9uIHRvIGNhbGwgZm9yIGVhY2ggaW50ZXJjZXB0b3JcbiAgICpcbiAgICogQHJldHVybnMge3ZvaWR9XG4gICAqL1xuICBmb3JFYWNoKGZuKSB7XG4gICAgdXRpbHMuZm9yRWFjaCh0aGlzLmhhbmRsZXJzLCBmdW5jdGlvbiBmb3JFYWNoSGFuZGxlcihoKSB7XG4gICAgICBpZiAoaCAhPT0gbnVsbCkge1xuICAgICAgICBmbihoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBJbnRlcmNlcHRvck1hbmFnZXI7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB0cmFuc2Zvcm1EYXRhIGZyb20gJy4vdHJhbnNmb3JtRGF0YS5qcyc7XG5pbXBvcnQgaXNDYW5jZWwgZnJvbSAnLi4vY2FuY2VsL2lzQ2FuY2VsLmpzJztcbmltcG9ydCBkZWZhdWx0cyBmcm9tICcuLi9kZWZhdWx0cy9pbmRleC5qcyc7XG5pbXBvcnQgQ2FuY2VsZWRFcnJvciBmcm9tICcuLi9jYW5jZWwvQ2FuY2VsZWRFcnJvci5qcyc7XG5pbXBvcnQgQXhpb3NIZWFkZXJzIGZyb20gJy4uL2NvcmUvQXhpb3NIZWFkZXJzLmpzJztcbmltcG9ydCBhZGFwdGVycyBmcm9tIFwiLi4vYWRhcHRlcnMvYWRhcHRlcnMuanNcIjtcblxuLyoqXG4gKiBUaHJvd3MgYSBgQ2FuY2VsZWRFcnJvcmAgaWYgY2FuY2VsbGF0aW9uIGhhcyBiZWVuIHJlcXVlc3RlZC5cbiAqXG4gKiBAcGFyYW0ge09iamVjdH0gY29uZmlnIFRoZSBjb25maWcgdGhhdCBpcyB0byBiZSB1c2VkIGZvciB0aGUgcmVxdWVzdFxuICpcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5mdW5jdGlvbiB0aHJvd0lmQ2FuY2VsbGF0aW9uUmVxdWVzdGVkKGNvbmZpZykge1xuICBpZiAoY29uZmlnLmNhbmNlbFRva2VuKSB7XG4gICAgY29uZmlnLmNhbmNlbFRva2VuLnRocm93SWZSZXF1ZXN0ZWQoKTtcbiAgfVxuXG4gIGlmIChjb25maWcuc2lnbmFsICYmIGNvbmZpZy5zaWduYWwuYWJvcnRlZCkge1xuICAgIHRocm93IG5ldyBDYW5jZWxlZEVycm9yKG51bGwsIGNvbmZpZyk7XG4gIH1cbn1cblxuLyoqXG4gKiBEaXNwYXRjaCBhIHJlcXVlc3QgdG8gdGhlIHNlcnZlciB1c2luZyB0aGUgY29uZmlndXJlZCBhZGFwdGVyLlxuICpcbiAqIEBwYXJhbSB7b2JqZWN0fSBjb25maWcgVGhlIGNvbmZpZyB0aGF0IGlzIHRvIGJlIHVzZWQgZm9yIHRoZSByZXF1ZXN0XG4gKlxuICogQHJldHVybnMge1Byb21pc2V9IFRoZSBQcm9taXNlIHRvIGJlIGZ1bGZpbGxlZFxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBkaXNwYXRjaFJlcXVlc3QoY29uZmlnKSB7XG4gIHRocm93SWZDYW5jZWxsYXRpb25SZXF1ZXN0ZWQoY29uZmlnKTtcblxuICBjb25maWcuaGVhZGVycyA9IEF4aW9zSGVhZGVycy5mcm9tKGNvbmZpZy5oZWFkZXJzKTtcblxuICAvLyBUcmFuc2Zvcm0gcmVxdWVzdCBkYXRhXG4gIGNvbmZpZy5kYXRhID0gdHJhbnNmb3JtRGF0YS5jYWxsKFxuICAgIGNvbmZpZyxcbiAgICBjb25maWcudHJhbnNmb3JtUmVxdWVzdFxuICApO1xuXG4gIGlmIChbJ3Bvc3QnLCAncHV0JywgJ3BhdGNoJ10uaW5kZXhPZihjb25maWcubWV0aG9kKSAhPT0gLTEpIHtcbiAgICBjb25maWcuaGVhZGVycy5zZXRDb250ZW50VHlwZSgnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJywgZmFsc2UpO1xuICB9XG5cbiAgY29uc3QgYWRhcHRlciA9IGFkYXB0ZXJzLmdldEFkYXB0ZXIoY29uZmlnLmFkYXB0ZXIgfHwgZGVmYXVsdHMuYWRhcHRlcik7XG5cbiAgcmV0dXJuIGFkYXB0ZXIoY29uZmlnKS50aGVuKGZ1bmN0aW9uIG9uQWRhcHRlclJlc29sdXRpb24ocmVzcG9uc2UpIHtcbiAgICB0aHJvd0lmQ2FuY2VsbGF0aW9uUmVxdWVzdGVkKGNvbmZpZyk7XG5cbiAgICAvLyBUcmFuc2Zvcm0gcmVzcG9uc2UgZGF0YVxuICAgIHJlc3BvbnNlLmRhdGEgPSB0cmFuc2Zvcm1EYXRhLmNhbGwoXG4gICAgICBjb25maWcsXG4gICAgICBjb25maWcudHJhbnNmb3JtUmVzcG9uc2UsXG4gICAgICByZXNwb25zZVxuICAgICk7XG5cbiAgICByZXNwb25zZS5oZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20ocmVzcG9uc2UuaGVhZGVycyk7XG5cbiAgICByZXR1cm4gcmVzcG9uc2U7XG4gIH0sIGZ1bmN0aW9uIG9uQWRhcHRlclJlamVjdGlvbihyZWFzb24pIHtcbiAgICBpZiAoIWlzQ2FuY2VsKHJlYXNvbikpIHtcbiAgICAgIHRocm93SWZDYW5jZWxsYXRpb25SZXF1ZXN0ZWQoY29uZmlnKTtcblxuICAgICAgLy8gVHJhbnNmb3JtIHJlc3BvbnNlIGRhdGFcbiAgICAgIGlmIChyZWFzb24gJiYgcmVhc29uLnJlc3BvbnNlKSB7XG4gICAgICAgIHJlYXNvbi5yZXNwb25zZS5kYXRhID0gdHJhbnNmb3JtRGF0YS5jYWxsKFxuICAgICAgICAgIGNvbmZpZyxcbiAgICAgICAgICBjb25maWcudHJhbnNmb3JtUmVzcG9uc2UsXG4gICAgICAgICAgcmVhc29uLnJlc3BvbnNlXG4gICAgICAgICk7XG4gICAgICAgIHJlYXNvbi5yZXNwb25zZS5oZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20ocmVhc29uLnJlc3BvbnNlLmhlYWRlcnMpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBQcm9taXNlLnJlamVjdChyZWFzb24pO1xuICB9KTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4vLi4vdXRpbHMuanMnO1xuaW1wb3J0IGRlZmF1bHRzIGZyb20gJy4uL2RlZmF1bHRzL2luZGV4LmpzJztcbmltcG9ydCBBeGlvc0hlYWRlcnMgZnJvbSAnLi4vY29yZS9BeGlvc0hlYWRlcnMuanMnO1xuXG4vKipcbiAqIFRyYW5zZm9ybSB0aGUgZGF0YSBmb3IgYSByZXF1ZXN0IG9yIGEgcmVzcG9uc2VcbiAqXG4gKiBAcGFyYW0ge0FycmF5fEZ1bmN0aW9ufSBmbnMgQSBzaW5nbGUgZnVuY3Rpb24gb3IgQXJyYXkgb2YgZnVuY3Rpb25zXG4gKiBAcGFyYW0gez9PYmplY3R9IHJlc3BvbnNlIFRoZSByZXNwb25zZSBvYmplY3RcbiAqXG4gKiBAcmV0dXJucyB7Kn0gVGhlIHJlc3VsdGluZyB0cmFuc2Zvcm1lZCBkYXRhXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHRyYW5zZm9ybURhdGEoZm5zLCByZXNwb25zZSkge1xuICBjb25zdCBjb25maWcgPSB0aGlzIHx8IGRlZmF1bHRzO1xuICBjb25zdCBjb250ZXh0ID0gcmVzcG9uc2UgfHwgY29uZmlnO1xuICBjb25zdCBoZWFkZXJzID0gQXhpb3NIZWFkZXJzLmZyb20oY29udGV4dC5oZWFkZXJzKTtcbiAgbGV0IGRhdGEgPSBjb250ZXh0LmRhdGE7XG5cbiAgdXRpbHMuZm9yRWFjaChmbnMsIGZ1bmN0aW9uIHRyYW5zZm9ybShmbikge1xuICAgIGRhdGEgPSBmbi5jYWxsKGNvbmZpZywgZGF0YSwgaGVhZGVycy5ub3JtYWxpemUoKSwgcmVzcG9uc2UgPyByZXNwb25zZS5zdGF0dXMgOiB1bmRlZmluZWQpO1xuICB9KTtcblxuICBoZWFkZXJzLm5vcm1hbGl6ZSgpO1xuXG4gIHJldHVybiBkYXRhO1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdXRpbHMgZnJvbSAnLi4vdXRpbHMuanMnO1xuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi4vY29yZS9BeGlvc0Vycm9yLmpzJztcbmltcG9ydCB0cmFuc2l0aW9uYWxEZWZhdWx0cyBmcm9tICcuL3RyYW5zaXRpb25hbC5qcyc7XG5pbXBvcnQgdG9Gb3JtRGF0YSBmcm9tICcuLi9oZWxwZXJzL3RvRm9ybURhdGEuanMnO1xuaW1wb3J0IHRvVVJMRW5jb2RlZEZvcm0gZnJvbSAnLi4vaGVscGVycy90b1VSTEVuY29kZWRGb3JtLmpzJztcbmltcG9ydCBwbGF0Zm9ybSBmcm9tICcuLi9wbGF0Zm9ybS9pbmRleC5qcyc7XG5pbXBvcnQgZm9ybURhdGFUb0pTT04gZnJvbSAnLi4vaGVscGVycy9mb3JtRGF0YVRvSlNPTi5qcyc7XG5cbi8qKlxuICogSXQgdGFrZXMgYSBzdHJpbmcsIHRyaWVzIHRvIHBhcnNlIGl0LCBhbmQgaWYgaXQgZmFpbHMsIGl0IHJldHVybnMgdGhlIHN0cmluZ2lmaWVkIHZlcnNpb25cbiAqIG9mIHRoZSBpbnB1dFxuICpcbiAqIEBwYXJhbSB7YW55fSByYXdWYWx1ZSAtIFRoZSB2YWx1ZSB0byBiZSBzdHJpbmdpZmllZC5cbiAqIEBwYXJhbSB7RnVuY3Rpb259IHBhcnNlciAtIEEgZnVuY3Rpb24gdGhhdCBwYXJzZXMgYSBzdHJpbmcgaW50byBhIEphdmFTY3JpcHQgb2JqZWN0LlxuICogQHBhcmFtIHtGdW5jdGlvbn0gZW5jb2RlciAtIEEgZnVuY3Rpb24gdGhhdCB0YWtlcyBhIHZhbHVlIGFuZCByZXR1cm5zIGEgc3RyaW5nLlxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IEEgc3RyaW5naWZpZWQgdmVyc2lvbiBvZiB0aGUgcmF3VmFsdWUuXG4gKi9cbmZ1bmN0aW9uIHN0cmluZ2lmeVNhZmVseShyYXdWYWx1ZSwgcGFyc2VyLCBlbmNvZGVyKSB7XG4gIGlmICh1dGlscy5pc1N0cmluZyhyYXdWYWx1ZSkpIHtcbiAgICB0cnkge1xuICAgICAgKHBhcnNlciB8fCBKU09OLnBhcnNlKShyYXdWYWx1ZSk7XG4gICAgICByZXR1cm4gdXRpbHMudHJpbShyYXdWYWx1ZSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgaWYgKGUubmFtZSAhPT0gJ1N5bnRheEVycm9yJykge1xuICAgICAgICB0aHJvdyBlO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoZW5jb2RlciB8fCBKU09OLnN0cmluZ2lmeSkocmF3VmFsdWUpO1xufVxuXG5jb25zdCBkZWZhdWx0cyA9IHtcblxuICB0cmFuc2l0aW9uYWw6IHRyYW5zaXRpb25hbERlZmF1bHRzLFxuXG4gIGFkYXB0ZXI6IFsneGhyJywgJ2h0dHAnXSxcblxuICB0cmFuc2Zvcm1SZXF1ZXN0OiBbZnVuY3Rpb24gdHJhbnNmb3JtUmVxdWVzdChkYXRhLCBoZWFkZXJzKSB7XG4gICAgY29uc3QgY29udGVudFR5cGUgPSBoZWFkZXJzLmdldENvbnRlbnRUeXBlKCkgfHwgJyc7XG4gICAgY29uc3QgaGFzSlNPTkNvbnRlbnRUeXBlID0gY29udGVudFR5cGUuaW5kZXhPZignYXBwbGljYXRpb24vanNvbicpID4gLTE7XG4gICAgY29uc3QgaXNPYmplY3RQYXlsb2FkID0gdXRpbHMuaXNPYmplY3QoZGF0YSk7XG5cbiAgICBpZiAoaXNPYmplY3RQYXlsb2FkICYmIHV0aWxzLmlzSFRNTEZvcm0oZGF0YSkpIHtcbiAgICAgIGRhdGEgPSBuZXcgRm9ybURhdGEoZGF0YSk7XG4gICAgfVxuXG4gICAgY29uc3QgaXNGb3JtRGF0YSA9IHV0aWxzLmlzRm9ybURhdGEoZGF0YSk7XG5cbiAgICBpZiAoaXNGb3JtRGF0YSkge1xuICAgICAgcmV0dXJuIGhhc0pTT05Db250ZW50VHlwZSA/IEpTT04uc3RyaW5naWZ5KGZvcm1EYXRhVG9KU09OKGRhdGEpKSA6IGRhdGE7XG4gICAgfVxuXG4gICAgaWYgKHV0aWxzLmlzQXJyYXlCdWZmZXIoZGF0YSkgfHxcbiAgICAgIHV0aWxzLmlzQnVmZmVyKGRhdGEpIHx8XG4gICAgICB1dGlscy5pc1N0cmVhbShkYXRhKSB8fFxuICAgICAgdXRpbHMuaXNGaWxlKGRhdGEpIHx8XG4gICAgICB1dGlscy5pc0Jsb2IoZGF0YSlcbiAgICApIHtcbiAgICAgIHJldHVybiBkYXRhO1xuICAgIH1cbiAgICBpZiAodXRpbHMuaXNBcnJheUJ1ZmZlclZpZXcoZGF0YSkpIHtcbiAgICAgIHJldHVybiBkYXRhLmJ1ZmZlcjtcbiAgICB9XG4gICAgaWYgKHV0aWxzLmlzVVJMU2VhcmNoUGFyYW1zKGRhdGEpKSB7XG4gICAgICBoZWFkZXJzLnNldENvbnRlbnRUeXBlKCdhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWQ7Y2hhcnNldD11dGYtOCcsIGZhbHNlKTtcbiAgICAgIHJldHVybiBkYXRhLnRvU3RyaW5nKCk7XG4gICAgfVxuXG4gICAgbGV0IGlzRmlsZUxpc3Q7XG5cbiAgICBpZiAoaXNPYmplY3RQYXlsb2FkKSB7XG4gICAgICBpZiAoY29udGVudFR5cGUuaW5kZXhPZignYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJykgPiAtMSkge1xuICAgICAgICByZXR1cm4gdG9VUkxFbmNvZGVkRm9ybShkYXRhLCB0aGlzLmZvcm1TZXJpYWxpemVyKS50b1N0cmluZygpO1xuICAgICAgfVxuXG4gICAgICBpZiAoKGlzRmlsZUxpc3QgPSB1dGlscy5pc0ZpbGVMaXN0KGRhdGEpKSB8fCBjb250ZW50VHlwZS5pbmRleE9mKCdtdWx0aXBhcnQvZm9ybS1kYXRhJykgPiAtMSkge1xuICAgICAgICBjb25zdCBfRm9ybURhdGEgPSB0aGlzLmVudiAmJiB0aGlzLmVudi5Gb3JtRGF0YTtcblxuICAgICAgICByZXR1cm4gdG9Gb3JtRGF0YShcbiAgICAgICAgICBpc0ZpbGVMaXN0ID8geydmaWxlc1tdJzogZGF0YX0gOiBkYXRhLFxuICAgICAgICAgIF9Gb3JtRGF0YSAmJiBuZXcgX0Zvcm1EYXRhKCksXG4gICAgICAgICAgdGhpcy5mb3JtU2VyaWFsaXplclxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChpc09iamVjdFBheWxvYWQgfHwgaGFzSlNPTkNvbnRlbnRUeXBlICkge1xuICAgICAgaGVhZGVycy5zZXRDb250ZW50VHlwZSgnYXBwbGljYXRpb24vanNvbicsIGZhbHNlKTtcbiAgICAgIHJldHVybiBzdHJpbmdpZnlTYWZlbHkoZGF0YSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGRhdGE7XG4gIH1dLFxuXG4gIHRyYW5zZm9ybVJlc3BvbnNlOiBbZnVuY3Rpb24gdHJhbnNmb3JtUmVzcG9uc2UoZGF0YSkge1xuICAgIGNvbnN0IHRyYW5zaXRpb25hbCA9IHRoaXMudHJhbnNpdGlvbmFsIHx8IGRlZmF1bHRzLnRyYW5zaXRpb25hbDtcbiAgICBjb25zdCBmb3JjZWRKU09OUGFyc2luZyA9IHRyYW5zaXRpb25hbCAmJiB0cmFuc2l0aW9uYWwuZm9yY2VkSlNPTlBhcnNpbmc7XG4gICAgY29uc3QgSlNPTlJlcXVlc3RlZCA9IHRoaXMucmVzcG9uc2VUeXBlID09PSAnanNvbic7XG5cbiAgICBpZiAoZGF0YSAmJiB1dGlscy5pc1N0cmluZyhkYXRhKSAmJiAoKGZvcmNlZEpTT05QYXJzaW5nICYmICF0aGlzLnJlc3BvbnNlVHlwZSkgfHwgSlNPTlJlcXVlc3RlZCkpIHtcbiAgICAgIGNvbnN0IHNpbGVudEpTT05QYXJzaW5nID0gdHJhbnNpdGlvbmFsICYmIHRyYW5zaXRpb25hbC5zaWxlbnRKU09OUGFyc2luZztcbiAgICAgIGNvbnN0IHN0cmljdEpTT05QYXJzaW5nID0gIXNpbGVudEpTT05QYXJzaW5nICYmIEpTT05SZXF1ZXN0ZWQ7XG5cbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBKU09OLnBhcnNlKGRhdGEpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBpZiAoc3RyaWN0SlNPTlBhcnNpbmcpIHtcbiAgICAgICAgICBpZiAoZS5uYW1lID09PSAnU3ludGF4RXJyb3InKSB7XG4gICAgICAgICAgICB0aHJvdyBBeGlvc0Vycm9yLmZyb20oZSwgQXhpb3NFcnJvci5FUlJfQkFEX1JFU1BPTlNFLCB0aGlzLCBudWxsLCB0aGlzLnJlc3BvbnNlKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBkYXRhO1xuICB9XSxcblxuICAvKipcbiAgICogQSB0aW1lb3V0IGluIG1pbGxpc2Vjb25kcyB0byBhYm9ydCBhIHJlcXVlc3QuIElmIHNldCB0byAwIChkZWZhdWx0KSBhXG4gICAqIHRpbWVvdXQgaXMgbm90IGNyZWF0ZWQuXG4gICAqL1xuICB0aW1lb3V0OiAwLFxuXG4gIHhzcmZDb29raWVOYW1lOiAnWFNSRi1UT0tFTicsXG4gIHhzcmZIZWFkZXJOYW1lOiAnWC1YU1JGLVRPS0VOJyxcblxuICBtYXhDb250ZW50TGVuZ3RoOiAtMSxcbiAgbWF4Qm9keUxlbmd0aDogLTEsXG5cbiAgZW52OiB7XG4gICAgRm9ybURhdGE6IHBsYXRmb3JtLmNsYXNzZXMuRm9ybURhdGEsXG4gICAgQmxvYjogcGxhdGZvcm0uY2xhc3Nlcy5CbG9iXG4gIH0sXG5cbiAgdmFsaWRhdGVTdGF0dXM6IGZ1bmN0aW9uIHZhbGlkYXRlU3RhdHVzKHN0YXR1cykge1xuICAgIHJldHVybiBzdGF0dXMgPj0gMjAwICYmIHN0YXR1cyA8IDMwMDtcbiAgfSxcblxuICBoZWFkZXJzOiB7XG4gICAgY29tbW9uOiB7XG4gICAgICAnQWNjZXB0JzogJ2FwcGxpY2F0aW9uL2pzb24sIHRleHQvcGxhaW4sICovKicsXG4gICAgICAnQ29udGVudC1UeXBlJzogdW5kZWZpbmVkXG4gICAgfVxuICB9XG59O1xuXG51dGlscy5mb3JFYWNoKFsnZGVsZXRlJywgJ2dldCcsICdoZWFkJywgJ3Bvc3QnLCAncHV0JywgJ3BhdGNoJ10sIChtZXRob2QpID0+IHtcbiAgZGVmYXVsdHMuaGVhZGVyc1ttZXRob2RdID0ge307XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgZGVmYXVsdHM7XG4iLCIndXNlIHN0cmljdCc7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgc2lsZW50SlNPTlBhcnNpbmc6IHRydWUsXG4gIGZvcmNlZEpTT05QYXJzaW5nOiB0cnVlLFxuICBjbGFyaWZ5VGltZW91dEVycm9yOiBmYWxzZVxufTtcbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4uL3V0aWxzLmpzJztcbmltcG9ydCB0b0Zvcm1EYXRhIGZyb20gJy4vdG9Gb3JtRGF0YS5qcyc7XG5pbXBvcnQgcGxhdGZvcm0gZnJvbSAnLi4vcGxhdGZvcm0vaW5kZXguanMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiB0b1VSTEVuY29kZWRGb3JtKGRhdGEsIG9wdGlvbnMpIHtcbiAgcmV0dXJuIHRvRm9ybURhdGEoZGF0YSwgbmV3IHBsYXRmb3JtLmNsYXNzZXMuVVJMU2VhcmNoUGFyYW1zKCksIE9iamVjdC5hc3NpZ24oe1xuICAgIHZpc2l0b3I6IGZ1bmN0aW9uKHZhbHVlLCBrZXksIHBhdGgsIGhlbHBlcnMpIHtcbiAgICAgIGlmIChwbGF0Zm9ybS5pc05vZGUgJiYgdXRpbHMuaXNCdWZmZXIodmFsdWUpKSB7XG4gICAgICAgIHRoaXMuYXBwZW5kKGtleSwgdmFsdWUudG9TdHJpbmcoJ2Jhc2U2NCcpKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gaGVscGVycy5kZWZhdWx0VmlzaXRvci5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgIH1cbiAgfSwgb3B0aW9ucykpO1xufVxuIiwiaW1wb3J0IHBsYXRmb3JtIGZyb20gJy4vbm9kZS9pbmRleC5qcyc7XG5pbXBvcnQgKiBhcyB1dGlscyBmcm9tICcuL2NvbW1vbi91dGlscy5qcyc7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgLi4udXRpbHMsXG4gIC4uLnBsYXRmb3JtXG59XG4iLCJpbXBvcnQgVVJMU2VhcmNoUGFyYW1zIGZyb20gJy4vY2xhc3Nlcy9VUkxTZWFyY2hQYXJhbXMuanMnXG5pbXBvcnQgRm9ybURhdGEgZnJvbSAnLi9jbGFzc2VzL0Zvcm1EYXRhLmpzJ1xuaW1wb3J0IEJsb2IgZnJvbSAnLi9jbGFzc2VzL0Jsb2IuanMnXG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgaXNCcm93c2VyOiB0cnVlLFxuICBjbGFzc2VzOiB7XG4gICAgVVJMU2VhcmNoUGFyYW1zLFxuICAgIEZvcm1EYXRhLFxuICAgIEJsb2JcbiAgfSxcbiAgcHJvdG9jb2xzOiBbJ2h0dHAnLCAnaHR0cHMnLCAnZmlsZScsICdibG9iJywgJ3VybCcsICdkYXRhJ11cbn07XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCBBeGlvc1VSTFNlYXJjaFBhcmFtcyBmcm9tICcuLi8uLi8uLi9oZWxwZXJzL0F4aW9zVVJMU2VhcmNoUGFyYW1zLmpzJztcbmV4cG9ydCBkZWZhdWx0IHR5cGVvZiBVUkxTZWFyY2hQYXJhbXMgIT09ICd1bmRlZmluZWQnID8gVVJMU2VhcmNoUGFyYW1zIDogQXhpb3NVUkxTZWFyY2hQYXJhbXM7XG4iLCIndXNlIHN0cmljdCc7XG5cbmV4cG9ydCBkZWZhdWx0IHR5cGVvZiBGb3JtRGF0YSAhPT0gJ3VuZGVmaW5lZCcgPyBGb3JtRGF0YSA6IG51bGw7XG4iLCIndXNlIHN0cmljdCdcblxuZXhwb3J0IGRlZmF1bHQgdHlwZW9mIEJsb2IgIT09ICd1bmRlZmluZWQnID8gQmxvYiA6IG51bGxcbiIsImNvbnN0IGhhc0Jyb3dzZXJFbnYgPSB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnO1xuXG4vKipcbiAqIERldGVybWluZSBpZiB3ZSdyZSBydW5uaW5nIGluIGEgc3RhbmRhcmQgYnJvd3NlciBlbnZpcm9ubWVudFxuICpcbiAqIFRoaXMgYWxsb3dzIGF4aW9zIHRvIHJ1biBpbiBhIHdlYiB3b3JrZXIsIGFuZCByZWFjdC1uYXRpdmUuXG4gKiBCb3RoIGVudmlyb25tZW50cyBzdXBwb3J0IFhNTEh0dHBSZXF1ZXN0LCBidXQgbm90IGZ1bGx5IHN0YW5kYXJkIGdsb2JhbHMuXG4gKlxuICogd2ViIHdvcmtlcnM6XG4gKiAgdHlwZW9mIHdpbmRvdyAtPiB1bmRlZmluZWRcbiAqICB0eXBlb2YgZG9jdW1lbnQgLT4gdW5kZWZpbmVkXG4gKlxuICogcmVhY3QtbmF0aXZlOlxuICogIG5hdmlnYXRvci5wcm9kdWN0IC0+ICdSZWFjdE5hdGl2ZSdcbiAqIG5hdGl2ZXNjcmlwdFxuICogIG5hdmlnYXRvci5wcm9kdWN0IC0+ICdOYXRpdmVTY3JpcHQnIG9yICdOUydcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAqL1xuY29uc3QgaGFzU3RhbmRhcmRCcm93c2VyRW52ID0gKFxuICAocHJvZHVjdCkgPT4ge1xuICAgIHJldHVybiBoYXNCcm93c2VyRW52ICYmIFsnUmVhY3ROYXRpdmUnLCAnTmF0aXZlU2NyaXB0JywgJ05TJ10uaW5kZXhPZihwcm9kdWN0KSA8IDBcbiAgfSkodHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCcgJiYgbmF2aWdhdG9yLnByb2R1Y3QpO1xuXG4vKipcbiAqIERldGVybWluZSBpZiB3ZSdyZSBydW5uaW5nIGluIGEgc3RhbmRhcmQgYnJvd3NlciB3ZWJXb3JrZXIgZW52aXJvbm1lbnRcbiAqXG4gKiBBbHRob3VnaCB0aGUgYGlzU3RhbmRhcmRCcm93c2VyRW52YCBtZXRob2QgaW5kaWNhdGVzIHRoYXRcbiAqIGBhbGxvd3MgYXhpb3MgdG8gcnVuIGluIGEgd2ViIHdvcmtlcmAsIHRoZSBXZWJXb3JrZXIgd2lsbCBzdGlsbCBiZVxuICogZmlsdGVyZWQgb3V0IGR1ZSB0byBpdHMganVkZ21lbnQgc3RhbmRhcmRcbiAqIGB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJyAmJiB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnYC5cbiAqIFRoaXMgbGVhZHMgdG8gYSBwcm9ibGVtIHdoZW4gYXhpb3MgcG9zdCBgRm9ybURhdGFgIGluIHdlYldvcmtlclxuICovXG5jb25zdCBoYXNTdGFuZGFyZEJyb3dzZXJXZWJXb3JrZXJFbnYgPSAoKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIHR5cGVvZiBXb3JrZXJHbG9iYWxTY29wZSAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdW5kZWZcbiAgICBzZWxmIGluc3RhbmNlb2YgV29ya2VyR2xvYmFsU2NvcGUgJiZcbiAgICB0eXBlb2Ygc2VsZi5pbXBvcnRTY3JpcHRzID09PSAnZnVuY3Rpb24nXG4gICk7XG59KSgpO1xuXG5leHBvcnQge1xuICBoYXNCcm93c2VyRW52LFxuICBoYXNTdGFuZGFyZEJyb3dzZXJXZWJXb3JrZXJFbnYsXG4gIGhhc1N0YW5kYXJkQnJvd3NlckVudlxufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdXRpbHMgZnJvbSAnLi4vdXRpbHMuanMnO1xuXG4vKipcbiAqIEl0IHRha2VzIGEgc3RyaW5nIGxpa2UgYGZvb1t4XVt5XVt6XWAgYW5kIHJldHVybnMgYW4gYXJyYXkgbGlrZSBgWydmb28nLCAneCcsICd5JywgJ3onXVxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBuYW1lIC0gVGhlIG5hbWUgb2YgdGhlIHByb3BlcnR5IHRvIGdldC5cbiAqXG4gKiBAcmV0dXJucyBBbiBhcnJheSBvZiBzdHJpbmdzLlxuICovXG5mdW5jdGlvbiBwYXJzZVByb3BQYXRoKG5hbWUpIHtcbiAgLy8gZm9vW3hdW3ldW3pdXG4gIC8vIGZvby54LnkuelxuICAvLyBmb28teC15LXpcbiAgLy8gZm9vIHggeSB6XG4gIHJldHVybiB1dGlscy5tYXRjaEFsbCgvXFx3K3xcXFsoXFx3KildL2csIG5hbWUpLm1hcChtYXRjaCA9PiB7XG4gICAgcmV0dXJuIG1hdGNoWzBdID09PSAnW10nID8gJycgOiBtYXRjaFsxXSB8fCBtYXRjaFswXTtcbiAgfSk7XG59XG5cbi8qKlxuICogQ29udmVydCBhbiBhcnJheSB0byBhbiBvYmplY3QuXG4gKlxuICogQHBhcmFtIHtBcnJheTxhbnk+fSBhcnIgLSBUaGUgYXJyYXkgdG8gY29udmVydCB0byBhbiBvYmplY3QuXG4gKlxuICogQHJldHVybnMgQW4gb2JqZWN0IHdpdGggdGhlIHNhbWUga2V5cyBhbmQgdmFsdWVzIGFzIHRoZSBhcnJheS5cbiAqL1xuZnVuY3Rpb24gYXJyYXlUb09iamVjdChhcnIpIHtcbiAgY29uc3Qgb2JqID0ge307XG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhhcnIpO1xuICBsZXQgaTtcbiAgY29uc3QgbGVuID0ga2V5cy5sZW5ndGg7XG4gIGxldCBrZXk7XG4gIGZvciAoaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgIGtleSA9IGtleXNbaV07XG4gICAgb2JqW2tleV0gPSBhcnJba2V5XTtcbiAgfVxuICByZXR1cm4gb2JqO1xufVxuXG4vKipcbiAqIEl0IHRha2VzIGEgRm9ybURhdGEgb2JqZWN0IGFuZCByZXR1cm5zIGEgSmF2YVNjcmlwdCBvYmplY3RcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gZm9ybURhdGEgVGhlIEZvcm1EYXRhIG9iamVjdCB0byBjb252ZXJ0IHRvIEpTT04uXG4gKlxuICogQHJldHVybnMge09iamVjdDxzdHJpbmcsIGFueT4gfCBudWxsfSBUaGUgY29udmVydGVkIG9iamVjdC5cbiAqL1xuZnVuY3Rpb24gZm9ybURhdGFUb0pTT04oZm9ybURhdGEpIHtcbiAgZnVuY3Rpb24gYnVpbGRQYXRoKHBhdGgsIHZhbHVlLCB0YXJnZXQsIGluZGV4KSB7XG4gICAgbGV0IG5hbWUgPSBwYXRoW2luZGV4KytdO1xuXG4gICAgaWYgKG5hbWUgPT09ICdfX3Byb3RvX18nKSByZXR1cm4gdHJ1ZTtcblxuICAgIGNvbnN0IGlzTnVtZXJpY0tleSA9IE51bWJlci5pc0Zpbml0ZSgrbmFtZSk7XG4gICAgY29uc3QgaXNMYXN0ID0gaW5kZXggPj0gcGF0aC5sZW5ndGg7XG4gICAgbmFtZSA9ICFuYW1lICYmIHV0aWxzLmlzQXJyYXkodGFyZ2V0KSA/IHRhcmdldC5sZW5ndGggOiBuYW1lO1xuXG4gICAgaWYgKGlzTGFzdCkge1xuICAgICAgaWYgKHV0aWxzLmhhc093blByb3AodGFyZ2V0LCBuYW1lKSkge1xuICAgICAgICB0YXJnZXRbbmFtZV0gPSBbdGFyZ2V0W25hbWVdLCB2YWx1ZV07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0YXJnZXRbbmFtZV0gPSB2YWx1ZTtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuICFpc051bWVyaWNLZXk7XG4gICAgfVxuXG4gICAgaWYgKCF0YXJnZXRbbmFtZV0gfHwgIXV0aWxzLmlzT2JqZWN0KHRhcmdldFtuYW1lXSkpIHtcbiAgICAgIHRhcmdldFtuYW1lXSA9IFtdO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3VsdCA9IGJ1aWxkUGF0aChwYXRoLCB2YWx1ZSwgdGFyZ2V0W25hbWVdLCBpbmRleCk7XG5cbiAgICBpZiAocmVzdWx0ICYmIHV0aWxzLmlzQXJyYXkodGFyZ2V0W25hbWVdKSkge1xuICAgICAgdGFyZ2V0W25hbWVdID0gYXJyYXlUb09iamVjdCh0YXJnZXRbbmFtZV0pO1xuICAgIH1cblxuICAgIHJldHVybiAhaXNOdW1lcmljS2V5O1xuICB9XG5cbiAgaWYgKHV0aWxzLmlzRm9ybURhdGEoZm9ybURhdGEpICYmIHV0aWxzLmlzRnVuY3Rpb24oZm9ybURhdGEuZW50cmllcykpIHtcbiAgICBjb25zdCBvYmogPSB7fTtcblxuICAgIHV0aWxzLmZvckVhY2hFbnRyeShmb3JtRGF0YSwgKG5hbWUsIHZhbHVlKSA9PiB7XG4gICAgICBidWlsZFBhdGgocGFyc2VQcm9wUGF0aChuYW1lKSwgdmFsdWUsIG9iaiwgMCk7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gb2JqO1xuICB9XG5cbiAgcmV0dXJuIG51bGw7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZvcm1EYXRhVG9KU09OO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgdXRpbHMgZnJvbSAnLi4vdXRpbHMuanMnO1xuaW1wb3J0IHBhcnNlSGVhZGVycyBmcm9tICcuLi9oZWxwZXJzL3BhcnNlSGVhZGVycy5qcyc7XG5cbmNvbnN0ICRpbnRlcm5hbHMgPSBTeW1ib2woJ2ludGVybmFscycpO1xuXG5mdW5jdGlvbiBub3JtYWxpemVIZWFkZXIoaGVhZGVyKSB7XG4gIHJldHVybiBoZWFkZXIgJiYgU3RyaW5nKGhlYWRlcikudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG59XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZVZhbHVlKHZhbHVlKSB7XG4gIGlmICh2YWx1ZSA9PT0gZmFsc2UgfHwgdmFsdWUgPT0gbnVsbCkge1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxuXG4gIHJldHVybiB1dGlscy5pc0FycmF5KHZhbHVlKSA/IHZhbHVlLm1hcChub3JtYWxpemVWYWx1ZSkgOiBTdHJpbmcodmFsdWUpO1xufVxuXG5mdW5jdGlvbiBwYXJzZVRva2VucyhzdHIpIHtcbiAgY29uc3QgdG9rZW5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3QgdG9rZW5zUkUgPSAvKFteXFxzLDs9XSspXFxzKig/Oj1cXHMqKFteLDtdKykpPy9nO1xuICBsZXQgbWF0Y2g7XG5cbiAgd2hpbGUgKChtYXRjaCA9IHRva2Vuc1JFLmV4ZWMoc3RyKSkpIHtcbiAgICB0b2tlbnNbbWF0Y2hbMV1dID0gbWF0Y2hbMl07XG4gIH1cblxuICByZXR1cm4gdG9rZW5zO1xufVxuXG5jb25zdCBpc1ZhbGlkSGVhZGVyTmFtZSA9IChzdHIpID0+IC9eWy1fYS16QS1aMC05XmB8fiwhIyQlJicqKy5dKyQvLnRlc3Qoc3RyLnRyaW0oKSk7XG5cbmZ1bmN0aW9uIG1hdGNoSGVhZGVyVmFsdWUoY29udGV4dCwgdmFsdWUsIGhlYWRlciwgZmlsdGVyLCBpc0hlYWRlck5hbWVGaWx0ZXIpIHtcbiAgaWYgKHV0aWxzLmlzRnVuY3Rpb24oZmlsdGVyKSkge1xuICAgIHJldHVybiBmaWx0ZXIuY2FsbCh0aGlzLCB2YWx1ZSwgaGVhZGVyKTtcbiAgfVxuXG4gIGlmIChpc0hlYWRlck5hbWVGaWx0ZXIpIHtcbiAgICB2YWx1ZSA9IGhlYWRlcjtcbiAgfVxuXG4gIGlmICghdXRpbHMuaXNTdHJpbmcodmFsdWUpKSByZXR1cm47XG5cbiAgaWYgKHV0aWxzLmlzU3RyaW5nKGZpbHRlcikpIHtcbiAgICByZXR1cm4gdmFsdWUuaW5kZXhPZihmaWx0ZXIpICE9PSAtMTtcbiAgfVxuXG4gIGlmICh1dGlscy5pc1JlZ0V4cChmaWx0ZXIpKSB7XG4gICAgcmV0dXJuIGZpbHRlci50ZXN0KHZhbHVlKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBmb3JtYXRIZWFkZXIoaGVhZGVyKSB7XG4gIHJldHVybiBoZWFkZXIudHJpbSgpXG4gICAgLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvKFthLXpcXGRdKShcXHcqKS9nLCAodywgY2hhciwgc3RyKSA9PiB7XG4gICAgICByZXR1cm4gY2hhci50b1VwcGVyQ2FzZSgpICsgc3RyO1xuICAgIH0pO1xufVxuXG5mdW5jdGlvbiBidWlsZEFjY2Vzc29ycyhvYmosIGhlYWRlcikge1xuICBjb25zdCBhY2Nlc3Nvck5hbWUgPSB1dGlscy50b0NhbWVsQ2FzZSgnICcgKyBoZWFkZXIpO1xuXG4gIFsnZ2V0JywgJ3NldCcsICdoYXMnXS5mb3JFYWNoKG1ldGhvZE5hbWUgPT4ge1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmosIG1ldGhvZE5hbWUgKyBhY2Nlc3Nvck5hbWUsIHtcbiAgICAgIHZhbHVlOiBmdW5jdGlvbihhcmcxLCBhcmcyLCBhcmczKSB7XG4gICAgICAgIHJldHVybiB0aGlzW21ldGhvZE5hbWVdLmNhbGwodGhpcywgaGVhZGVyLCBhcmcxLCBhcmcyLCBhcmczKTtcbiAgICAgIH0sXG4gICAgICBjb25maWd1cmFibGU6IHRydWVcbiAgICB9KTtcbiAgfSk7XG59XG5cbmNsYXNzIEF4aW9zSGVhZGVycyB7XG4gIGNvbnN0cnVjdG9yKGhlYWRlcnMpIHtcbiAgICBoZWFkZXJzICYmIHRoaXMuc2V0KGhlYWRlcnMpO1xuICB9XG5cbiAgc2V0KGhlYWRlciwgdmFsdWVPclJld3JpdGUsIHJld3JpdGUpIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcblxuICAgIGZ1bmN0aW9uIHNldEhlYWRlcihfdmFsdWUsIF9oZWFkZXIsIF9yZXdyaXRlKSB7XG4gICAgICBjb25zdCBsSGVhZGVyID0gbm9ybWFsaXplSGVhZGVyKF9oZWFkZXIpO1xuXG4gICAgICBpZiAoIWxIZWFkZXIpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdoZWFkZXIgbmFtZSBtdXN0IGJlIGEgbm9uLWVtcHR5IHN0cmluZycpO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBrZXkgPSB1dGlscy5maW5kS2V5KHNlbGYsIGxIZWFkZXIpO1xuXG4gICAgICBpZigha2V5IHx8IHNlbGZba2V5XSA9PT0gdW5kZWZpbmVkIHx8IF9yZXdyaXRlID09PSB0cnVlIHx8IChfcmV3cml0ZSA9PT0gdW5kZWZpbmVkICYmIHNlbGZba2V5XSAhPT0gZmFsc2UpKSB7XG4gICAgICAgIHNlbGZba2V5IHx8IF9oZWFkZXJdID0gbm9ybWFsaXplVmFsdWUoX3ZhbHVlKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCBzZXRIZWFkZXJzID0gKGhlYWRlcnMsIF9yZXdyaXRlKSA9PlxuICAgICAgdXRpbHMuZm9yRWFjaChoZWFkZXJzLCAoX3ZhbHVlLCBfaGVhZGVyKSA9PiBzZXRIZWFkZXIoX3ZhbHVlLCBfaGVhZGVyLCBfcmV3cml0ZSkpO1xuXG4gICAgaWYgKHV0aWxzLmlzUGxhaW5PYmplY3QoaGVhZGVyKSB8fCBoZWFkZXIgaW5zdGFuY2VvZiB0aGlzLmNvbnN0cnVjdG9yKSB7XG4gICAgICBzZXRIZWFkZXJzKGhlYWRlciwgdmFsdWVPclJld3JpdGUpXG4gICAgfSBlbHNlIGlmKHV0aWxzLmlzU3RyaW5nKGhlYWRlcikgJiYgKGhlYWRlciA9IGhlYWRlci50cmltKCkpICYmICFpc1ZhbGlkSGVhZGVyTmFtZShoZWFkZXIpKSB7XG4gICAgICBzZXRIZWFkZXJzKHBhcnNlSGVhZGVycyhoZWFkZXIpLCB2YWx1ZU9yUmV3cml0ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGhlYWRlciAhPSBudWxsICYmIHNldEhlYWRlcih2YWx1ZU9yUmV3cml0ZSwgaGVhZGVyLCByZXdyaXRlKTtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIGdldChoZWFkZXIsIHBhcnNlcikge1xuICAgIGhlYWRlciA9IG5vcm1hbGl6ZUhlYWRlcihoZWFkZXIpO1xuXG4gICAgaWYgKGhlYWRlcikge1xuICAgICAgY29uc3Qga2V5ID0gdXRpbHMuZmluZEtleSh0aGlzLCBoZWFkZXIpO1xuXG4gICAgICBpZiAoa2V5KSB7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gdGhpc1trZXldO1xuXG4gICAgICAgIGlmICghcGFyc2VyKSB7XG4gICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHBhcnNlciA9PT0gdHJ1ZSkge1xuICAgICAgICAgIHJldHVybiBwYXJzZVRva2Vucyh2YWx1ZSk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodXRpbHMuaXNGdW5jdGlvbihwYXJzZXIpKSB7XG4gICAgICAgICAgcmV0dXJuIHBhcnNlci5jYWxsKHRoaXMsIHZhbHVlLCBrZXkpO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHV0aWxzLmlzUmVnRXhwKHBhcnNlcikpIHtcbiAgICAgICAgICByZXR1cm4gcGFyc2VyLmV4ZWModmFsdWUpO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcigncGFyc2VyIG11c3QgYmUgYm9vbGVhbnxyZWdleHB8ZnVuY3Rpb24nKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBoYXMoaGVhZGVyLCBtYXRjaGVyKSB7XG4gICAgaGVhZGVyID0gbm9ybWFsaXplSGVhZGVyKGhlYWRlcik7XG5cbiAgICBpZiAoaGVhZGVyKSB7XG4gICAgICBjb25zdCBrZXkgPSB1dGlscy5maW5kS2V5KHRoaXMsIGhlYWRlcik7XG5cbiAgICAgIHJldHVybiAhIShrZXkgJiYgdGhpc1trZXldICE9PSB1bmRlZmluZWQgJiYgKCFtYXRjaGVyIHx8IG1hdGNoSGVhZGVyVmFsdWUodGhpcywgdGhpc1trZXldLCBrZXksIG1hdGNoZXIpKSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgZGVsZXRlKGhlYWRlciwgbWF0Y2hlcikge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgIGxldCBkZWxldGVkID0gZmFsc2U7XG5cbiAgICBmdW5jdGlvbiBkZWxldGVIZWFkZXIoX2hlYWRlcikge1xuICAgICAgX2hlYWRlciA9IG5vcm1hbGl6ZUhlYWRlcihfaGVhZGVyKTtcblxuICAgICAgaWYgKF9oZWFkZXIpIHtcbiAgICAgICAgY29uc3Qga2V5ID0gdXRpbHMuZmluZEtleShzZWxmLCBfaGVhZGVyKTtcblxuICAgICAgICBpZiAoa2V5ICYmICghbWF0Y2hlciB8fCBtYXRjaEhlYWRlclZhbHVlKHNlbGYsIHNlbGZba2V5XSwga2V5LCBtYXRjaGVyKSkpIHtcbiAgICAgICAgICBkZWxldGUgc2VsZltrZXldO1xuXG4gICAgICAgICAgZGVsZXRlZCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAodXRpbHMuaXNBcnJheShoZWFkZXIpKSB7XG4gICAgICBoZWFkZXIuZm9yRWFjaChkZWxldGVIZWFkZXIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBkZWxldGVIZWFkZXIoaGVhZGVyKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZGVsZXRlZDtcbiAgfVxuXG4gIGNsZWFyKG1hdGNoZXIpIHtcbiAgICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXModGhpcyk7XG4gICAgbGV0IGkgPSBrZXlzLmxlbmd0aDtcbiAgICBsZXQgZGVsZXRlZCA9IGZhbHNlO1xuXG4gICAgd2hpbGUgKGktLSkge1xuICAgICAgY29uc3Qga2V5ID0ga2V5c1tpXTtcbiAgICAgIGlmKCFtYXRjaGVyIHx8IG1hdGNoSGVhZGVyVmFsdWUodGhpcywgdGhpc1trZXldLCBrZXksIG1hdGNoZXIsIHRydWUpKSB7XG4gICAgICAgIGRlbGV0ZSB0aGlzW2tleV07XG4gICAgICAgIGRlbGV0ZWQgPSB0cnVlO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBkZWxldGVkO1xuICB9XG5cbiAgbm9ybWFsaXplKGZvcm1hdCkge1xuICAgIGNvbnN0IHNlbGYgPSB0aGlzO1xuICAgIGNvbnN0IGhlYWRlcnMgPSB7fTtcblxuICAgIHV0aWxzLmZvckVhY2godGhpcywgKHZhbHVlLCBoZWFkZXIpID0+IHtcbiAgICAgIGNvbnN0IGtleSA9IHV0aWxzLmZpbmRLZXkoaGVhZGVycywgaGVhZGVyKTtcblxuICAgICAgaWYgKGtleSkge1xuICAgICAgICBzZWxmW2tleV0gPSBub3JtYWxpemVWYWx1ZSh2YWx1ZSk7XG4gICAgICAgIGRlbGV0ZSBzZWxmW2hlYWRlcl07XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgY29uc3Qgbm9ybWFsaXplZCA9IGZvcm1hdCA/IGZvcm1hdEhlYWRlcihoZWFkZXIpIDogU3RyaW5nKGhlYWRlcikudHJpbSgpO1xuXG4gICAgICBpZiAobm9ybWFsaXplZCAhPT0gaGVhZGVyKSB7XG4gICAgICAgIGRlbGV0ZSBzZWxmW2hlYWRlcl07XG4gICAgICB9XG5cbiAgICAgIHNlbGZbbm9ybWFsaXplZF0gPSBub3JtYWxpemVWYWx1ZSh2YWx1ZSk7XG5cbiAgICAgIGhlYWRlcnNbbm9ybWFsaXplZF0gPSB0cnVlO1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICBjb25jYXQoLi4udGFyZ2V0cykge1xuICAgIHJldHVybiB0aGlzLmNvbnN0cnVjdG9yLmNvbmNhdCh0aGlzLCAuLi50YXJnZXRzKTtcbiAgfVxuXG4gIHRvSlNPTihhc1N0cmluZ3MpIHtcbiAgICBjb25zdCBvYmogPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXG4gICAgdXRpbHMuZm9yRWFjaCh0aGlzLCAodmFsdWUsIGhlYWRlcikgPT4ge1xuICAgICAgdmFsdWUgIT0gbnVsbCAmJiB2YWx1ZSAhPT0gZmFsc2UgJiYgKG9ialtoZWFkZXJdID0gYXNTdHJpbmdzICYmIHV0aWxzLmlzQXJyYXkodmFsdWUpID8gdmFsdWUuam9pbignLCAnKSA6IHZhbHVlKTtcbiAgICB9KTtcblxuICAgIHJldHVybiBvYmo7XG4gIH1cblxuICBbU3ltYm9sLml0ZXJhdG9yXSgpIHtcbiAgICByZXR1cm4gT2JqZWN0LmVudHJpZXModGhpcy50b0pTT04oKSlbU3ltYm9sLml0ZXJhdG9yXSgpO1xuICB9XG5cbiAgdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHRoaXMudG9KU09OKCkpLm1hcCgoW2hlYWRlciwgdmFsdWVdKSA9PiBoZWFkZXIgKyAnOiAnICsgdmFsdWUpLmpvaW4oJ1xcbicpO1xuICB9XG5cbiAgZ2V0IFtTeW1ib2wudG9TdHJpbmdUYWddKCkge1xuICAgIHJldHVybiAnQXhpb3NIZWFkZXJzJztcbiAgfVxuXG4gIHN0YXRpYyBmcm9tKHRoaW5nKSB7XG4gICAgcmV0dXJuIHRoaW5nIGluc3RhbmNlb2YgdGhpcyA/IHRoaW5nIDogbmV3IHRoaXModGhpbmcpO1xuICB9XG5cbiAgc3RhdGljIGNvbmNhdChmaXJzdCwgLi4udGFyZ2V0cykge1xuICAgIGNvbnN0IGNvbXB1dGVkID0gbmV3IHRoaXMoZmlyc3QpO1xuXG4gICAgdGFyZ2V0cy5mb3JFYWNoKCh0YXJnZXQpID0+IGNvbXB1dGVkLnNldCh0YXJnZXQpKTtcblxuICAgIHJldHVybiBjb21wdXRlZDtcbiAgfVxuXG4gIHN0YXRpYyBhY2Nlc3NvcihoZWFkZXIpIHtcbiAgICBjb25zdCBpbnRlcm5hbHMgPSB0aGlzWyRpbnRlcm5hbHNdID0gKHRoaXNbJGludGVybmFsc10gPSB7XG4gICAgICBhY2Nlc3NvcnM6IHt9XG4gICAgfSk7XG5cbiAgICBjb25zdCBhY2Nlc3NvcnMgPSBpbnRlcm5hbHMuYWNjZXNzb3JzO1xuICAgIGNvbnN0IHByb3RvdHlwZSA9IHRoaXMucHJvdG90eXBlO1xuXG4gICAgZnVuY3Rpb24gZGVmaW5lQWNjZXNzb3IoX2hlYWRlcikge1xuICAgICAgY29uc3QgbEhlYWRlciA9IG5vcm1hbGl6ZUhlYWRlcihfaGVhZGVyKTtcblxuICAgICAgaWYgKCFhY2Nlc3NvcnNbbEhlYWRlcl0pIHtcbiAgICAgICAgYnVpbGRBY2Nlc3NvcnMocHJvdG90eXBlLCBfaGVhZGVyKTtcbiAgICAgICAgYWNjZXNzb3JzW2xIZWFkZXJdID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICB1dGlscy5pc0FycmF5KGhlYWRlcikgPyBoZWFkZXIuZm9yRWFjaChkZWZpbmVBY2Nlc3NvcikgOiBkZWZpbmVBY2Nlc3NvcihoZWFkZXIpO1xuXG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbn1cblxuQXhpb3NIZWFkZXJzLmFjY2Vzc29yKFsnQ29udGVudC1UeXBlJywgJ0NvbnRlbnQtTGVuZ3RoJywgJ0FjY2VwdCcsICdBY2NlcHQtRW5jb2RpbmcnLCAnVXNlci1BZ2VudCcsICdBdXRob3JpemF0aW9uJ10pO1xuXG4vLyByZXNlcnZlZCBuYW1lcyBob3RmaXhcbnV0aWxzLnJlZHVjZURlc2NyaXB0b3JzKEF4aW9zSGVhZGVycy5wcm90b3R5cGUsICh7dmFsdWV9LCBrZXkpID0+IHtcbiAgbGV0IG1hcHBlZCA9IGtleVswXS50b1VwcGVyQ2FzZSgpICsga2V5LnNsaWNlKDEpOyAvLyBtYXAgYHNldGAgPT4gYFNldGBcbiAgcmV0dXJuIHtcbiAgICBnZXQ6ICgpID0+IHZhbHVlLFxuICAgIHNldChoZWFkZXJWYWx1ZSkge1xuICAgICAgdGhpc1ttYXBwZWRdID0gaGVhZGVyVmFsdWU7XG4gICAgfVxuICB9XG59KTtcblxudXRpbHMuZnJlZXplTWV0aG9kcyhBeGlvc0hlYWRlcnMpO1xuXG5leHBvcnQgZGVmYXVsdCBBeGlvc0hlYWRlcnM7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLy4uL3V0aWxzLmpzJztcblxuLy8gUmF3QXhpb3NIZWFkZXJzIHdob3NlIGR1cGxpY2F0ZXMgYXJlIGlnbm9yZWQgYnkgbm9kZVxuLy8gYy5mLiBodHRwczovL25vZGVqcy5vcmcvYXBpL2h0dHAuaHRtbCNodHRwX21lc3NhZ2VfaGVhZGVyc1xuY29uc3QgaWdub3JlRHVwbGljYXRlT2YgPSB1dGlscy50b09iamVjdFNldChbXG4gICdhZ2UnLCAnYXV0aG9yaXphdGlvbicsICdjb250ZW50LWxlbmd0aCcsICdjb250ZW50LXR5cGUnLCAnZXRhZycsXG4gICdleHBpcmVzJywgJ2Zyb20nLCAnaG9zdCcsICdpZi1tb2RpZmllZC1zaW5jZScsICdpZi11bm1vZGlmaWVkLXNpbmNlJyxcbiAgJ2xhc3QtbW9kaWZpZWQnLCAnbG9jYXRpb24nLCAnbWF4LWZvcndhcmRzJywgJ3Byb3h5LWF1dGhvcml6YXRpb24nLFxuICAncmVmZXJlcicsICdyZXRyeS1hZnRlcicsICd1c2VyLWFnZW50J1xuXSk7XG5cbi8qKlxuICogUGFyc2UgaGVhZGVycyBpbnRvIGFuIG9iamVjdFxuICpcbiAqIGBgYFxuICogRGF0ZTogV2VkLCAyNyBBdWcgMjAxNCAwODo1ODo0OSBHTVRcbiAqIENvbnRlbnQtVHlwZTogYXBwbGljYXRpb24vanNvblxuICogQ29ubmVjdGlvbjoga2VlcC1hbGl2ZVxuICogVHJhbnNmZXItRW5jb2Rpbmc6IGNodW5rZWRcbiAqIGBgYFxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSByYXdIZWFkZXJzIEhlYWRlcnMgbmVlZGluZyB0byBiZSBwYXJzZWRcbiAqXG4gKiBAcmV0dXJucyB7T2JqZWN0fSBIZWFkZXJzIHBhcnNlZCBpbnRvIGFuIG9iamVjdFxuICovXG5leHBvcnQgZGVmYXVsdCByYXdIZWFkZXJzID0+IHtcbiAgY29uc3QgcGFyc2VkID0ge307XG4gIGxldCBrZXk7XG4gIGxldCB2YWw7XG4gIGxldCBpO1xuXG4gIHJhd0hlYWRlcnMgJiYgcmF3SGVhZGVycy5zcGxpdCgnXFxuJykuZm9yRWFjaChmdW5jdGlvbiBwYXJzZXIobGluZSkge1xuICAgIGkgPSBsaW5lLmluZGV4T2YoJzonKTtcbiAgICBrZXkgPSBsaW5lLnN1YnN0cmluZygwLCBpKS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICB2YWwgPSBsaW5lLnN1YnN0cmluZyhpICsgMSkudHJpbSgpO1xuXG4gICAgaWYgKCFrZXkgfHwgKHBhcnNlZFtrZXldICYmIGlnbm9yZUR1cGxpY2F0ZU9mW2tleV0pKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKGtleSA9PT0gJ3NldC1jb29raWUnKSB7XG4gICAgICBpZiAocGFyc2VkW2tleV0pIHtcbiAgICAgICAgcGFyc2VkW2tleV0ucHVzaCh2YWwpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcGFyc2VkW2tleV0gPSBbdmFsXTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgcGFyc2VkW2tleV0gPSBwYXJzZWRba2V5XSA/IHBhcnNlZFtrZXldICsgJywgJyArIHZhbCA6IHZhbDtcbiAgICB9XG4gIH0pO1xuXG4gIHJldHVybiBwYXJzZWQ7XG59O1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBpc0NhbmNlbCh2YWx1ZSkge1xuICByZXR1cm4gISEodmFsdWUgJiYgdmFsdWUuX19DQU5DRUxfXyk7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgdXRpbHMgZnJvbSAnLi4vdXRpbHMuanMnO1xuXG4vKipcbiAqIEEgYENhbmNlbGVkRXJyb3JgIGlzIGFuIG9iamVjdCB0aGF0IGlzIHRocm93biB3aGVuIGFuIG9wZXJhdGlvbiBpcyBjYW5jZWxlZC5cbiAqXG4gKiBAcGFyYW0ge3N0cmluZz19IG1lc3NhZ2UgVGhlIG1lc3NhZ2UuXG4gKiBAcGFyYW0ge09iamVjdD19IGNvbmZpZyBUaGUgY29uZmlnLlxuICogQHBhcmFtIHtPYmplY3Q9fSByZXF1ZXN0IFRoZSByZXF1ZXN0LlxuICpcbiAqIEByZXR1cm5zIHtDYW5jZWxlZEVycm9yfSBUaGUgY3JlYXRlZCBlcnJvci5cbiAqL1xuZnVuY3Rpb24gQ2FuY2VsZWRFcnJvcihtZXNzYWdlLCBjb25maWcsIHJlcXVlc3QpIHtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWVxLW51bGwsZXFlcWVxXG4gIEF4aW9zRXJyb3IuY2FsbCh0aGlzLCBtZXNzYWdlID09IG51bGwgPyAnY2FuY2VsZWQnIDogbWVzc2FnZSwgQXhpb3NFcnJvci5FUlJfQ0FOQ0VMRUQsIGNvbmZpZywgcmVxdWVzdCk7XG4gIHRoaXMubmFtZSA9ICdDYW5jZWxlZEVycm9yJztcbn1cblxudXRpbHMuaW5oZXJpdHMoQ2FuY2VsZWRFcnJvciwgQXhpb3NFcnJvciwge1xuICBfX0NBTkNFTF9fOiB0cnVlXG59KTtcblxuZXhwb3J0IGRlZmF1bHQgQ2FuY2VsZWRFcnJvcjtcbiIsImltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgaHR0cEFkYXB0ZXIgZnJvbSAnLi9odHRwLmpzJztcbmltcG9ydCB4aHJBZGFwdGVyIGZyb20gJy4veGhyLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gXCIuLi9jb3JlL0F4aW9zRXJyb3IuanNcIjtcblxuY29uc3Qga25vd25BZGFwdGVycyA9IHtcbiAgaHR0cDogaHR0cEFkYXB0ZXIsXG4gIHhocjogeGhyQWRhcHRlclxufVxuXG51dGlscy5mb3JFYWNoKGtub3duQWRhcHRlcnMsIChmbiwgdmFsdWUpID0+IHtcbiAgaWYgKGZuKSB7XG4gICAgdHJ5IHtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShmbiwgJ25hbWUnLCB7dmFsdWV9KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tZW1wdHlcbiAgICB9XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGZuLCAnYWRhcHRlck5hbWUnLCB7dmFsdWV9KTtcbiAgfVxufSk7XG5cbmNvbnN0IHJlbmRlclJlYXNvbiA9IChyZWFzb24pID0+IGAtICR7cmVhc29ufWA7XG5cbmNvbnN0IGlzUmVzb2x2ZWRIYW5kbGUgPSAoYWRhcHRlcikgPT4gdXRpbHMuaXNGdW5jdGlvbihhZGFwdGVyKSB8fCBhZGFwdGVyID09PSBudWxsIHx8IGFkYXB0ZXIgPT09IGZhbHNlO1xuXG5leHBvcnQgZGVmYXVsdCB7XG4gIGdldEFkYXB0ZXI6IChhZGFwdGVycykgPT4ge1xuICAgIGFkYXB0ZXJzID0gdXRpbHMuaXNBcnJheShhZGFwdGVycykgPyBhZGFwdGVycyA6IFthZGFwdGVyc107XG5cbiAgICBjb25zdCB7bGVuZ3RofSA9IGFkYXB0ZXJzO1xuICAgIGxldCBuYW1lT3JBZGFwdGVyO1xuICAgIGxldCBhZGFwdGVyO1xuXG4gICAgY29uc3QgcmVqZWN0ZWRSZWFzb25zID0ge307XG5cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKSB7XG4gICAgICBuYW1lT3JBZGFwdGVyID0gYWRhcHRlcnNbaV07XG4gICAgICBsZXQgaWQ7XG5cbiAgICAgIGFkYXB0ZXIgPSBuYW1lT3JBZGFwdGVyO1xuXG4gICAgICBpZiAoIWlzUmVzb2x2ZWRIYW5kbGUobmFtZU9yQWRhcHRlcikpIHtcbiAgICAgICAgYWRhcHRlciA9IGtub3duQWRhcHRlcnNbKGlkID0gU3RyaW5nKG5hbWVPckFkYXB0ZXIpKS50b0xvd2VyQ2FzZSgpXTtcblxuICAgICAgICBpZiAoYWRhcHRlciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoYFVua25vd24gYWRhcHRlciAnJHtpZH0nYCk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKGFkYXB0ZXIpIHtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG5cbiAgICAgIHJlamVjdGVkUmVhc29uc1tpZCB8fCAnIycgKyBpXSA9IGFkYXB0ZXI7XG4gICAgfVxuXG4gICAgaWYgKCFhZGFwdGVyKSB7XG5cbiAgICAgIGNvbnN0IHJlYXNvbnMgPSBPYmplY3QuZW50cmllcyhyZWplY3RlZFJlYXNvbnMpXG4gICAgICAgIC5tYXAoKFtpZCwgc3RhdGVdKSA9PiBgYWRhcHRlciAke2lkfSBgICtcbiAgICAgICAgICAoc3RhdGUgPT09IGZhbHNlID8gJ2lzIG5vdCBzdXBwb3J0ZWQgYnkgdGhlIGVudmlyb25tZW50JyA6ICdpcyBub3QgYXZhaWxhYmxlIGluIHRoZSBidWlsZCcpXG4gICAgICAgICk7XG5cbiAgICAgIGxldCBzID0gbGVuZ3RoID9cbiAgICAgICAgKHJlYXNvbnMubGVuZ3RoID4gMSA/ICdzaW5jZSA6XFxuJyArIHJlYXNvbnMubWFwKHJlbmRlclJlYXNvbikuam9pbignXFxuJykgOiAnICcgKyByZW5kZXJSZWFzb24ocmVhc29uc1swXSkpIDpcbiAgICAgICAgJ2FzIG5vIGFkYXB0ZXIgc3BlY2lmaWVkJztcblxuICAgICAgdGhyb3cgbmV3IEF4aW9zRXJyb3IoXG4gICAgICAgIGBUaGVyZSBpcyBubyBzdWl0YWJsZSBhZGFwdGVyIHRvIGRpc3BhdGNoIHRoZSByZXF1ZXN0IGAgKyBzLFxuICAgICAgICAnRVJSX05PVF9TVVBQT1JUJ1xuICAgICAgKTtcbiAgICB9XG5cbiAgICByZXR1cm4gYWRhcHRlcjtcbiAgfSxcbiAgYWRhcHRlcnM6IGtub3duQWRhcHRlcnNcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IHV0aWxzIGZyb20gJy4vLi4vdXRpbHMuanMnO1xuaW1wb3J0IHNldHRsZSBmcm9tICcuLy4uL2NvcmUvc2V0dGxlLmpzJztcbmltcG9ydCBjb29raWVzIGZyb20gJy4vLi4vaGVscGVycy9jb29raWVzLmpzJztcbmltcG9ydCBidWlsZFVSTCBmcm9tICcuLy4uL2hlbHBlcnMvYnVpbGRVUkwuanMnO1xuaW1wb3J0IGJ1aWxkRnVsbFBhdGggZnJvbSAnLi4vY29yZS9idWlsZEZ1bGxQYXRoLmpzJztcbmltcG9ydCBpc1VSTFNhbWVPcmlnaW4gZnJvbSAnLi8uLi9oZWxwZXJzL2lzVVJMU2FtZU9yaWdpbi5qcyc7XG5pbXBvcnQgdHJhbnNpdGlvbmFsRGVmYXVsdHMgZnJvbSAnLi4vZGVmYXVsdHMvdHJhbnNpdGlvbmFsLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5pbXBvcnQgQ2FuY2VsZWRFcnJvciBmcm9tICcuLi9jYW5jZWwvQ2FuY2VsZWRFcnJvci5qcyc7XG5pbXBvcnQgcGFyc2VQcm90b2NvbCBmcm9tICcuLi9oZWxwZXJzL3BhcnNlUHJvdG9jb2wuanMnO1xuaW1wb3J0IHBsYXRmb3JtIGZyb20gJy4uL3BsYXRmb3JtL2luZGV4LmpzJztcbmltcG9ydCBBeGlvc0hlYWRlcnMgZnJvbSAnLi4vY29yZS9BeGlvc0hlYWRlcnMuanMnO1xuaW1wb3J0IHNwZWVkb21ldGVyIGZyb20gJy4uL2hlbHBlcnMvc3BlZWRvbWV0ZXIuanMnO1xuXG5mdW5jdGlvbiBwcm9ncmVzc0V2ZW50UmVkdWNlcihsaXN0ZW5lciwgaXNEb3dubG9hZFN0cmVhbSkge1xuICBsZXQgYnl0ZXNOb3RpZmllZCA9IDA7XG4gIGNvbnN0IF9zcGVlZG9tZXRlciA9IHNwZWVkb21ldGVyKDUwLCAyNTApO1xuXG4gIHJldHVybiBlID0+IHtcbiAgICBjb25zdCBsb2FkZWQgPSBlLmxvYWRlZDtcbiAgICBjb25zdCB0b3RhbCA9IGUubGVuZ3RoQ29tcHV0YWJsZSA/IGUudG90YWwgOiB1bmRlZmluZWQ7XG4gICAgY29uc3QgcHJvZ3Jlc3NCeXRlcyA9IGxvYWRlZCAtIGJ5dGVzTm90aWZpZWQ7XG4gICAgY29uc3QgcmF0ZSA9IF9zcGVlZG9tZXRlcihwcm9ncmVzc0J5dGVzKTtcbiAgICBjb25zdCBpblJhbmdlID0gbG9hZGVkIDw9IHRvdGFsO1xuXG4gICAgYnl0ZXNOb3RpZmllZCA9IGxvYWRlZDtcblxuICAgIGNvbnN0IGRhdGEgPSB7XG4gICAgICBsb2FkZWQsXG4gICAgICB0b3RhbCxcbiAgICAgIHByb2dyZXNzOiB0b3RhbCA/IChsb2FkZWQgLyB0b3RhbCkgOiB1bmRlZmluZWQsXG4gICAgICBieXRlczogcHJvZ3Jlc3NCeXRlcyxcbiAgICAgIHJhdGU6IHJhdGUgPyByYXRlIDogdW5kZWZpbmVkLFxuICAgICAgZXN0aW1hdGVkOiByYXRlICYmIHRvdGFsICYmIGluUmFuZ2UgPyAodG90YWwgLSBsb2FkZWQpIC8gcmF0ZSA6IHVuZGVmaW5lZCxcbiAgICAgIGV2ZW50OiBlXG4gICAgfTtcblxuICAgIGRhdGFbaXNEb3dubG9hZFN0cmVhbSA/ICdkb3dubG9hZCcgOiAndXBsb2FkJ10gPSB0cnVlO1xuXG4gICAgbGlzdGVuZXIoZGF0YSk7XG4gIH07XG59XG5cbmNvbnN0IGlzWEhSQWRhcHRlclN1cHBvcnRlZCA9IHR5cGVvZiBYTUxIdHRwUmVxdWVzdCAhPT0gJ3VuZGVmaW5lZCc7XG5cbmV4cG9ydCBkZWZhdWx0IGlzWEhSQWRhcHRlclN1cHBvcnRlZCAmJiBmdW5jdGlvbiAoY29uZmlnKSB7XG4gIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiBkaXNwYXRjaFhoclJlcXVlc3QocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgbGV0IHJlcXVlc3REYXRhID0gY29uZmlnLmRhdGE7XG4gICAgY29uc3QgcmVxdWVzdEhlYWRlcnMgPSBBeGlvc0hlYWRlcnMuZnJvbShjb25maWcuaGVhZGVycykubm9ybWFsaXplKCk7XG4gICAgbGV0IHtyZXNwb25zZVR5cGUsIHdpdGhYU1JGVG9rZW59ID0gY29uZmlnO1xuICAgIGxldCBvbkNhbmNlbGVkO1xuICAgIGZ1bmN0aW9uIGRvbmUoKSB7XG4gICAgICBpZiAoY29uZmlnLmNhbmNlbFRva2VuKSB7XG4gICAgICAgIGNvbmZpZy5jYW5jZWxUb2tlbi51bnN1YnNjcmliZShvbkNhbmNlbGVkKTtcbiAgICAgIH1cblxuICAgICAgaWYgKGNvbmZpZy5zaWduYWwpIHtcbiAgICAgICAgY29uZmlnLnNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKCdhYm9ydCcsIG9uQ2FuY2VsZWQpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGxldCBjb250ZW50VHlwZTtcblxuICAgIGlmICh1dGlscy5pc0Zvcm1EYXRhKHJlcXVlc3REYXRhKSkge1xuICAgICAgaWYgKHBsYXRmb3JtLmhhc1N0YW5kYXJkQnJvd3NlckVudiB8fCBwbGF0Zm9ybS5oYXNTdGFuZGFyZEJyb3dzZXJXZWJXb3JrZXJFbnYpIHtcbiAgICAgICAgcmVxdWVzdEhlYWRlcnMuc2V0Q29udGVudFR5cGUoZmFsc2UpOyAvLyBMZXQgdGhlIGJyb3dzZXIgc2V0IGl0XG4gICAgICB9IGVsc2UgaWYgKChjb250ZW50VHlwZSA9IHJlcXVlc3RIZWFkZXJzLmdldENvbnRlbnRUeXBlKCkpICE9PSBmYWxzZSkge1xuICAgICAgICAvLyBmaXggc2VtaWNvbG9uIGR1cGxpY2F0aW9uIGlzc3VlIGZvciBSZWFjdE5hdGl2ZSBGb3JtRGF0YSBpbXBsZW1lbnRhdGlvblxuICAgICAgICBjb25zdCBbdHlwZSwgLi4udG9rZW5zXSA9IGNvbnRlbnRUeXBlID8gY29udGVudFR5cGUuc3BsaXQoJzsnKS5tYXAodG9rZW4gPT4gdG9rZW4udHJpbSgpKS5maWx0ZXIoQm9vbGVhbikgOiBbXTtcbiAgICAgICAgcmVxdWVzdEhlYWRlcnMuc2V0Q29udGVudFR5cGUoW3R5cGUgfHwgJ211bHRpcGFydC9mb3JtLWRhdGEnLCAuLi50b2tlbnNdLmpvaW4oJzsgJykpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGxldCByZXF1ZXN0ID0gbmV3IFhNTEh0dHBSZXF1ZXN0KCk7XG5cbiAgICAvLyBIVFRQIGJhc2ljIGF1dGhlbnRpY2F0aW9uXG4gICAgaWYgKGNvbmZpZy5hdXRoKSB7XG4gICAgICBjb25zdCB1c2VybmFtZSA9IGNvbmZpZy5hdXRoLnVzZXJuYW1lIHx8ICcnO1xuICAgICAgY29uc3QgcGFzc3dvcmQgPSBjb25maWcuYXV0aC5wYXNzd29yZCA/IHVuZXNjYXBlKGVuY29kZVVSSUNvbXBvbmVudChjb25maWcuYXV0aC5wYXNzd29yZCkpIDogJyc7XG4gICAgICByZXF1ZXN0SGVhZGVycy5zZXQoJ0F1dGhvcml6YXRpb24nLCAnQmFzaWMgJyArIGJ0b2EodXNlcm5hbWUgKyAnOicgKyBwYXNzd29yZCkpO1xuICAgIH1cblxuICAgIGNvbnN0IGZ1bGxQYXRoID0gYnVpbGRGdWxsUGF0aChjb25maWcuYmFzZVVSTCwgY29uZmlnLnVybCk7XG5cbiAgICByZXF1ZXN0Lm9wZW4oY29uZmlnLm1ldGhvZC50b1VwcGVyQ2FzZSgpLCBidWlsZFVSTChmdWxsUGF0aCwgY29uZmlnLnBhcmFtcywgY29uZmlnLnBhcmFtc1NlcmlhbGl6ZXIpLCB0cnVlKTtcblxuICAgIC8vIFNldCB0aGUgcmVxdWVzdCB0aW1lb3V0IGluIE1TXG4gICAgcmVxdWVzdC50aW1lb3V0ID0gY29uZmlnLnRpbWVvdXQ7XG5cbiAgICBmdW5jdGlvbiBvbmxvYWRlbmQoKSB7XG4gICAgICBpZiAoIXJlcXVlc3QpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgLy8gUHJlcGFyZSB0aGUgcmVzcG9uc2VcbiAgICAgIGNvbnN0IHJlc3BvbnNlSGVhZGVycyA9IEF4aW9zSGVhZGVycy5mcm9tKFxuICAgICAgICAnZ2V0QWxsUmVzcG9uc2VIZWFkZXJzJyBpbiByZXF1ZXN0ICYmIHJlcXVlc3QuZ2V0QWxsUmVzcG9uc2VIZWFkZXJzKClcbiAgICAgICk7XG4gICAgICBjb25zdCByZXNwb25zZURhdGEgPSAhcmVzcG9uc2VUeXBlIHx8IHJlc3BvbnNlVHlwZSA9PT0gJ3RleHQnIHx8IHJlc3BvbnNlVHlwZSA9PT0gJ2pzb24nID9cbiAgICAgICAgcmVxdWVzdC5yZXNwb25zZVRleHQgOiByZXF1ZXN0LnJlc3BvbnNlO1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSB7XG4gICAgICAgIGRhdGE6IHJlc3BvbnNlRGF0YSxcbiAgICAgICAgc3RhdHVzOiByZXF1ZXN0LnN0YXR1cyxcbiAgICAgICAgc3RhdHVzVGV4dDogcmVxdWVzdC5zdGF0dXNUZXh0LFxuICAgICAgICBoZWFkZXJzOiByZXNwb25zZUhlYWRlcnMsXG4gICAgICAgIGNvbmZpZyxcbiAgICAgICAgcmVxdWVzdFxuICAgICAgfTtcblxuICAgICAgc2V0dGxlKGZ1bmN0aW9uIF9yZXNvbHZlKHZhbHVlKSB7XG4gICAgICAgIHJlc29sdmUodmFsdWUpO1xuICAgICAgICBkb25lKCk7XG4gICAgICB9LCBmdW5jdGlvbiBfcmVqZWN0KGVycikge1xuICAgICAgICByZWplY3QoZXJyKTtcbiAgICAgICAgZG9uZSgpO1xuICAgICAgfSwgcmVzcG9uc2UpO1xuXG4gICAgICAvLyBDbGVhbiB1cCByZXF1ZXN0XG4gICAgICByZXF1ZXN0ID0gbnVsbDtcbiAgICB9XG5cbiAgICBpZiAoJ29ubG9hZGVuZCcgaW4gcmVxdWVzdCkge1xuICAgICAgLy8gVXNlIG9ubG9hZGVuZCBpZiBhdmFpbGFibGVcbiAgICAgIHJlcXVlc3Qub25sb2FkZW5kID0gb25sb2FkZW5kO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBMaXN0ZW4gZm9yIHJlYWR5IHN0YXRlIHRvIGVtdWxhdGUgb25sb2FkZW5kXG4gICAgICByZXF1ZXN0Lm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uIGhhbmRsZUxvYWQoKSB7XG4gICAgICAgIGlmICghcmVxdWVzdCB8fCByZXF1ZXN0LnJlYWR5U3RhdGUgIT09IDQpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBUaGUgcmVxdWVzdCBlcnJvcmVkIG91dCBhbmQgd2UgZGlkbid0IGdldCBhIHJlc3BvbnNlLCB0aGlzIHdpbGwgYmVcbiAgICAgICAgLy8gaGFuZGxlZCBieSBvbmVycm9yIGluc3RlYWRcbiAgICAgICAgLy8gV2l0aCBvbmUgZXhjZXB0aW9uOiByZXF1ZXN0IHRoYXQgdXNpbmcgZmlsZTogcHJvdG9jb2wsIG1vc3QgYnJvd3NlcnNcbiAgICAgICAgLy8gd2lsbCByZXR1cm4gc3RhdHVzIGFzIDAgZXZlbiB0aG91Z2ggaXQncyBhIHN1Y2Nlc3NmdWwgcmVxdWVzdFxuICAgICAgICBpZiAocmVxdWVzdC5zdGF0dXMgPT09IDAgJiYgIShyZXF1ZXN0LnJlc3BvbnNlVVJMICYmIHJlcXVlc3QucmVzcG9uc2VVUkwuaW5kZXhPZignZmlsZTonKSA9PT0gMCkpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gcmVhZHlzdGF0ZSBoYW5kbGVyIGlzIGNhbGxpbmcgYmVmb3JlIG9uZXJyb3Igb3Igb250aW1lb3V0IGhhbmRsZXJzLFxuICAgICAgICAvLyBzbyB3ZSBzaG91bGQgY2FsbCBvbmxvYWRlbmQgb24gdGhlIG5leHQgJ3RpY2snXG4gICAgICAgIHNldFRpbWVvdXQob25sb2FkZW5kKTtcbiAgICAgIH07XG4gICAgfVxuXG4gICAgLy8gSGFuZGxlIGJyb3dzZXIgcmVxdWVzdCBjYW5jZWxsYXRpb24gKGFzIG9wcG9zZWQgdG8gYSBtYW51YWwgY2FuY2VsbGF0aW9uKVxuICAgIHJlcXVlc3Qub25hYm9ydCA9IGZ1bmN0aW9uIGhhbmRsZUFib3J0KCkge1xuICAgICAgaWYgKCFyZXF1ZXN0KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgcmVqZWN0KG5ldyBBeGlvc0Vycm9yKCdSZXF1ZXN0IGFib3J0ZWQnLCBBeGlvc0Vycm9yLkVDT05OQUJPUlRFRCwgY29uZmlnLCByZXF1ZXN0KSk7XG5cbiAgICAgIC8vIENsZWFuIHVwIHJlcXVlc3RcbiAgICAgIHJlcXVlc3QgPSBudWxsO1xuICAgIH07XG5cbiAgICAvLyBIYW5kbGUgbG93IGxldmVsIG5ldHdvcmsgZXJyb3JzXG4gICAgcmVxdWVzdC5vbmVycm9yID0gZnVuY3Rpb24gaGFuZGxlRXJyb3IoKSB7XG4gICAgICAvLyBSZWFsIGVycm9ycyBhcmUgaGlkZGVuIGZyb20gdXMgYnkgdGhlIGJyb3dzZXJcbiAgICAgIC8vIG9uZXJyb3Igc2hvdWxkIG9ubHkgZmlyZSBpZiBpdCdzIGEgbmV0d29yayBlcnJvclxuICAgICAgcmVqZWN0KG5ldyBBeGlvc0Vycm9yKCdOZXR3b3JrIEVycm9yJywgQXhpb3NFcnJvci5FUlJfTkVUV09SSywgY29uZmlnLCByZXF1ZXN0KSk7XG5cbiAgICAgIC8vIENsZWFuIHVwIHJlcXVlc3RcbiAgICAgIHJlcXVlc3QgPSBudWxsO1xuICAgIH07XG5cbiAgICAvLyBIYW5kbGUgdGltZW91dFxuICAgIHJlcXVlc3Qub250aW1lb3V0ID0gZnVuY3Rpb24gaGFuZGxlVGltZW91dCgpIHtcbiAgICAgIGxldCB0aW1lb3V0RXJyb3JNZXNzYWdlID0gY29uZmlnLnRpbWVvdXQgPyAndGltZW91dCBvZiAnICsgY29uZmlnLnRpbWVvdXQgKyAnbXMgZXhjZWVkZWQnIDogJ3RpbWVvdXQgZXhjZWVkZWQnO1xuICAgICAgY29uc3QgdHJhbnNpdGlvbmFsID0gY29uZmlnLnRyYW5zaXRpb25hbCB8fCB0cmFuc2l0aW9uYWxEZWZhdWx0cztcbiAgICAgIGlmIChjb25maWcudGltZW91dEVycm9yTWVzc2FnZSkge1xuICAgICAgICB0aW1lb3V0RXJyb3JNZXNzYWdlID0gY29uZmlnLnRpbWVvdXRFcnJvck1lc3NhZ2U7XG4gICAgICB9XG4gICAgICByZWplY3QobmV3IEF4aW9zRXJyb3IoXG4gICAgICAgIHRpbWVvdXRFcnJvck1lc3NhZ2UsXG4gICAgICAgIHRyYW5zaXRpb25hbC5jbGFyaWZ5VGltZW91dEVycm9yID8gQXhpb3NFcnJvci5FVElNRURPVVQgOiBBeGlvc0Vycm9yLkVDT05OQUJPUlRFRCxcbiAgICAgICAgY29uZmlnLFxuICAgICAgICByZXF1ZXN0KSk7XG5cbiAgICAgIC8vIENsZWFuIHVwIHJlcXVlc3RcbiAgICAgIHJlcXVlc3QgPSBudWxsO1xuICAgIH07XG5cbiAgICAvLyBBZGQgeHNyZiBoZWFkZXJcbiAgICAvLyBUaGlzIGlzIG9ubHkgZG9uZSBpZiBydW5uaW5nIGluIGEgc3RhbmRhcmQgYnJvd3NlciBlbnZpcm9ubWVudC5cbiAgICAvLyBTcGVjaWZpY2FsbHkgbm90IGlmIHdlJ3JlIGluIGEgd2ViIHdvcmtlciwgb3IgcmVhY3QtbmF0aXZlLlxuICAgIGlmKHBsYXRmb3JtLmhhc1N0YW5kYXJkQnJvd3NlckVudikge1xuICAgICAgd2l0aFhTUkZUb2tlbiAmJiB1dGlscy5pc0Z1bmN0aW9uKHdpdGhYU1JGVG9rZW4pICYmICh3aXRoWFNSRlRva2VuID0gd2l0aFhTUkZUb2tlbihjb25maWcpKTtcblxuICAgICAgaWYgKHdpdGhYU1JGVG9rZW4gfHwgKHdpdGhYU1JGVG9rZW4gIT09IGZhbHNlICYmIGlzVVJMU2FtZU9yaWdpbihmdWxsUGF0aCkpKSB7XG4gICAgICAgIC8vIEFkZCB4c3JmIGhlYWRlclxuICAgICAgICBjb25zdCB4c3JmVmFsdWUgPSBjb25maWcueHNyZkhlYWRlck5hbWUgJiYgY29uZmlnLnhzcmZDb29raWVOYW1lICYmIGNvb2tpZXMucmVhZChjb25maWcueHNyZkNvb2tpZU5hbWUpO1xuXG4gICAgICAgIGlmICh4c3JmVmFsdWUpIHtcbiAgICAgICAgICByZXF1ZXN0SGVhZGVycy5zZXQoY29uZmlnLnhzcmZIZWFkZXJOYW1lLCB4c3JmVmFsdWUpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gUmVtb3ZlIENvbnRlbnQtVHlwZSBpZiBkYXRhIGlzIHVuZGVmaW5lZFxuICAgIHJlcXVlc3REYXRhID09PSB1bmRlZmluZWQgJiYgcmVxdWVzdEhlYWRlcnMuc2V0Q29udGVudFR5cGUobnVsbCk7XG5cbiAgICAvLyBBZGQgaGVhZGVycyB0byB0aGUgcmVxdWVzdFxuICAgIGlmICgnc2V0UmVxdWVzdEhlYWRlcicgaW4gcmVxdWVzdCkge1xuICAgICAgdXRpbHMuZm9yRWFjaChyZXF1ZXN0SGVhZGVycy50b0pTT04oKSwgZnVuY3Rpb24gc2V0UmVxdWVzdEhlYWRlcih2YWwsIGtleSkge1xuICAgICAgICByZXF1ZXN0LnNldFJlcXVlc3RIZWFkZXIoa2V5LCB2YWwpO1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gQWRkIHdpdGhDcmVkZW50aWFscyB0byByZXF1ZXN0IGlmIG5lZWRlZFxuICAgIGlmICghdXRpbHMuaXNVbmRlZmluZWQoY29uZmlnLndpdGhDcmVkZW50aWFscykpIHtcbiAgICAgIHJlcXVlc3Qud2l0aENyZWRlbnRpYWxzID0gISFjb25maWcud2l0aENyZWRlbnRpYWxzO1xuICAgIH1cblxuICAgIC8vIEFkZCByZXNwb25zZVR5cGUgdG8gcmVxdWVzdCBpZiBuZWVkZWRcbiAgICBpZiAocmVzcG9uc2VUeXBlICYmIHJlc3BvbnNlVHlwZSAhPT0gJ2pzb24nKSB7XG4gICAgICByZXF1ZXN0LnJlc3BvbnNlVHlwZSA9IGNvbmZpZy5yZXNwb25zZVR5cGU7XG4gICAgfVxuXG4gICAgLy8gSGFuZGxlIHByb2dyZXNzIGlmIG5lZWRlZFxuICAgIGlmICh0eXBlb2YgY29uZmlnLm9uRG93bmxvYWRQcm9ncmVzcyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgcmVxdWVzdC5hZGRFdmVudExpc3RlbmVyKCdwcm9ncmVzcycsIHByb2dyZXNzRXZlbnRSZWR1Y2VyKGNvbmZpZy5vbkRvd25sb2FkUHJvZ3Jlc3MsIHRydWUpKTtcbiAgICB9XG5cbiAgICAvLyBOb3QgYWxsIGJyb3dzZXJzIHN1cHBvcnQgdXBsb2FkIGV2ZW50c1xuICAgIGlmICh0eXBlb2YgY29uZmlnLm9uVXBsb2FkUHJvZ3Jlc3MgPT09ICdmdW5jdGlvbicgJiYgcmVxdWVzdC51cGxvYWQpIHtcbiAgICAgIHJlcXVlc3QudXBsb2FkLmFkZEV2ZW50TGlzdGVuZXIoJ3Byb2dyZXNzJywgcHJvZ3Jlc3NFdmVudFJlZHVjZXIoY29uZmlnLm9uVXBsb2FkUHJvZ3Jlc3MpKTtcbiAgICB9XG5cbiAgICBpZiAoY29uZmlnLmNhbmNlbFRva2VuIHx8IGNvbmZpZy5zaWduYWwpIHtcbiAgICAgIC8vIEhhbmRsZSBjYW5jZWxsYXRpb25cbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG4gICAgICBvbkNhbmNlbGVkID0gY2FuY2VsID0+IHtcbiAgICAgICAgaWYgKCFyZXF1ZXN0KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHJlamVjdCghY2FuY2VsIHx8IGNhbmNlbC50eXBlID8gbmV3IENhbmNlbGVkRXJyb3IobnVsbCwgY29uZmlnLCByZXF1ZXN0KSA6IGNhbmNlbCk7XG4gICAgICAgIHJlcXVlc3QuYWJvcnQoKTtcbiAgICAgICAgcmVxdWVzdCA9IG51bGw7XG4gICAgICB9O1xuXG4gICAgICBjb25maWcuY2FuY2VsVG9rZW4gJiYgY29uZmlnLmNhbmNlbFRva2VuLnN1YnNjcmliZShvbkNhbmNlbGVkKTtcbiAgICAgIGlmIChjb25maWcuc2lnbmFsKSB7XG4gICAgICAgIGNvbmZpZy5zaWduYWwuYWJvcnRlZCA/IG9uQ2FuY2VsZWQoKSA6IGNvbmZpZy5zaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbkNhbmNlbGVkKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCBwcm90b2NvbCA9IHBhcnNlUHJvdG9jb2woZnVsbFBhdGgpO1xuXG4gICAgaWYgKHByb3RvY29sICYmIHBsYXRmb3JtLnByb3RvY29scy5pbmRleE9mKHByb3RvY29sKSA9PT0gLTEpIHtcbiAgICAgIHJlamVjdChuZXcgQXhpb3NFcnJvcignVW5zdXBwb3J0ZWQgcHJvdG9jb2wgJyArIHByb3RvY29sICsgJzonLCBBeGlvc0Vycm9yLkVSUl9CQURfUkVRVUVTVCwgY29uZmlnKSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG5cbiAgICAvLyBTZW5kIHRoZSByZXF1ZXN0XG4gICAgcmVxdWVzdC5zZW5kKHJlcXVlc3REYXRhIHx8IG51bGwpO1xuICB9KTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IEF4aW9zRXJyb3IgZnJvbSAnLi9BeGlvc0Vycm9yLmpzJztcblxuLyoqXG4gKiBSZXNvbHZlIG9yIHJlamVjdCBhIFByb21pc2UgYmFzZWQgb24gcmVzcG9uc2Ugc3RhdHVzLlxuICpcbiAqIEBwYXJhbSB7RnVuY3Rpb259IHJlc29sdmUgQSBmdW5jdGlvbiB0aGF0IHJlc29sdmVzIHRoZSBwcm9taXNlLlxuICogQHBhcmFtIHtGdW5jdGlvbn0gcmVqZWN0IEEgZnVuY3Rpb24gdGhhdCByZWplY3RzIHRoZSBwcm9taXNlLlxuICogQHBhcmFtIHtvYmplY3R9IHJlc3BvbnNlIFRoZSByZXNwb25zZS5cbiAqXG4gKiBAcmV0dXJucyB7b2JqZWN0fSBUaGUgcmVzcG9uc2UuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIHNldHRsZShyZXNvbHZlLCByZWplY3QsIHJlc3BvbnNlKSB7XG4gIGNvbnN0IHZhbGlkYXRlU3RhdHVzID0gcmVzcG9uc2UuY29uZmlnLnZhbGlkYXRlU3RhdHVzO1xuICBpZiAoIXJlc3BvbnNlLnN0YXR1cyB8fCAhdmFsaWRhdGVTdGF0dXMgfHwgdmFsaWRhdGVTdGF0dXMocmVzcG9uc2Uuc3RhdHVzKSkge1xuICAgIHJlc29sdmUocmVzcG9uc2UpO1xuICB9IGVsc2Uge1xuICAgIHJlamVjdChuZXcgQXhpb3NFcnJvcihcbiAgICAgICdSZXF1ZXN0IGZhaWxlZCB3aXRoIHN0YXR1cyBjb2RlICcgKyByZXNwb25zZS5zdGF0dXMsXG4gICAgICBbQXhpb3NFcnJvci5FUlJfQkFEX1JFUVVFU1QsIEF4aW9zRXJyb3IuRVJSX0JBRF9SRVNQT05TRV1bTWF0aC5mbG9vcihyZXNwb25zZS5zdGF0dXMgLyAxMDApIC0gNF0sXG4gICAgICByZXNwb25zZS5jb25maWcsXG4gICAgICByZXNwb25zZS5yZXF1ZXN0LFxuICAgICAgcmVzcG9uc2VcbiAgICApKTtcbiAgfVxufVxuIiwiaW1wb3J0IHV0aWxzIGZyb20gJy4vLi4vdXRpbHMuanMnO1xuaW1wb3J0IHBsYXRmb3JtIGZyb20gJy4uL3BsYXRmb3JtL2luZGV4LmpzJztcblxuZXhwb3J0IGRlZmF1bHQgcGxhdGZvcm0uaGFzU3RhbmRhcmRCcm93c2VyRW52ID9cblxuICAvLyBTdGFuZGFyZCBicm93c2VyIGVudnMgc3VwcG9ydCBkb2N1bWVudC5jb29raWVcbiAge1xuICAgIHdyaXRlKG5hbWUsIHZhbHVlLCBleHBpcmVzLCBwYXRoLCBkb21haW4sIHNlY3VyZSkge1xuICAgICAgY29uc3QgY29va2llID0gW25hbWUgKyAnPScgKyBlbmNvZGVVUklDb21wb25lbnQodmFsdWUpXTtcblxuICAgICAgdXRpbHMuaXNOdW1iZXIoZXhwaXJlcykgJiYgY29va2llLnB1c2goJ2V4cGlyZXM9JyArIG5ldyBEYXRlKGV4cGlyZXMpLnRvR01UU3RyaW5nKCkpO1xuXG4gICAgICB1dGlscy5pc1N0cmluZyhwYXRoKSAmJiBjb29raWUucHVzaCgncGF0aD0nICsgcGF0aCk7XG5cbiAgICAgIHV0aWxzLmlzU3RyaW5nKGRvbWFpbikgJiYgY29va2llLnB1c2goJ2RvbWFpbj0nICsgZG9tYWluKTtcblxuICAgICAgc2VjdXJlID09PSB0cnVlICYmIGNvb2tpZS5wdXNoKCdzZWN1cmUnKTtcblxuICAgICAgZG9jdW1lbnQuY29va2llID0gY29va2llLmpvaW4oJzsgJyk7XG4gICAgfSxcblxuICAgIHJlYWQobmFtZSkge1xuICAgICAgY29uc3QgbWF0Y2ggPSBkb2N1bWVudC5jb29raWUubWF0Y2gobmV3IFJlZ0V4cCgnKF58O1xcXFxzKikoJyArIG5hbWUgKyAnKT0oW147XSopJykpO1xuICAgICAgcmV0dXJuIChtYXRjaCA/IGRlY29kZVVSSUNvbXBvbmVudChtYXRjaFszXSkgOiBudWxsKTtcbiAgICB9LFxuXG4gICAgcmVtb3ZlKG5hbWUpIHtcbiAgICAgIHRoaXMud3JpdGUobmFtZSwgJycsIERhdGUubm93KCkgLSA4NjQwMDAwMCk7XG4gICAgfVxuICB9XG5cbiAgOlxuXG4gIC8vIE5vbi1zdGFuZGFyZCBicm93c2VyIGVudiAod2ViIHdvcmtlcnMsIHJlYWN0LW5hdGl2ZSkgbGFjayBuZWVkZWQgc3VwcG9ydC5cbiAge1xuICAgIHdyaXRlKCkge30sXG4gICAgcmVhZCgpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH0sXG4gICAgcmVtb3ZlKCkge31cbiAgfTtcblxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQgaXNBYnNvbHV0ZVVSTCBmcm9tICcuLi9oZWxwZXJzL2lzQWJzb2x1dGVVUkwuanMnO1xuaW1wb3J0IGNvbWJpbmVVUkxzIGZyb20gJy4uL2hlbHBlcnMvY29tYmluZVVSTHMuanMnO1xuXG4vKipcbiAqIENyZWF0ZXMgYSBuZXcgVVJMIGJ5IGNvbWJpbmluZyB0aGUgYmFzZVVSTCB3aXRoIHRoZSByZXF1ZXN0ZWRVUkwsXG4gKiBvbmx5IHdoZW4gdGhlIHJlcXVlc3RlZFVSTCBpcyBub3QgYWxyZWFkeSBhbiBhYnNvbHV0ZSBVUkwuXG4gKiBJZiB0aGUgcmVxdWVzdFVSTCBpcyBhYnNvbHV0ZSwgdGhpcyBmdW5jdGlvbiByZXR1cm5zIHRoZSByZXF1ZXN0ZWRVUkwgdW50b3VjaGVkLlxuICpcbiAqIEBwYXJhbSB7c3RyaW5nfSBiYXNlVVJMIFRoZSBiYXNlIFVSTFxuICogQHBhcmFtIHtzdHJpbmd9IHJlcXVlc3RlZFVSTCBBYnNvbHV0ZSBvciByZWxhdGl2ZSBVUkwgdG8gY29tYmluZVxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBjb21iaW5lZCBmdWxsIHBhdGhcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gYnVpbGRGdWxsUGF0aChiYXNlVVJMLCByZXF1ZXN0ZWRVUkwpIHtcbiAgaWYgKGJhc2VVUkwgJiYgIWlzQWJzb2x1dGVVUkwocmVxdWVzdGVkVVJMKSkge1xuICAgIHJldHVybiBjb21iaW5lVVJMcyhiYXNlVVJMLCByZXF1ZXN0ZWRVUkwpO1xuICB9XG4gIHJldHVybiByZXF1ZXN0ZWRVUkw7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbi8qKlxuICogRGV0ZXJtaW5lcyB3aGV0aGVyIHRoZSBzcGVjaWZpZWQgVVJMIGlzIGFic29sdXRlXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IHVybCBUaGUgVVJMIHRvIHRlc3RcbiAqXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB0aGUgc3BlY2lmaWVkIFVSTCBpcyBhYnNvbHV0ZSwgb3RoZXJ3aXNlIGZhbHNlXG4gKi9cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGlzQWJzb2x1dGVVUkwodXJsKSB7XG4gIC8vIEEgVVJMIGlzIGNvbnNpZGVyZWQgYWJzb2x1dGUgaWYgaXQgYmVnaW5zIHdpdGggXCI8c2NoZW1lPjovL1wiIG9yIFwiLy9cIiAocHJvdG9jb2wtcmVsYXRpdmUgVVJMKS5cbiAgLy8gUkZDIDM5ODYgZGVmaW5lcyBzY2hlbWUgbmFtZSBhcyBhIHNlcXVlbmNlIG9mIGNoYXJhY3RlcnMgYmVnaW5uaW5nIHdpdGggYSBsZXR0ZXIgYW5kIGZvbGxvd2VkXG4gIC8vIGJ5IGFueSBjb21iaW5hdGlvbiBvZiBsZXR0ZXJzLCBkaWdpdHMsIHBsdXMsIHBlcmlvZCwgb3IgaHlwaGVuLlxuICByZXR1cm4gL14oW2Etel1bYS16XFxkK1xcLS5dKjopP1xcL1xcLy9pLnRlc3QodXJsKTtcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IFVSTCBieSBjb21iaW5pbmcgdGhlIHNwZWNpZmllZCBVUkxzXG4gKlxuICogQHBhcmFtIHtzdHJpbmd9IGJhc2VVUkwgVGhlIGJhc2UgVVJMXG4gKiBAcGFyYW0ge3N0cmluZ30gcmVsYXRpdmVVUkwgVGhlIHJlbGF0aXZlIFVSTFxuICpcbiAqIEByZXR1cm5zIHtzdHJpbmd9IFRoZSBjb21iaW5lZCBVUkxcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gY29tYmluZVVSTHMoYmFzZVVSTCwgcmVsYXRpdmVVUkwpIHtcbiAgcmV0dXJuIHJlbGF0aXZlVVJMXG4gICAgPyBiYXNlVVJMLnJlcGxhY2UoL1xcLz9cXC8kLywgJycpICsgJy8nICsgcmVsYXRpdmVVUkwucmVwbGFjZSgvXlxcLysvLCAnJylcbiAgICA6IGJhc2VVUkw7XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLy4uL3V0aWxzLmpzJztcbmltcG9ydCBwbGF0Zm9ybSBmcm9tICcuLi9wbGF0Zm9ybS9pbmRleC5qcyc7XG5cbmV4cG9ydCBkZWZhdWx0IHBsYXRmb3JtLmhhc1N0YW5kYXJkQnJvd3NlckVudiA/XG5cbi8vIFN0YW5kYXJkIGJyb3dzZXIgZW52cyBoYXZlIGZ1bGwgc3VwcG9ydCBvZiB0aGUgQVBJcyBuZWVkZWQgdG8gdGVzdFxuLy8gd2hldGhlciB0aGUgcmVxdWVzdCBVUkwgaXMgb2YgdGhlIHNhbWUgb3JpZ2luIGFzIGN1cnJlbnQgbG9jYXRpb24uXG4gIChmdW5jdGlvbiBzdGFuZGFyZEJyb3dzZXJFbnYoKSB7XG4gICAgY29uc3QgbXNpZSA9IC8obXNpZXx0cmlkZW50KS9pLnRlc3QobmF2aWdhdG9yLnVzZXJBZ2VudCk7XG4gICAgY29uc3QgdXJsUGFyc2luZ05vZGUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgbGV0IG9yaWdpblVSTDtcblxuICAgIC8qKlxuICAgICogUGFyc2UgYSBVUkwgdG8gZGlzY292ZXIgaXRzIGNvbXBvbmVudHNcbiAgICAqXG4gICAgKiBAcGFyYW0ge1N0cmluZ30gdXJsIFRoZSBVUkwgdG8gYmUgcGFyc2VkXG4gICAgKiBAcmV0dXJucyB7T2JqZWN0fVxuICAgICovXG4gICAgZnVuY3Rpb24gcmVzb2x2ZVVSTCh1cmwpIHtcbiAgICAgIGxldCBocmVmID0gdXJsO1xuXG4gICAgICBpZiAobXNpZSkge1xuICAgICAgICAvLyBJRSBuZWVkcyBhdHRyaWJ1dGUgc2V0IHR3aWNlIHRvIG5vcm1hbGl6ZSBwcm9wZXJ0aWVzXG4gICAgICAgIHVybFBhcnNpbmdOb2RlLnNldEF0dHJpYnV0ZSgnaHJlZicsIGhyZWYpO1xuICAgICAgICBocmVmID0gdXJsUGFyc2luZ05vZGUuaHJlZjtcbiAgICAgIH1cblxuICAgICAgdXJsUGFyc2luZ05vZGUuc2V0QXR0cmlidXRlKCdocmVmJywgaHJlZik7XG5cbiAgICAgIC8vIHVybFBhcnNpbmdOb2RlIHByb3ZpZGVzIHRoZSBVcmxVdGlscyBpbnRlcmZhY2UgLSBodHRwOi8vdXJsLnNwZWMud2hhdHdnLm9yZy8jdXJsdXRpbHNcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGhyZWY6IHVybFBhcnNpbmdOb2RlLmhyZWYsXG4gICAgICAgIHByb3RvY29sOiB1cmxQYXJzaW5nTm9kZS5wcm90b2NvbCA/IHVybFBhcnNpbmdOb2RlLnByb3RvY29sLnJlcGxhY2UoLzokLywgJycpIDogJycsXG4gICAgICAgIGhvc3Q6IHVybFBhcnNpbmdOb2RlLmhvc3QsXG4gICAgICAgIHNlYXJjaDogdXJsUGFyc2luZ05vZGUuc2VhcmNoID8gdXJsUGFyc2luZ05vZGUuc2VhcmNoLnJlcGxhY2UoL15cXD8vLCAnJykgOiAnJyxcbiAgICAgICAgaGFzaDogdXJsUGFyc2luZ05vZGUuaGFzaCA/IHVybFBhcnNpbmdOb2RlLmhhc2gucmVwbGFjZSgvXiMvLCAnJykgOiAnJyxcbiAgICAgICAgaG9zdG5hbWU6IHVybFBhcnNpbmdOb2RlLmhvc3RuYW1lLFxuICAgICAgICBwb3J0OiB1cmxQYXJzaW5nTm9kZS5wb3J0LFxuICAgICAgICBwYXRobmFtZTogKHVybFBhcnNpbmdOb2RlLnBhdGhuYW1lLmNoYXJBdCgwKSA9PT0gJy8nKSA/XG4gICAgICAgICAgdXJsUGFyc2luZ05vZGUucGF0aG5hbWUgOlxuICAgICAgICAgICcvJyArIHVybFBhcnNpbmdOb2RlLnBhdGhuYW1lXG4gICAgICB9O1xuICAgIH1cblxuICAgIG9yaWdpblVSTCA9IHJlc29sdmVVUkwod2luZG93LmxvY2F0aW9uLmhyZWYpO1xuXG4gICAgLyoqXG4gICAgKiBEZXRlcm1pbmUgaWYgYSBVUkwgc2hhcmVzIHRoZSBzYW1lIG9yaWdpbiBhcyB0aGUgY3VycmVudCBsb2NhdGlvblxuICAgICpcbiAgICAqIEBwYXJhbSB7U3RyaW5nfSByZXF1ZXN0VVJMIFRoZSBVUkwgdG8gdGVzdFxuICAgICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgVVJMIHNoYXJlcyB0aGUgc2FtZSBvcmlnaW4sIG90aGVyd2lzZSBmYWxzZVxuICAgICovXG4gICAgcmV0dXJuIGZ1bmN0aW9uIGlzVVJMU2FtZU9yaWdpbihyZXF1ZXN0VVJMKSB7XG4gICAgICBjb25zdCBwYXJzZWQgPSAodXRpbHMuaXNTdHJpbmcocmVxdWVzdFVSTCkpID8gcmVzb2x2ZVVSTChyZXF1ZXN0VVJMKSA6IHJlcXVlc3RVUkw7XG4gICAgICByZXR1cm4gKHBhcnNlZC5wcm90b2NvbCA9PT0gb3JpZ2luVVJMLnByb3RvY29sICYmXG4gICAgICAgICAgcGFyc2VkLmhvc3QgPT09IG9yaWdpblVSTC5ob3N0KTtcbiAgICB9O1xuICB9KSgpIDpcblxuICAvLyBOb24gc3RhbmRhcmQgYnJvd3NlciBlbnZzICh3ZWIgd29ya2VycywgcmVhY3QtbmF0aXZlKSBsYWNrIG5lZWRlZCBzdXBwb3J0LlxuICAoZnVuY3Rpb24gbm9uU3RhbmRhcmRCcm93c2VyRW52KCkge1xuICAgIHJldHVybiBmdW5jdGlvbiBpc1VSTFNhbWVPcmlnaW4oKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9O1xuICB9KSgpO1xuIiwiJ3VzZSBzdHJpY3QnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBwYXJzZVByb3RvY29sKHVybCkge1xuICBjb25zdCBtYXRjaCA9IC9eKFstK1xcd117MSwyNX0pKDo/XFwvXFwvfDopLy5leGVjKHVybCk7XG4gIHJldHVybiBtYXRjaCAmJiBtYXRjaFsxXSB8fCAnJztcbn1cbiIsIid1c2Ugc3RyaWN0JztcblxuLyoqXG4gKiBDYWxjdWxhdGUgZGF0YSBtYXhSYXRlXG4gKiBAcGFyYW0ge051bWJlcn0gW3NhbXBsZXNDb3VudD0gMTBdXG4gKiBAcGFyYW0ge051bWJlcn0gW21pbj0gMTAwMF1cbiAqIEByZXR1cm5zIHtGdW5jdGlvbn1cbiAqL1xuZnVuY3Rpb24gc3BlZWRvbWV0ZXIoc2FtcGxlc0NvdW50LCBtaW4pIHtcbiAgc2FtcGxlc0NvdW50ID0gc2FtcGxlc0NvdW50IHx8IDEwO1xuICBjb25zdCBieXRlcyA9IG5ldyBBcnJheShzYW1wbGVzQ291bnQpO1xuICBjb25zdCB0aW1lc3RhbXBzID0gbmV3IEFycmF5KHNhbXBsZXNDb3VudCk7XG4gIGxldCBoZWFkID0gMDtcbiAgbGV0IHRhaWwgPSAwO1xuICBsZXQgZmlyc3RTYW1wbGVUUztcblxuICBtaW4gPSBtaW4gIT09IHVuZGVmaW5lZCA/IG1pbiA6IDEwMDA7XG5cbiAgcmV0dXJuIGZ1bmN0aW9uIHB1c2goY2h1bmtMZW5ndGgpIHtcbiAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuXG4gICAgY29uc3Qgc3RhcnRlZEF0ID0gdGltZXN0YW1wc1t0YWlsXTtcblxuICAgIGlmICghZmlyc3RTYW1wbGVUUykge1xuICAgICAgZmlyc3RTYW1wbGVUUyA9IG5vdztcbiAgICB9XG5cbiAgICBieXRlc1toZWFkXSA9IGNodW5rTGVuZ3RoO1xuICAgIHRpbWVzdGFtcHNbaGVhZF0gPSBub3c7XG5cbiAgICBsZXQgaSA9IHRhaWw7XG4gICAgbGV0IGJ5dGVzQ291bnQgPSAwO1xuXG4gICAgd2hpbGUgKGkgIT09IGhlYWQpIHtcbiAgICAgIGJ5dGVzQ291bnQgKz0gYnl0ZXNbaSsrXTtcbiAgICAgIGkgPSBpICUgc2FtcGxlc0NvdW50O1xuICAgIH1cblxuICAgIGhlYWQgPSAoaGVhZCArIDEpICUgc2FtcGxlc0NvdW50O1xuXG4gICAgaWYgKGhlYWQgPT09IHRhaWwpIHtcbiAgICAgIHRhaWwgPSAodGFpbCArIDEpICUgc2FtcGxlc0NvdW50O1xuICAgIH1cblxuICAgIGlmIChub3cgLSBmaXJzdFNhbXBsZVRTIDwgbWluKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgcGFzc2VkID0gc3RhcnRlZEF0ICYmIG5vdyAtIHN0YXJ0ZWRBdDtcblxuICAgIHJldHVybiBwYXNzZWQgPyBNYXRoLnJvdW5kKGJ5dGVzQ291bnQgKiAxMDAwIC8gcGFzc2VkKSA6IHVuZGVmaW5lZDtcbiAgfTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgc3BlZWRvbWV0ZXI7XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLi91dGlscy5qcyc7XG5pbXBvcnQgQXhpb3NIZWFkZXJzIGZyb20gXCIuL0F4aW9zSGVhZGVycy5qc1wiO1xuXG5jb25zdCBoZWFkZXJzVG9PYmplY3QgPSAodGhpbmcpID0+IHRoaW5nIGluc3RhbmNlb2YgQXhpb3NIZWFkZXJzID8geyAuLi50aGluZyB9IDogdGhpbmc7XG5cbi8qKlxuICogQ29uZmlnLXNwZWNpZmljIG1lcmdlLWZ1bmN0aW9uIHdoaWNoIGNyZWF0ZXMgYSBuZXcgY29uZmlnLW9iamVjdFxuICogYnkgbWVyZ2luZyB0d28gY29uZmlndXJhdGlvbiBvYmplY3RzIHRvZ2V0aGVyLlxuICpcbiAqIEBwYXJhbSB7T2JqZWN0fSBjb25maWcxXG4gKiBAcGFyYW0ge09iamVjdH0gY29uZmlnMlxuICpcbiAqIEByZXR1cm5zIHtPYmplY3R9IE5ldyBvYmplY3QgcmVzdWx0aW5nIGZyb20gbWVyZ2luZyBjb25maWcyIHRvIGNvbmZpZzFcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gbWVyZ2VDb25maWcoY29uZmlnMSwgY29uZmlnMikge1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcGFyYW0tcmVhc3NpZ25cbiAgY29uZmlnMiA9IGNvbmZpZzIgfHwge307XG4gIGNvbnN0IGNvbmZpZyA9IHt9O1xuXG4gIGZ1bmN0aW9uIGdldE1lcmdlZFZhbHVlKHRhcmdldCwgc291cmNlLCBjYXNlbGVzcykge1xuICAgIGlmICh1dGlscy5pc1BsYWluT2JqZWN0KHRhcmdldCkgJiYgdXRpbHMuaXNQbGFpbk9iamVjdChzb3VyY2UpKSB7XG4gICAgICByZXR1cm4gdXRpbHMubWVyZ2UuY2FsbCh7Y2FzZWxlc3N9LCB0YXJnZXQsIHNvdXJjZSk7XG4gICAgfSBlbHNlIGlmICh1dGlscy5pc1BsYWluT2JqZWN0KHNvdXJjZSkpIHtcbiAgICAgIHJldHVybiB1dGlscy5tZXJnZSh7fSwgc291cmNlKTtcbiAgICB9IGVsc2UgaWYgKHV0aWxzLmlzQXJyYXkoc291cmNlKSkge1xuICAgICAgcmV0dXJuIHNvdXJjZS5zbGljZSgpO1xuICAgIH1cbiAgICByZXR1cm4gc291cmNlO1xuICB9XG5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGNvbnNpc3RlbnQtcmV0dXJuXG4gIGZ1bmN0aW9uIG1lcmdlRGVlcFByb3BlcnRpZXMoYSwgYiwgY2FzZWxlc3MpIHtcbiAgICBpZiAoIXV0aWxzLmlzVW5kZWZpbmVkKGIpKSB7XG4gICAgICByZXR1cm4gZ2V0TWVyZ2VkVmFsdWUoYSwgYiwgY2FzZWxlc3MpO1xuICAgIH0gZWxzZSBpZiAoIXV0aWxzLmlzVW5kZWZpbmVkKGEpKSB7XG4gICAgICByZXR1cm4gZ2V0TWVyZ2VkVmFsdWUodW5kZWZpbmVkLCBhLCBjYXNlbGVzcyk7XG4gICAgfVxuICB9XG5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGNvbnNpc3RlbnQtcmV0dXJuXG4gIGZ1bmN0aW9uIHZhbHVlRnJvbUNvbmZpZzIoYSwgYikge1xuICAgIGlmICghdXRpbHMuaXNVbmRlZmluZWQoYikpIHtcbiAgICAgIHJldHVybiBnZXRNZXJnZWRWYWx1ZSh1bmRlZmluZWQsIGIpO1xuICAgIH1cbiAgfVxuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXJldHVyblxuICBmdW5jdGlvbiBkZWZhdWx0VG9Db25maWcyKGEsIGIpIHtcbiAgICBpZiAoIXV0aWxzLmlzVW5kZWZpbmVkKGIpKSB7XG4gICAgICByZXR1cm4gZ2V0TWVyZ2VkVmFsdWUodW5kZWZpbmVkLCBiKTtcbiAgICB9IGVsc2UgaWYgKCF1dGlscy5pc1VuZGVmaW5lZChhKSkge1xuICAgICAgcmV0dXJuIGdldE1lcmdlZFZhbHVlKHVuZGVmaW5lZCwgYSk7XG4gICAgfVxuICB9XG5cbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGNvbnNpc3RlbnQtcmV0dXJuXG4gIGZ1bmN0aW9uIG1lcmdlRGlyZWN0S2V5cyhhLCBiLCBwcm9wKSB7XG4gICAgaWYgKHByb3AgaW4gY29uZmlnMikge1xuICAgICAgcmV0dXJuIGdldE1lcmdlZFZhbHVlKGEsIGIpO1xuICAgIH0gZWxzZSBpZiAocHJvcCBpbiBjb25maWcxKSB7XG4gICAgICByZXR1cm4gZ2V0TWVyZ2VkVmFsdWUodW5kZWZpbmVkLCBhKTtcbiAgICB9XG4gIH1cblxuICBjb25zdCBtZXJnZU1hcCA9IHtcbiAgICB1cmw6IHZhbHVlRnJvbUNvbmZpZzIsXG4gICAgbWV0aG9kOiB2YWx1ZUZyb21Db25maWcyLFxuICAgIGRhdGE6IHZhbHVlRnJvbUNvbmZpZzIsXG4gICAgYmFzZVVSTDogZGVmYXVsdFRvQ29uZmlnMixcbiAgICB0cmFuc2Zvcm1SZXF1ZXN0OiBkZWZhdWx0VG9Db25maWcyLFxuICAgIHRyYW5zZm9ybVJlc3BvbnNlOiBkZWZhdWx0VG9Db25maWcyLFxuICAgIHBhcmFtc1NlcmlhbGl6ZXI6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgdGltZW91dDogZGVmYXVsdFRvQ29uZmlnMixcbiAgICB0aW1lb3V0TWVzc2FnZTogZGVmYXVsdFRvQ29uZmlnMixcbiAgICB3aXRoQ3JlZGVudGlhbHM6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgd2l0aFhTUkZUb2tlbjogZGVmYXVsdFRvQ29uZmlnMixcbiAgICBhZGFwdGVyOiBkZWZhdWx0VG9Db25maWcyLFxuICAgIHJlc3BvbnNlVHlwZTogZGVmYXVsdFRvQ29uZmlnMixcbiAgICB4c3JmQ29va2llTmFtZTogZGVmYXVsdFRvQ29uZmlnMixcbiAgICB4c3JmSGVhZGVyTmFtZTogZGVmYXVsdFRvQ29uZmlnMixcbiAgICBvblVwbG9hZFByb2dyZXNzOiBkZWZhdWx0VG9Db25maWcyLFxuICAgIG9uRG93bmxvYWRQcm9ncmVzczogZGVmYXVsdFRvQ29uZmlnMixcbiAgICBkZWNvbXByZXNzOiBkZWZhdWx0VG9Db25maWcyLFxuICAgIG1heENvbnRlbnRMZW5ndGg6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgbWF4Qm9keUxlbmd0aDogZGVmYXVsdFRvQ29uZmlnMixcbiAgICBiZWZvcmVSZWRpcmVjdDogZGVmYXVsdFRvQ29uZmlnMixcbiAgICB0cmFuc3BvcnQ6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgaHR0cEFnZW50OiBkZWZhdWx0VG9Db25maWcyLFxuICAgIGh0dHBzQWdlbnQ6IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgY2FuY2VsVG9rZW46IGRlZmF1bHRUb0NvbmZpZzIsXG4gICAgc29ja2V0UGF0aDogZGVmYXVsdFRvQ29uZmlnMixcbiAgICByZXNwb25zZUVuY29kaW5nOiBkZWZhdWx0VG9Db25maWcyLFxuICAgIHZhbGlkYXRlU3RhdHVzOiBtZXJnZURpcmVjdEtleXMsXG4gICAgaGVhZGVyczogKGEsIGIpID0+IG1lcmdlRGVlcFByb3BlcnRpZXMoaGVhZGVyc1RvT2JqZWN0KGEpLCBoZWFkZXJzVG9PYmplY3QoYiksIHRydWUpXG4gIH07XG5cbiAgdXRpbHMuZm9yRWFjaChPYmplY3Qua2V5cyhPYmplY3QuYXNzaWduKHt9LCBjb25maWcxLCBjb25maWcyKSksIGZ1bmN0aW9uIGNvbXB1dGVDb25maWdWYWx1ZShwcm9wKSB7XG4gICAgY29uc3QgbWVyZ2UgPSBtZXJnZU1hcFtwcm9wXSB8fCBtZXJnZURlZXBQcm9wZXJ0aWVzO1xuICAgIGNvbnN0IGNvbmZpZ1ZhbHVlID0gbWVyZ2UoY29uZmlnMVtwcm9wXSwgY29uZmlnMltwcm9wXSwgcHJvcCk7XG4gICAgKHV0aWxzLmlzVW5kZWZpbmVkKGNvbmZpZ1ZhbHVlKSAmJiBtZXJnZSAhPT0gbWVyZ2VEaXJlY3RLZXlzKSB8fCAoY29uZmlnW3Byb3BdID0gY29uZmlnVmFsdWUpO1xuICB9KTtcblxuICByZXR1cm4gY29uZmlnO1xufVxuIiwiJ3VzZSBzdHJpY3QnO1xuXG5pbXBvcnQge1ZFUlNJT059IGZyb20gJy4uL2Vudi9kYXRhLmpzJztcbmltcG9ydCBBeGlvc0Vycm9yIGZyb20gJy4uL2NvcmUvQXhpb3NFcnJvci5qcyc7XG5cbmNvbnN0IHZhbGlkYXRvcnMgPSB7fTtcblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGZ1bmMtbmFtZXNcblsnb2JqZWN0JywgJ2Jvb2xlYW4nLCAnbnVtYmVyJywgJ2Z1bmN0aW9uJywgJ3N0cmluZycsICdzeW1ib2wnXS5mb3JFYWNoKCh0eXBlLCBpKSA9PiB7XG4gIHZhbGlkYXRvcnNbdHlwZV0gPSBmdW5jdGlvbiB2YWxpZGF0b3IodGhpbmcpIHtcbiAgICByZXR1cm4gdHlwZW9mIHRoaW5nID09PSB0eXBlIHx8ICdhJyArIChpIDwgMSA/ICduICcgOiAnICcpICsgdHlwZTtcbiAgfTtcbn0pO1xuXG5jb25zdCBkZXByZWNhdGVkV2FybmluZ3MgPSB7fTtcblxuLyoqXG4gKiBUcmFuc2l0aW9uYWwgb3B0aW9uIHZhbGlkYXRvclxuICpcbiAqIEBwYXJhbSB7ZnVuY3Rpb258Ym9vbGVhbj99IHZhbGlkYXRvciAtIHNldCB0byBmYWxzZSBpZiB0aGUgdHJhbnNpdGlvbmFsIG9wdGlvbiBoYXMgYmVlbiByZW1vdmVkXG4gKiBAcGFyYW0ge3N0cmluZz99IHZlcnNpb24gLSBkZXByZWNhdGVkIHZlcnNpb24gLyByZW1vdmVkIHNpbmNlIHZlcnNpb25cbiAqIEBwYXJhbSB7c3RyaW5nP30gbWVzc2FnZSAtIHNvbWUgbWVzc2FnZSB3aXRoIGFkZGl0aW9uYWwgaW5mb1xuICpcbiAqIEByZXR1cm5zIHtmdW5jdGlvbn1cbiAqL1xudmFsaWRhdG9ycy50cmFuc2l0aW9uYWwgPSBmdW5jdGlvbiB0cmFuc2l0aW9uYWwodmFsaWRhdG9yLCB2ZXJzaW9uLCBtZXNzYWdlKSB7XG4gIGZ1bmN0aW9uIGZvcm1hdE1lc3NhZ2Uob3B0LCBkZXNjKSB7XG4gICAgcmV0dXJuICdbQXhpb3MgdicgKyBWRVJTSU9OICsgJ10gVHJhbnNpdGlvbmFsIG9wdGlvbiBcXCcnICsgb3B0ICsgJ1xcJycgKyBkZXNjICsgKG1lc3NhZ2UgPyAnLiAnICsgbWVzc2FnZSA6ICcnKTtcbiAgfVxuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG4gIHJldHVybiAodmFsdWUsIG9wdCwgb3B0cykgPT4ge1xuICAgIGlmICh2YWxpZGF0b3IgPT09IGZhbHNlKSB7XG4gICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcihcbiAgICAgICAgZm9ybWF0TWVzc2FnZShvcHQsICcgaGFzIGJlZW4gcmVtb3ZlZCcgKyAodmVyc2lvbiA/ICcgaW4gJyArIHZlcnNpb24gOiAnJykpLFxuICAgICAgICBBeGlvc0Vycm9yLkVSUl9ERVBSRUNBVEVEXG4gICAgICApO1xuICAgIH1cblxuICAgIGlmICh2ZXJzaW9uICYmICFkZXByZWNhdGVkV2FybmluZ3Nbb3B0XSkge1xuICAgICAgZGVwcmVjYXRlZFdhcm5pbmdzW29wdF0gPSB0cnVlO1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnNvbGVcbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgZm9ybWF0TWVzc2FnZShcbiAgICAgICAgICBvcHQsXG4gICAgICAgICAgJyBoYXMgYmVlbiBkZXByZWNhdGVkIHNpbmNlIHYnICsgdmVyc2lvbiArICcgYW5kIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgbmVhciBmdXR1cmUnXG4gICAgICAgIClcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHZhbGlkYXRvciA/IHZhbGlkYXRvcih2YWx1ZSwgb3B0LCBvcHRzKSA6IHRydWU7XG4gIH07XG59O1xuXG4vKipcbiAqIEFzc2VydCBvYmplY3QncyBwcm9wZXJ0aWVzIHR5cGVcbiAqXG4gKiBAcGFyYW0ge29iamVjdH0gb3B0aW9uc1xuICogQHBhcmFtIHtvYmplY3R9IHNjaGVtYVxuICogQHBhcmFtIHtib29sZWFuP30gYWxsb3dVbmtub3duXG4gKlxuICogQHJldHVybnMge29iamVjdH1cbiAqL1xuXG5mdW5jdGlvbiBhc3NlcnRPcHRpb25zKG9wdGlvbnMsIHNjaGVtYSwgYWxsb3dVbmtub3duKSB7XG4gIGlmICh0eXBlb2Ygb3B0aW9ucyAhPT0gJ29iamVjdCcpIHtcbiAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcignb3B0aW9ucyBtdXN0IGJlIGFuIG9iamVjdCcsIEF4aW9zRXJyb3IuRVJSX0JBRF9PUFRJT05fVkFMVUUpO1xuICB9XG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhvcHRpb25zKTtcbiAgbGV0IGkgPSBrZXlzLmxlbmd0aDtcbiAgd2hpbGUgKGktLSA+IDApIHtcbiAgICBjb25zdCBvcHQgPSBrZXlzW2ldO1xuICAgIGNvbnN0IHZhbGlkYXRvciA9IHNjaGVtYVtvcHRdO1xuICAgIGlmICh2YWxpZGF0b3IpIHtcbiAgICAgIGNvbnN0IHZhbHVlID0gb3B0aW9uc1tvcHRdO1xuICAgICAgY29uc3QgcmVzdWx0ID0gdmFsdWUgPT09IHVuZGVmaW5lZCB8fCB2YWxpZGF0b3IodmFsdWUsIG9wdCwgb3B0aW9ucyk7XG4gICAgICBpZiAocmVzdWx0ICE9PSB0cnVlKSB7XG4gICAgICAgIHRocm93IG5ldyBBeGlvc0Vycm9yKCdvcHRpb24gJyArIG9wdCArICcgbXVzdCBiZSAnICsgcmVzdWx0LCBBeGlvc0Vycm9yLkVSUl9CQURfT1BUSU9OX1ZBTFVFKTtcbiAgICAgIH1cbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBpZiAoYWxsb3dVbmtub3duICE9PSB0cnVlKSB7XG4gICAgICB0aHJvdyBuZXcgQXhpb3NFcnJvcignVW5rbm93biBvcHRpb24gJyArIG9wdCwgQXhpb3NFcnJvci5FUlJfQkFEX09QVElPTik7XG4gICAgfVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgYXNzZXJ0T3B0aW9ucyxcbiAgdmFsaWRhdG9yc1xufTtcbiIsImV4cG9ydCBjb25zdCBWRVJTSU9OID0gXCIxLjYuOFwiOyIsIid1c2Ugc3RyaWN0JztcblxuaW1wb3J0IENhbmNlbGVkRXJyb3IgZnJvbSAnLi9DYW5jZWxlZEVycm9yLmpzJztcblxuLyoqXG4gKiBBIGBDYW5jZWxUb2tlbmAgaXMgYW4gb2JqZWN0IHRoYXQgY2FuIGJlIHVzZWQgdG8gcmVxdWVzdCBjYW5jZWxsYXRpb24gb2YgYW4gb3BlcmF0aW9uLlxuICpcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGV4ZWN1dG9yIFRoZSBleGVjdXRvciBmdW5jdGlvbi5cbiAqXG4gKiBAcmV0dXJucyB7Q2FuY2VsVG9rZW59XG4gKi9cbmNsYXNzIENhbmNlbFRva2VuIHtcbiAgY29uc3RydWN0b3IoZXhlY3V0b3IpIHtcbiAgICBpZiAodHlwZW9mIGV4ZWN1dG9yICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdleGVjdXRvciBtdXN0IGJlIGEgZnVuY3Rpb24uJyk7XG4gICAgfVxuXG4gICAgbGV0IHJlc29sdmVQcm9taXNlO1xuXG4gICAgdGhpcy5wcm9taXNlID0gbmV3IFByb21pc2UoZnVuY3Rpb24gcHJvbWlzZUV4ZWN1dG9yKHJlc29sdmUpIHtcbiAgICAgIHJlc29sdmVQcm9taXNlID0gcmVzb2x2ZTtcbiAgICB9KTtcblxuICAgIGNvbnN0IHRva2VuID0gdGhpcztcblxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG4gICAgdGhpcy5wcm9taXNlLnRoZW4oY2FuY2VsID0+IHtcbiAgICAgIGlmICghdG9rZW4uX2xpc3RlbmVycykgcmV0dXJuO1xuXG4gICAgICBsZXQgaSA9IHRva2VuLl9saXN0ZW5lcnMubGVuZ3RoO1xuXG4gICAgICB3aGlsZSAoaS0tID4gMCkge1xuICAgICAgICB0b2tlbi5fbGlzdGVuZXJzW2ldKGNhbmNlbCk7XG4gICAgICB9XG4gICAgICB0b2tlbi5fbGlzdGVuZXJzID0gbnVsbDtcbiAgICB9KTtcblxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG4gICAgdGhpcy5wcm9taXNlLnRoZW4gPSBvbmZ1bGZpbGxlZCA9PiB7XG4gICAgICBsZXQgX3Jlc29sdmU7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuICAgICAgY29uc3QgcHJvbWlzZSA9IG5ldyBQcm9taXNlKHJlc29sdmUgPT4ge1xuICAgICAgICB0b2tlbi5zdWJzY3JpYmUocmVzb2x2ZSk7XG4gICAgICAgIF9yZXNvbHZlID0gcmVzb2x2ZTtcbiAgICAgIH0pLnRoZW4ob25mdWxmaWxsZWQpO1xuXG4gICAgICBwcm9taXNlLmNhbmNlbCA9IGZ1bmN0aW9uIHJlamVjdCgpIHtcbiAgICAgICAgdG9rZW4udW5zdWJzY3JpYmUoX3Jlc29sdmUpO1xuICAgICAgfTtcblxuICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgfTtcblxuICAgIGV4ZWN1dG9yKGZ1bmN0aW9uIGNhbmNlbChtZXNzYWdlLCBjb25maWcsIHJlcXVlc3QpIHtcbiAgICAgIGlmICh0b2tlbi5yZWFzb24pIHtcbiAgICAgICAgLy8gQ2FuY2VsbGF0aW9uIGhhcyBhbHJlYWR5IGJlZW4gcmVxdWVzdGVkXG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgdG9rZW4ucmVhc29uID0gbmV3IENhbmNlbGVkRXJyb3IobWVzc2FnZSwgY29uZmlnLCByZXF1ZXN0KTtcbiAgICAgIHJlc29sdmVQcm9taXNlKHRva2VuLnJlYXNvbik7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogVGhyb3dzIGEgYENhbmNlbGVkRXJyb3JgIGlmIGNhbmNlbGxhdGlvbiBoYXMgYmVlbiByZXF1ZXN0ZWQuXG4gICAqL1xuICB0aHJvd0lmUmVxdWVzdGVkKCkge1xuICAgIGlmICh0aGlzLnJlYXNvbikge1xuICAgICAgdGhyb3cgdGhpcy5yZWFzb247XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFN1YnNjcmliZSB0byB0aGUgY2FuY2VsIHNpZ25hbFxuICAgKi9cblxuICBzdWJzY3JpYmUobGlzdGVuZXIpIHtcbiAgICBpZiAodGhpcy5yZWFzb24pIHtcbiAgICAgIGxpc3RlbmVyKHRoaXMucmVhc29uKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5fbGlzdGVuZXJzKSB7XG4gICAgICB0aGlzLl9saXN0ZW5lcnMucHVzaChsaXN0ZW5lcik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX2xpc3RlbmVycyA9IFtsaXN0ZW5lcl07XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFVuc3Vic2NyaWJlIGZyb20gdGhlIGNhbmNlbCBzaWduYWxcbiAgICovXG5cbiAgdW5zdWJzY3JpYmUobGlzdGVuZXIpIHtcbiAgICBpZiAoIXRoaXMuX2xpc3RlbmVycykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBpbmRleCA9IHRoaXMuX2xpc3RlbmVycy5pbmRleE9mKGxpc3RlbmVyKTtcbiAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICB0aGlzLl9saXN0ZW5lcnMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhbiBvYmplY3QgdGhhdCBjb250YWlucyBhIG5ldyBgQ2FuY2VsVG9rZW5gIGFuZCBhIGZ1bmN0aW9uIHRoYXQsIHdoZW4gY2FsbGVkLFxuICAgKiBjYW5jZWxzIHRoZSBgQ2FuY2VsVG9rZW5gLlxuICAgKi9cbiAgc3RhdGljIHNvdXJjZSgpIHtcbiAgICBsZXQgY2FuY2VsO1xuICAgIGNvbnN0IHRva2VuID0gbmV3IENhbmNlbFRva2VuKGZ1bmN0aW9uIGV4ZWN1dG9yKGMpIHtcbiAgICAgIGNhbmNlbCA9IGM7XG4gICAgfSk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHRva2VuLFxuICAgICAgY2FuY2VsXG4gICAgfTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBDYW5jZWxUb2tlbjtcbiIsIid1c2Ugc3RyaWN0JztcblxuLyoqXG4gKiBTeW50YWN0aWMgc3VnYXIgZm9yIGludm9raW5nIGEgZnVuY3Rpb24gYW5kIGV4cGFuZGluZyBhbiBhcnJheSBmb3IgYXJndW1lbnRzLlxuICpcbiAqIENvbW1vbiB1c2UgY2FzZSB3b3VsZCBiZSB0byB1c2UgYEZ1bmN0aW9uLnByb3RvdHlwZS5hcHBseWAuXG4gKlxuICogIGBgYGpzXG4gKiAgZnVuY3Rpb24gZih4LCB5LCB6KSB7fVxuICogIHZhciBhcmdzID0gWzEsIDIsIDNdO1xuICogIGYuYXBwbHkobnVsbCwgYXJncyk7XG4gKiAgYGBgXG4gKlxuICogV2l0aCBgc3ByZWFkYCB0aGlzIGV4YW1wbGUgY2FuIGJlIHJlLXdyaXR0ZW4uXG4gKlxuICogIGBgYGpzXG4gKiAgc3ByZWFkKGZ1bmN0aW9uKHgsIHksIHopIHt9KShbMSwgMiwgM10pO1xuICogIGBgYFxuICpcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGNhbGxiYWNrXG4gKlxuICogQHJldHVybnMge0Z1bmN0aW9ufVxuICovXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBzcHJlYWQoY2FsbGJhY2spIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIHdyYXAoYXJyKSB7XG4gICAgcmV0dXJuIGNhbGxiYWNrLmFwcGx5KG51bGwsIGFycik7XG4gIH07XG59XG4iLCIndXNlIHN0cmljdCc7XG5cbmltcG9ydCB1dGlscyBmcm9tICcuLy4uL3V0aWxzLmpzJztcblxuLyoqXG4gKiBEZXRlcm1pbmVzIHdoZXRoZXIgdGhlIHBheWxvYWQgaXMgYW4gZXJyb3IgdGhyb3duIGJ5IEF4aW9zXG4gKlxuICogQHBhcmFtIHsqfSBwYXlsb2FkIFRoZSB2YWx1ZSB0byB0ZXN0XG4gKlxuICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdGhlIHBheWxvYWQgaXMgYW4gZXJyb3IgdGhyb3duIGJ5IEF4aW9zLCBvdGhlcndpc2UgZmFsc2VcbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaXNBeGlvc0Vycm9yKHBheWxvYWQpIHtcbiAgcmV0dXJuIHV0aWxzLmlzT2JqZWN0KHBheWxvYWQpICYmIChwYXlsb2FkLmlzQXhpb3NFcnJvciA9PT0gdHJ1ZSk7XG59XG4iLCJjb25zdCBIdHRwU3RhdHVzQ29kZSA9IHtcbiAgQ29udGludWU6IDEwMCxcbiAgU3dpdGNoaW5nUHJvdG9jb2xzOiAxMDEsXG4gIFByb2Nlc3Npbmc6IDEwMixcbiAgRWFybHlIaW50czogMTAzLFxuICBPazogMjAwLFxuICBDcmVhdGVkOiAyMDEsXG4gIEFjY2VwdGVkOiAyMDIsXG4gIE5vbkF1dGhvcml0YXRpdmVJbmZvcm1hdGlvbjogMjAzLFxuICBOb0NvbnRlbnQ6IDIwNCxcbiAgUmVzZXRDb250ZW50OiAyMDUsXG4gIFBhcnRpYWxDb250ZW50OiAyMDYsXG4gIE11bHRpU3RhdHVzOiAyMDcsXG4gIEFscmVhZHlSZXBvcnRlZDogMjA4LFxuICBJbVVzZWQ6IDIyNixcbiAgTXVsdGlwbGVDaG9pY2VzOiAzMDAsXG4gIE1vdmVkUGVybWFuZW50bHk6IDMwMSxcbiAgRm91bmQ6IDMwMixcbiAgU2VlT3RoZXI6IDMwMyxcbiAgTm90TW9kaWZpZWQ6IDMwNCxcbiAgVXNlUHJveHk6IDMwNSxcbiAgVW51c2VkOiAzMDYsXG4gIFRlbXBvcmFyeVJlZGlyZWN0OiAzMDcsXG4gIFBlcm1hbmVudFJlZGlyZWN0OiAzMDgsXG4gIEJhZFJlcXVlc3Q6IDQwMCxcbiAgVW5hdXRob3JpemVkOiA0MDEsXG4gIFBheW1lbnRSZXF1aXJlZDogNDAyLFxuICBGb3JiaWRkZW46IDQwMyxcbiAgTm90Rm91bmQ6IDQwNCxcbiAgTWV0aG9kTm90QWxsb3dlZDogNDA1LFxuICBOb3RBY2NlcHRhYmxlOiA0MDYsXG4gIFByb3h5QXV0aGVudGljYXRpb25SZXF1aXJlZDogNDA3LFxuICBSZXF1ZXN0VGltZW91dDogNDA4LFxuICBDb25mbGljdDogNDA5LFxuICBHb25lOiA0MTAsXG4gIExlbmd0aFJlcXVpcmVkOiA0MTEsXG4gIFByZWNvbmRpdGlvbkZhaWxlZDogNDEyLFxuICBQYXlsb2FkVG9vTGFyZ2U6IDQxMyxcbiAgVXJpVG9vTG9uZzogNDE0LFxuICBVbnN1cHBvcnRlZE1lZGlhVHlwZTogNDE1LFxuICBSYW5nZU5vdFNhdGlzZmlhYmxlOiA0MTYsXG4gIEV4cGVjdGF0aW9uRmFpbGVkOiA0MTcsXG4gIEltQVRlYXBvdDogNDE4LFxuICBNaXNkaXJlY3RlZFJlcXVlc3Q6IDQyMSxcbiAgVW5wcm9jZXNzYWJsZUVudGl0eTogNDIyLFxuICBMb2NrZWQ6IDQyMyxcbiAgRmFpbGVkRGVwZW5kZW5jeTogNDI0LFxuICBUb29FYXJseTogNDI1LFxuICBVcGdyYWRlUmVxdWlyZWQ6IDQyNixcbiAgUHJlY29uZGl0aW9uUmVxdWlyZWQ6IDQyOCxcbiAgVG9vTWFueVJlcXVlc3RzOiA0MjksXG4gIFJlcXVlc3RIZWFkZXJGaWVsZHNUb29MYXJnZTogNDMxLFxuICBVbmF2YWlsYWJsZUZvckxlZ2FsUmVhc29uczogNDUxLFxuICBJbnRlcm5hbFNlcnZlckVycm9yOiA1MDAsXG4gIE5vdEltcGxlbWVudGVkOiA1MDEsXG4gIEJhZEdhdGV3YXk6IDUwMixcbiAgU2VydmljZVVuYXZhaWxhYmxlOiA1MDMsXG4gIEdhdGV3YXlUaW1lb3V0OiA1MDQsXG4gIEh0dHBWZXJzaW9uTm90U3VwcG9ydGVkOiA1MDUsXG4gIFZhcmlhbnRBbHNvTmVnb3RpYXRlczogNTA2LFxuICBJbnN1ZmZpY2llbnRTdG9yYWdlOiA1MDcsXG4gIExvb3BEZXRlY3RlZDogNTA4LFxuICBOb3RFeHRlbmRlZDogNTEwLFxuICBOZXR3b3JrQXV0aGVudGljYXRpb25SZXF1aXJlZDogNTExLFxufTtcblxuT2JqZWN0LmVudHJpZXMoSHR0cFN0YXR1c0NvZGUpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4ge1xuICBIdHRwU3RhdHVzQ29kZVt2YWx1ZV0gPSBrZXk7XG59KTtcblxuZXhwb3J0IGRlZmF1bHQgSHR0cFN0YXR1c0NvZGU7XG4iXSwibmFtZXMiOltdLCJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5IQVNIX1JFRl8yM2FlNTNhNWU0ZDFlZDRhLmpzLm1hcCJ9
